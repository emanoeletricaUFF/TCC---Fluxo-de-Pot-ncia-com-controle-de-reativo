import numpy as np
import math
import csv
import glob
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from matplotlib.widgets import Button
import mplcursors 
import re
import os
from matplotlib.widgets import TextBox
import matplotlib.gridspec as gridspec




''' ------------------------------------------------------------------------------------------------ '''
''' ------------------------------ ESTUDO DE FLUXO (CARREGAMENTO DO CDF) --------------------------- '''
''' ------------------------------------------------------------------------------------------------ '''

def GoS_generator_FluxoInicial (SYSname, MODELin, Tolerancia, HabiltAval_Lim_Reativo, S_base, Desabilitar_CS, Tipo_de_logicaSuplementar, ComutacaoMaxima, Ativar_inverter, GirarTrafo):
    ''' INICIALIZAÇÃO '''
    status_program='CDF' #---MANUAL or CDF (DADOS DE BARRA)
    alterar_tensao_decontrole_doCDF='X' #---X, A or B 
    ([matrizSystem],[matrizSystem2])=Ler_Arquivo(SYSname)
    # for auxiliar_corrigeMS in range(len(matrizSystem)):
    #     matrizSystem[auxiliar_corrigeMS][18]=(-1)*matrizSystem[auxiliar_corrigeMS][18] ## IEEE30 or IEEE118 (linha em T)
    matrizSystem2 = corrige_duplicidadeDeLinha(matrizSystem2)
    ([matriz_DadosBarra],[infoVctrl])=DefineMatrizDadosBarra(matrizSystem, S_base, HabiltAval_Lim_Reativo, status_program, MODELin, None, alterar_tensao_decontrole_doCDF)
    (infoVctrl, matriz_DadosBarra)=liga_desliga_CS(matrizSystem, status_program, MODELin, None , alterar_tensao_decontrole_doCDF, S_base, HabiltAval_Lim_Reativo, Desabilitar_CS, matriz_DadosBarra, infoVctrl)
    ATIVA_ESPEC=extrair_potencias_negativas(matrizSystem)
    PVbarIndex, _, _, _, _, _, _, _, _ = extrair_vetores_da_matrizSystem(matrizSystem)

    modelagem_linha = MODELin # Tipo de modelo da linha (PI ou T)
    matrizSystem, matrizSystem2, modelagem_resultante = alterar_matrizes(matrizSystem, matrizSystem2, modelagem_linha)
    MatrizY=calcularMATRIZ_Y(matrizSystem, matrizSystem2, Ativar_inverter, GirarTrafo)        
    #Tolerancia=0.01
    #print('PVbarIndex=',PVbarIndex)
    
    #matriz_DadosBarra[1]= [0.0, -0.217, -0.9420000000000001, -0.478, -0.076, -0.11199999999999999, 0.0, 0.0, -0.53, -0.18, -0.035, -0.055, -0.135, -0.298]
    #matriz_DadosBarra[1]= [0.0, -0.217, -0.9420000000000001, -0.478, -0.076, -0.11199999999999999, 0.0, 0.0, -0.57, -0.18, -0.035, -0.055, -0.135, -0.298]
    #matriz_DadosBarra[1]= [0.0, -0.217, -0.9420000000000001, -0.478, -0.076, -0.11199999999999999, 0.0, 0.0, -0.58, -0.18, -0.035, -0.055, -0.135, -0.298]
    #matriz_DadosBarra[1]= [0.0, -0.217, -0.9420000000000001, -0.478, -0.076, -0.11199999999999999, 0.0, 0.0, -0.59, -0.18, -0.035, -0.061, -0.135, -0.298]
    """matriz_DadosBarra[1] = [0.0, -0.217, -0.9420000000000001, -0.478, -0.076, -0.11199999999999999, 0.0, 0.0, -0.59, -0.18, -0.035, -0.061, -0.135, -0.298]"""
    #matriz_DadosBarra[1]= [0.0, -0.217, -0.9420000000000001, -0.478, -0.076, -0.11199999999999999, 0.0, 0.0, -0.59, -0.18, -0.035, -0.061, -0.135, -0.298]
    #matriz_DadosBarra[1]= [0.0, -0.217, -0.9420000000000001, -0.478, -0.076, -0.11199999999999999, 0.0, 0.0, -0.60, -0.18, -0.035, -0.055, -0.135, -0.298]
    #matriz_DadosBarra[1]= [0.0, -0.217, -0.9420000000000001, -0.478, -0.076, -0.11199999999999999, 0.0, 0.0, -0.65, -0.18, -0.035, -0.055, -0.135, -0.298]
    


    """matriz_DadosBarra[1]=[0.0, -21.7, -94.2, -47.8, -7.6, -11.2, 0.0, 0.0, -29.5, -9.04, -3.5, -6.1, -13.5, -14.9]"""
    
    #AUX=[0.0, -21.7, -94.2, -47.8, -7.6, -11.2, 0.0, 0.0, -29.520000000000003, -9.0, -3.5199999999999996, -6.519999999999999, -13.5, -14.9]
    #AUX=[0.0, -21.7, -94.2, -47.8, -7.6, -11.2, 0.0, 0.0, -29.5, -9.25, -3.5, -6.1, -13.5, -14.9]
    # for varreAUX in range(len(AUX)):
    #     AUX[varreAUX]=AUX[varreAUX]/S_base

    # matriz_DadosBarra[1]=AUX


    # AUX=[0.0, -21.7, -94.2, -47.8, -7.6, -11.2, 0.0, 0.0, -25.214, -9.00, -3.5, -6.1, -13.5, -14.9]
    # for varreAUX in range(len(AUX)):
    #     AUX[varreAUX]=AUX[varreAUX]/S_base

    # matriz_DadosBarra[1]=AUX



    ''' NEWTON COMPLETO '''
    Fluxo_divergente_0='no'
    try:
        (DeltaV, Delta0, PotP, PotQ, _, _, cont, MATRIZ_Y, Barras_PQ, JACOBIANA_INICIAL, JACOBIANA_FINAL, BarraQViola_estatica,_, _, _, _, _, _, _, _, _, _, VerificaSeViola,  EvolutionMatrixVECTORS, EvolutionMatrixVECTORS2, EvolutionMatrixMatriz2)=CHAMA_FLNR_03_LTT (matrizSystem,matrizSystem2,matriz_DadosBarra,infoVctrl,MODELin,Tolerancia,'no', None, None, None, None, None, None, None, None, 'no', None, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY)
    
        DeltaV=[float(x) for x in DeltaV]
        Delta0=[float(x) for x in Delta0]
        PotP=[float(x) for x in PotP]
        PotQ=[float(x) for x in PotQ]
        
    except Exception as e:
        Fluxo_divergente_0='yes' 
        Observation='FLUXO INICIAL DIVERGENTE. CONFERIR ARQUIVO CDF.'
        DeltaV=[0]*len(ATIVA_ESPEC)  
        Delta0=[0]*len(ATIVA_ESPEC) 
        PotP=[0]*len(ATIVA_ESPEC)
        PotQ=[0]*len(ATIVA_ESPEC)
        Barras_PQ= ['FLUXO DIVERGENTE']*len(ATIVA_ESPEC)
        cont=0  
        JACOBIANA_FINAL=[] 
        JACOBIANA_INICIAL=[]
        MATRIZ_Y=[]
        stringQauntidadeQViolaInical='FLUXO DIVERGENTE!'
        stingBarraQViola_estatica='FLUXO DIVERGENTE!'
        #print('FLUXO DIVERGENTE EM REGIME DE CARGA INICIAL')



    if Fluxo_divergente_0=='no':
        """ ARRUMAR DADOS """
        (DeltaV, Delta0, PotP, PotQ, Barras_PQ, BarraQViola_estatica)=arrumar_DadosDeModelagem_LinhaPItoT(DeltaV, Delta0, PotP, PotQ, Barras_PQ, BarraQViola_estatica, matrizSystem, MODELin)
        (JACOBIANA_INICIAL, JACOBIANA_FINAL)=limpa_jacobs(JACOBIANA_INICIAL, JACOBIANA_FINAL) 
        
        # for aux in range(len(DeltaV)):
        #     DeltaV
        
        # Criar strings de concatenados valores não nulos
        stingBarraQViola_estatica = "_".join(str(x) for x in BarraQViola_estatica if x != 0)
        non_zero_estatica = sum(1 for x in BarraQViola_estatica if x != 0)
        non_zero_pvbar = sum(1 for x in PVbarIndex if x != 0)
        stringQauntidadeQViolaInical = f"{non_zero_estatica} de {non_zero_pvbar}"
        Observation='FLUXO INICIAL CONVERGENTE.'

    return(DeltaV,Delta0,PotP,PotQ, infoVctrl, matriz_DadosBarra, Barras_PQ, cont,'|', MATRIZ_Y, JACOBIANA_INICIAL, JACOBIANA_FINAL,'|', Observation, stringQauntidadeQViolaInical, stingBarraQViola_estatica, EvolutionMatrixVECTORS, EvolutionMatrixVECTORS2, EvolutionMatrixMatriz2)  



''' ------------------------------------------------------------------------------------------------ '''
''' ------------------------------ ESTUDO DE FLUXO (CARREGAMENTO QUALQUER) ------------------------- '''
''' ------------------------------------------------------------------------------------------------ ''' 

def GoS_generator_FluxoManual(SYSname, MODELin, Tolerancia, HabiltAval_Lim_Reativo, entrad_rodarManual, S_base, Regime_de_CARGA, Desabilitar_CS, Tipo_de_logicaSuplementar, ComutacaoMaxima, Ativar_inverter, GirarTrafo):
    ''' INICIALIZAÇÃO '''
    status_program='CDF' #---MANUAL or CDF (DADOS DE BARRA)
    alterar_tensao_decontrole_doCDF='X' #---X, A or B 
    ([matrizSystem],[matrizSystem2])=Ler_Arquivo(SYSname)
    # for auxiliar_corrigeMS in range(len(matrizSystem)):
    #     matrizSystem[auxiliar_corrigeMS][18]=(-1)*matrizSystem[auxiliar_corrigeMS][18] ## IEEE30 or IEEE118 (linha em T)
    matrizSystem2 = corrige_duplicidadeDeLinha(matrizSystem2)
    ([matriz_DadosBarra],[infoVctrl])=DefineMatrizDadosBarra(matrizSystem, S_base, HabiltAval_Lim_Reativo, status_program, MODELin, None, alterar_tensao_decontrole_doCDF)
    (infoVctrl, matriz_DadosBarra)=liga_desliga_CS(matrizSystem, status_program, MODELin, None , alterar_tensao_decontrole_doCDF, S_base, HabiltAval_Lim_Reativo, Desabilitar_CS, matriz_DadosBarra, infoVctrl)
    ATIVA_ESPEC=extrair_potencias_negativas(matrizSystem)
    PVbarIndex, _, _, _, _, _, _, _, _ = extrair_vetores_da_matrizSystem(matrizSystem)

    modelagem_linha = MODELin # Tipo de modelo da linha (PI ou T)
    matrizSystem, matrizSystem2, modelagem_resultante = alterar_matrizes(matrizSystem, matrizSystem2, modelagem_linha)
    MatrizY=calcularMATRIZ_Y(matrizSystem, matrizSystem2, Ativar_inverter, GirarTrafo)    
    #print('PVbarIndex=',PVbarIndex)

    ''' NEWTON COMPLETO '''
    Fluxo_divergente_0='no'
    try:
        (DeltaV, Delta0, PotP, PotQ, _, _, cont, MATRIZ_Y, Barras_PQ, JACOBIANA_INICIAL, JACOBIANA_FINAL, BarraQViola_estatica,_, _, _, _, _, _, _, _, _, _, VerificaSeViola, EvolutionMatrixVECTORS, EvolutionMatrixVECTORS2, EvolutionMatrixMatriz2)=CHAMA_FLNR_03_LTT (matrizSystem,matrizSystem2,matriz_DadosBarra,infoVctrl,MODELin,Tolerancia,'no', None, None, None, None, None, None, None, None, 'no', None, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY)
        
        DeltaV=[float(x) for x in DeltaV]
        Delta0=[float(x) for x in Delta0]
        PotP=[float(x) for x in PotP]
        PotQ=[float(x) for x in PotQ]

    except Exception as e:
        Fluxo_divergente_0='yes' 
        Observation='FLUXO INICIAL DIVERGENTE. CONFERIR ARQUIVO CDF.'
        DeltaV=[0]*len(ATIVA_ESPEC)  
        Delta0=[0]*len(ATIVA_ESPEC) 
        PotP=[0]*len(ATIVA_ESPEC)
        PotQ=[0]*len(ATIVA_ESPEC)
        Barras_PQ= ['FLUXO DIVERGENTE']*len(ATIVA_ESPEC)
        cont=0  
        JACOBIANA_FINAL=[] 
        JACOBIANA_INICIAL=[]
        stringQauntidadeQViolaInical='FLUXO DIVERGENTE!'
        stingBarraQViola_estatica='FLUXO DIVERGENTE!'
        #print('FLUXO DIVERGENTE EM REGIME DE CARGA INICIAL')
    


    if Fluxo_divergente_0=='no':
        """ ARRUMAR DADOS """
        (DeltaV, Delta0, PotP, PotQ, Barras_PQ, BarraQViola_estatica)=arrumar_DadosDeModelagem_LinhaPItoT(DeltaV, Delta0, PotP, PotQ, Barras_PQ, BarraQViola_estatica, matrizSystem, MODELin)
        (JACOBIANA_INICIAL, JACOBIANA_FINAL)=limpa_jacobs(JACOBIANA_INICIAL, JACOBIANA_FINAL) 
        
        # for aux in range(len(DeltaV)):
        #     DeltaV
        
        # Criar strings de concatenados valores não nulos
        stingBarraQViola_estatica = "_".join(str(x) for x in BarraQViola_estatica if x != 0)
        non_zero_estatica = sum(1 for x in BarraQViola_estatica if x != 0)
        non_zero_pvbar = sum(1 for x in PVbarIndex if x != 0)
        stringQauntidadeQViolaInical = f"{non_zero_estatica} de {non_zero_pvbar}"

        # # ''' PLOTAGEM'''
        # #print(BarraQViola_estatica)
        # print('Quantidade Violada Inicial:',stringQauntidadeQViolaInical)
        # print('Barras que Violam',stingBarraQViola_estatica)
        # Encabecalha_plot(DeltaV, Delta0, PotP, PotQ,infoVctrl,cont)
        # Encabecalha_plot_PotGer(PotP, PotQ, infoVctrl, Barras_PQ, matriz_DadosBarra)
        # Observation='FLUXO INICIAL CONVERGENTE.'


    ''' INICIALIZAÇÃO '''
    lim_sup = len(ATIVA_ESPEC)
    Observation_GERAL='NONE'
    try:
        vetor_barr, vetor_percent, vetor_percent_up, vetor_percent_down = interpretar_entrad_rodarManual(entrad_rodarManual, lim_sup)
        # print("vetor_barr:", vetor_barr)
        # print("vetor_percent:", vetor_percent)
        # print("vetor_percent_up:", vetor_percent_up)
        # print("vetor_percent_down:", vetor_percent_down)
    except Exception as e:
        Observation_GERAL='MUDAR A ENTRADA DOS PARÂMETROS MANUAIS'
        DeltaV=[0]*len(ATIVA_ESPEC)  
        Delta0=[0]*len(ATIVA_ESPEC) 
        PotP=[0]*len(ATIVA_ESPEC)
        PotQ=[0]*len(ATIVA_ESPEC)
        Barras_PQ= ['FLUXO DIVERGENTE']*len(ATIVA_ESPEC)
        cont=0  
        # JACOBIANA_FINAL=[] 
        # JACOBIANA_INICIAL=[]
        stringQauntidadeQViolaInical='PARÂMETROS INVÁLIDOS'
        stingBarraQViola_estatica='PARÂMETROS INVÁLIDOS'
        return(DeltaV, Delta0, PotP, PotQ, infoVctrl, matriz_DadosBarra, Barras_PQ, cont,'|', None, None,'|', Observation_GERAL, 'PARÂMETROS INVÁLIDOS', 'PARÂMETROS INVÁLIDOS','|' , 'PARÂMETROS INVÁLIDOS', 'PARÂMETROS INVÁLIDOS', 'PARÂMETROS INVÁLIDOS', None, None, None)
        #print('MUDE entrad_rodarManual')
        #exit()

    ATIVA_ESPEC_ManUp, ATIVA_ESPEC_ManDown = ajustar_ATIVA_ESPEC0(ATIVA_ESPEC, vetor_barr, vetor_percent_up, vetor_percent_down)
    Fluxo_divergente_up='no'
    Fluxo_divergente_down='no'

    ''' --------------------------------------- REGIME DE CARGA PESADA -------------------------------- '''
    if Regime_de_CARGA=='pesado':
        matriz_DadosBarra_up=matriz_DadosBarra
        for auxiliar in range(len(matriz_DadosBarra[0])):
            matriz_DadosBarra_up[1][auxiliar]=ATIVA_ESPEC_ManUp[auxiliar]/S_base
            matrizSystem[auxiliar][9]=(-1)*ATIVA_ESPEC_ManUp[auxiliar]

        ''' NEWTON COMPLETO '''
        try:
            (DeltaV_up, Delta0_up, PotP_up, PotQ_up, _, _, cont_up, MATRIZ_Y_up, Barras_PQ_up, JACOBIANA_INICIAL_up, JACOBIANA_FINAL_up, BarraQViola_estatica_up,_, _, _, _, _, _, _, _, _, _, VerificaSeViola_up, EvolutionMatrixVECTORS_up, EvolutionMatrixVECTORS2_up, EvolutionMatrixMatriz2_up)=CHAMA_FLNR_03_LTT (matrizSystem,matrizSystem2,matriz_DadosBarra_up,infoVctrl,MODELin,Tolerancia,'no', None, None, None, None, None, None, None, None, 'no', None, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY)
            
            DeltaV_up=[float(x) for x in DeltaV_up]
            Delta0_up=[float(x) for x in Delta0_up]
            PotP_up=[float(x) for x in PotP_up]
            PotQ_up=[float(x) for x in PotQ_up]
        
        except Exception as e:
            Fluxo_divergente_up='yes'            
            #print('FLUXO DIVERGENTE EM REGIME DE CARGA PESADA')
            Observation_up='FLUXO DIVERGENTE EM REGIME DE CARGA PESADA'
            DeltaV_up=[0]*len(ATIVA_ESPEC)  
            Delta0_up=[0]*len(ATIVA_ESPEC) 
            PotP_up=[0]*len(ATIVA_ESPEC)
            PotQ_up=[0]*len(ATIVA_ESPEC)
            Barras_PQ_up= ['FLUXO DIVERGENTE']*len(ATIVA_ESPEC)
            cont_up=0 
            MATRIZ_Y_up=[] 
            JACOBIANA_FINAL_up=[] 
            JACOBIANA_INICIAL_up=[]
            BarraQViola_estatica_up_modific=[]
            BarraQViola_estatica_modific=[]
            stringBarraQViola_estatica_up_modific=[]
            stringBarraQViola_estatica_modific=[]
            stringIndicadeQualidade_up=[]
            stringQauntidadeQViolaFinal_up=[]    
            stingBarra_Adicionadas=[]
            stingBarra_AdicionadasPercent=[]
            stringBqV_unica='DIVERGENTE'
            # stringQauntidadeQViolaInical_up='FLUXO DIVERGENTE!'
            # stingBarraQViola_estatica_up='FLUXO DIVERGENTE!'

        if  Fluxo_divergente_up=='no':
            """ ARRUMAR DADOS """
            (DeltaV_up, Delta0_up, PotP_up, PotQ_up, Barras_PQ_up, BarraQViola_estatica_up)=arrumar_DadosDeModelagem_LinhaPItoT(DeltaV_up, Delta0_up, PotP_up, PotQ_up, Barras_PQ_up, BarraQViola_estatica_up, matrizSystem, MODELin)
            (JACOBIANA_INICIAL_up, JACOBIANA_FINAL_up)=limpa_jacobs(JACOBIANA_INICIAL_up, JACOBIANA_FINAL_up)    

            ''' PLOTAGEM'''

            # Encabecalha_plot(DeltaV_up, Delta0_up, PotP_up, PotQ,infoVctrl,cont_up)
            # Encabecalha_plot_PotGer(PotP_up, PotQ_up, infoVctrl, Barras_PQ_up, matriz_DadosBarra_up)

            # print('\n')
            # print('********* MATRIZ Y **********')
            # print('\n')
            # for aux in range(len(MATRIZ_Y_up)):
            #     if aux<4:
            #         print(MATRIZ_Y_up[aux])

            # print('\n')
            # print('********* MATRIZ H **********')
            # print('          INICIAL            ')
            # print('\n')
            # for aux in range(len(JACOBIANA_INICIAL_up)):
            #     if aux<4:
            #         print(JACOBIANA_INICIAL_up[aux])

            # print('\n')
            # print('********* MATRIZ H **********')
            # print('           FINAL             ')
            # print('\n')
            # for aux in range(len(JACOBIANA_INICIAL_up)):
            #     if aux<4:
            #         print(JACOBIANA_INICIAL_up[aux])
            
            resultado_down, ver1= detectar_mudanca_de_status_0(BarraQViola_estatica, VerificaSeViola, BarraQViola_estatica_up, VerificaSeViola_up)
            if resultado_down==False:
                Observation_up='regime de carga PESADA selecionada INDIFERENTE DO ESTUDO ORIGINAL'
            else:
                Observation_up='regime de carga PESADA selecionada DIFERENTE DO ESTUDO ORIGINAL'
            
            # print('BarraQViola_estatica=',BarraQViola_estatica)
            # print('BarraQViola_estatica_up=',BarraQViola_estatica_up)
            #vetor_BqV_PES = analisa_BqV(BarraQViola_estatica_up)
            
            # quantidadeViolada, _ , vetor_de_diferencas_PES, Indicador_de_QUALIDADE_PES, Quantidade_Violada_PES = analisadora_DeResultados(
            #     BarraQViola_estatica, PVbarIndex, BarraQViola_estatica_up
            # ) 

            (BarraQViola_estatica_up_modific, BarraQViola_estatica_modific, 
            stingBarraQViola_estatica, stringBarraQViola_estatica_up_modific, 
            stringBarraQViola_estatica_modific, stringIndicadeQualidade_up, 
            stringQauntidadeQViolaInical, stringQauntidadeQViolaFinal_up) = comparar_BarraQViola(
                BarraQViola_estatica, BarraQViola_estatica_up, PVbarIndex)
            stingBarra_Adicionadas = "_".join(str(x) for x in vetor_barr if x != 0)
            #vetor_percent=[0]*len(vetor_percent)
            for auxiliar in range(len(vetor_percent)):
                vetor_percent[auxiliar]=100*vetor_percent[auxiliar]
            stingBarra_AdicionadasPercent = "_".join(str(x) for x in vetor_percent if x != 0)
            Observation_up='FLUXO DE REGIME PEASADO CONVERGENTE.'
            # print('\n')
            # print("INFORMAÇÕES RELEVANTES - REGIME PESADO")
            # #print("BarraQViola_estatica_up_modific:", BarraQViola_estatica_up_modific)
            # #print("BarraQViola_estatica_modific:", BarraQViola_estatica_modific)
            # print("stingBarraQViola_estatica:", stingBarraQViola_estatica)
            # print("stringBarraQViola_estatica_up_modific:", stringBarraQViola_estatica_up_modific)
            # print("stringBarraQViola_estatica_modific:", stringBarraQViola_estatica_modific)
            # print("stringIndicadeQualidade:", stringIndicadeQualidade_up)
            # print("stringQauntidadeQViolaInical:", stringQauntidadeQViolaInical)
            # print("stringQauntidadeQViolaFinal:", stringQauntidadeQViolaFinal_up)
            # print("Barras adicionadas:", stingBarra_Adicionadas)   
            # print("Porcentagens adicionadas:", stingBarra_AdicionadasPercent)
            if stringIndicadeQualidade_up=='MELHOR':
                stringBqV_unica=stringBarraQViola_estatica_modific
            elif stringIndicadeQualidade_up=='PIOR':
                stringBqV_unica=stringBarraQViola_estatica_up_modific
            elif stringIndicadeQualidade_up=='INDIFERENTE':
                stringBqV_unica='INDIFERENTE'   
        return(DeltaV_up,Delta0_up,PotP_up,PotQ_up, infoVctrl, matriz_DadosBarra_up, Barras_PQ_up, cont_up,'|', MATRIZ_Y_up, JACOBIANA_INICIAL_up, JACOBIANA_FINAL_up,'|', Observation_up, stringQauntidadeQViolaInical, stingBarraQViola_estatica,'|', stringQauntidadeQViolaFinal_up, stringBqV_unica, stringIndicadeQualidade_up, stingBarra_Adicionadas, stingBarra_AdicionadasPercent, EvolutionMatrixVECTORS_up, EvolutionMatrixVECTORS2_up, EvolutionMatrixMatriz2_up)  

    ''' --------------------------------------- REGIME DE CARGA LEVE --------------------------------- '''
    if Regime_de_CARGA=='leve':
        matriz_DadosBarra_down=matriz_DadosBarra
        for auxiliar in range(len(matriz_DadosBarra[0])):
            matriz_DadosBarra_down[1][auxiliar]=ATIVA_ESPEC_ManDown[auxiliar]/S_base
            matrizSystem[auxiliar][9]=(-1)*ATIVA_ESPEC_ManDown[auxiliar]
            
        ''' NEWTON COMPLETO '''
        try:
            (DeltaV_down, Delta0_down, PotP_down, PotQ_down, _, _, cont_down, MATRIZ_Y_down, Barras_PQ_down, JACOBIANA_INICIAL_down, JACOBIANA_FINAL_down, BarraQViola_estatica_down,_, _, _, _, _, _, _, _, _, _, VerificaSeViola_down, EvolutionMatrixVECTORS_down, EvolutionMatrixVECTORS2_down, EvolutionMatrixMatriz2_down)=CHAMA_FLNR_03_LTT (matrizSystem,matrizSystem2,matriz_DadosBarra_down,infoVctrl,MODELin,Tolerancia,'no', None, None, None, None, None, None, None, None, 'no', None, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY)

            DeltaV_down=[float(x) for x in DeltaV_down]
            Delta0_down=[float(x) for x in Delta0_down]
            PotP_down=[float(x) for x in PotP_down]
            PotQ_down=[float(x) for x in PotQ_down]

        except Exception as e:
            Fluxo_divergente_down='yes'            
            #print('FLUXO DIVERGENTE EM REGIME DE CARGA LEVE')
            Observation_down='FLUXO DIVERGENTE EM REGIME DE CARGA LEVE'
            DeltaV_down=[0]*len(ATIVA_ESPEC)  
            Delta0_down=[0]*len(ATIVA_ESPEC) 
            PotP_down=[0]*len(ATIVA_ESPEC)
            PotQ_down=[0]*len(ATIVA_ESPEC)
            Barras_PQ_down= ['FLUXO DIVERGENTE']*len(ATIVA_ESPEC)
            cont_down=0  
            MATRIZ_Y_down=[]
            JACOBIANA_FINAL_down=[] 
            JACOBIANA_INICIAL_down=[]
            BarraQViola_estatica_down_modific=[]
            BarraQViola_estatica_modific=[]
            stringBarraQViola_estatica_down_modific=[]
            stringBarraQViola_estatica_modific=[]
            stringIndicadeQualidade_down=[]
            stringQauntidadeQViolaFinal_down=[]    
            stingBarra_Adicionadas=[]
            stingBarra_AdicionadasPercent=[]
            stringBqV_unica='DIVERGENTE'

        if  Fluxo_divergente_down=='no':
            """ ARRUMAR DADOS """
            (DeltaV_down, Delta0_down, PotP_down, PotQ_down, Barras_PQ_down, BarraQViola_estatica_down)=arrumar_DadosDeModelagem_LinhaPItoT(DeltaV_down, Delta0_down, PotP_down, PotQ_down, Barras_PQ_down, BarraQViola_estatica_down, matrizSystem, MODELin)
            (JACOBIANA_INICIAL_down, JACOBIANA_FINAL_down)=limpa_jacobs(JACOBIANA_INICIAL_down, JACOBIANA_FINAL_down)    

            ''' PLOTAGEM'''

            # Encabecalha_plot(DeltaV_down, Delta0_down, PotP_down, PotQ_down, infoVctrl,cont_down)
            # Encabecalha_plot_PotGer(PotP_down, PotQ_down, infoVctrl, Barras_PQ_down, matriz_DadosBarra_down)

            # print('\n')
            # print('********* MATRIZ Y **********')
            # print('\n')
            # for aux in range(len(MATRIZ_Y_down)):
            #     if aux<4:
            #         print(MATRIZ_Y_down[aux])

            # print('\n')
            # print('********* MATRIZ H **********')
            # print('          INICIAL            ')
            # print('\n')
            # for aux in range(len(JACOBIANA_INICIAL_down)):
            #     if aux<4:
            #         print(JACOBIANA_INICIAL_down[aux])

            # print('\n')
            # print('********* MATRIZ H **********')
            # print('           FINAL             ')
            # print('\n')
            # for aux in range(len(JACOBIANA_INICIAL_down)):
            #     if aux<4:
            #         print(JACOBIANA_INICIAL_down[aux])

            resultado_down, ver= detectar_mudanca_de_status_0(BarraQViola_estatica, VerificaSeViola, BarraQViola_estatica_down, VerificaSeViola_down)
            
            
            # if resultado_down==True:
            #     vetor_BqV_PES = analisa_BqV(BarraQViola_estatica_down)
            #     quantidadeViolada, _ , vetor_de_diferencas_PES, Indicador_de_QUALIDADE_PES, Quantidade_Violada_PES = analisadora_DeResultados(
            #         BarraQViola_estatica, PVbarIndex, BarraQViola_estatica_down
            #     )         

            (BarraQViola_estatica_down_modific, BarraQViola_estatica_modific, 
            stingBarraQViola_estatica, stringBarraQViola_estatica_down_modific, 
            stringBarraQViola_estatica_modific, stringIndicadeQualidade_down, 
            stringQauntidadeQViolaInical, stringQauntidadeQViolaFinal_down) = comparar_BarraQViola(
                BarraQViola_estatica, BarraQViola_estatica_down, PVbarIndex)
            stingBarra_Adicionadas = "_".join(str(x) for x in vetor_barr if x != 0)
            #vetor_percent=[0]*len(vetor_percent)
            for auxiliar in range(len(vetor_percent)):
                vetor_percent[auxiliar]=100*vetor_percent[auxiliar]
            stingBarra_AdicionadasPercent = "_".join(str(x) for x in vetor_percent if x != 0)
            Observation_down='FLUXO DE REGIME LEVE CONVERGENTE.'

            # print('\n')
            # print("INFORMAÇÕES RELEVANTES - REGIME LEVE")
            # #print("BarraQViola_estatica_down_modific:", BarraQViola_estatica_down_modific)
            # #print("BarraQViola_estatica_modific:", BarraQViola_estatica_modific)
            # print("stingBarraQViola_estatica:", stingBarraQViola_estatica)
            # print("stringBarraQViola_estatica_down_modific:", stringBarraQViola_estatica_down_modific)
            # print("stringIndicadeQualidade:", stringIndicadeQualidade_down)
            # print("stringQauntidadeQViolaInical:", stringQauntidadeQViolaInical)
            # print("stringQauntidadeQViolaFinal_down:", stringQauntidadeQViolaFinal_down)
            # print("Barras adicionadas:", stingBarra_Adicionadas)  
            # print("Porcentagens adicionadas:", stingBarra_AdicionadasPercent)
            if stringIndicadeQualidade_down=='MELHOR':
                stringBqV_unica=stringBarraQViola_estatica_modific
            elif stringIndicadeQualidade_down=='PIOR':
                stringBqV_unica=stringBarraQViola_estatica_down_modific
            elif stringIndicadeQualidade_down=='INDIFERENTE':
                stringBqV_unica='INDIFERENTE'

        return(DeltaV_down,Delta0_down,PotP_down,PotQ_down, infoVctrl, matriz_DadosBarra_down, Barras_PQ_down, cont_down,'|',MATRIZ_Y_down, JACOBIANA_INICIAL_down, JACOBIANA_FINAL_down,'|',Observation_down, stringQauntidadeQViolaInical, stingBarraQViola_estatica,'|',stringQauntidadeQViolaFinal_down, stringBqV_unica , stringIndicadeQualidade_down, stingBarra_Adicionadas, stingBarra_AdicionadasPercent, EvolutionMatrixVECTORS_down, EvolutionMatrixVECTORS2_down, EvolutionMatrixMatriz2_down)




''' ------------------------------------------------------------------------------------------------ '''
''' ------------------------------ ESTUDOS DAS CURVAS EVOLUTIVAS ----------------------------------- '''
''' ------------------------------------------------------------------------------------------------ '''

def GoS_generator_EvolutionCurves (SYSname, MODELin, Tolerancia, HabiltAval_Lim_Reativo, S_base, Desabilitar_CS, Tipo_de_logicaSuplementar, ComutacaoMaxima, Ativar_inverter, PORTS_IN, GirarTrafo):
    ''' INICIALIZAÇÃO '''
    status_program='CDF' #---MANUAL or CDF (DADOS DE BARRA)
    alterar_tensao_decontrole_doCDF='X' #---X, A or B 
    ([matrizSystem],[matrizSystem2])=Ler_Arquivo(SYSname)
    # for auxiliar_corrigeMS in range(len(matrizSystem)):
    #     matrizSystem[auxiliar_corrigeMS][18]=(-1)*matrizSystem[auxiliar_corrigeMS][18] ## IEEE30 or IEEE118 (linha em T)
    matrizSystem2 = corrige_duplicidadeDeLinha(matrizSystem2)
    ([matriz_DadosBarra],[infoVctrl])=DefineMatrizDadosBarra(matrizSystem, S_base, HabiltAval_Lim_Reativo, status_program, MODELin, None, alterar_tensao_decontrole_doCDF)
    (infoVctrl, matriz_DadosBarra)=liga_desliga_CS(matrizSystem, status_program, MODELin, None , alterar_tensao_decontrole_doCDF, S_base, HabiltAval_Lim_Reativo, Desabilitar_CS, matriz_DadosBarra, infoVctrl)
    ATIVA_ESPEC=extrair_potencias_negativas(matrizSystem)
    PVbarIndex, _, _, _, _, _, _, _, _ = extrair_vetores_da_matrizSystem(matrizSystem)
    
    somaP0=0
    for AUXILIAR in range(len(matriz_DadosBarra[1])):
        somaP0=somaP0+(-1)*matriz_DadosBarra[1][AUXILIAR]

    if PORTS_IN[0]!=None:
        _ , matriz_DadosBarra[1]=read_vector_csv(PORTS_IN[1])

    somaPE=0
    for AUXILIAR in range(len(matriz_DadosBarra[1])):
        somaPE=somaPE+(-1)*matriz_DadosBarra[1][AUXILIAR]
    #     matrizSystem[AUXILIAR][9]=(-1)*(float(matriz_DadosBarra[1][AUXILIAR])*S_base)

    modelagem_linha = MODELin # Tipo de modelo da linha (PI ou T)
    matrizSystem, matrizSystem2, modelagem_resultante = alterar_matrizes(matrizSystem, matrizSystem2, modelagem_linha)
    MatrizY=calcularMATRIZ_Y(matrizSystem, matrizSystem2, Ativar_inverter, GirarTrafo)

    #Tolerancia=0.01
    #print('PVbarIndex=',PVbarIndex)
    
    #matriz_DadosBarra[1]= [0.0, -0.217, -0.9420000000000001, -0.478, -0.076, -0.11199999999999999, 0.0, 0.0, -0.53, -0.18, -0.035, -0.055, -0.135, -0.298]
    #matriz_DadosBarra[1]= [0.0, -0.217, -0.9420000000000001, -0.478, -0.076, -0.11199999999999999, 0.0, 0.0, -0.57, -0.18, -0.035, -0.055, -0.135, -0.298]
    #matriz_DadosBarra[1]= [0.0, -0.217, -0.9420000000000001, -0.478, -0.076, -0.11199999999999999, 0.0, 0.0, -0.58, -0.18, -0.035, -0.055, -0.135, -0.298]
    #matriz_DadosBarra[1]= [0.0, -0.217, -0.9420000000000001, -0.478, -0.076, -0.11199999999999999, 0.0, 0.0, -0.59, -0.18, -0.035, -0.061, -0.135, -0.298]
    """matriz_DadosBarra[1] = [0.0, -0.217, -0.9420000000000001, -0.478, -0.076, -0.11199999999999999, 0.0, 0.0, -0.59, -0.18, -0.035, -0.061, -0.135, -0.298]"""
    #matriz_DadosBarra[1]= [0.0, -0.217, -0.9420000000000001, -0.478, -0.076, -0.11199999999999999, 0.0, 0.0, -0.59, -0.18, -0.035, -0.069, -0.135, -0.298]
    #matriz_DadosBarra[1]= [0.0, -0.217, -0.9420000000000001, -0.478, -0.076, -0.11199999999999999, 0.0, 0.0, -0.60, -0.18, -0.035, -0.055, -0.135, -0.298]
    #matriz_DadosBarra[1]= [0.0, -0.217, -0.9420000000000001, -0.478, -0.076, -0.11199999999999999, 0.0, 0.0, -0.65, -0.18, -0.035, -0.055, -0.135, -0.298]
    


    """matriz_DadosBarra[1]=[0.0, -21.7, -94.2, -47.8, -7.6, -11.2, 0.0, 0.0, -29.5, -9.04, -3.5, -6.1, -13.5, -14.9]"""
    
    ### ESTUDO DE PONTO CRÍTICO IEEE118.
    #matriz_DadosBarra[1]=[-0.61, -0.30000000000000004, -0.49, -0.4, -0.1, -0.62, -0.29000000000000004, -0.1, -0.1, -0.1, -0.7999999999999999, -0.57, -0.44000000000000006, -0.24000000000000002, -1.0, -0.35, -0.21000000000000002, -0.7, -0.55, -0.28, -0.24000000000000002, -0.1, -0.07, 0.0, 0.0, 0.0, -0.62, -0.17, -0.24, 0.0, -0.43, -0.59, -0.23, -0.59, -0.33, -0.31, 0.0, 0.0, -0.27, -0.2, -0.37, -0.37, -0.18, -0.16, -0.53, -0.28, -0.34, -0.2, -0.87, -0.17, -0.17, -0.18, -0.23, -1.13, -0.63, -0.84, -0.12, -0.12, -2.77, -0.78, 0.0, -0.77, 0.0, 0.0, 0.0, -0.39, -0.28, 0.0, 0.0, -0.66, 0.0, 0.0, 0.0, -0.68, -0.47, -0.68, -0.61, -0.71, -0.39, -1.3, 0.0, -0.54, -0.2, -0.11, -0.24, -0.21, 0.0, -0.48, 0.0, -0.78, 0.0, -0.65, -0.12, -0.3, -0.42, -0.38, -0.15, -0.34, 0.0, -0.37, -0.22, -0.05, -0.23, -0.38, -0.31, -0.43, -0.28, -0.02, -0.08, -0.39, 0.0, -0.25, 0.0, -0.08, -0.22, 0.0, -0.2, -0.33]
    #matriz_DadosBarra[1]=[-0.51,-0.18,-0.37,-0.27999999999999997,0.0,-0.5,-0.16999999999999998,0.0,0.0,0.0,-0.6799999999999999,-0.44999999999999996,-0.32,-0.12000000000000001,-0.88,-0.22999999999999998,-0.09000000000000001,-0.58,-0.43,-0.15999999999999998,-0.12000000000000001,-0.08000000000000002,-0.05,0.0,0.0,0.0,-0.6,-0.15,-0.21999999999999997,0.0,-0.41,-0.57,-0.21,-0.57,-0.31,-0.29,0.0,0.0,-0.25,-0.18,-0.35,-0.35,-0.15999999999999998,-0.13999999999999999,-0.52,-0.27,-0.33,-0.19,-0.86,-0.16,-0.16,-0.16999999999999998,-0.22,-1.1199999999999999,-0.62,-0.83,-0.11,-0.11,-2.7600000000000002,-0.77,0.0,-0.76,0.0,0.0,0.0,-0.38,-0.27,0.0,0.0,-0.65,0.0,0.0,0.0,-0.67,-0.45999999999999996,-0.67,-0.6,-0.7,-0.38,-1.29,0.0,-0.53,-0.19,-0.1,-0.22999999999999998,-0.19999999999999998,0.0,-0.47,0.0,-0.77,0.0,-0.64,-0.11,-0.29,-0.41,-0.37,-0.13999999999999999,-0.33,0.0,-0.36,-0.21,-0.05,-0.23,-0.38,-0.31,-0.43,-0.28,-0.02,-0.08,-0.39,0.0,-0.25,0.0,-0.08,-0.22,0.0,-0.2,-0.33]
    #matriz_DadosBarra[1]=[-0.51,-0.18,-0.37,-0.27999999999999997,0.0,-0.5,-0.16999999999999998,0.0,0.0,0.0,-0.6799999999999999,-0.44999999999999996,-0.32,-0.12000000000000001,-0.88,-0.22999999999999998,-0.09000000000000001,-0.58,-0.43,-0.15999999999999998,-0.12000000000000001,-0.08000000000000002,-0.05,0.0,0.0,0.0,-0.6,-0.15,-0.21999999999999997,0.0,-0.41,-0.57,-0.21,-0.57,-0.31,-0.29,0.0,0.0,-0.25,-0.18,-0.35,-0.35,-0.15999999999999998,-0.13999999999999999,-0.52,-0.27,-0.33,-0.19,-0.86,-0.16,-0.16,-0.16999999999999998,-0.22,-1.1199999999999999,-0.62,-0.83,-0.11,-0.11,-2.7600000000000002,-0.77,0.0,-0.76,0.0,0.0,0.0,-0.38,-0.27,0.0,0.0,-0.65,0.0,0.0,0.0,-0.67,-0.45999999999999996,-0.67,-0.6,-0.7,-0.38,-1.29,0.0,-0.53,-0.19,-0.1,-0.22999999999999998,-0.19999999999999998,0.0,-0.47,0.0,-0.77,0.0,-0.64,-0.11,-0.29,-0.41,-0.37,-0.13999999999999999,-0.33,0.0,-0.36,-0.21,-0.05,-0.23,-0.38,-0.31,-0.43,-0.28,-0.02,-0.08,-0.39,0.0,-0.25,0.0,-0.08,-0.22,0.0,-0.2,-0.33]
    #matriz_DadosBarra[1]=[-0.51,-0.01999999999999997,-0.20999999999999985,-0.11999999999999984,-0.0,-0.33999999999999986,-0.009999999999999969,-0.0,-0.0,-0.0,-0.5199999999999998,-0.2899999999999998,-0.15999999999999986,0.03999999999999998,-0.7199999999999999,-0.06999999999999992,0.055,-0.4199999999999998,-0.26999999999999985,3.122502256758253e-17,0.03999999999999998,0.05,0.035,-0.0,-0.0,-0.0,-0.43999999999999984,0.010000000000000004,-0.05999999999999992,-0.0,-0.24999999999999983,-0.4099999999999998,-0.04999999999999995,-0.4099999999999998,-0.14999999999999986,-0.12999999999999984,-0.0,-0.0,-0.08999999999999991,-0.01999999999999997,-0.18999999999999984,-0.18999999999999984,3.122502256758253e-17,0.020000000000000004,-0.34999999999999987,-0.09999999999999991,-0.15999999999999986,-0.01999999999999997,-0.6899999999999998,0.010000000000000004,0.010000000000000004,3.122502256758253e-17,-0.04999999999999995,-0.9499999999999997,-0.44999999999999984,-0.6599999999999998,0.06,0.06,-2.590000000000004,-0.5999999999999999,-0.0,-0.5899999999999999,-0.0,-0.0,-0.0,-0.20999999999999985,-0.09999999999999991,-0.0,-0.0,-0.47999999999999987,-0.0,-0.0,-0.0,-0.4999999999999999,-0.2899999999999998,-0.4999999999999999,-0.4299999999999998,-0.5299999999999998,-0.20999999999999985,-1.1199999999999999,-0.0,-0.3599999999999999,-0.01999999999999997,0.055,-0.05999999999999992,-0.029999999999999943,-0.0,-0.2999999999999998,-0.0,-0.5999999999999999,-0.0,-0.46999999999999986,0.06,-0.11999999999999984,-0.23999999999999982,-0.20999999999999985,0.020000000000000004,-0.16999999999999987,-0.0,-0.19999999999999984,-0.04999999999999995,-0.05,-0.23,-0.38,-0.31,-0.43,-0.28,-0.02,-0.08,-0.39,0.0,-0.25,0.0,-0.08,-0.22,0.0,-0.2,-0.33]
    ###########
    #matriz_DadosBarra[1]=[-0.51,-0.3100000000000001,-0.5000000000000001,-0.4100000000000001,0.0,-0.6300000000000001,-0.3000000000000001,0.0,0.0,0.0,-0.81,-0.5800000000000001,-0.4500000000000001,-0.2500000000000001,-1.01,-0.3600000000000001,-0.22000000000000008,-0.7100000000000001,-0.56,-0.2900000000000001,-0.2500000000000001,-0.21000000000000008,-0.17500000000000002,0.0,0.0,0.0,-0.7300000000000001,-0.2800000000000001,-0.3500000000000001,0.0,-0.54,-0.7000000000000001,-0.3400000000000001,-0.7000000000000001,-0.4400000000000001,-0.4200000000000001,0.0,0.0,-0.3800000000000001,-0.3100000000000001,-0.4800000000000001,-0.4800000000000001,-0.2900000000000001,-0.2700000000000001,-0.6400000000000001,-0.3900000000000001,-0.4500000000000001,-0.3100000000000001,-0.9800000000000001,-0.2800000000000001,-0.2800000000000001,-0.2900000000000001,-0.3400000000000001,-1.24,-0.7400000000000001,-0.9500000000000001,-0.2300000000000001,-0.2300000000000001,-2.8799999999999977,-0.8900000000000001,0.0,-0.8800000000000001,0.0,0.0,0.0,-0.5000000000000001,-0.3900000000000001,0.0,0.0,-0.7700000000000001,0.0,0.0,0.0,-0.7900000000000001,-0.5800000000000001,-0.7900000000000001,-0.7200000000000001,-0.8200000000000001,-0.5000000000000001,-1.4100000000000001,0.0,-0.6500000000000001,-0.3100000000000001,-0.22000000000000008,-0.3500000000000001,-0.32000000000000006,0.0,-0.5900000000000001,0.0,-0.8900000000000001,0.0,-0.7600000000000001,-0.2300000000000001,-0.4100000000000001,-0.52,-0.4800000000000001,-0.25000000000000006,-0.4400000000000001,0.0,-0.4700000000000001,-0.32000000000000006,-0.05,-0.23,-0.38,-0.31,-0.43,-0.28,-0.02,-0.08,-0.39,0.0,-0.25,0.0,-0.08,-0.22,0.0,-0.2,-0.33]
    #matriz_DadosBarra[1]=[-0.51,-0.3100000000000001,-0.5000000000000001,-0.4100000000000001,0.0,-0.6300000000000001,-0.3000000000000001,0.0,0.0,0.0,-0.81,-0.5800000000000001,-0.4500000000000001,-0.2500000000000001,-1.01,-0.3600000000000001,-0.22000000000000008,-0.7100000000000001,-0.56,-0.2900000000000001,-0.2500000000000001,-0.21000000000000008,-0.17500000000000002,0.0,0.0,0.0,-0.7300000000000001,-0.2800000000000001,-0.3500000000000001,0.0,-0.54,-0.7000000000000001,-0.3400000000000001,-0.7000000000000001,-0.4400000000000001,-0.4200000000000001,0.0,0.0,-0.3800000000000001,-0.3100000000000001,-0.4800000000000001,-0.4800000000000001,-0.2900000000000001,-0.2700000000000001,-0.6400000000000001,-0.3900000000000001,-0.4500000000000001,-0.3100000000000001,-0.9800000000000001,-0.2800000000000001,-0.2800000000000001,-0.2900000000000001,-0.3400000000000001,-1.24,-0.7400000000000001,-0.9500000000000001,-0.2300000000000001,-0.2300000000000001,-2.8799999999999977,-0.8900000000000001,0.0,-0.8800000000000001,0.0,0.0,0.0,-0.5000000000000001,-0.3900000000000001,0.0,0.0,-0.7700000000000001,0.0,0.0,0.0,-0.7900000000000001,-0.5800000000000001,-0.7900000000000001,-0.7200000000000001,-0.8200000000000001,-0.5000000000000001,-1.4100000000000001,0.0,-0.6500000000000001,-0.3100000000000001,-0.22000000000000008,-0.3500000000000001,-0.32000000000000006,0.0,-0.5900000000000001,0.0,-0.8900000000000001,0.0,-0.7600000000000001,-0.2300000000000001,-0.4100000000000001,-0.53,-0.4800000000000001,-0.25000000000000006,-0.4400000000000001,0.0,-0.4700000000000001,-0.32000000000000006,-0.05,-0.23,-0.38,-0.31,-0.43,-0.28,-0.02,-0.08,-0.39,0.0,-0.25,0.0,-0.08,-0.22,0.0,-0.2,-0.33]
    #matriz_DadosBarra[1]=[-0.51,-0.3100000000000001,-0.5000000000000001,-0.4100000000000001,0.0,-0.6300000000000001,-0.3000000000000001,0.0,0.0,0.0,-0.81,-0.5800000000000001,-0.4500000000000001,-0.2500000000000001,-1.01,-0.3600000000000001,-0.22000000000000008,-0.7100000000000001,-0.56,-0.2900000000000001,-0.2500000000000001,-0.21000000000000008,-0.17500000000000002,0.0,0.0,0.0,-0.7300000000000001,-0.2800000000000001,-0.3500000000000001,0.0,-0.54,-0.7000000000000001,-0.3400000000000001,-0.7000000000000001,-0.4400000000000001,-0.4200000000000001,0.0,0.0,-0.3800000000000001,-0.3100000000000001,-0.4800000000000001,-0.4800000000000001,-0.2900000000000001,-0.2700000000000001,-0.6400000000000001,-0.3900000000000001,-0.4500000000000001,-0.3100000000000001,-0.9800000000000001,-0.2800000000000001,-0.2800000000000001,-0.2900000000000001,-0.3400000000000001,-1.24,-0.7400000000000001,-0.9500000000000001,-0.2300000000000001,-0.2300000000000001,-2.8799999999999977,-0.8900000000000001,0.0,-0.8800000000000001,0.0,0.0,0.0,-0.5000000000000001,-0.3900000000000001,0.0,0.0,-0.7700000000000001,0.0,0.0,0.0,-0.7900000000000001,-0.5800000000000001,-0.7900000000000001,-0.7200000000000001,-0.8200000000000001,-0.5000000000000001,-1.4100000000000001,0.0,-0.6500000000000001,-0.3100000000000001,-0.22000000000000008,-0.3500000000000001,-0.32000000000000006,0.0,-0.5900000000000001,0.0,-0.8900000000000001,0.0,-0.7600000000000001,-0.2300000000000001,-0.4100000000000001,-0.53,-0.4900000000000001,-0.25000000000000006,-0.4400000000000001,0.0,-0.4700000000000001,-0.32000000000000006,-0.05,-0.23,-0.38,-0.31,-0.43,-0.28,-0.02,-0.08,-0.39,0.0,-0.25,0.0,-0.08,-0.22,0.0,-0.2,-0.33]
    #matriz_DadosBarra[1]=[-0.51,-0.01999999999999997,-0.20999999999999985,-0.11999999999999984,-0.0,-0.33999999999999986,-0.009999999999999969,-0.0,-0.0,-0.0,-0.5199999999999998,-0.2899999999999998,-0.15999999999999986,0.03999999999999998,-0.7199999999999999,-0.06999999999999992,0.055,-0.4199999999999998,-0.26999999999999985,3.122502256758253e-17,0.03999999999999998,0.05,0.035,-0.0,-0.0,-0.0,-0.43999999999999984,3.469446951953614e-18,-0.06999999999999992,-0.0,-0.25999999999999984,-0.4199999999999998,-0.05999999999999995,-0.4199999999999998,-0.15999999999999986,-0.13999999999999985,-0.0,-0.0,-0.09999999999999991,-0.02999999999999997,-0.19999999999999984,-0.19999999999999984,-0.009999999999999969,0.010000000000000004,-0.3599999999999999,-0.1099999999999999,-0.16999999999999987,-0.02999999999999997,-0.6999999999999998,3.469446951953614e-18,3.469446951953614e-18,-0.009999999999999969,-0.05999999999999995,-0.9599999999999997,-0.45999999999999985,-0.6699999999999998,0.049999999999999996,0.049999999999999996,-2.6000000000000036,-0.6099999999999999,-0.0,-0.5999999999999999,-0.0,-0.0,-0.0,-0.21999999999999986,-0.1099999999999999,-0.0,-0.0,-0.4899999999999999,-0.0,-0.0,-0.0,-0.5099999999999999,-0.2999999999999998,-0.5099999999999999,-0.43999999999999984,-0.5399999999999998,-0.21999999999999986,-1.13,-0.0,-0.3699999999999999,-0.02999999999999997,0.055,-0.06999999999999992,-0.039999999999999945,-0.0,-0.30999999999999983,-0.0,-0.6099999999999999,-0.0,-0.47999999999999987,0.049999999999999996,-0.12999999999999984,-0.24999999999999983,-0.20999999999999985,0.020000000000000004,-0.16999999999999987,-0.0,-0.19999999999999984,-0.04999999999999995,-0.05,-0.23,-0.38,-0.31,-0.43,-0.28,-0.02,-0.08,-0.39,0.0,-0.25,0.0,-0.08,-0.22,0.0,-0.2,-0.33]

    ### ESTUDO DE PONTO CRÍTICO IEEE14.    
    #matriz_DadosBarra[1]=[0]*len(matriz_DadosBarra[1])
    #AUX=[0.0, -21.7, -94.2, -47.8, -7.6, -11.2, 0.0, 0.0, -29.5, -9.25, -3.5, -6.1, -13.5, -14.9]
    #matriz_DadosBarra[1]=[0.0,0.217,0.25800000000000073,0.478,0.076,0.11199999999999999,-0.0,-0.0,0.295,0.09,0.035,0.061,0.135,0.149]
    #matriz_DadosBarra[1]=[0.0,-0.434,-1.8479999999999066,-0.956,-0.152,-0.22399999999999998,0.0,0.0,-0.59,-0.18,-0.07,-0.122,-0.27,-0.298]
    #matriz_DadosBarra[1]=[0.0,-0.434,-1.844999999999907,-0.956,-0.152,-0.22399999999999998,0.0,0.0,-0.59,-0.18,-0.07,-0.122,-0.27,-0.298]
    #matriz_DadosBarra[1]=[0.0,-0.434,-1.8369999999999078,-0.956,-0.152,-0.22399999999999998,0.0,0.0,-0.59,-0.18,-0.07,-0.122,-0.27,-0.298]


    ### ESTUDO DE PONTO CRÍTICO IEEE30. 
    #matriz_DadosBarra[1]=[-0.25,-0.3870000000000001,-0.048,-0.152,-1.112,0.0,-0.39800000000000013,-0.46000000000000013,0.0,-0.11599999999999999,0.0,-0.22399999999999998,0.0,-0.124,-0.16399999999999998,-0.07,-0.18,-0.064,-0.19,-0.044000000000000004,-0.33500000000000013,0.0,-0.064,-0.174,0.0,-0.07,0.0,0.0,-0.048,-0.212]
    #matriz_DadosBarra[1]=[-0.25,-0.3870000000000001,-0.048,-0.152,-1.112,0.0,-0.39800000000000013,-0.35000000000000013,0.0,-0.11599999999999999,0.0,-0.22399999999999998,0.0,-0.124,-0.16399999999999998,-0.07,-0.18,-0.064,-0.19,-0.044000000000000004,-0.33500000000000013,0.0,-0.064,-0.174,0.0,-0.07,0.0,0.0,-0.048,-0.212]
    #matriz_DadosBarra[1]=[-0.25,-0.3870000000000001,-0.048,-0.152,-1.112,0.0,-0.39800000000000013,-0.50000000000000013,0.0,-0.11599999999999999,0.0,-0.22399999999999998,0.0,-0.124,-0.16399999999999998,-0.07,-0.18,-0.064,-0.19,-0.044000000000000004,-0.33500000000000013,0.0,-0.064,-0.174,0.0,-0.07,0.0,0.0,-0.048,-0.212]
    #matriz_DadosBarra[1]=[-0.25,-0.3870000000000001,-0.048,-0.152,-1.102,0.0,-0.3880000000000001,-0.46000000000000013,0.0,-0.11599999999999999,0.0,-0.22399999999999998,0.0,-0.124,-0.16399999999999998,-0.07,-0.18,-0.064,-0.19,-0.044000000000000004,-0.33500000000000013,0.0,-0.064,-0.174,0.0,-0.07,0.0,0.0,-0.048,-0.212]
    #matriz_DadosBarra[1]=[-0.25,-0.24400000000000002,-0.048,-0.10300000000000002,-0.9690000000000001,0.0,-0.255,-0.327,0.0,-0.08500000000000002,0.0,-0.138,0.0,-0.08800000000000002,-0.10800000000000001,-0.061000000000000026,-0.11600000000000002,-0.058000000000000024,-0.12100000000000002,-0.044000000000000004,-0.201,0.0,-0.058000000000000024,-0.11300000000000002,0.0,-0.061000000000000026,0.0,0.0,-0.048,-0.132]
    #matriz_DadosBarra[1]=[-0.25,-0.24400000000000002,-0.048,-0.10300000000000002,-0.9690000000000001,0.0,-0.255,-0.327,0.0,-0.08500000000000002,0.0,-0.138,0.0,-0.08800000000000002,-0.10800000000000001,-0.061000000000000026,-0.11600000000000002,-0.058000000000000024,-0.12100000000000002,-0.044000000000000004,-0.201,0.0,-0.058000000000000024,-0.11300000000000002,0.0,-0.061000000000000026,0.0,0.0,-0.048,-0.132]
    #matriz_DadosBarra[1]=[-0.25,-0.3790000000000001,-0.048,-0.152,-1.1039999999999885,0.0,-0.3900000000000001,-0.46200000000000013,0.0,-0.11599999999999999,0.0,-0.22399999999999998,0.0,-0.124,-0.16399999999999998,-0.07,-0.18,-0.064,-0.19,-0.044000000000000004,-0.33600000000000013,0.0,-0.064,-0.174,0.0,-0.07,0.0,0.0,-0.048,-0.212]       
    #matriz_DadosBarra[1]=[-0.25,-0.3790000000000001,-0.048,-0.152,-1.1039999999999885,0.0,-0.3900000000000001,-0.46200000000000013,0.0,-0.11599999999999999,0.0,-0.22399999999999998,0.0,-0.124,-0.16399999999999998,-0.07,-0.18,-0.064,-0.19,-0.044000000000000004,-0.33600000000000013,0.0,-0.064,-0.174,0.0,-0.07,0.0,0.0,-0.048,-0.212]
    
    #AUX=[0.0, -21.7, -94.2, -47.8, -7.6, -11.2, 0.0, 0.0, -29.5, -9.25, -3.5, -6.1, -13.5, -14.9]

    # for varreAUX in range(len(AUX)):
    #     AUX[varreAUX]=AUX[varreAUX]/S_base

    # matriz_DadosBarra[1]=AUX


    # AUX=[0.0, -21.7, -94.2, -47.8, -7.6, -11.2, 0.0, 0.0, -25.214, -9.00, -3.5, -6.1, -13.5, -14.9]
    # for varreAUX in range(len(AUX)):
    #     AUX[varreAUX]=AUX[varreAUX]/S_base

    # matriz_DadosBarra[1]=AUX



    ''' NEWTON COMPLETO '''
    Fluxo_divergente_0='no'
    try:
        (DeltaV, Delta0, PotP, PotQ, _, _, cont, MATRIZ_Y, Barras_PQ, JACOBIANA_INICIAL, JACOBIANA_FINAL, BarraQViola_estatica,_, _, _, _, _, _, _, _, _, _, VerificaSeViola,  EvolutionMatrixVECTORS, EvolutionMatrixVECTORS2, EvolutionMatrixMatriz2)=CHAMA_FLNR_03_LTT (matrizSystem,matrizSystem2,matriz_DadosBarra,infoVctrl,MODELin,Tolerancia,'no', None, None, None, None, None, None, None, None, 'no', None, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY)
    
        DeltaV=[float(x) for x in DeltaV]
        Delta0=[float(x) for x in Delta0]
        PotP=[float(x) for x in PotP]
        PotQ=[float(x) for x in PotQ]
        
    except Exception as e:
        Fluxo_divergente_0='yes' 
        Observation='FLUXO INICIAL DIVERGENTE. CONFERIR ARQUIVO CDF.'
        DeltaV=[0]*len(ATIVA_ESPEC)  
        Delta0=[0]*len(ATIVA_ESPEC) 
        PotP=[0]*len(ATIVA_ESPEC)
        PotQ=[0]*len(ATIVA_ESPEC)
        Barras_PQ= ['FLUXO DIVERGENTE']*len(ATIVA_ESPEC)
        cont=0  
        JACOBIANA_FINAL=[] 
        JACOBIANA_INICIAL=[]
        MATRIZ_Y=[]
        stringQauntidadeQViolaInical='FLUXO DIVERGENTE!'
        stingBarraQViola_estatica='FLUXO DIVERGENTE!'
        #print('FLUXO DIVERGENTE EM REGIME DE CARGA INICIAL')

    if Fluxo_divergente_0=='no':
        """ ARRUMAR DADOS """
        (DeltaV, Delta0, PotP, PotQ, Barras_PQ, BarraQViola_estatica)=arrumar_DadosDeModelagem_LinhaPItoT(DeltaV, Delta0, PotP, PotQ, Barras_PQ, BarraQViola_estatica, matrizSystem, MODELin)
        (JACOBIANA_INICIAL, JACOBIANA_FINAL)=limpa_jacobs(JACOBIANA_INICIAL, JACOBIANA_FINAL) 
        
        # for aux in range(len(DeltaV)):
        #     DeltaV
        
        # Criar strings de concatenados valores não nulos
        stingBarraQViola_estatica = "_".join(str(x) for x in BarraQViola_estatica if x != 0)
        non_zero_estatica = sum(1 for x in BarraQViola_estatica if x != 0)
        non_zero_pvbar = sum(1 for x in PVbarIndex if x != 0)
        stringQauntidadeQViolaInical = f"{non_zero_estatica} de {non_zero_pvbar}"
        Observation='FLUXO INICIAL CONVERGENTE.'

        soma=[somaP0, somaPE]
        return (DeltaV,Delta0,PotP,PotQ, infoVctrl, matriz_DadosBarra, Barras_PQ, cont,'|', MATRIZ_Y, JACOBIANA_INICIAL, JACOBIANA_FINAL,'|', Observation, stringQauntidadeQViolaInical, stingBarraQViola_estatica, EvolutionMatrixVECTORS, EvolutionMatrixVECTORS2, EvolutionMatrixMatriz2, soma)  
  










def saveAbnormalPoints (DadosCarga, Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN):
    SYSname=PORTAS_E3_IN[0]
    MODELin=PORTAS_E3_IN[1]
    Tolerancia=PORTAS_E3_IN[2]
    HabiltAval_Lim_Reativo=PORTAS_E3_IN[3]
    S_base=PORTAS_E3_IN[4]
    Desabilitar_CS=PORTAS_E3_IN[5]
    Tipo_de_logicaSuplementar=PORTAS_E3_IN[6]
    ComutacaoMaxima=PORTAS_E3_IN[7]
    Ativar_inverter=PORTAS_E3_IN[8]
    passoE3=PORTAS_E3_IN[9]
    limite_variacao=PORTAS_E3_IN[10]
    RegimeE3=PORTAS_E3_IN[11]
    limite_variacao_lev=PORTAS_E3_IN[12]
    limite_variacao_pes=PORTAS_E3_IN[13]
    Estrategia=PORTAS_E3_IN[14]
    ESCOLHER=PORTAS_E3_IN[15]
    
    # Cria o dicionário de parâmetros (ajuste os valores conforme seu contexto)
    parameters = {
        "SYSname": SYSname,
        "MODELin": MODELin,
        "Tolerancia": Tolerancia,
        "HabiltAval_Lim_Reativo": HabiltAval_Lim_Reativo,
        "S_base": S_base,
        "Desabilitar_CS": Desabilitar_CS,
        "Tipo_de_logicaSuplementar": Tipo_de_logicaSuplementar,
        "ComutacaoMaxima": ComutacaoMaxima,
        "Ativar_inverter": Ativar_inverter,
        "passoE3": passoE3,
        "limite_variacao": limite_variacao,
        "RegimeE3": RegimeE3,
        "limite_variacao_lev": limite_variacao_lev,
        "limite_variacao_pes": limite_variacao_pes,
        "Estrategia": Estrategia,
        "ESCOLHER": ESCOLHER,
    }
 
    save_dir = os.path.join(os.getcwd(), "plot", "GenOfSimul", "AbnormalPoints")
    os.makedirs(save_dir, exist_ok=True)

    tag = create_unique_tag2(save_dir, len(DadosCarga))   
    
    save_vector_csv(DadosCarga, parameters, tag, "csv", save_dir)
    return

def saveDivergencies (DadosCarga, Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN):
    SYSname=PORTAS_E3_IN[0]
    MODELin=PORTAS_E3_IN[1]
    Tolerancia=PORTAS_E3_IN[2]
    HabiltAval_Lim_Reativo=PORTAS_E3_IN[3]
    S_base=PORTAS_E3_IN[4]
    Desabilitar_CS=PORTAS_E3_IN[5]
    Tipo_de_logicaSuplementar=PORTAS_E3_IN[6]
    ComutacaoMaxima=PORTAS_E3_IN[7]
    Ativar_inverter=PORTAS_E3_IN[8]
    passoE3=PORTAS_E3_IN[9]
    limite_variacao=PORTAS_E3_IN[10]
    RegimeE3=PORTAS_E3_IN[11]
    limite_variacao_lev=PORTAS_E3_IN[12]
    limite_variacao_pes=PORTAS_E3_IN[13]
    Estrategia=PORTAS_E3_IN[14]
    ESCOLHER=PORTAS_E3_IN[15]

    # Cria o dicionário de parâmetros (ajuste conforme necessário)
    parameters = {
        "SYSname": SYSname,
        "MODELin": MODELin,
        "Tolerancia": Tolerancia,
        "HabiltAval_Lim_Reativo": HabiltAval_Lim_Reativo,
        "S_base": S_base,
        "Desabilitar_CS": Desabilitar_CS,
        "Tipo_de_logicaSuplementar": Tipo_de_logicaSuplementar,
        "ComutacaoMaxima": ComutacaoMaxima,
        "Ativar_inverter": Ativar_inverter,
        "passoE3": passoE3,
        "limite_variacao": limite_variacao,
        "RegimeE3": RegimeE3,
        "limite_variacao_lev": limite_variacao_lev,
        "limite_variacao_pes": limite_variacao_pes,
        "Estrategia": Estrategia,
        "ESCOLHER": ESCOLHER,
    }

    save_dir = os.path.join(os.getcwd(), "plot", "GenOfSimul", "Divergencies")
    os.makedirs(save_dir, exist_ok=True)

    tag = create_unique_tag2(save_dir, len(DadosCarga))

    save_vector_csv(DadosCarga, parameters, tag, "csv", save_dir)
    return

def save_vector_csv (vector, parameters, base_filename="vector", extension="csv", subfolder=os.path.join("plot", "GoPVcurve", "AbnormalPoints")):
    """
    Salva o vetor em um arquivo CSV dentro de uma subpasta.
    Antes do vetor, insere um cabeçalho com os parâmetros (um por linha, iniciando com '#').
    
    Parâmetros:
      vector (list): Vetor a ser salvo.
      parameters (dict): Dicionário com os parâmetros a serem salvos no cabeçalho.
      base_filename (str): Nome base para o arquivo.
      extension (str): Extensão do arquivo.
      subfolder (str): Subpasta onde o arquivo será salvo.
    """
    # Diretório atual
    dir_path = os.getcwd()
    output_dir = os.path.join(dir_path, subfolder)
    os.makedirs(output_dir, exist_ok=True)
    
    # Cria um padrão para buscar arquivos existentes (caso queira versionar os arquivos)
    pattern = os.path.join(output_dir, f"{base_filename}_*.{extension}")
    files = glob.glob(pattern)
    
    max_index = 0
    for file in files:
        base = os.path.basename(file)
        try:
            index_str = base.split('_')[1].split('.')[0]
            index = int(index_str)
            if index > max_index:
                max_index = index
        except (IndexError, ValueError):
            continue
    
    new_index = max_index + 1
    new_filename = os.path.join(output_dir, f"{base_filename}_{new_index}.{extension}")
    
    with open(new_filename, mode='w', newline='') as csvfile:
        # Primeiro escreve as linhas de cabeçalho com os parâmetros
        for key, value in parameters.items():
            csvfile.write(f"# {key}={value}\n")
        # Linha em branco para separar (opcional)
        csvfile.write("\n")
        
        # Em seguida, salva o vetor (cada elemento separado por vírgula)
        writer = csv.writer(csvfile)
        writer.writerow(vector)
    
    print(f"Vetor salvo com sucesso em: {new_filename}")

def read_vector_csv (filepath):
    """
    Lê o arquivo CSV criado pela função save_vector_csv.
    Recupera os parâmetros (do cabeçalho) e o vetor e os retorna.
    Em seguida, imprime cada parâmetro individualmente.
    
    Retorno:
      parameters (dict): Dicionário de parâmetros.
      vector (list): Vetor lido do CSV.
    """
    parameters = {}
    vector = None
    header_lines = []
    data_lines = []
    
    with open(filepath, mode='r') as file:
        for line in file:
            line = line.rstrip("\n")
            if line.startswith("#"):
                header_lines.append(line)
            elif line.strip() != "":
                data_lines.append(line)
    
    # Processa o cabeçalho para extrair os parâmetros
    for line in header_lines:
        # Remove o caractere de comentário e espaços
        line = line.lstrip("#").strip()
        if "=" in line:
            key, val = line.split("=", 1)
            parameters[key.strip()] = val.strip()
    
    # Agora, processa os dados (vetor)
    # Aqui usamos o csv.reader para garantir o tratamento correto de separadores
    if data_lines:
        reader = csv.reader(data_lines)
        for row in reader:
            vector = row  # Considera que o vetor está em uma única linha
            break  # Apenas a primeira linha com dados
    
    # Imprime cada parâmetro individualmente
    # print("Parâmetros recuperados:")
    # for key, val in parameters.items():
    #     print(f"{key} = {val}")
    
    #print("\nVetor recuperado:")
    #print(vector)
    for i in range(len(vector)):
        vector[i]=float(vector[i])

    return parameters, vector




def interpret_choose_bar(CHOOSE_BAR):
    """
    Interpreta a string CHOOSE_BAR, que pode conter:
      - Um intervalo no formato "N-M", que retorna todos os inteiros entre N e M (inclusive);
      - Números individuais separados por underline, por exemplo "2_4_7" retorna [2, 4, 7];
      - Combinações de intervalos e números individuais, por exemplo "2-4_7" retorna [2, 3, 4, 7].
    """
    CHOOSE_BAR = CHOOSE_BAR.strip()
    # Separa a string por '_' para identificar os segmentos
    segmentos = CHOOSE_BAR.split('_')
    vet_CHOOSE_BAR = []
    
    for seg in segmentos:
        seg = seg.strip()
        # Se o segmento contém '-', trata-o como um intervalo "N-M"
        if '-' in seg:
            match = re.fullmatch(r'(\d+)-(\d+)', seg)
            if not match:
                raise ValueError(f"Formato inválido no segmento '{seg}'. Use o formato 'N-M'.")
            start, end = int(match.group(1)), int(match.group(2))
            if start > end:
                raise ValueError(f"O número à esquerda deve ser menor ou igual ao número à direita no segmento '{seg}'.")
            # Acrescenta o intervalo (todos os inteiros de start até end)
            vet_CHOOSE_BAR.extend(range(start, end + 1))
        else:
            # Caso contrário, o segmento deve ser apenas um número
            if not seg.isdigit():
                raise ValueError(f"Formato inválido no segmento '{seg}'. Espera-se um inteiro.")
            vet_CHOOSE_BAR.append(int(seg))
            
    return vet_CHOOSE_BAR



def ceifar_matriz_vetor(matriz_X, vetor_X, remover_linhas_correspondentes=True):
    """
    Remove colunas nulas de matriz_X e, opcionalmente, ceifa vetor_X para manter a coerência.
    
    Parâmetros:
    - matriz_X: np.ndarray -> Matriz de entrada (2D).
    - vetor_X: np.ndarray -> Vetor correspondente (1D).
    - remover_linhas_correspondentes: bool -> Se True, remove as mesmas linhas de vetor_X.
    
    Retorna:
    - matriz_X_ceifada: np.ndarray -> Matriz sem colunas nulas.
    - vetor_X_ceifado: np.ndarray -> Vetor ajustado (se aplicável).
    """
    matriz_X = np.array(matriz_X)
    # Identificar colunas completamente nulas (soma igual a zero)
    colunas_nulas = np.all(matriz_X == 0, axis=0)
    
    # Remover colunas nulas
    matriz_X_ceifada = matriz_X[:, ~colunas_nulas]
    
    if remover_linhas_correspondentes:
        # Remover linhas correspondentes do vetor_X
        vetor_X_ceifado = vetor_X[~colunas_nulas]
    else:
        vetor_X_ceifado = vetor_X  # Mantém o vetor original
    
    return matriz_X_ceifada, vetor_X_ceifado



def limpar_cache_legenda():
    """Limpa o cache antes de exibir uma nova legenda."""
    plt.close('all')  # Fecha todas as figuras abertas para garantir que não restem resíduos


def abrir_legenda_imagem():
    """Lê e exibe a imagem da legenda salva."""
    legend_path = "plot/temp/legend.png"
    
    if not os.path.exists(legend_path):
        print("Legenda ainda não foi gerada. Execute o gráfico primeiro.")
        return
    
    img = mpimg.imread(legend_path)
    plt.figure(figsize=(6, 6))
    plt.imshow(img)
    plt.axis("off")  # Remove os eixos
    plt.show()




def plot_evolution(deltaV_sets, selection, BarrasPV, rename_mapping=None):
    titles = {
        "1": "Evolução da Tensão",
        "2": "Evolução do Ângulo",
        "3": "Evolução Mismatch P",
        "4": "Evolução Mismatch Q"
    }

    if selection not in titles:
        print("Seleção inválida. Escolha entre '1', '2', '3' ou '4'.")
        return

    fig, ax = plt.subplots(figsize=(12, 8))
    ax.set_title(titles[selection])

    if selection == '1':
        ax.set_xlabel("Iteração")
        ax.set_ylabel("Tensão (p.u.)")
    elif selection == '2':
        ax.set_xlabel("Iteração")
        ax.set_ylabel("Ângulo de defasagem (rad)")
    elif selection == '3':
        ax.set_xlabel("Iteração")
        ax.set_ylabel("Mismatch de potência ativa P (p.u)")
    elif selection == '4':
        ax.set_xlabel("Iteração")
        ax.set_ylabel("Mismatch de potência reativa Q (p.u)")

    ax.grid()
    num_iteracoes = len(deltaV_sets[selection])
    num_barras = len(BarrasPV)

    if rename_mapping is None:
        rename_mapping = {i: f"Barra {barra}" for i, barra in enumerate(BarrasPV)}

    cores = plt.get_cmap("tab10")
    marcadores = ['o', 's', '^', 'D', 'P', 'X', '*', 'v', '>', '<']
    estilos = ['-', '--', '-.', ':']

    all_lines = []
    all_labels = []

    for i, barra in enumerate(BarrasPV):
        evolucao = [deltaV_sets[selection][j][i] for j in range(num_iteracoes)]
        cor = cores(i % 10)
        marker = marcadores[i % len(marcadores)]
        estilo = estilos[i % len(estilos)]
        label = rename_mapping.get(i, f"Barra {barra}")

        line, = ax.plot(range(num_iteracoes), evolucao, color=cor, marker=marker, linestyle=estilo, label=label)
        all_lines.append((line, barra))
        all_labels.append(label)

    cursor = mplcursors.cursor([l[0] for l in all_lines], hover=True)
    @cursor.connect("add")
    def on_add(sel):
        sel.annotation.set_text(sel.artist.get_label())
        sel.annotation.get_bbox_patch().set(alpha=0.8, fc="white")

    # Caixa de texto para filtro lateral
    # axbox = plt.axes([0.05, 0.02, 0.4, 0.03])
    # text_box = TextBox(axbox, 'Filtrar Barras', initial="1-5_7_9")

    gs_main = gridspec.GridSpec(1, 2, width_ratios=[0.9, 0.1], figure=fig)
    ax_control = fig.add_subplot(gs_main[1])
    ax_control.axis('off')
    # Texto "Filtrar Barras" acima da caixa, centralizado e ajustado
    ax_control.text(-10.7, -0.085, "Filtrar Barras", fontsize=10, ha='right')

    # Caixa de texto ajustada à direita
    text_box_ax = fig.add_axes([0.01, 0.009, 0.89, 0.03])
    text_box = TextBox(text_box_ax, '', initial="1-5_7_9")

    # Botão para aplicar filtro
    axbutton = plt.axes([0.91, 0.009, 0.060, 0.030])
    button = Button(axbutton, 'APLICAR',color='grey')

    def parse_barras(text):
        indices = set()
        for part in text.split("_"):
            if "-" in part:
                start, end = part.split("-")
                indices.update(range(int(start), int(end)+1))
            else:
                indices.add(int(part))
        return sorted(indices)

    def aplicar_callback(event):
        try:
            filtro_barras = parse_barras(text_box.text)
            for (line, barra), label in zip(all_lines, all_labels):
                if barra in filtro_barras:
                    line.set_visible(True)
                else:
                    line.set_visible(False)
            fig.canvas.draw_idle()
        except Exception as e:
            print("Erro no filtro:", e)

    button.on_clicked(aplicar_callback)

    # Legenda externa em figura separada
    fig_legenda = plt.figure(figsize=(5, 3))
    fig_legenda.canvas.manager.set_window_title('Legenda')
    num_cols = 3
    num_rows = int(np.ceil(len(all_labels) / num_cols))
    gs = gridspec.GridSpec(num_rows, num_cols, figure=fig_legenda, wspace=0.1, hspace=0.1)

    for i, (label, (line, _)) in enumerate(zip(all_labels, all_lines)):
        row = i // num_cols
        col = i % num_cols
        ax_leg = fig_legenda.add_subplot(gs[row, col])
        ax_leg.plot([0, 0.25], [0.5, 0.5], linestyle=line.get_linestyle(), color=line.get_color(), linewidth=2)
        ax_leg.text(0.4, 0.5, label, fontsize=7, va='center')
        ax_leg.set_xlim(0, 1)
        ax_leg.set_ylim(0, 1)
        ax_leg.axis('off')

    plt.show()









def add_to_DeltaV_sets(DeltaV_list, DeltaV_sets):
    """Função para adicionar um novo conjunto DeltaV_list ao DeltaV_sets com um identificador sequencial."""
    new_key = str(len(DeltaV_sets) + 1)
    DeltaV_sets[new_key] = DeltaV_list
    #print(f"Conjunto {new_key} adicionado ao DeltaV_sets.")
    return DeltaV_sets



def verificar_status(status_checarOscilacao):
    """
    Verifica se todos os elementos da lista status_checarOscilacao são 'N'.
    
    Se todos forem 'N', retorna uma tupla com:
       ('Divergencies', 'MA')
    
    Caso ao menos um elemento seja diferente de 'N', retorna:
       ('AbnormalPoints', None)
    
    Parâmetro:
      - status_checarOscilacao: lista de strings.
    
    Retorno:
      - tuple: (string, string ou None)
    """
    if all(item == 'N' for item in status_checarOscilacao):
        return 'Divergencies', 'MA'
    else:
        return 'Divergencies', None


def create_unique_tag(folder, SYSname, limite_variacao_lev, limite_variacao_pes,
                      RegimeE3, passoE3, Estrategia, limite_variacao, Tolerancia, ESCOLHER_bar):
    """
    Cria uma TAG única (em letras maiúsculas) composta de 4 ou 5 blocos, conforme as regras:
    
    1. Bloco 1: Parte de SYSname até o primeiro '_' ou '.' (sem extensão). Ex.: 'ieee9_Marcelo.cdf' -> 'IEEE9'
    
    2. Bloco 2: Se RegimeE3 for 'AMBOS' (independente de caixa) usa a letra 'A'
       seguida dos valores de limite_variacao_lev e limite_variacao_pes separados por '-'.
       Ex.: 3 e 5  → 'A3-5'
       Caso RegimeE3 seja 'PESADO' ou 'LEVE', use a letra inicial (P ou L) e em seguida o valor de limite_variacao.
       Ex.: se RegimeE3 == 'PESADO' e limite_variacao==100 → 'P100'
    
    3. Bloco 3: Baseado em passoE3 e Tolerancia. Use o prefixo 'stp' seguido dos dígitos após a vírgula de passoE3,
       depois um '-' e, em seguida, 'tol' seguido dos dígitos após a vírgula de Tolerancia.
       Ex.: 0.01 e 0.001  → 'stp01-tol001'
    
    4. Bloco 4: As três primeiras letras de Estrategia (em maiúsculas). Se Estrategia for 'ESCOLHER',
       acrescente ainda o valor de ESCOLHER_bar (sem separador adicional).
       Ex.: Estrategia='ESCOLHER' com ESCOLHER_bar='1-8' → 'ESC1-8'
    
    Esses blocos são concatenados com o caractere '_' formando a TAG base.
    
    Para garantir que a TAG seja única na pasta indicada, a função procura arquivos existentes (ou nomes de arquivos)
    que comecem com essa TAG; se encontrar, acrescenta um índice (bloco 5) no final, por exemplo:
       'IEEE9_A3-5_stp01-tol001_ESC1-8_1', 'IEEE9_A3-5_stp01-tol001_ESC1-8_2', etc.
    
    Parâmetros:
      - folder: caminho (string) da pasta onde os arquivos serão salvos (para checar duplicidade).
      - SYSname, ESCOLHER_bar, RegimeE3, Estrategia: strings.
      - limite_variacao_lev, limite_variacao_pes, limite_variacao: números (int ou float).
      - passoE3, Tolerancia: números (float).
      
    Retorna:
      - tag: string única conforme especificado.
    """
    
    # Bloco 1: extrair a parte de SYSname até o primeiro '_' ou '.'
    separadores = ['_', '.']
    base_sys = SYSname
    for sep in separadores:
        if sep in base_sys:
            base_sys = base_sys.split(sep)[0]
            break
    bloco1 = base_sys.upper()
    
    # Bloco 2: definir de acordo com RegimeE3
    regime = RegimeE3.strip().upper()
    if regime == "AMBOS":
        bloco2 = "A" + f"{limite_variacao_lev}-{limite_variacao_pes}"
    elif regime == "PESADO":
        bloco2 = "P" + str(limite_variacao)
    elif regime == "LEVE":
        bloco2 = "L" + str(limite_variacao)
    else:
        # Caso não seja nenhum dos anteriores, pode-se definir um padrão (aqui usa-se 'A')
        bloco2 = "A" + f"{limite_variacao_lev}-{limite_variacao_pes}"
    
    # Função auxiliar para extrair os dígitos após o ponto decimal
    def get_decimal_digits(value):
        s = str(value)
        if '.' in s:
            # Separa e retorna a parte depois do ponto
            return s.split('.')[1]
        else:
            return "0"
    
    # Bloco 3: com base em passoE3 e Tolerancia
    passo_digits = get_decimal_digits(passoE3)
    tol_digits = get_decimal_digits(Tolerancia)
    bloco3 = f"stp{passo_digits}-tol{tol_digits}"
    
    # Bloco 4: as três primeiras letras de Estrategia (maiúsculas).
    # Se for 'ESCOLHER', acrescenta ESCOLHER_bar (mantendo a formatação fornecida).
    bloco4 = Estrategia[:3].upper()
    if Estrategia.strip().upper() == "ESCOLHER":
        bloco4 += ESCOLHER_bar.upper()
    
    # Monta a TAG base com os 4 blocos, unidos por '_'
    base_tag = "_".join([bloco1, bloco2, bloco3, bloco4])
    
    # Verifica se na pasta já existe algum arquivo que inicie com essa TAG;
    # se sim, acrescenta um indexador (bloco 5) para torná-la única.
    tag = base_tag
    index = 1
    if os.path.isdir(folder):
        existing = os.listdir(folder)
    else:
        # Se a pasta não existir, considere que não há duplicatas.
        existing = []
        
    # Enquanto houver algum nome (arquivo ou pasta) que comece com a tag atual, incremente o índice.
    while any(name.startswith(tag) for name in existing):
        tag = f"{base_tag}_{index}"
        index += 1
    
    return tag


def create_unique_tag2(folder, tamanho):

    #tamanho = 118
    bloco1 = f"IEEE{tamanho}"
    
    
    # Função auxiliar para extrair os dígitos após o ponto decimal
    def get_decimal_digits(value):
        s = str(value)
        if '.' in s:
            # Separa e retorna a parte depois do ponto
            return s.split('.')[1]
        else:
            return "0"
    
    # Bloco 3: com base em passoE3 e Tolerancia
    #passo_digits = get_decimal_digits(passoE3)
    # tol_digits = get_decimal_digits(Tolerancia)
    #bloco3 = f"stp{passo_digits}-tol{tol_digits}"
    # bloco2 = f"tol{tol_digits}"

    # if LogSupl!=None:
    #     bloco3 = f"ls{LogSupl}"
    # else:
    #      bloco3 = f"lsNo"
    
    # Monta a TAG base com os 4 blocos, unidos por '_'
    #base_tag = "_".join([bloco1, bloco2, bloco3, bloco4])
    base_tag = "_".join([bloco1])
    
    # Verifica se na pasta já existe algum arquivo que inicie com essa TAG;
    # se sim, acrescenta um indexador (bloco 5) para torná-la única.
    tag = base_tag
    
    index = 1
    if os.path.isdir(folder):
        existing = os.listdir(folder)
    else:
        # Se a pasta não existir, considere que não há duplicatas.
        existing = []
        
    # Enquanto houver algum nome (arquivo ou pasta) que comece com a tag atual, incremente o índice.
    while any(name.startswith(tag) for name in existing):
        tag = f"{base_tag}_{index}"
        index += 1
    
    return tag



# --- Função para salvar as matrizes e a especificação em um arquivo CSV ---
def save_matrices(matrices, file_suffix, specification):
    """
    Salva as matrizes em um arquivo CSV na pasta 'plot/GoPVcurve'.
    
    Espera que:
      matrices[0] -> matriz 2D (lista de listas)
      matrices[1] -> vetor (lista)
    
    O arquivo será nomeado com file_suffix.
    
    A especificação (lista de strings ou dicionário) é escrita no cabeçalho.
    """
    save_dir = os.path.join(os.getcwd(), "plot", "GoPVcurve")
    os.makedirs(save_dir, exist_ok=True)
    filename = f"{file_suffix}.csv"
    filepath = os.path.join(save_dir, filename)
    
    with open(filepath, mode='w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        
        # Escreve o cabeçalho fixo com a especificação:
        writer.writerow(["# ============================================================================="])
        writer.writerow(["# SEÇÃO 1: ESPECIFICAÇÃO DO ESTUDO 3 - GENERATOR OF PV-CURVE"])
        writer.writerow(["# ============================================================================="])
        writer.writerow([])
        writer.writerow(["''' ESPECIFICAÇÃO '''"])
        # Se specification for um dicionário, escreve cada par; se for uma lista de strings, escreve-as
        if isinstance(specification, dict):
            for key, value in specification.items():
                writer.writerow([f"{key}={value}"])
        else:
            for line in specification:
                writer.writerow([line])
        writer.writerow([])  # separa do restante
        
        # Escreve a matriz 0
        writer.writerow(["EvolutionMatrixMatriz2[0]"])
        for row in matrices[0]:
            writer.writerow(row)
        
        # Escreve o vetor (matriz 1)
        writer.writerow(["EvolutionMatrixMatriz2[1]"])
        writer.writerow(matrices[1])
    
    print(f"Matrizes e especificação salvos em: {filepath}")

# --- Função para ler o arquivo CSV e recuperar as duas matrizes ---
def load_matrices(filepath):
    """
    Lê o arquivo CSV salvo e retorna uma tupla: (matrix0, matrix1)
    Ignora o cabeçalho até encontrar a seção "EvolutionMatrixMatriz2[0]".
    """
    matrix0 = []
    matrix1 = []
    current_section = None
    
    with open(filepath, mode='r', newline='') as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            if not row:
                continue  # ignora linhas vazias
            if row[0] == "EvolutionMatrixMatriz2[0]":
                current_section = "matrix0"
                continue
            elif row[0] == "EvolutionMatrixMatriz2[1]":
                current_section = "matrix1"
                continue
            
            if current_section == "matrix0":
                try:
                    matrix0.append([float(x) for x in row])
                except Exception as e:
                    print("Erro convertendo linha para matrix0:", e)
            elif current_section == "matrix1":
                try:
                    matrix1 = [float(x) for x in row]
                except Exception as e:
                    print("Erro convertendo linha para matrix1:", e)
    
    return matrix0, matrix1






# Função corrigir duplicidade
def corrige_duplicidadeDeLinha(matriz):
    matriz_corrigida = []
    linhas_removidas = set()
    for i in range(len(matriz)):
        if i in linhas_removidas:
            continue
        for j in range(i + 1, len(matriz)):
            if matriz[i][0] == matriz[j][0] and matriz[i][1] == matriz[j][1]:
                for k in range(6, 9):
                    matriz[i][k] = (matriz[i][k] * matriz[j][k]) / (matriz[i][k] + matriz[j][k]) if (matriz[i][k] + matriz[j][k]) != 0 else 0
                linhas_removidas.add(j)
        matriz_corrigida.append(matriz[i])
    return matriz_corrigida

def corrigir_LerArquivo(novalinha):
    # Identificar os valores diferentes de ''
    nao_vazios = [item for item in novalinha if item != '']

    # Verificar a quantidade de valores não vazios
    if len(nao_vazios) == 20:
        # Verificar se o terceiro item não vazio não é um número inteiro
        terceiro_nao_vazio = nao_vazios[2]
        if not terceiro_nao_vazio.isdigit():
            # Concatenar o segundo item com o terceiro não vazio
            segundo_nao_vazio = nao_vazios[1]
            concatenado = f"{segundo_nao_vazio}_{terceiro_nao_vazio}"

            # Substituir o terceiro item não vazio pelo primeiro item não vazio
            primeiro_nao_vazio = nao_vazios[0]

            # Atualizar novalinha
            for i in range(len(novalinha)):
                if novalinha[i] == segundo_nao_vazio:
                    novalinha[i] = concatenado
                elif novalinha[i] == terceiro_nao_vazio:
                    novalinha[i] = primeiro_nao_vazio

    elif len(nao_vazios) == 19:
        # Inserir um novo item não vazio após o segundo item não vazio
        primeiro_nao_vazio = nao_vazios[0]
        segundo_nao_vazio = nao_vazios[1]
        index_segundo = novalinha.index(segundo_nao_vazio)
        novalinha.insert(index_segundo + 1, primeiro_nao_vazio)

    elif len(nao_vazios) == 18:
        # Inserir um novo item não vazio após o segundo item não vazio
        primeiro_nao_vazio = nao_vazios[0]
        segundo_nao_vazio = nao_vazios[1]
        index_segundo = novalinha.index(segundo_nao_vazio)
        novalinha.insert(index_segundo + 1, primeiro_nao_vazio)

        # Verificar se o segundo item tem um número inteiro concatenado com uma palavra
        match = re.match(r"(\D+)(\d+)", segundo_nao_vazio)
        if match:
            palavra, numero = match.groups()
            index_terceiro = novalinha.index(primeiro_nao_vazio, index_segundo + 1)
            novalinha.insert(index_terceiro + 1, numero)

    return novalinha



def Ler_Arquivo(caminho):
    matrizSystem=[]
    matrizSystem2=[]

    arquivo = open(caminho, 'r')
    linha = arquivo.readline()
    #print(linha)
    count=0
    count2=0
    count3=0
    

    while linha!="":
    # print(linha)
        linha = arquivo.readline()
        count+=1
        
        if (count >= 4 and count2==0):
            novalinha = linha.split(' ')
            novalinha = corrigir_LerArquivo(novalinha)
            # valor=len(novalinha)
            # print (novalinha)
            MatrizAux=[]
            
            for valor in range(len(novalinha)):
                if novalinha[valor] != '':
                    novalinha[valor] = novalinha[valor].replace('\n','')
                    #print (novalinha[valor])
                    if novalinha[valor] == '-999':
                        count2=count
                        break
                    MatrizAux.append(novalinha[valor])

            if len(MatrizAux) != 0:
                matrizSystem.append(MatrizAux)        
                    
                
                #print("-------")
                #print(count2)

        # print("*********")
        # print (count)
        # print (count2)
        # print("-------")
        if count2 != 0:
            #print("ok")
            if count >= count2+4:
                novalinha = linha.split(' ')
                valor=len(novalinha)
                #print (novalinha)
                #print (valor)
                MatrizAux2=[]
                for valor in range(len(novalinha)):
                    if novalinha[valor] != '':
                        novalinha[valor] = novalinha[valor].replace('\n','')
                        #print (novalinha[valor])
                        MatrizAux2.append(novalinha[valor])
                
                    if novalinha[valor] == '-999':
                        count3=count
                        return ([matrizSystem],[matrizSystem2]) 

                matrizSystem2.append(MatrizAux2)

        #print (matrizSystem)
        

        for m in range(len(matrizSystem)):
            for n in range(len(matrizSystem[m])):
                if (n>6):
                    matrizSystem[m][n]=float(matrizSystem[m][n])
                if (n==0 or n==2 or n==4 or n==5 or n==6):
                    matrizSystem[m][n]=int(matrizSystem[m][n])


        for m in range(len(matrizSystem2)):
            for n in range(len(matrizSystem2[m])):
                if (n==6 or n==7 or n==8 or n>13):
                    matrizSystem2[m][n]=float(matrizSystem2[m][n])
                if (n<6 or n==9 or n==10 or n==11 or n==12 or n==13):
                    matrizSystem2[m][n]=int(matrizSystem2[m][n])
        #print ('-------')
        #print (matrizSystem2,matrizSystem)
        #break

    arquivo.close()
    
    
def DefineMatrizDadosBarra (matrizSystem, S_base, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento,alterar_tensao_decontrole_doCDF):
    
    matriz_DadosBarra=[0]*8
    # Aux=[0]*len(matrizSystem)
    # for i in range (len(matriz_DadosBarra)):
    #     matriz_DadosBarra[i]=Aux
    # print("----")
    # print (matriz_DadosBarra)
   # MAuxBshunt=[0]*len(matrizSystem)
    Aux0=[0]*len(matrizSystem)
    Aux1=[0]*len(matrizSystem)
    Aux2=[0]*len(matrizSystem)
    Aux3=['N']*len(matrizSystem)
    Aux4=[0]*len(matrizSystem)
    Aux5=[0]*len(matrizSystem)
    Aux6=['N']*len(matrizSystem)
    Aux7=[0]*len(matrizSystem)
    Aux8=[0]*len(matrizSystem)
    Aux9=['-----|>']*len(matrizSystem)

    Gexistente=['N']*len(matrizSystem)
    #HabiltAval_Lim_Reativo='N'
    NaoH=['N']*len(matrizSystem)

    if (status_program=='CDF'): ### SE "CDF" (DEVE ENTRAR AQUI)
        for i in range (5):
            if (i==0):
                for j in range(len(matrizSystem)):
                    Aux0[j]=matrizSystem[j][18]
            if (i==1):
                for j in range(len(matrizSystem)):
                    if matrizSystem[j][9]!=0:
                        Aux1[j]=(-1)*matrizSystem[j][9]/S_base
                    else:
                        Aux1[j]=0.0
            if (i==2):
                for j in range(len(matrizSystem)):
                    Aux2[j]=(-1)*matrizSystem[j][10]/S_base
            if (i==3):
                for j in range(len(matrizSystem)):
                    if (matrizSystem[j][15]!=0 or matrizSystem[j][16]!=0):
                        #HabiltAval_Lim_Reativo='Y'
                        Aux3[j]='Y'
                        Aux4[j]=matrizSystem[j][16]/S_base
                        Aux5[j]=matrizSystem[j][15]/S_base
            if (i==4):
                for j in range(len(matrizSystem)):
                        if (matrizSystem[j][11]!=0 or j==0):
                            Aux6[j]='Y'
                            Aux7[j]=matrizSystem[j][11]/S_base
                            if j==0:
                                Aux9[j]='swing'
                            else:
                                Aux9[j]='G'

        for j in range(len(Aux8)):
            if (matrizSystem[j][14]!=0):
                Aux8[j]=matrizSystem[j][14]


        if HabiltAval_Lim_Reativo=='Y':
            # print("--------------------------------------------------")
            # print("FOI IDENTIFICADO EQUIPAMENTOS DE BARRA CAPAZES DE CONTROLAR REATIVO (G OU CS).")
            # print("DESEJA HABILITAR CONTROLE DE LIMITES DE REATIVO (Y OR N)?")
            # habilitar = str(input("RESPOSTA: "))
            # print("--------------------------------------------------")
            habilitar = HabiltAval_Lim_Reativo
        else:
            habilitar ='N'
            # if (habilitar=='Y' or habilitar=='y'):
            #     prossiga='Y'
            # else
        if habilitar=='Y':
            for j in range(len(Aux9)):
                if j>0:
                    if (Aux7[j]==0 and (Aux5[j] or Aux4[j])>0):
                        Aux9[j]='CS'

        Vcontrol=[]
        Barra_Vctrl=[]
        TipoBarra_Vctrl=[]
        for j in range(len(Aux9)):
            if (Aux9[j]=='swing' or Aux9[j]=='G' or Aux9[j]=='CS'):
                Vcontrol.append(Aux8[j])
                Barra_Vctrl.append(j+1)
                TipoBarra_Vctrl.append(Aux9[j])

        # print("--------------------------------------------------")
        # print("TODOS AS BARRAS CAPAZES DE CONTROLAR TENSÃO SÃO...")
        # print(Barra_Vctrl)
        # print(TipoBarra_Vctrl)
        # print("E SUAS TENSÕES DE CONTROLE IDENTIFICADAS SÃO......")
        # print(Vcontrol)

        # print("--------------------------------------------------")
        # print("DESEJA ALTERAR ALGUMA DELAS (QUALQUER BARRA DO SISTEMA**)? (A* or B or C)")
        # print("\n")
        # print("nota (*): A - Altera apenas barras CONTROLADAS")
        # print("          B - Altera TODAS as barras que se queira")
        # print("          X - Não altera NENHUMA tensao de controle permanecendo as mesmas")
        # print("nota (**): para fins didaticos o programa permite o controle da tensão de")
        # print("           de QUALQUER barra do sistema e não só aquelas pré-determinadas")
        # alterarVcontolVal=str(input("RESPOSTA: "))
        alterarVcontolVal=alterar_tensao_decontrole_doCDF

        
        if  (alterarVcontolVal=='A' or alterarVcontolVal=='a'):
            print("DIGITE UM NÚMERO VÁLIDO ENTRE O VETOR ", Barra_Vctrl)

            alterarVctrl=[0]*len(Vcontrol)
            print("QUAIS VOCE DEVE ALTERAR? (NdaBarra+enter)")
            #desbloqueador=='roda'
            #valorBVdigitado=0
            
            cont=0
            
            for j in range(len(Vcontrol)):
                valorBVdigitado=int(input("RESPOSTA: "))
                if valorBVdigitado==0:
                    break

                for k in range(len(Vcontrol)):
                    if alterarVctrl[k]==valorBVdigitado:
                        print("Barra já digitada!")
                        valorBVdigitado=-1

                rodar='nao'
                for k in range(len(Vcontrol)):
                    if (valorBVdigitado==Barra_Vctrl[k]):
                        rodar='sim'
                            

                while (valorBVdigitado<0 or valorBVdigitado>len(Aux8) or rodar=='nao'):
                    # print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
                    # print("!!!!!                A BARRA DIGITADA NÃO EXISTE                     !!!!!")
                    # print("!!!!!                    ", valorBVdigitado ,"                       !!!!!")
                    # print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
                    print("DIGITE UM NÚMERO VÁLIDO ENTRE O VETOR ", Barra_Vctrl)
                    print("--------------------------------------------------------------------------")
                    valorBVdigitado=int(input("RESPOSTA: "))
                    if valorBVdigitado==0:
                        break
                    for m in range(len(Barra_Vctrl)):
                        if alterarVctrl[m]==valorBVdigitado:
                            print("Barra já digitada!")
                            valorBVdigitado=-1
                    rodar='nao'
                    for n in range(len(Vcontrol)):
                        if (valorBVdigitado==Barra_Vctrl[n]):
                            rodar='sim'

                # print("0k")
                alterarVctrl[j]=valorBVdigitado
                cont=cont+1

            for m in range(len(Barra_Vctrl)):
                for n in range(len(Barra_Vctrl)):
                    if (alterarVctrl[m]==Barra_Vctrl[n]):
                        print("DIGITE A TENSÃO EM PU DA BARRA ", Barra_Vctrl[n])
                        Vcontrol[n]=float(input("RESPOSTA: "))
            
            ordenarAlterarVctrl=[0]*len(Aux8)
            for i in range (len(alterarVctrl)):
                for j in range (len(alterarVctrl)):
                    if (alterarVctrl[i]==j+1):
                        ordenarAlterarVctrl[j]=j+1
            
            RefAux2=ordenarAlterarVctrl
                        
                            
        if  (alterarVcontolVal=='B' or alterarVcontolVal=='b'):
            VctrlRef=[0]*len(Aux8)
            alterarVctrl=[0]*len(Aux8)
            
            for i in range (len(Aux8)):
                VctrlRef[i]=i+1
            
            print("QUAIS VOCE DEVE ALTERAR? (NdaBarra+enter)")
            #desbloqueador=='roda'
            #valorBVdigitado=0
            
            cont=0
            for j in range(len(Aux8)):
                valorBVdigitado=int(input("RESPOSTA: "))
                if valorBVdigitado==0:
                    break

                for k in range(len(Aux8)):
                    if alterarVctrl[k]==valorBVdigitado:
                        print("Barra já digitada!")
                        valorBVdigitado=-1

                while (valorBVdigitado<0 or valorBVdigitado>len(Aux8)):
                        # print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
                        # print("!!!!!                A BARRA DIGITADA NÃO EXISTE                     !!!!!")
                        # print("!!!!!                    ", valorBVdigitado ,"                       !!!!!")
                        # print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
                        print("DIGITE UM NÚMERO VÁLIDO ENTRE 1 E ", len(matrizSystem))
                        print("--------------------------------------------------------------------------")
                        valorBVdigitado=int(input("RESPOSTA: "))
                        if valorBVdigitado==0:
                            break
                        for k in range(len(Aux8)):
                            if alterarVctrl[k]==valorBVdigitado:
                                print("Barra já digitada!")
                                valorBVdigitado=-1

                # print("0k")
                alterarVctrl[j]=valorBVdigitado
                cont=cont+1

            RefAux=[0]*len(Aux8)
            # for i in range(len(Aux8)):
            #     RefAux[i]=i+1
            
            #RefAux=VctrlRef
            # print (alterarVctrl)
            # print (Barra_Vctrl)
            # print('aqui')

            ordenarAlterarVctrl=[0]*len(Aux8)
            for i in range (len(alterarVctrl)):
                for j in range (len(alterarVctrl)):
                    if (alterarVctrl[i]==j+1):
                        ordenarAlterarVctrl[j]=j+1

            for m in range(len(Aux8)):
                for n in range(len(Barra_Vctrl)):
                    if (alterarVctrl[m]!=0):
                        if (alterarVctrl[m]==Barra_Vctrl[n]):
                            print("DIGITE A TENSÃO EM PU DA BARRA ", Barra_Vctrl[n])
                            RefAux[m]=Barra_Vctrl[n]
                            Vcontrol[n]=float(input("RESPOSTA: "))
                #RefAux[m]=auxiliar      
            
            RefAux2=[0]*len(Aux8)
            for i in range (len(RefAux)):
                for j in range (len(RefAux)):
                    if (RefAux[i]==j+1):
                        RefAux2[j]=j+1
            # print(RefAux)
            # print(ordenarAlterarVctrl)
            # print('aqui2')
            
            for j in range(len(RefAux2)):
                if  (ordenarAlterarVctrl[j]!=0):
                    if (ordenarAlterarVctrl[j]!=RefAux2[j]):
                        print("DIGITE A TENSÃO EM PU DA BARRA ", ordenarAlterarVctrl[j])
                        Vcontrol.append(float(input("RESPOSTA: ")))
                        Barra_Vctrl.append(ordenarAlterarVctrl[j])
                        TipoBarra_Vctrl.append('G')
        
        if  (alterarVcontolVal!='A' or alterarVcontolVal!='a'or alterarVcontolVal!='B'or alterarVcontolVal!='b'):
            ordenarAlterarVctrl=[0]*len(Aux8)
            for i in range (len(Barra_Vctrl)):
                for j in range (len(Aux8)):
                    if (Barra_Vctrl[i]==j+1):
                        ordenarAlterarVctrl[j]=j+1
            
            RefAux2=ordenarAlterarVctrl

        # print('******')
        # #print(VctrlRef)

        Vcontrol_extendido=[0]*len(Aux8)
        Barra_Vctrl_extendido=[0]*len(Aux8)
        TipoBarra_Vctrl_extendido=['-']*len(Aux8)
        for i in range (len(Vcontrol)):
            for j in range (len(Barra_Vctrl_extendido)):
                if (Barra_Vctrl[i]==j+1):
                    Barra_Vctrl_extendido[j]=j+1
                    Vcontrol_extendido[j]=Vcontrol[i]
                    TipoBarra_Vctrl_extendido[j]=TipoBarra_Vctrl[i]

        # print(Vcontrol)
        # print(Barra_Vctrl)
        # print(TipoBarra_Vctrl)
        # print('******')
        # print(Vcontrol_extendido)
        # print(Barra_Vctrl_extendido)
        # print(TipoBarra_Vctrl_extendido)
        # print('hhhhhhh')
        infoVctrl=[]
        for i in range(2):
            if (i==0):
                infoVctrl.append(TipoBarra_Vctrl_extendido)
            if (i==1):
                infoVctrl.append(Vcontrol_extendido)

        for i in range(len(TipoBarra_Vctrl_extendido)):
            if (TipoBarra_Vctrl_extendido[i]=='G'):
                Aux6[i]='Y'
                if (ordenarAlterarVctrl[i]!=RefAux2[i]):
                    print("DESEJA ALTERAR A POTÊNCIA ATIVA DA NOVA BARRA DE CONTROLE DE TENSÃO? BARRA: ", ordenarAlterarVctrl[i])
                    print("NA PRÁTICA ESSA BARRA PASSA A SER DE GERAÇÃO.", )
                    POTCONT=str(input("RESPOSTA: "))
                    if (POTCONT=='y' or POTCONT=='Y'):
                        Aux7[i]=float(input("POTENCIA (PU): "))
                                    
    else: ### SE "MANUAL" (DEVE ENTRAR AQUI)
        habilitar = HabiltAval_Lim_Reativo
        TipoBarra_Vctrl_extendido=['-']*len(Aux9)
        
        if MODELin=='PI':
            for j in range(len(matrizSystem)):
                Aux0[j]=matrizSystem[j][18]

            for lin in range(len(MatrizCarregamento)):
                for j in range(len(MatrizCarregamento[0])):
                    if (j>1):
                        if (MatrizCarregamento[lin][0]=='P'):
                            Aux1[j-2]=MatrizCarregamento[lin][j]/S_base
                        if (MatrizCarregamento[lin][0]=='Q'):
                            Aux2[j-2]=MatrizCarregamento[lin][j]/S_base
                        if (MatrizCarregamento[lin][0]=='Qmin_idx'):
                             if (MatrizCarregamento[lin+1][0]=='Qmin' and MatrizCarregamento[lin+3][0]=='Qmax'):
                                if (MatrizCarregamento[lin][j]!=-1):                            
                                    Aux3[j-2]='Y'
                                    Aux4[j-2]=MatrizCarregamento[lin+1][j]/S_base
                                    Aux5[j-2]=MatrizCarregamento[lin+3][j]/S_base
                        if (MatrizCarregamento[lin][0]=='G_idx'):
                            if (MatrizCarregamento[lin+1][0]=='G'):
                                if (MatrizCarregamento[lin][j]!=-1):
                                    Aux6[j-2]='Y'
                                    Aux7[j-2]=MatrizCarregamento[lin+1][j]/S_base
                                    TipoBarra_Vctrl_extendido[j-2]='G'
            
            TipoBarra_Vctrl_extendido[0]='swing'
            for m in range(len(Aux3)):
                if (Aux3[m]=='Y' and TipoBarra_Vctrl_extendido[m]!='G'):
                    TipoBarra_Vctrl_extendido[m]='CS'
            
            for n in range(len(TipoBarra_Vctrl_extendido)):
                if (MatrizCarregamento[0][n+2]!=-1):
                    if(MatrizCarregamento[1][0]=='PV'):
                        Aux8[n]=MatrizCarregamento[1][n+2]
                else:
                    Aux8[n]=0

            infoVctrl=[]
            for i in range(2):
                if (i==0):
                    infoVctrl.append(TipoBarra_Vctrl_extendido)
                if (i==1):
                    infoVctrl.append(Aux8)
            

        elif MODELin=='T':
            print('AINDA DEVE MODELAR PARA T')
            exit()
    



    ### MODELAR MINHA MATRIZ DE CONTROLE INTERNO
    Aux6[0]='N'
    for k in range(8):
        if k==0:
            matriz_DadosBarra[k]=Aux0
        if k==1:
            matriz_DadosBarra[k]=Aux1
        if k==2:
            matriz_DadosBarra[k]=Aux2
        if k==3:
            if (habilitar=='Y' or habilitar=='y'):
                matriz_DadosBarra[k]=Aux3
            else:
                matriz_DadosBarra[k]=NaoH
        if k==4:
            matriz_DadosBarra[k]=Aux4
        if k==5:
            matriz_DadosBarra[k]=Aux5
        if k==6:
            matriz_DadosBarra[k]=Aux6
        if k==7:
            matriz_DadosBarra[k]=Aux7
    return ([matriz_DadosBarra],[infoVctrl])




def aumenta_Potindex (vetor_entrada, tamanho_vetor_resposta):
    # Inicializa o vetor de resposta com zeros
    vetor_resposta = [0] * tamanho_vetor_resposta
    
    # Percorre o vetor de resposta
    for i in range(tamanho_vetor_resposta):
        # Verifica se o índice + 1 está no vetor de entrada
        if i  in vetor_entrada:
            # Se estiver, define o valor do vetor de resposta
            vetor_resposta[i] = i 

    return vetor_resposta


def aumenta_Pot(vetor_indices, vetor_valores, tamanho_vetor_resposta):
    # Inicializa o vetor de resposta com zeros
    vetor_resposta = [0] * tamanho_vetor_resposta
    
    # Percorre o vetor de resposta
    for i in range(tamanho_vetor_resposta):
        # Verifica se o índice + 1 está no vetor de índices
        if (i) in vetor_indices:
            # Obtém a posição correspondente no vetor de valores
            posicao = vetor_indices.index(i)
            vetor_resposta[i] = vetor_valores[posicao]

    return vetor_resposta






""" 

!!!!!!!!!!!!!!!!!!!!!!!!!!!!

SECOND SECTION OF FUNCTIONS

!!!!!!!!!!!!!!!!!!!!!!!!!!!!

"""

def inverter_positionTAP(matrizSystem2,Ativar_inverter):
    matrizSystem20=np.array(matrizSystem2)
    matrizSystem21=np.array(matrizSystem2)
    if Ativar_inverter=='no':
        for aux in range(len(matrizSystem2)):
            if matrizSystem2[aux][14]!=0:
                matrizSystem20[aux][14]=1/matrizSystem2[aux][14]
                matrizSystem21[aux][14]=1      
    elif Ativar_inverter=='yes':
        for aux in range(len(matrizSystem2)):
            if matrizSystem2[aux][14]!=0:
                matrizSystem21[aux][14]=1/matrizSystem2[aux][14]
                matrizSystem20[aux][14]=1               
    return matrizSystem20, matrizSystem21




def inverter_positionTAP2(vetor,Ativar_inverter='no',GirarTrafo='no'):
    vet_saida20=[0]*len(vetor)
    vet_saida21=[0]*len(vetor)
    #GirarTrafo='no'
    if Ativar_inverter=='yes':
        if GirarTrafo=='no':
            for aux in range(len(vetor)):
                if vetor[aux]!=0:
                    vet_saida20[aux]=1/vetor[aux]
                    vet_saida21[aux]=1 
        else:
            for aux in range(len(vetor)):
                if vetor[aux]!=0:
                    vet_saida20[aux]=1
                    vet_saida21[aux]=1/vetor[aux]                     
          
    elif Ativar_inverter=='no':
        if GirarTrafo=='no':        
            for aux in range(len(vetor)):
                if vetor[aux]!=0:
                    vet_saida20[aux]=vetor[aux]
                    vet_saida21[aux]=1 
        else:
            for aux in range(len(vetor)):
                if vetor[aux]!=0:
                    vet_saida20[aux]=1
                    vet_saida21[aux]=vetor[aux]              
               
    return vet_saida20, vet_saida21








def calcularMATRIZ_Y (matrizSystem, matrizSystem2, Ativar_inverter, GirarTrafo):
        
    V_Barra=[]
    V_BarraVal=[]
    #Ativar_inverter='yes'
    matrizSystem2tapn=[0]*len(matrizSystem2)
    matrizSystem2tapm=[0]*len(matrizSystem2)
    #GirarTrafo='no'
    for aux in range(len(matrizSystem2)):
        matrizSystem2tapn[aux]=matrizSystem2[aux][14]
        matrizSystem2tapm[aux]=matrizSystem2[aux][14]

    
    vetTAP , _ =inverter_positionTAP2(matrizSystem2tapn,Ativar_inverter,GirarTrafo)
    for x in range(len(matrizSystem2)):
        V_Barra.append([matrizSystem2[x][0],matrizSystem2[x][6],matrizSystem2[x][7],matrizSystem2[x][8], vetTAP[x] ,matrizSystem2[x][1]])
        #V_BarraVal.append(matriz_DadosConexao[x][6]

    _ , vetTAP =inverter_positionTAP2(matrizSystem2tapm,Ativar_inverter,GirarTrafo)
    for x in range(len(matrizSystem2)):
        V_Barra.append([matrizSystem2[x][1],matrizSystem2[x][6],matrizSystem2[x][7],matrizSystem2[x][8], vetTAP[x] ,matrizSystem2[x][0]])
        #V_BarraVal.append(matriz_DadosConexao[x][6])


    # print(V_Barra)  
    # print ("------", len(V_Barra))
    matriz_ordenada = sorted(V_Barra)
    #for aux in range(len(matriz_ordenada)):
    #    print ("Essa é a informaçao da matriz_ordenada",float(matriz_ordenada[aux][3]))
    # print(matriz_ordenada)  
    # exit()


    MatrixY_aux=[0]*len(matriz_ordenada)
    for k in range(len(matriz_ordenada)):
        MatrixY_aux_lin=[0]*4
        for l in range (4):
            if (l==0):
                MatrixY_aux_lin[0]=matriz_ordenada[k][0]
            if (l==1):
                if (matriz_ordenada[k][4]!=0): #Se for TRAFO
                    MatrixY_aux_lin[1]=((matriz_ordenada[k][4])**2)*(1/complex(matriz_ordenada[k][1],matriz_ordenada[k][2]))
                else: #Se for LINHA
                    #print (+(1/complex(matriz_ordenada[k][1],matriz_ordenada[k][2])), k)
                    MatrixY_aux_lin[1]=complex(0,(1/2)*((matriz_ordenada[k][3])))+(1/complex(matriz_ordenada[k][1],matriz_ordenada[k][2]))  ## IEEE30 or IEEE118 (linha em T)
                    #MatrixY_aux_lin[1]=complex(0,((+1/2)*(matriz_ordenada[k][3])))+(1/complex(matriz_ordenada[k][1],matriz_ordenada[k][2]))
            if (l==2):
                if (matriz_ordenada[k][4]!=0):
                    MatrixY_aux_lin[2]=-matriz_ordenada[k][4]*(1/complex(matriz_ordenada[k][1],matriz_ordenada[k][2]))
                else:
                    MatrixY_aux_lin[2]=-(1/complex(matriz_ordenada[k][1],matriz_ordenada[k][2]))
            if (l==3):
                MatrixY_aux_lin[3]=matriz_ordenada[k][5]
        MatrixY_aux[k]=MatrixY_aux_lin

    #print(MatrixY_aux)
    MatrixY_dig=[0]*len(matrizSystem)


    #print('----------------')
    

    for k in range(len(matrizSystem)):
        Aux1=0
        for l in range(len(MatrixY_aux)):
                if (k+1==MatrixY_aux[l][0]):
                    Aux1=Aux1+MatrixY_aux[l][1]
        MatrixY_dig[k]=Aux1

    #print(MatrixY_dig)

    MatrizY=[0]*len(matrizSystem)

    for m in range(len(matrizSystem)):
        MatrizY_lin=[0]*len(matrizSystem)
        for n in range(len(matrizSystem)):
            if m==n:
                aux=procurar_valor_na_coluna(matrizSystem, m+1, 0, 18)
                # print(aux)
                # print(n)
                # exit()
                MatrizY_lin[m]=MatrixY_dig[m]+complex(0,aux)
                #print('COMPLEXO: ',complex(0,aux))
            if n>m:
                for j in range(len(MatrixY_aux)):
                    #for k in range(len(MatrixY_aux)):
                        #if (MatrixY_aux[j][0]==m and MatrixY_aux[k][3]==n):
                        if (MatrixY_aux[j][0]==m+1 and MatrixY_aux[j][3]==n+1):
                            MatrizY_lin[n]=(MatrixY_aux[j][2])
                        # else:
                        #     MatrizY.append(0)
            if n<m:
                for j in range(len(MatrixY_aux)):
                    #for k in range(len(MatrixY_aux)):
                        #if (MatrixY_aux[j][0]==m and MatrixY_aux[k][3]==n):
                        if (MatrixY_aux[j][0]==n+1 and MatrixY_aux[j][3]==m+1):
                            MatrizY_lin[n]=(MatrixY_aux[j][2])
                        # else:
                        #     MatrizY.append(0)
        MatrizY[m]=MatrizY_lin
    return MatrizY


### LOOP PRINCIPAL:
def calcularDeltas (NB, Barras_PQ, matriz_DadosBarra, MatrizG, MatrizB,Tensao, Def_Ang, VerificaSeViola):
    deltaP=[0]*(NB)
    deltaQ=[0]*(NB)

    for k in range(NB):
        somaP=0
        somaQ=0
        if k==0:
            deltaP[k]=0
            #deltaQ[k]=0
        else:
            potP_liq=(matriz_DadosBarra[1][k]+matriz_DadosBarra[7][k])
            for aux in range(NB):
                somaP=somaP+Tensao[aux]*(MatrizG[k][aux]*math.cos(Def_Ang[k]-Def_Ang[aux])+MatrizB[k][aux]*math.sin(Def_Ang[k]-Def_Ang[aux]))
                #print ('soma1:',soma)
                #print ('soma2:',soma)

            deltaP[k]=potP_liq-Tensao[k]*somaP
            
        if (Barras_PQ[k]=='Y'):
                if matriz_DadosBarra[3][k]=="Y":
                    if (VerificaSeViola[k]=="ViolaPB"):
                        potQ_liq=(matriz_DadosBarra[2][k]+matriz_DadosBarra[4][k]) #Soma apenas pq a carga sempre entra negativa
                        for aux in range(NB):
                            somaQ=somaQ+Tensao[aux]*(MatrizG[k][aux]*math.sin(Def_Ang[k]-Def_Ang[aux])-MatrizB[k][aux]*math.cos(Def_Ang[k]-Def_Ang[aux]))
                        deltaQ[k]=potQ_liq-Tensao[k]*somaQ 
                    if (VerificaSeViola[k]=="ViolaPC"):
                        potQ_liq=(matriz_DadosBarra[2][k]+matriz_DadosBarra[5][k])
                        for aux in range(NB):
                            somaQ=somaQ+Tensao[aux]*(MatrizG[k][aux]*math.sin(Def_Ang[k]-Def_Ang[aux])-MatrizB[k][aux]*math.cos(Def_Ang[k]-Def_Ang[aux]))
                        deltaQ[k]=potQ_liq-Tensao[k]*somaQ 
                else:
                    potQ_liq=(matriz_DadosBarra[2][k])
                    for aux in range(NB):
                        somaQ=somaQ+Tensao[aux]*(MatrizG[k][aux]*math.sin(Def_Ang[k]-Def_Ang[aux])-MatrizB[k][aux]*math.cos(Def_Ang[k]-Def_Ang[aux]))
                    deltaQ[k]=potQ_liq-Tensao[k]*somaQ
        else:
                deltaQ[k]=0

    return ([deltaP],[deltaQ])

def organizarDeltas (NPV, NPQ, Barras_PQ, deltaP, deltaQ):
    Barras_Q_val=[]
    for k in range(len(Barras_PQ)):
        if (Barras_PQ[k]=='Y'):
            Barras_Q_val.append(deltaQ[k])

    DeltaPQ=[]
    for k in range(2*NPQ+NPV):
        if (k<NPQ+NPV):
            DeltaPQ.append(deltaP[k+1])
        else:
            DeltaPQ.append(Barras_Q_val[k-(NPQ+NPV)])

    return DeltaPQ

def voltarDeltas (NPV, NPQ, Barras_PQ , DeltaV0, Tensao):
    Delta0=[0]*(NPV+NPQ+1)
    DeltaV=Tensao
    DeltaV_aux=[]
    for k in range(2*NPQ+NPV):
        if (k<NPQ+NPV):
            Delta0[k+1]=DeltaV0[k]
        else:
            DeltaV_aux.append(DeltaV0[k])
            
    cont=0
    for k in range(NPQ+NPV+1):
        if (Barras_PQ[k]=='Y'):
            DeltaV[k]=DeltaV_aux[cont]
            cont=cont+1
    
    return ([DeltaV],[Delta0])


def confirmarTolerancia (deltaP,deltaQ,Tolerancia):
    status=['prosseguir']*len(deltaQ)
    for k in range(len(deltaQ)):
        if (abs(deltaP[k])<Tolerancia and abs(deltaQ[k])<Tolerancia):
            status[k]='parar'
        else:
            status[k]='prosseguir'
    return status


def confirmarTolerancia2 (deltaPQ,Tolerancia):
    status=['prosseguir']*len(deltaPQ)
    for k in range(len(deltaPQ)):
        if (abs(deltaPQ[k])<Tolerancia):
            status[k]='parar'
        else:
            status[k]='prosseguir'
    return status


def calcularJacobiana(NPV, NPQ, Barras_PQ, MatrizG, MatrizB, Tensao, Def_Ang):
    num_Barras=NPQ+NPV+1
    Barras_PQ_val=[]
    for k in range(len(Barras_PQ)):
        if (Barras_PQ[k]=='Y'):
            Barras_PQ_val.append(k+1)
   # print('matrizbarrasPQ: ',Barras_PQ_val)

    ## CÁLCULO DA MATRIZ H:
    MatrizH=[0]*(NPQ+NPV)
    #print("TamannhoNPQ+NPV",num_Barras-1)
    for k in range(NPQ+NPV):
        MatrizH_l=[0]*(NPQ+NPV)
        for f in range(NPQ+NPV):
            soma_aux=0
            valor_temp=0

            if (f+1==k+1):
                for aux in range(num_Barras):
                    if aux!=k+1:
                        soma_aux=soma_aux+Tensao[aux]*(-MatrizG[k+1][aux]*math.sin(Def_Ang[k+1]-Def_Ang[aux])+MatrizB[k+1][aux]*math.cos(Def_Ang[k+1]-Def_Ang[aux]))
                        #print('somaparcial:', soma_aux, aux)
                    
                valor_temp=(-1)*Tensao[k+1]*soma_aux
               
                #print("ValorTempIF: ", valor_temp)
            else:
                valor_temp=(-1)*Tensao[k+1]*Tensao[f+1]*(MatrizG[k+1][f+1]*math.sin(Def_Ang[k+1]-Def_Ang[f+1])-MatrizB[k+1][f+1]*math.cos(Def_Ang[k+1]-Def_Ang[f+1]))
                #print("ValorTempILSE: ", valor_temp)
            
            if valor_temp!=0:
                MatrizH_l[f]=valor_temp
            
            #print("ValorTempILSE: ", valor_temp)
        
        MatrizH[k]=MatrizH_l

    #print(MatrizH)
    if (NPQ>0):
    ## CÁLCULO DA MATRIZ N: (dP|dV)--2
        MatrizN=[0]*(NPQ+NPV)
        for k in range(NPQ+NPV):
            MatrizN_l=[0]*(NPQ)
            dp_index=k+1
            for f in range(NPQ):
                f_index=Barras_PQ_val[f]-1
                soma_aux=0
                valor_temp=0

                if (Barras_PQ_val[f]==dp_index+1):
                    for aux in range(num_Barras):
                        if aux!=dp_index:
                            soma_aux=soma_aux+Tensao[aux]*(MatrizG[dp_index][aux]*math.cos(Def_Ang[dp_index]-Def_Ang[aux])+MatrizB[dp_index][aux]*math.sin(Def_Ang[dp_index]-Def_Ang[aux]))
                            #print('somaparcial:', soma_aux, aux)
                        
                    valor_temp=(-1)*(2*Tensao[dp_index]*MatrizG[dp_index][dp_index]+soma_aux)
                
                    #print("ValorTempIF: ", valor_temp)
                else:
                    
                    valor_temp=(-1)*Tensao[dp_index]*(MatrizG[dp_index][f_index]*math.cos(Def_Ang[dp_index]-Def_Ang[f_index])+MatrizB[dp_index][f_index]*math.sin(Def_Ang[dp_index]-Def_Ang[f_index]))
                    #print("ValorTempILSE: ", valor_temp)
                
                if valor_temp!=0:
                    MatrizN_l[f]=valor_temp

            MatrizN[k]=MatrizN_l
        # print(MatrizN)
        # print('aqui')

        ## CÁLCULO DA MATRIZ M: (dQ|d0)--3
        MatrizM=[0]*(NPQ)
        for k in range(NPQ):
            MatrizM_l=[0]*(NPQ+NPV)
            PQ_index=Barras_PQ_val[k]-1
            for f in range(NPQ+NPV):
                f_index=f+1
                soma_aux=0
                valor_temp=0

                if (Barras_PQ_val[k]==f_index+1):
                    for aux in range(num_Barras):
                        if aux!=PQ_index:
                            soma_aux=soma_aux+Tensao[aux]*(MatrizG[PQ_index][aux]*math.cos(Def_Ang[PQ_index]-Def_Ang[aux])+MatrizB[PQ_index][aux]*math.sin(Def_Ang[PQ_index]-Def_Ang[aux]))
                            #print('somaparcial:', soma_aux, aux)
                        
                    valor_temp=(-1)*(Tensao[PQ_index]*soma_aux)
                
                    #print("ValorTempIF: ", valor_temp)
                else:

                    valor_temp=Tensao[PQ_index]*Tensao[f_index]*(MatrizG[PQ_index][f_index]*math.cos(Def_Ang[PQ_index]-Def_Ang[f_index])+MatrizB[PQ_index][f_index]*math.sin(Def_Ang[PQ_index]-Def_Ang[f_index]))
                    #print("ValorTempILSE: ", valor_temp)
                
                if valor_temp!=0:
                    MatrizM_l[f]=valor_temp

            MatrizM[k]=MatrizM_l


        ## CÁLCULO DA MATRIZ L:
        MatrizL=[0]*(NPQ)
        for k in range(NPQ):
            MatrizL_l=[0]*(NPQ)
            dq_index=Barras_PQ_val[k]-1
            for f in range(NPQ):
                PQ_index=Barras_PQ_val[f]-1
                soma_aux=0
                valor_temp=0

                if (f==k):
                    for aux in range(num_Barras):
                        if aux!=dq_index:
                            soma_aux=(soma_aux+Tensao[aux]*(MatrizG[dq_index][aux]*math.sin(Def_Ang[dq_index]-Def_Ang[aux])-MatrizB[dq_index][aux]*math.cos(Def_Ang[dq_index]-Def_Ang[aux])))
                            #print('somaparcial:', soma_aux, aux)
                        
                    valor_temp=(-1)*(-2*Tensao[dq_index]*MatrizB[dq_index][dq_index]+soma_aux)
                    #print("ValorTempIF: ", valor_temp)
                else:                  
                    valor_temp=(-1)*Tensao[PQ_index]*(MatrizG[PQ_index][dq_index]*math.sin(Def_Ang[PQ_index]-Def_Ang[dq_index])-MatrizB[PQ_index][dq_index]*math.cos(Def_Ang[PQ_index]-Def_Ang[dq_index]))
                    #print("ValorTempILSE: ", valor_temp)


                if valor_temp!=0:
                    MatrizL_l[f]=valor_temp

            MatrizL[k]=MatrizL_l

        #MatrizJ_l=[]
        #MatrizJ=[]

        """for m in range(2*NPQ+NPV):
            for n in range(2*NPQ+NPV):
                if (n<NPQ+NPV and m<NPQ+NPV):
                    MatrizJ_l.append(MatrizH[m][n])
                elif (n>NPQ+NPV and m<NPQ+NPV):
                    MatrizJ_l.append(MatrizN[m][n-(NPQ+NPV)])
                elif (n<NPQ+NPV and m>NPQ+NPV):
                    MatrizJ_l.append(MatrizM[m-(NPQ+NPV)][n])
                elif (n>NPQ+NPV and m>NPQ+NPV):
                    MatrizJ_l.append(MatrizL[m-(NPQ+NPV)][n-(NPQ+NPV)])
            print('ver o que ta printando:', MatrizJ_l)
            MatrizJ.append(MatrizJ_l) """

        # Concatenação lado a lado
        MatrizJ_Aux1 = np.concatenate((MatrizH, MatrizN), axis=1)
        MatrizJ_Aux2 = np.concatenate((MatrizM, MatrizL), axis=1)
        MatrizJ=np.concatenate((MatrizJ_Aux1, MatrizJ_Aux2), axis=0)
    else:
        MatrizJ=MatrizH
        
    return MatrizJ


def calcularPotencias (NB, Barras_PQ, MatrizG, MatrizB,Tensao, Def_Ang):
    PotP=[0]*(NB)
    PotQ=[0]*(NB)

    for k in range(NB):
        somaP=0
        somaQ=0
        
        #potP_liq=(matriz_DadosBarra[1][k]+matriz_DadosBarra[7][k])
        for aux in range(NB):
            somaP=somaP+Tensao[aux]*(MatrizG[k][aux]*math.cos(Def_Ang[k]-Def_Ang[aux])+MatrizB[k][aux]*math.sin(Def_Ang[k]-Def_Ang[aux]))
            #print ('soma1:',soma)
            #print ('soma2:',soma)
        PotP[k]=Tensao[k]*somaP

        for aux in range(NB):
            somaQ=somaQ+Tensao[aux]*(MatrizG[k][aux]*math.sin(Def_Ang[k]-Def_Ang[aux])-MatrizB[k][aux]*math.cos(Def_Ang[k]-Def_Ang[aux]))
        #Qshunt = Yshunt[k] * (Tensao[k] ** 2)  # Yshunt[k] é a susceptância shunt em pu
        PotQ[k]=Tensao[k]*somaQ

    return ([PotP],[PotQ])

def polar_to_rectangular(magnitude, angle_degrees):
    # Convertendo o ângulo de graus para radianos
    angle_radians = math.radians(angle_degrees)
    
    # Calculando as partes real e imaginária
    real_part = magnitude * math.cos(angle_radians)
    imag_part = magnitude * math.sin(angle_radians)
    
    # Retornando o número complexo na forma retangular
    return real_part, imag_part


def Verifica_limites_CS (PotQ, matriz_DadosBarra, NPQ, NPV, Barras_PQ, DeltaV, Delta0, DeltaV0, VerificaSeViola):
    NB=NPV+NPQ+1
    BarraQViola=[0]*NB
    if (NB==len(matriz_DadosBarra[0])):
        for k in range(NB):
            temp=0
            if (matriz_DadosBarra[3][k]=="Y" and VerificaSeViola[k]=="N"):
                temp=PotQ[k]-matriz_DadosBarra[2][k]
                if (temp>(matriz_DadosBarra[5][k])):
                    NPV=NPV-1
                    NPQ=NPQ+1
                    Barras_PQ[k]="Y"
                    DeltaV0=organizarDeltasV0 (NPV, NPQ, Barras_PQ, DeltaV, Delta0)
                    BarraQViola[k]=k
                    VerificaSeViola[k]="ViolaPC"
                if (temp<matriz_DadosBarra[4][k]):
                    NPV=NPV-1
                    NPQ=NPQ+1
                    Barras_PQ[k]="Y"
                    DeltaV0=organizarDeltasV0 (NPV, NPQ, Barras_PQ, DeltaV, Delta0)
                    BarraQViola[k]=k
                    VerificaSeViola[k]="ViolaPB"
                    
    else:
        print("ERRO GRAVE: NB difentes")
    
    return (Barras_PQ, NPQ, NPV, DeltaV0, VerificaSeViola, BarraQViola)

def organizarDeltasV0 (NPV, NPQ, Barras_PQ, DeltaV, Delta0):
    DeltaV_val=[]
    for k in range(len(Barras_PQ)):
        if (Barras_PQ[k]=='Y'):
            DeltaV_val.append(DeltaV[k])

    DeltaV0=[]
    for k in range(2*NPQ+NPV):
        if (k<NPQ+NPV):
            DeltaV0.append(Delta0[k+1])
        else:
            DeltaV0.append(DeltaV_val[k-(NPQ+NPV)])

    return DeltaV0



def radianos_to_graus(radianos):
    # Converte radianos para graus
    return [r * (180 / np.pi) for r in radianos]

def monta_V0(infoVctrl):
    Tensao=[0]*len(infoVctrl[0])
    for i in range(len(infoVctrl[0])):
        if (infoVctrl[1][i]!=0):
            Tensao[i]=infoVctrl[1][i]
        else:
            Tensao[i]=1.0
    return Tensao

# Converte os radianos para graus
# vetor_graus = [radianos_para_graus(r) for r in vetor_radianos]

# # Mostra o resultado
# print("Vetor em radianos:", vetor_radianos)
# print("Vetor em graus:", vetor_graus)

def encontrar_PQ(vetor_De_MID):
    vetor_PQ = []  # Lista para armazenar os índices de 'Y'
    
    for i, valor in enumerate(vetor_De_MID):
        if valor == 'Y':  # Se encontrar 'Y', salva o índice
            vetor_PQ.append(i)
    
    return vetor_PQ



def extrair_linha(matriz, linha):
    """
    Extrai uma linha de uma matriz e retorna como um vetor_De_MID (lista).
    
    :param matriz: Matriz (lista de listas).
    :param linha: Índice da linha a ser extraída (base 0).
    :return: Vetor (lista) contendo os elementos da linha selecionada.
    """
    if linha < 0 or linha >= len(matriz):
        raise IndexError("Índice da linha está fora do intervalo da matriz.")
    
    # Retorna a linha especificada como vetor_De_MID
    return matriz[linha]


def cria_MID_linha(matrizSystem, matrizSystem2):
    tamanho_QL=len(matrizSystem2)
    tamanho_QB=len(matrizSystem)
    nova_matriz2=matrizSystem2
    
    for linha in range(len(matrizSystem2)):
        #vetor_De_MID=[0]*21
        vetor_Mid_Para=[0]*21
        #print(vetor_De_MID)
        
        if (matrizSystem2[linha][14]==0 and matrizSystem2[linha][8]!=0):
            tamanho_QL=tamanho_QL+1
            tamanho_QB=tamanho_QB+1

            vetor_Mid_Para[0]=tamanho_QB
            vetor_Mid_Para[1]=matrizSystem2[linha][1]
            vetor_Mid_Para[2]=1
            vetor_Mid_Para[3]=1
            vetor_Mid_Para[4]=1
            vetor_Mid_Para[5]=0
            vetor_Mid_Para[6]=matrizSystem2[linha][6]/2
            vetor_Mid_Para[7]=matrizSystem2[linha][7]/2
            vetor_Mid_Para[8]=0
            nova_matriz2 = inserir_linha_na_matriz(nova_matriz2, vetor_Mid_Para, tamanho_QL-1)
    
    #nova_matriz=nova_matriz2
    aux=len(matrizSystem)
    for linha in range(len(matrizSystem2)):
        vetor_De_MID=[0]*21
        #vetor_Mid_Para=[0]*21
        #print(vetor_De_MID)
        
        if (matrizSystem2[linha][14]==0 and matrizSystem2[linha][8]!=0):
            # tamanho_QL=tamanho_QL+1
            # tamanho_QB=tamanho_QB+1
            aux=aux+1
            vetor_De_MID[0]=matrizSystem2[linha][0]
            vetor_De_MID[1]=aux
            vetor_De_MID[2]=1
            vetor_De_MID[3]=1
            vetor_De_MID[4]=1
            vetor_De_MID[5]=0
            vetor_De_MID[6]=matrizSystem2[linha][6]/2
            vetor_De_MID[7]=matrizSystem2[linha][7]/2
            vetor_De_MID[8]=matrizSystem2[linha][8]
            nova_matriz2 = substituir_linha_na_matriz(nova_matriz2, vetor_De_MID, linha)

    
    nova_matriz3=matrizSystem
    for linha1 in range(tamanho_QB+1):
        vetor1=[0]*20
        if linha1>len(matrizSystem):
            vetor1[0]=linha1
            vetor1[1]='MID'
            vetor1[2]=linha1
            vetor1[3]=procurar_valor_na_coluna(matrizSystem,procurar_valor_na_coluna(nova_matriz2, linha1, 1, 0),0,3)
            vetor1[4]=1
            vetor1[5]=1
            vetor1[6]=0
            vetor1[7]=1
            vetor1[8]=0
            vetor1[18]=procurar_valor_na_coluna(nova_matriz2, linha1, 1, 8)
            nova_matriz3=inserir_linha_na_matriz(nova_matriz3, vetor1, linha1-1)
            # print(vetor1[3])
            # print('nnnn')
            # exit()
    # Índice da coluna a ser substituída por 0.0 (exemplo: coluna 2)
    coluna_a_substituir = 8

    # Chamada da função para substituir a coluna
    matriz_System2_modificada = substituir_coluna_por_zero(nova_matriz2, coluna_a_substituir)

    # print(matriz_System2_modificada)
    # print('vetor_De_MID')
    # exit()
    for auxiliar in range(len(nova_matriz3)):
        nova_matriz3[auxiliar][18]=(+1)*nova_matriz3[auxiliar][18]
        #print('col18: ',nova_matriz3[auxiliar][18])    
    return (nova_matriz3, matriz_System2_modificada)


def inserir_linha_na_matriz(matriz, linha, posicao):
    """
    Insere uma linha dentro de uma matriz em uma posição específica.
    
    Parâmetros:
    - matriz: A matriz original (lista de listas).
    - linha: O vetor_De_MID (lista) a ser inserido.
    - posicao: A posição onde a linha será inserida (índice).
    
    Retorna:
    - A nova matriz com a linha inserida.
    """
    # Verifica se a posição é válida
    if posicao < 0 or posicao > len(matriz):
        raise IndexError("Posição inválida. A posição deve ser entre 0 e o número de linhas da matriz.")

    # Insere a linha na posição desejada
    matriz.insert(posicao, linha)
    
    return matriz


def substituir_linha_na_matriz(matriz, linha_nova, posicao):
    """
    Substitui uma linha dentro de uma matriz em uma posição específica por uma nova linha.
    
    Parâmetros:
    - matriz: A matriz original (lista de listas).
    - linha_nova: O vetor (lista) que irá substituir a linha existente.
    - posicao: A posição da linha a ser substituída (índice).
    
    Retorna:
    - A nova matriz com a linha substituída.
    """
    # Verifica se a posição é válida
    if posicao < 0 or posicao >= len(matriz):
        raise IndexError("Posição inválida. A posição deve ser entre 0 e o número de linhas da matriz.")
    
    # Verifica se o tamanho da nova linha é igual ao tamanho da linha existente
    if len(linha_nova) != len(matriz[posicao]):
        raise ValueError("O tamanho da nova linha deve ser igual ao tamanho da linha existente.")
    
    # Substitui a linha na posição especificada
    matriz[posicao] = linha_nova
    
    return matriz


def procurar_valor_na_coluna(matriz, valor, coluna, linha_val):
    """
    Procura um valor em uma coluna específica de uma matriz e retorna o primeiro
    elemento da linha onde o valor foi encontrado.
    
    Parâmetros:
    - matriz: A matriz onde a busca será realizada (lista de listas).
    - valor: O valor a ser procurado na coluna.
    - coluna: O índice da coluna onde o valor será procurado.
    
    Retorna:
    - O primeiro elemento da linha onde o valor foi encontrado. Caso o valor não
      seja encontrado, retorna None.
    """
    # Verifica se a coluna especificada é válida
    if coluna < 0 or coluna >= len(matriz[0]):
        raise IndexError("Índice de coluna inválido.")
    
    # Percorre as linhas da matriz
    for linha in matriz:
        # Verifica se o valor está na coluna especificada
        if linha[coluna] == valor:
            # Retorna o primeiro elemento da linha
            return linha[linha_val]
    
    # Se o valor não for encontrado, retorna None
    return None


def substituir_coluna_por_zero(matriz, coluna):
    """
    Substitui todos os elementos de uma coluna específica por 0.0 em uma matriz.

    Parâmetros:
    - matriz: A matriz onde a substituição será realizada (lista de listas).
    - coluna: O índice da coluna que será modificada.

    Retorna:
    - A matriz com os valores da coluna especificada substituídos por 0.0.
    """
    # Verifica se a coluna especificada é válida
    if coluna < 0 or coluna >= len(matriz[0]):
        raise IndexError("Índice de coluna inválido.")

    # Percorre as linhas da matriz e substitui o valor na coluna especificada
    for linha in matriz:
        linha[coluna] = 0.0
    
    return matriz



def alterar_matrizes(matriz1, matriz2, modelagem):
    """
    Recebe duas matrizes e uma string que pode ser 'T' ou 'PI'. Dependendo da modelagem,
    a função decide se altera as matrizes ou as mantém intactas.
    
    Parâmetros:
    - matriz1: Primeira matriz a ser manipulada.
    - matriz2: Segunda matriz a ser manipulada.
    - modelagem: Um valor string que pode ser 'T' ou 'PI', indicativo da modelagem a ser aplicada.
    
    Retorna:
    - matriz1: A primeira matriz após a alteração (ou intacta).
    - matriz2: A segunda matriz após a alteração (ou intacta).
    - modelagem: A modelagem fornecida ('T' ou 'PI').
    """
    
    if modelagem == 'PI':
        # Não altera as matrizes (mantém as matrizes intactas)
        #print("Modelagem PI: Matrizes intactas.")
        return matriz1, matriz2, modelagem
    elif modelagem == 'T':
        # Realiza uma alteração nas matrizes. Neste exemplo, vou substituir a primeira coluna por 0.0.
        print("Modelagem T: Matrizes alteradas.")
        # Exemplo de alteração: substituir a primeira coluna por 0.0 nas duas matrizes
        (matriz1,matriz2)=cria_MID_linha(matriz1, matriz2)
    else:
        raise ValueError("Entrada inválida. A modelagem deve ser 'T' ou 'PI'.")
    
    return matriz1, matriz2, modelagem



def extrair_coluna(matriz, indice_coluna):
    """
    Extrai uma coluna de uma matriz e a transforma em um vetor.
    
    Parâmetros:
    - matriz: np.ndarray, matriz de entrada
    - indice_coluna: int, índice da coluna a ser extraída
    
    Retorna:
    - vetor_coluna: np.ndarray, vetor correspondente à coluna extraída
    """
    vetor_coluna = matriz[:, indice_coluna]
    return vetor_coluna

def calcular_desvio_porcentagem(vetor1, vetor2):
    """
    Calcula a porcentagem de desvio entre dois vetores elemento a elemento.
    
    Parâmetros:
    - vetor1: list ou np.ndarray, vetor com os valores a serem comparados
    - vetor2: list ou np.ndarray, vetor de referência (vetor_base)
    
    Retorna:
    - desvios: list, lista com os desvios percentuais
    - maior_desvio: float, maior desvio percentual observado
    - indice_maior_desvio: int, índice do maior desvio percentual
    """
    # Verificar se os vetores têm o mesmo tamanho
    if len(vetor1) != len(vetor2):
        raise ValueError("Os vetores devem ter o mesmo tamanho.")
    
    # Inicializar lista de desvios e variáveis para maior desvio
    desvios = []
    maior_desvio = 0
    indice_maior_desvio = -1

    # Iterar sobre os elementos dos vetores
    for i in range(len(vetor1)):
        try:
            # Evitar divisão por zero
            if vetor2[i] == 0:
                desvio = float('inf')  # Desvio infinito se o elemento de vetor_base for zero
            else:
                desvio = abs((vetor1[i] - vetor2[i]) / vetor2[i]) * 100
            
            # Adicionar desvio à lista
            desvios.append(desvio)
            
            # Verificar se é o maior desvio
            if (desvio > maior_desvio):
                if desvio!=float('inf'):
                    maior_desvio = desvio
                    indice_maior_desvio = i
        
        except Exception as e:
            raise ValueError(f"Erro ao calcular desvio no índice {i}: {e}")
    
    return desvios, maior_desvio, indice_maior_desvio

# # Exemplo de uso
# if __name__ == "__main__":
#     vetor1 = [10.5, 21, 31, 41.5, 49, 61]
#     vetor2 = [10, 20, 30, 40, 50, 60]
    
#     # Calcular o desvio percentual
#     desvios, maior_desvio, indice_maior_desvio = calcular_desvio_porcentagem(vetor1, vetor2)

#     # Exibir resultados
#     print("Desvios percentuais:", desvios)
#     print(f"Maior desvio: {maior_desvio:.2f}%")
#     print("Índice do maior desvio:", indice_maior_desvio)


# def salva_vetor_nao_nulo_inteiros(vetor):
#     # Verifica se o vetor contém pelo menos um elemento diferente de 0
#     if any(elemento != 0 for elemento in vetor):
#         # Se houver algum elemento diferente de 0, copia o vetor
#         novo_vetor = vetor.copy()
#         return novo_vetor

def transforma_vetor_indices(vetor):
    # Inicializa o vetor de saída com o primeiro elemento igual a 0
    vetor_saida = [0]
    
    # Itera sobre os elementos do vetor de entrada a partir do segundo (índice 1)
    for i in range(1, len(vetor)):
        if vetor[i] == 'Y':
            # Adiciona o índice atual ao vetor de saída
            vetor_saida.append(i)
        elif vetor[i] == 'N':
            # Adiciona 0 se o elemento for 'N'
            vetor_saida.append(0)

    return vetor_saida

def remove_por_indice(vetor, indice_para_remover):
    # Verifica se o índice está dentro do intervalo válido
    if 0 <= indice_para_remover < len(vetor):
        # Usa numpy.delete para remover o elemento no índice especificado
        vetor_resultante = np.delete(vetor, indice_para_remover)
        return vetor_resultante
    else:
        raise IndexError("Índice fora do intervalo válido.")
    

def confirma_PV (NPQ,NPV,Barras_PQ,DeltaV0,VerificaSeViola,BarraQViola,Tensao,infoVctrl,BarraQViola_estatica,PotQ, status_checarOscilacao):
    BarraQNAO_Viola=[0]*(NPQ+NPV+1)            
    
    # for i in range(len(BarraQViola)):
    #     for j in range(len(BarraQViola_estatica)):
    #         if (BarraQViola[i]!=0):
    #             if (BarraQViola_estatica[j]!=0):
    #                 BarraQViola_estatica


    if any(elemento != 0 for elemento in BarraQViola):
        if any(elemento2 != 0 for elemento2 in BarraQViola_estatica):
            for aux3 in range(len(BarraQViola_estatica)):
                if (BarraQViola[aux3]!=0 and BarraQViola_estatica[aux3]==0):
                    BarraQViola_estatica[aux3] = BarraQViola[aux3]
                elif(BarraQViola[aux3]!=0 and BarraQViola_estatica[aux3]!=0):
                    BarraQViola_estatica[aux3] = BarraQViola[aux3]
        else:
            BarraQViola_estatica = BarraQViola.copy()


    Tensao0=monta_V0(infoVctrl)

    Barras_PQ_index=transforma_vetor_indices(Barras_PQ)
    if 'ViolaPB' in VerificaSeViola or 'ViolaPC' in VerificaSeViola:
        for aux in range(len(BarraQViola_estatica)):
            if (BarraQViola_estatica[aux]==Barras_PQ_index[aux] and Barras_PQ_index[aux]!=0):
                if status_checarOscilacao[aux]=='N':
                    ([DeltaV],[Delta0])=voltarDeltas(NPV, NPQ, Barras_PQ, DeltaV0, Tensao)
                    # print(DeltaV)
                    # print(Tensao)
                    #print('kkkkkkkkkkkkkkkk')
                    if (infoVctrl[1][aux]<DeltaV[aux] and VerificaSeViola[aux]=='ViolaPC'):
                        # print(DeltaV)
                        # print(infoVctrl[1][aux])
                        #print(Barras_PQ)
                        #print('aquiiiiiii22222222')
                        # # Barras_PQ=
                        
                        NPQ=NPQ-1
                        NPV=NPV+1
                        
                        novo=encontrar_indices_Y(Barras_PQ)
                        # print(novo)
                        INDEX_barraQNAOviola=encontrar_indice(aux,novo)
                        #print(INDEX_barraQNAOviola)
                        auux=NPV+NPQ+INDEX_barraQNAOviola
                        # print(auux)
                        # exit()
                        Barras_PQ[aux]='N'
                        DeltaV0=remove_por_indice(DeltaV0,auux)
                        VerificaSeViola[aux]='N'
                        # print(DeltaV0_teste)
                        # print('DeltaV0_teste')
                        BarraQViola_estatica[aux]=0
                        BarraQNAO_Viola[aux]=aux
                        Tensao[aux]=Tensao0[aux]

                    elif (infoVctrl[1][aux]>DeltaV[aux] and VerificaSeViola[aux]=='ViolaPB'):
                        
                        indices = [i for i, v in enumerate(Barras_PQ) if v == 'Y']
                        indicesindices = indices.index(aux) 
                        #print(indicesindices)
                        auux=NPV+NPQ+indicesindices
                        Barras_PQ[aux]='N'
                        NPQ=NPQ-1
                        NPV=NPV+1
                        
                        DeltaV0=remove_por_indice(DeltaV0,auux)
                        VerificaSeViola[aux]='N'
                        BarraQViola_estatica[aux]=0
                        BarraQNAO_Viola[aux]=aux
                        Tensao[aux]=Tensao0[aux]

    return (Barras_PQ, NPQ, NPV, DeltaV0, VerificaSeViola, BarraQNAO_Viola, BarraQViola_estatica, Tensao)


def encontrar_indices_Y(Barras_PQ):
    """
    Função para encontrar os índices onde o valor é 'Y' no vetor Barras_PQ.
    
    Parâmetros:
        Barras_PQ (list): Lista de strings contendo valores 'swing', 'N' e 'Y'.
    
    Retorna:
        vetor_novo (list): Lista de índices onde 'Y' foi encontrado.
    """
    vetor_novo = [i for i, valor in enumerate(Barras_PQ) if valor == 'Y']
    return vetor_novo



def encontrar_indice(valor_procurado, vetor):
    """
    Função para encontrar o índice de um valor específico em um vetor de inteiros.
    
    Parâmetros:
        valor_procurado (int): O valor que deseja encontrar.
        vetor (list): Lista de inteiros onde será realizada a busca.
    
    Retorna:
        indice (int): O índice do valor encontrado no vetor ou -1 se não estiver presente.
    """
    for i, valor in enumerate(vetor):
        if valor == valor_procurado:
            return i
    return -1  # Retorna -1 se o valor não for encontrado



""" 

!!!!!!!!!!!!!!!!!!!!!!!!!!!!

THIRD SECTION OF FUNCTIONS

!!!!!!!!!!!!!!!!!!!!!!!!!!!!

"""
def checarOscilacao_ins(vet_contador_logic_suplementar12_out, vet_contador_logic_suplementar12_ins, VerificaSeViola):
    for auxiliar_logic_suplementar12_ins in range(len(vet_contador_logic_suplementar12_out)):
        if vet_contador_logic_suplementar12_out[auxiliar_logic_suplementar12_ins]!=0:
            if VerificaSeViola[auxiliar_logic_suplementar12_ins]=='N':
                vet_contador_logic_suplementar12_ins[auxiliar_logic_suplementar12_ins]=vet_contador_logic_suplementar12_ins[auxiliar_logic_suplementar12_ins]+1
    return vet_contador_logic_suplementar12_ins

def checarOscilacao_out(vet_contador_logic_suplementar12_out, VerificaSeViola):
    for auxiliar_logic_suplementar12_out in range(len(VerificaSeViola)):
        if VerificaSeViola[auxiliar_logic_suplementar12_out]!='N':
            vet_contador_logic_suplementar12_out[auxiliar_logic_suplementar12_out]=vet_contador_logic_suplementar12_out[auxiliar_logic_suplementar12_out]+1
    return vet_contador_logic_suplementar12_out


def checarOscilacao_tot(Tipo_de_logicaSuplementar, vet_contador_logic_suplementar12_ins, NaoAvaliarMais, status_checarOscilacao, ComutacaoMaxima):
    if Tipo_de_logicaSuplementar==1:
        for  auxiliar_logic_suplementar12_tot in range(len(vet_contador_logic_suplementar12_ins)):
            if vet_contador_logic_suplementar12_ins[auxiliar_logic_suplementar12_tot]>=ComutacaoMaxima:
                status_checarOscilacao[auxiliar_logic_suplementar12_tot]='P'
    elif Tipo_de_logicaSuplementar==2:
        if NaoAvaliarMais=='no':
            maior=max(vet_contador_logic_suplementar12_ins) 
            indice_maximo = vet_contador_logic_suplementar12_ins.index(maior)
            if maior>=ComutacaoMaxima:
                status_checarOscilacao[indice_maximo]='P' 
                NaoAvaliarMais='yes'
    return (status_checarOscilacao, NaoAvaliarMais)

def liga_desliga_CS(matrizSystem, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF, Sbase, HabiltAval_Lim_Reativo, Desabilitar_CS, matriz_DadosBarra, infoVctrl):
    if HabiltAval_Lim_Reativo=='N' and Desabilitar_CS=='N':
        HabiltAval_Lim_Reativo='Y'
        ( _ ,[infoVctrl])=DefineMatrizDadosBarra(matrizSystem, Sbase, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF)
        HabiltAval_Lim_Reativo='N'
        for auxiliar_ligaCS in range(len(matriz_DadosBarra[6])):
            if auxiliar_ligaCS>0:
                if matriz_DadosBarra[4][auxiliar_ligaCS]!=0 or matriz_DadosBarra[5][auxiliar_ligaCS]!=0:
                    matriz_DadosBarra[6][auxiliar_ligaCS]='Y'
    elif HabiltAval_Lim_Reativo=='Y' and Desabilitar_CS=='Y':
        HabiltAval_Lim_Reativo='N'
        ( _ ,[infoVctrl])=DefineMatrizDadosBarra(matrizSystem, Sbase, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF)
        HabiltAval_Lim_Reativo='Y'
        for auxiliar_DESligaCS in range(len(matriz_DadosBarra[6])):
            if auxiliar_DESligaCS>0:
                if (matriz_DadosBarra[4][auxiliar_DESligaCS]!=0 or matriz_DadosBarra[5][auxiliar_DESligaCS]!=0) and infoVctrl[0][auxiliar_DESligaCS]=='-':
                    matriz_DadosBarra[3][auxiliar_DESligaCS]='N'
    return (infoVctrl, matriz_DadosBarra)   







def CHAMA_FLNR_03_LTT (matrizSystem,matrizSystem2,matriz_DadosBarra,infoVctrl,MODELin,Tolerancia,momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouaft, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY):
    """  ------------------------------------------------------------------------  """ 
    """  ---------------------- CAPÍTULO 1: LEITURA DO SISTEMA ------------------  """
    """  ------------------------------------------------------------------------  """ 

    #modelagem_linha = MODELin # Tipo de modelo da linha (PI ou T)
    #matrizSystem, matrizSystem2, modelagem_resultante = alterar_matrizes(matrizSystem, matrizSystem2, modelagem_linha)
    #MatrizY=calcularMATRIZ_Y(matrizSystem, matrizSystem2, Ativar_inverter)
    # print(matrizSystem)
    # print(matrizSystem2)
    # exit()##PAREIII AQUIII

    """  --------------------- SEÇÃO 2: ENTRADAS DE PV E PQ ---------------------  """
    """  ------------(define quais são as barras de tensão controlada)-----------  """ 
    """  ------------------------------ FLAT START ------------------------------  """
    
    ## INICIA V E 0 (ENTRADA PROGRAMAÇÃO):
    
    if MODELin=='PI':
        NB=len(matriz_DadosBarra[0])
        Tensao=monta_V0(infoVctrl)
    else:

        NB=len(matrizSystem)
        tam=len(infoVctrl[0])
        newinfoVctrl0=['-']*NB
        newinfoVctrl1=[0]*NB
        newinfoVctrl=[]
        newinfoVctrl.append(newinfoVctrl0)
        newinfoVctrl.append(newinfoVctrl1)

        newMDB0=[0]*NB
        for auxiliar2 in range(NB):
            newMDB0[auxiliar2]=matrizSystem[auxiliar2][18]

        newMDB1=[0]*NB
        newMDB2=[0]*NB
        newMDB3=['N']*NB
        newMDB4=[0]*NB
        newMDB5=[0]*NB
        newMDB6=['N']*NB
        newMDB7=[0]*NB
        newMDB=[]
        newMDB.append(newMDB0)
        newMDB.append(newMDB1)
        newMDB.append(newMDB2)
        newMDB.append(newMDB3)
        newMDB.append(newMDB4)
        newMDB.append(newMDB5)
        newMDB.append(newMDB6)
        newMDB.append(newMDB7)
        for auxiliar in range(NB):
            if auxiliar<tam:
                newinfoVctrl[0][auxiliar]=infoVctrl[0][auxiliar]
                newinfoVctrl[1][auxiliar]=infoVctrl[1][auxiliar]

                newMDB[0][auxiliar]=matriz_DadosBarra[0][auxiliar]
                newMDB[1][auxiliar]=matriz_DadosBarra[1][auxiliar]
                newMDB[2][auxiliar]=matriz_DadosBarra[2][auxiliar]
                newMDB[3][auxiliar]=matriz_DadosBarra[3][auxiliar]
                newMDB[4][auxiliar]=matriz_DadosBarra[4][auxiliar]
                newMDB[5][auxiliar]=matriz_DadosBarra[5][auxiliar]
                newMDB[6][auxiliar]=matriz_DadosBarra[6][auxiliar]
                newMDB[7][auxiliar]=matriz_DadosBarra[7][auxiliar]
            if auxiliar>=tam:
                newinfoVctrl[0][auxiliar]= newinfoVctrl0[auxiliar]
                newinfoVctrl[1][auxiliar]= newinfoVctrl1[auxiliar]

                newMDB[0][auxiliar]=newMDB0[auxiliar]
                newMDB[1][auxiliar]=newMDB1[auxiliar]
                newMDB[2][auxiliar]=newMDB2[auxiliar]
                newMDB[3][auxiliar]=newMDB3[auxiliar]
                newMDB[4][auxiliar]=newMDB4[auxiliar]
                newMDB[5][auxiliar]=newMDB5[auxiliar]
                newMDB[6][auxiliar]=newMDB6[auxiliar]
                newMDB[7][auxiliar]=newMDB7[auxiliar]

        infoVctrl=newinfoVctrl
        Tensao=monta_V0(infoVctrl)
        matriz_DadosBarra=newMDB



    # print('-----')
    # print(Tensao)
    Def_Ang=[0]*NB


    ### INICIA INFORMAÇÃO DE NPVs e NPQs (ENTRADA PROGRAMAÇÃO):
    NPV=0;
    Barras_PV=['N']*NB
    Barras_PQ=['Y']*NB


    for i in range(len(infoVctrl[0])):
        if (infoVctrl[0][i]!='-' and infoVctrl[0][i]!='swing'):
            Barras_PQ[i]='N'
            Barras_PV[i]='Y'
            NPV=NPV+1
        if (infoVctrl[0][i]=='swing'):
            Barras_PQ[i]='swing'
            Barras_PV[i]='swing'

    # print('--------')
    # print(Barras_PQ)
    # print(Barras_PV)
    # print('--------')
    # print(infoVctrl[0])
    # exit()

    """  -------------- SEÇÃO 3: OUTRAS INICIALIZAÇÕES IMPORTANTES --------------  """
    """  -----------------------------(pelo programa)----------------------------  """ 

    NPQ=NB-NPV-1
    # print(NPQ)
    # Barras_PV[0]='swing'
    # Barras_PQ[0]='swing'   
    # print('barrasPV: ',Barras_PV)
    # print('barrasPQ: ',Barras_PQ)

    ### DEFININDO AS MATRIZES G E B:
    MatrizG = np.zeros_like(MatrizY, dtype=np.float64)
    MatrizB = np.zeros_like(MatrizY, dtype=np.float64)

    for i in range(len(MatrizY)): # Itera sobre cada elemento da matriz complexa
        for j in range(len(MatrizY)):
            MatrizG[i][j] = MatrizY[i][j].real
            MatrizB[i][j] = MatrizY[i][j].imag

    VerificaSeViola=["N"]*NB
    #Tipo_de_logicaSuplementar=1 #1 or 2 or None
    vet_contador_logic_suplementar12_out=[0]*NB
    vet_contador_logic_suplementar12_ins=[0]*NB
    status_checarOscilacao=['N']*NB
    NaoAvaliarMais='no'
    #ComutacaoMaxima=8
    Desbloqueador=1

    ### CÁLCULO INICIAL DAS VARIÁVEIS
    ## ("Vai rodar o fluxo inicialmente e confirmar o quão longe da solução estamos")
    ([deltaP],[deltaQ])= calcularDeltas(NB, Barras_PQ, matriz_DadosBarra, MatrizG, MatrizB,Tensao, Def_Ang, VerificaSeViola)
    status = confirmarTolerancia(deltaP,deltaQ,Tolerancia)
    DeltaV0=organizarDeltas (NPV, NPQ, Barras_PQ, Def_Ang, Tensao)

    #DeltaPQ=organizarDeltas (NPV, NPQ, Barras_PQ, deltaP, deltaQ)
    # ([DeltaV],[Delta0])=voltarDeltas(NPV, NPQ, Barras_PQ, DeltaV0)
    # MatrizJ=calcularJacobiana(NPV, NPQ, Barras_PQ ,MatrizG, MatrizB, DeltaV, Delta0)
    # print('deltaV: ', DeltaV)
    # print('delta0: ', Delta0)
    # print('MatrizJ: ', MatrizJ)
    #print(DeltaV0)

    rodar_fluxo=False
    for k in range(len(status)):
        if (status[k]=='prosseguir'):
            rodar_fluxo=True
            continue

    EvolutionMatrixVECTORS=[]        
    EvolutionVECTOR_DeltaV=[] 
    EvolutionVECTOR_Delta0=[]
    EvolutionVECTOR_mismatchP=[]
    EvolutionVECTOR_mismatchQ=[]
    EvolutionVECTOR_swing=[]
    resultado1=None
    resultado2=None
    explodiuporTENSAOGRANDE='no'

    """  ------------------------------------------------------------------------  """ 
    """  --------------------  SEÇÃO 4: FLUXO DE POTÊNCIA -----------------------  """
    """  ------------------------------------------------------------------------  """ 
    cont=0
    BarraQViola_estatica=[0]*NB

    while rodar_fluxo==True:

        ## CÁLCULO DO FLUXO_NR
        # print('\n')
        # print('FLUXO: ', cont)
        #print('Barras_PQ=', Barras_PQ)
        ([DeltaV],[Delta0])=voltarDeltas(NPV, NPQ, Barras_PQ, DeltaV0, Tensao)
        # print('DELTAV: ', DeltaV)
        # print('DELTA0: ', Delta0)

        DeltaV_temp=[0]*len(DeltaV)
        Delta0_temp=[0]*len(DeltaV)
        for aux in range(len(DeltaV)):
            DeltaV_temp[aux]=float(DeltaV[aux])
            Delta0_temp[aux]=float(Delta0[aux])
        #print('DeltaV=',DeltaV)
        EvolutionVECTOR_DeltaV.append(DeltaV_temp)
        EvolutionVECTOR_Delta0.append(Delta0_temp)

        ## TESTES IEEE118 COM A MINHA JACOBIANA (Se quiser testar a função LER_MATRIZ)
        # if cont==0:               
        #     MatrizJ=LER_MATRIZreal('J0_meuAlg.csv')
        # elif cont==1:      
        #     MatrizJ=LER_MATRIZreal('J1_meuAlg.csv')
        # elif cont==2:      
        #     MatrizJ=LER_MATRIZreal('J2_meuAlg.csv')
        # elif cont==3:      
        #     MatrizJ=LER_MATRIZreal('J3_meuAlg.csv')    
        
        ## TESTES IEEE118 COM A JACOBIANA DA COMUNIDADE MATLAB 
        # if cont==0:               
        #     MatrizJ=LER_MATRIZreal('J0_matAlg.csv')
        # elif cont==1:      
        #     MatrizJ=LER_MATRIZreal('J0_matAlg.csv')
        # elif cont==2:      
        #     MatrizJ=LER_MATRIZreal('J0_matAlg.csv')
        # elif cont==3:      
        #     MatrizJ=LER_MATRIZreal('J0_matAlg.csv')
        
        # MatrizJ_inv =(+1)* np.linalg.inv(MatrizJ)

        MatrizJ=calcularJacobiana(NPV, NPQ, Barras_PQ ,MatrizG, MatrizB, DeltaV, Delta0)
        MatrizJ_inv =(-1)* np.linalg.inv(MatrizJ)
        #print(MatrizJ)

        if cont==0:
            indices_extra_Q=indices_N(Barras_PQ)
            if len(indices_extra_Q)>1:
                #SALVAR_MATRIZreal('J4_meuAlg.csv',MatrizJ)
                JACOBIANA_INICIAL=expandir_matriz_com_identificadores(MatrizJ,NPQ+NPV,indices_extra_Q,indices_extra_Q)
            else:
                JACOBIANA_INICIAL=MatrizJ

        # print (MatrizJ)    
        # print_matriz_ordenada(JACOBIANA_INICIAL)
        # exit()
        ([deltaP],[deltaQ])= calcularDeltas(NB, Barras_PQ, matriz_DadosBarra, MatrizG, MatrizB,DeltaV, Delta0, VerificaSeViola)
        DeltaPQ=organizarDeltas (NPV, NPQ, Barras_PQ, deltaP, deltaQ)

        deltaP_temp=[0]*len(deltaP)
        deltaQ_temp=[0]*len(deltaQ)
        for aux in range(len(deltaP)):
            deltaP_temp[aux]=float(deltaP[aux])
            deltaQ_temp[aux]=float(deltaQ[aux])

        EvolutionVECTOR_mismatchP.append(deltaP_temp)
        EvolutionVECTOR_mismatchQ.append(deltaQ_temp)
        # resultado1 = verificar_vetor(VerificaSeViola) #PARTE A1.0: INICIO DA VERIFICAÇÃO DE COERÊNCIA
        # if resultado1=='PERMITIR':
        #     V0_anterior=DeltaV0

        DeltaV0=DeltaV0+np.dot(MatrizJ_inv, DeltaPQ)
        # print('MatrizJ: ')
        # print(MatrizJ)
        # print('DeltaV0: ', DeltaV0)

        #DeltaV0=organizarDeltas (NPV, NPQ, Barras_PQ, Def_Ang, Tensao)
        status = confirmarTolerancia(deltaP,deltaQ,Tolerancia)
        # print('DELTAP: ', deltaP)
        # print('DELTAQ: ', deltaQ)
        # print('DELTAPQ: ', DeltaPQ)
        # print('status: ', status)

        rodar_fluxo=False
        for k in range(len(status)):
            if (status[k]=='prosseguir'):
                rodar_fluxo=True
                #continue    
        
        ## CONFIRMAR LIMITES DO COMPENSADOR SÍNCRONO
        if (cont>Desbloqueador):
            ([PotP],[PotQ])=calcularPotencias (NB, Barras_PQ, MatrizG, MatrizB, DeltaV, Delta0)
            #([PotP],[PotQ])=calcularPotencias(NB, Barras_PQ, MatrizG, MatrizB, DeltaV, Delta0, Y_shunt)
            # print("POTÊNCIA_LIQUIDA CALCULADA ATIVA: ", PotP)
            # print("POTÊNCIA_LIQUIDA CALCULADA REATIVA: ", PotQ)
            (Barras_PQ, NPQ, NPV, DeltaV0, VerificaSeViola, BarraQViola)= Verifica_limites_CS (PotQ, matriz_DadosBarra, NPQ, NPV, Barras_PQ, DeltaV, Delta0, DeltaV0, VerificaSeViola)
            vet_contador_logic_suplementar12_out=checarOscilacao_out(vet_contador_logic_suplementar12_out, VerificaSeViola)
            (Barras_PQ, NPQ, NPV, DeltaV0, VerificaSeViola, BarraQNAOViola, BarraQViola_estatica, Tensao)= confirma_PV(NPQ,NPV,Barras_PQ,DeltaV0,VerificaSeViola,BarraQViola,Tensao,infoVctrl, BarraQViola_estatica,PotQ, status_checarOscilacao)
            vet_contador_logic_suplementar12_ins=checarOscilacao_ins(vet_contador_logic_suplementar12_out, vet_contador_logic_suplementar12_ins, VerificaSeViola)
            (status_checarOscilacao, NaoAvaliarMais)=checarOscilacao_tot(Tipo_de_logicaSuplementar, vet_contador_logic_suplementar12_ins, NaoAvaliarMais, status_checarOscilacao, ComutacaoMaxima)
            #print('vet_contador_logic_suplementar12_ins=',vet_contador_logic_suplementar12_ins)                   
            
            # if cont==100:
            #     print('TREME TREME TREME TREME TREME')
            #     save_dir = os.path.join(os.getcwd(), "plot", "GoPVcurve", "Divergencies")

            #     os.makedirs(save_dir, exist_ok=True)

            #     # tag = create_unique_tag(save_dir, SYSname, limite_variacao_lev, limite_variacao_pes,
            #     #     RegimeE3, passoE3, Estrategia, limite_variacao, Tolerancia, ESCOLHER_bar) 

            #     tag = create_unique_tag2(save_dir, len(matriz_DadosBarra[0]), Tolerancia, Tipo_de_logicaSuplementar)                 

            #     save_vector_csv(matriz_DadosBarra[1],tag,"csv",save_dir)                
            #     #print('matriz_DadosBarra[1]=',matriz_DadosBarra[1])
            #     resultado1, resultado2 = verificar_status(status_checarOscilacao)
            #     #save_vector_csv(matriz_DadosBarra[1],"IEEE118")

        elif(cont<Desbloqueador):        
            if (cont<Desbloqueador):
                ([PotP],[PotQ])=calcularPotencias (NB, Barras_PQ, MatrizG, MatrizB, DeltaV, Delta0)   

        soma_encontraPgerTot=0
        for encontraPgerTot in range(len(PotP)):
            if encontraPgerTot!=0:
                if PotP[encontraPgerTot]>0:
                    soma_encontraPgerTot=soma_encontraPgerTot+PotP[encontraPgerTot]
        EvolutionVECTOR_swing.append(float(soma_encontraPgerTot+PotP[0]))

        for auxiliar_impede in range(len(DeltaV)):
            if DeltaV[auxiliar_impede]>10^3 or Delta0[auxiliar_impede]>10^3:
                rodar_fluxo=False
                explodiuporTENSAOGRANDE='yes'
                #print("saiu do fluxo por EXPLODIR AS TENSOES E ANGULO!!!", cont)
       
       ## DETERMINAR CONTAGEM LIMITE
        cont=cont+1
        if cont==200:
            rodar_fluxo=False
            # print(BarraQViola)
            # print(BarraQViola_estatica)
            # print(BarraQNAOViola)
            # print('DeltaV=',DeltaV)
            # print('Delta0=',Delta0)
            # #for limpa_auxiliar in range(matriz_DadosBarra[1])
            # print('matriz_DadosBarra[1]=',matriz_DadosBarra[1])
            print("saiu do fluxo por ATINGIR O NUMERO MÁXIMO DE ITERAÇÕES - ", cont)
    
    if explodiuporTENSAOGRANDE=='yes':
        ("saiu do fluxo por EXPLODIR AS TENSÕES E ÂNGULO - ", cont)

    #print('EvolutionVECTOR_swing=', EvolutionVECTOR_swing)
    #print('EvolutionVECTOR_DeltaV=', EvolutionVECTOR_DeltaV)
    """  ------------------------  JACOBIANA FINAL -------------------------------  """
    indices_extra_Q=indices_N(Barras_PQ)
    if len(indices_extra_Q)==1:
        indices_extra_Q=[indices_extra_Q]

    try:
        JACOBIANA_FINAL=expandir_matriz_com_identificadores(MatrizJ,NPQ+NPV,indices_extra_Q,indices_extra_Q)
        # print_matriz_ordenada(JACOBIANA_FINAL)
        # exit       
    except Exception as e:
        JACOBIANA_FINAL=MatrizJ        



    """  --------------  SEÇÃO 5: CALCULO DAS POTÊNCIAS NAS BARRAS --------------  """
    ([PotP],[PotQ])=calcularPotencias (NB, Barras_PQ, MatrizG, MatrizB, DeltaV, Delta0)
    #([PotP],[PotQ])=calcularPotencias(NB, Barras_PQ, MatrizG, MatrizB, DeltaV, Delta0, Y_shunt)
    
    somaP=0
    SomaQ=0
    for k in range (len(PotP)):
        somaP=PotP[k]+somaP
        SomaQ=PotQ[k]+SomaQ
    pausa='no'
    
    """  --------------  SEÇÃO 6: ARRUMAR DADOS DE ACORDO COM MODELO DE LINHA ---  """
    if MODELin=='T':
        DeltaVt=[]
        Delta0t=[]
        PotPt=[]
        PotQt=[]
        Barras_PQt=[]
        BarraQViola_estaticat=[]
        VerificaSeViolat=[]   
        # EvolutionVECTOR_DeltaVt=[]  
        # EvolutionVECTOR_Delta0t=[]  
        # EvolutionVECTOR_mismatchPt=[]
        # EvolutionVECTOR_mismatchQt=[]
        EvolutionMatrixVECTORS_temp=[]
        EvolutionMatrixVECTORS_tempVt=[]  
        EvolutionMatrixVECTORS_temp0t=[]  
        EvolutionMatrixVECTORS_tempPt=[]
        EvolutionMatrixVECTORS_tempQt=[]

        
        for auxiliar_corrigirDeacordoComALinha in range(len(matrizSystem)):
            if matrizSystem[auxiliar_corrigirDeacordoComALinha][1]!='MID':
                DeltaVt.append(DeltaV[auxiliar_corrigirDeacordoComALinha])
                Delta0t.append(Delta0[auxiliar_corrigirDeacordoComALinha])
                PotPt.append(PotP[auxiliar_corrigirDeacordoComALinha])
                PotQt.append(PotQ[auxiliar_corrigirDeacordoComALinha])
                Barras_PQt.append(Barras_PQ[auxiliar_corrigirDeacordoComALinha])
                BarraQViola_estaticat.append(BarraQViola_estatica[auxiliar_corrigirDeacordoComALinha])
                VerificaSeViolat.append(VerificaSeViola[auxiliar_corrigirDeacordoComALinha])

        for aux_aux in range(len(EvolutionVECTOR_DeltaV)):
            EvolutionVECTOR_DeltaVt=[]  
            EvolutionVECTOR_Delta0t=[]  
            EvolutionVECTOR_mismatchPt=[]
            EvolutionVECTOR_mismatchQt=[]
            for auxiliar_corrigirDeacordoComALinha in range(len(matrizSystem)):
                if matrizSystem[auxiliar_corrigirDeacordoComALinha][1]!='MID':            
                    EvolutionVECTOR_DeltaVt.append(EvolutionVECTOR_DeltaV[aux_aux][auxiliar_corrigirDeacordoComALinha])
                    EvolutionVECTOR_Delta0t.append(EvolutionVECTOR_Delta0[aux_aux][auxiliar_corrigirDeacordoComALinha])
                    EvolutionVECTOR_mismatchPt.append(EvolutionVECTOR_mismatchP[aux_aux][auxiliar_corrigirDeacordoComALinha])
                    EvolutionVECTOR_mismatchQt.append(EvolutionVECTOR_mismatchQ[aux_aux][auxiliar_corrigirDeacordoComALinha])
              
            #print('wait')
            EvolutionMatrixVECTORS_tempVt.append(EvolutionVECTOR_DeltaVt) #PORTAS EM USO
            EvolutionMatrixVECTORS_temp0t.append(EvolutionVECTOR_Delta0t)
            EvolutionMatrixVECTORS_tempPt.append(EvolutionVECTOR_mismatchPt) #PORTAS EM USO
            EvolutionMatrixVECTORS_tempQt.append(EvolutionVECTOR_mismatchQt) 
            
        #print('wait')
        EvolutionMatrixVECTORS.append(EvolutionMatrixVECTORS_tempVt) #PORTAS EM USO
        EvolutionMatrixVECTORS.append(EvolutionMatrixVECTORS_temp0t)
        EvolutionMatrixVECTORS.append(EvolutionMatrixVECTORS_tempPt) #PORTAS EM USO
        EvolutionMatrixVECTORS.append(EvolutionMatrixVECTORS_tempQt)        
        return (DeltaVt, Delta0t, PotPt, PotQt, somaP, SomaQ, cont, MatrizY, Barras_PQt,JACOBIANA_INICIAL,JACOBIANA_FINAL,BarraQViola_estatica,pausa, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func,Delta0_Lim_Func, VerificaSeViola, EvolutionMatrixVECTORS, [], [])
                #(DeltaV, Delta0, PotP, PotQ, somaP, SomaQ, cont, MatrizY, Barras_PQ,JACOBIANA_INICIAL,JACOBIANA_FINAL,BarraQViola_estatica,pausa, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func,Delta0_Lim_Func, VerificaSeViola)

    """  --------------  SEÇÃO 7: PRINTS IMPORTANTES E PORTAS DE COMUNICAÇÃO -----------------  """
    EvolutionMatrixVECTORS.append(EvolutionVECTOR_DeltaV) #PORTAS EM USO
    EvolutionMatrixVECTORS.append(EvolutionVECTOR_Delta0)
    EvolutionMatrixVECTORS.append(EvolutionVECTOR_mismatchP)
    EvolutionMatrixVECTORS.append(EvolutionVECTOR_mismatchQ)
    EvolutionMatrixVECTORS.append(EvolutionVECTOR_swing)
    EvolutionMatrixVECTORS2=[None, None, explodiuporTENSAOGRANDE] #SPARES DE PORTAS DE COMUNICAÇÃO
    EvolutionMatrixMatriz2=None #SPARES DE PORTAS DE COMUNICAÇÃO
    
    #Encabecalha_plot_PotGer(PotP, PotQ, infoVctrl, Barras_PQ, matriz_DadosBarra)
    

    #([DeltaV],[Delta0])=voltarDeltas(NPV, NPQ, Barras_PQ, DeltaV0)
    # print('\n\n')
    # print('INFORMAÇÕES ÚTEIS (DADOS DE BARRA):')
    # print(matriz_DadosBarra)
    # print('\n')
    # print(infoVctrl)
    # print('contador: ', cont)
    # print('INFORMAÇÕES ÚTEIS (VARIÁVEIS DE ESTADO):')
    # print('Barras_PQ=', Barras_PQ)

    # #print('MatrizG=', MatrizG)
    # #print('MatrizB: ', MatrizB)
    # print('Tensão das barras: ', DeltaV)
    # print('Defasagem angular:  ', radianos_to_graus(Delta0))
    # print('Potência ATIVA LÍQUIDA das barras: ', PotP)
    # print('Potência REATIVA LÍQUIDA das barras: ', PotQ)
    # print('------------------------------------------')

    # print('Potência PERDAS ativa: ', somaP)
    # print('Potência PERDAS reativa: ', SomaQ)
    # print('Potência PERDAS VA: ', ((SomaQ**2+somaP**2)**(0.5)))
    # print('------------------------------------------')
    #print("cont", cont)

    # print_matriz_ordenada(JACOBIANA_FINAL)
    # exit


    # vetor_base = DeltaV
    # vetor_coluna = extrair_coluna(matrizSystem, 7)
    # print("Vetor extraído:", vetor_coluna)

    # # Calcular o desvio percentual
    # desvios, maior_desvio, indice_maior_desvio = calcular_desvio_porcentagem(vetor_coluna, vetor_base)
    # print('**************')
    # # Exibir resultados
    # print("Desvios percentuais da TENSÃO:", desvios)
    # print(f"Maior desvio: {maior_desvio:.2f}%")
    # print("Índice do maior desvio:", indice_maior_desvio)
    # print('**************')

    # print('tttttttttttttttt')
    # vetor_base = radianos_to_graus(Delta0)
    # vetor_coluna = extrair_coluna(matrizSystem, 8)
    # print("Vetor extraído:", vetor_coluna)

    # # Calcular o desvio percentual
    # desvios, maior_desvio, indice_maior_desvio = calcular_desvio_porcentagem(vetor_coluna, vetor_base)

    # # Exibir resultados
    # print("Desvios percentuais:", desvios)
    # print(f"Maior desvio: {maior_desvio:.2f}%")
    # print("Índice do maior desvio:", indice_maior_desvio)
    # print('tttttttttttttttt')

    return (DeltaV, Delta0, PotP, PotQ, somaP, SomaQ, cont, MatrizY, Barras_PQ,JACOBIANA_INICIAL,JACOBIANA_FINAL,BarraQViola_estatica,pausa, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func,Delta0_Lim_Func, VerificaSeViola, EvolutionMatrixVECTORS, EvolutionMatrixVECTORS2, EvolutionMatrixMatriz2)


def verificar_vetor(vetor):
    # Percorrer cada elemento do vetor
    for elemento in vetor:
        if (elemento == 'ViolaPB' or elemento == 'ViolaPC'):
            return 'PERMITIR'
    return 'NEGAR'



def HABILITAR_avaliacao_REATIVO (matrizSystem,HabiltAval_Lim_Reativo):
    verifica_se_permite='N'
    for j in range(len(matrizSystem)):
        if (matrizSystem[j][15]!=0 or matrizSystem[j][16]!=0):
            #HabiltAval_Lim_Reativo='Y'
            verifica_se_permite='Y'

    if (verifica_se_permite=='N' and HabiltAval_Lim_Reativo=='Y'):
        print('OS LIMITES DE REATIVOS ESTAO ZERADOS E POR ISSO NAO SERAO CONSIDERADOS NA ANÁLISE.')
        print('        !!!!!!!!!!      ANALISES SEM AVALIAR OS LIMITES      !!!!!!!!!')
        HabiltAval_Lim_Reativo='N'
        return HabiltAval_Lim_Reativo
    elif(verifica_se_permite=='Y' and HabiltAval_Lim_Reativo=='Y'):
        return HabiltAval_Lim_Reativo
    elif(verifica_se_permite=='N' and HabiltAval_Lim_Reativo=='N'):
        return HabiltAval_Lim_Reativo
    elif(verifica_se_permite=='Y' and HabiltAval_Lim_Reativo=='N'):
        return HabiltAval_Lim_Reativo
    

# def COERENCIA_de_Verifica_Se_Viola (PotQ_cal,PotQ_lim,V0_anterior,V0_atual,VerificaSeViola):
#     i=-1
#     for elemento in VerificaSeViola:
#         i=i+1
#         if (elemento == 'ViolaPB'):
#             if (V0_atual[i]<V0_anterior[i]):
#                 FALHA='Y'
        
#     FALHA='N'
#     return()

def criar_matriz_esparsa_com_indices(
    PVbarIndex, TENSAO_ESPEC,
    PIndex, ATIVA_ESPEC,
    GIndex, GERADOR,
    QIndex, REATIVA_ESPEC,
    MinMaxIndex, Qmin, Qmax,
    num_colunas,status_program
):
    if (status_program=='MANUAL'):
        # Identificadores para cada linha
        identificadores = ["PV", "P", "G", "Q", "Qmin", "Qmax"]
        num_linhas = len(identificadores) * 2  # Dobramos o número de linhas para incluir os índices
        
        # Inicializa a matriz com -1 para índices e 0 para valores
        matriz = np.zeros((num_linhas, num_colunas))
        matriz[::2, 1:] = -1  # Define os índices como -1 nas linhas de índices
        matriz[1::2, 1:] = 0  # Define as linhas de valores com 0 inicialmente
        
        # Função auxiliar para preencher índices e valores
        def preencher_linha(idx_linha, indices, valores):
            for idx in range(num_colunas - 1):
                if idx in indices:
                    pos = indices.index(idx)
                    matriz[idx_linha, idx + 1] = idx  # Preenche a linha de índice com o próprio índice
                    matriz[idx_linha + 1, idx + 1] = valores[pos]  # Preenche a linha de valores
                else:
                    matriz[idx_linha, idx + 1] = -1  # Marca como -1 os índices ausentes

        # Preenchendo a matriz
        preencher_linha(0, PVbarIndex, TENSAO_ESPEC)   # Para "PV"
        preencher_linha(2, PIndex, ATIVA_ESPEC)        # Para "P"
        preencher_linha(4, GIndex, GERADOR)            # Para "G"
        preencher_linha(6, QIndex, REATIVA_ESPEC)      # Para "Q"
        preencher_linha(8, MinMaxIndex, Qmin)          # Para "Qmin"
        preencher_linha(10, MinMaxIndex, Qmax)         # Para "Qmax"
        
        # Adiciona os identificadores nas linhas de valores e índices
        matriz_completa = []
        for i, identificador in enumerate(identificadores):
            # Linha de índices
            linha_indices = [f"{identificador}_idx"] + list(matriz[2 * i])
            matriz_completa.append(linha_indices)
            # Linha de valores
            linha_valores = [identificador] + list(matriz[2 * i + 1])
            matriz_completa.append(linha_valores)
    
    if(status_program=='CDF'):
        return None
    
    return matriz_completa




def extrair_coluna(matriz, indice_coluna):
    """
    Extrai uma coluna de uma matriz (lista de listas ou array numpy) e a transforma em um vetor (array numpy).
    
    Parâmetros:
    - matriz: list ou np.ndarray, matriz de entrada
    - indice_coluna: int, índice da coluna a ser extraída
    
    Retorna:
    - vetor_coluna: np.ndarray, vetor correspondente à coluna extraída
    
    Lança:
    - ValueError: se o índice da coluna estiver fora dos limites
    - TypeError: se a entrada não for uma lista ou um array numpy
    """
    
    # Convertendo a matriz para um numpy array, se necessário
    if isinstance(matriz, list):
        matriz = np.array(matriz)
    
    # Verificando se a entrada é uma matriz numpy
    if not isinstance(matriz, np.ndarray):
        raise TypeError("A matriz de entrada deve ser uma lista de listas ou um array numpy.")
    
    # Verificando o índice da coluna
    num_colunas = matriz.shape[1]
    if indice_coluna < 0 or indice_coluna >= num_colunas:
        raise ValueError(f"Índice da coluna ({indice_coluna}) fora dos limites. A matriz possui {num_colunas} colunas.")
    
    # Extraindo a coluna e transformando em um vetor
    vetor_coluna = matriz[:, indice_coluna].flatten()
    lista_floats = converter_vetor_strings_para_float(vetor_coluna)
    return lista_floats



def converter_vetor_strings_para_float(vetor_strings):
    """
    Converte um vetor de strings para um vetor de floats.
    
    Parâmetros:
    - vetor_strings: list, vetor contendo strings representando números
    
    Retorna:
    - lista_floats: list, vetor com valores convertidos para float
    """
    try:
        # Conversão de cada elemento da lista para float
        lista_floats = [float(valor) for valor in vetor_strings]
    except ValueError:
        raise ValueError("O vetor contém elementos não numéricos que não podem ser convertidos para float.")
    
    return lista_floats


def expandir_matriz_com_identificadores(matriz_inicial, tamanhoX, indices_extra_O, indices_extra_Q):
    """
    Expande a matriz fornecida inserindo identificadores conforme especificações, mantendo a mesma dimensão.

    Parâmetros:
        matriz_inicial (list of list): Matriz inicial quadrada de dimensões NxN.
        tamanhoX (int): Número de elementos sequenciais 'V' e 'P' até `tamanhoX`.
        indices_extra_O (list of int): Índices para identificadores extras 'O' nas colunas.
        indices_extra_Q (list of int): Índices para identificadores extras 'Q' nas linhas.

    Retorna:
        list of list: Matriz expandida NxN com identificadores de linha e coluna.
    """
    # Dimensão da matriz inicial (N x N)
    N = len(matriz_inicial)
    
    # Ordenando índices extras
    indices_extra_O = sorted(indices_extra_O)
    indices_extra_Q = sorted(indices_extra_Q)

    # Criando identificadores para colunas: 'V' seguido de extras 'O'
    colunas_identificadores = [f'V{i}' for i in range(2, tamanhoX + 2)]
    colunas_identificadores += [f'O{idx}' for idx in indices_extra_O]
    
    # Criando identificadores para linhas: 'P' seguido de extras 'Q'
    linhas_identificadores = [f'P{i}' for i in range(2, tamanhoX + 2)]
    linhas_identificadores += [f'Q{idx}' for idx in indices_extra_Q]

    # # Garantir que as listas têm exatamente N elementos
    # colunas_identificadores = colunas_identificadores[:N]
    # linhas_identificadores = linhas_identificadores[:N]
    
   # Ajustando tamanho dos identificadores (linhas e colunas) para N 
    colunas_identificadores = colunas_identificadores[:N] 
    linhas_identificadores = linhas_identificadores[:N]
    
    # Criando a matriz expandida com a primeira linha de identificadores
    matriz_expandida = []
    
    # Adicionando a primeira linha com identificadores de colunas
    primeira_linha = [''] + colunas_identificadores
    matriz_expandida.append(primeira_linha)
    
    # Preenchendo as linhas da matriz original com identificadores na primeira coluna
    for i in range(N):
        linha_atual = [linhas_identificadores[i]]  # Identificador da linha
        for j in range(N):
            linha_atual.append(matriz_inicial[i][j])  # Adiciona os valores da matriz original
        matriz_expandida.append(linha_atual)
    
    # Adicionando a nova linha com identificadores extras
    # nova_linha = ['EXTRA'] + [0.0] * N + [0.0]  # A nova linha com os valores 0.0
    # matriz_expandida.append(nova_linha)
    
    # Adicionando a nova coluna para cada linha da matriz expandida
    # for i in range(1, N + 1):
    #     matriz_expandida[i].append(0.0)  # Adiciona a coluna extra com 0.0
    return matriz_expandida


def indices_N(vetor):
    """
    Encontra e retorna os índices onde o valor do vetor é 'N'.

    Parâmetros:
        vetor (list of str): Lista de strings contendo elementos como 'swing', 'N', 'Y', etc.

    Retorna:
        list of int: Lista de índices onde o elemento do vetor é 'N'.
    """
    # Encontrando os índices onde o valor é 'N'
    indices = [i+1 for i, valor in enumerate(vetor) if valor == 'Y']
    return indices



def print_matriz_ordenada(matriz):
    """
    Função para imprimir uma matriz de forma ordenada, com alinhamento dos elementos
    e com valores numéricos formatados para 4 casas decimais.
    
    Parâmetros:
        matriz (list of list): Matriz a ser impressa.
    """
    # Número de colunas
    colunas = len(matriz[0])
    
    # Calculando a largura máxima de cada coluna
    larguras = []
    for j in range(colunas):
        max_len = 0
        for i in range(len(matriz)):
            if isinstance(matriz[i][j], (int, float)):  # Se o valor for numérico
                max_len = max(max_len, len(f"{matriz[i][j]:.4f}"))
            else:  # Caso o valor seja string
                max_len = max(max_len, len(str(matriz[i][j])))
        larguras.append(max_len)

    # Agora, imprimimos a matriz linha por linha
    for linha in matriz:
        for j, valor in enumerate(linha):
            # Para a primeira coluna, não precisa alinhar os valores, mas para as outras, alinhamos à direita
            if j == 0:
                print(f"{valor:<{larguras[j]}}", end='')  # Alinha à esquerda para o identificador
            else:
                # Formata os valores numéricos com 4 casas decimais
                if isinstance(valor, (int, float)):
                    print(f"{valor:>{larguras[j]}.4f}", end='')  # Alinha à direita para os valores numéricos
                else:
                    print(f"{valor:<{larguras[j]}}", end='')  # Para strings, alinha à esquerda
        print()  # Nova linha após imprimir todos os valores de uma linha


def print_matriz_complexa_centralizada(matriz):
    """
    Função para imprimir uma matriz quadrada de números complexos de forma compacta,
    com alinhamento central dos elementos e formatando as partes real e imaginária com 2 casas decimais.
    
    Parâmetros:
        matriz (list of list): Matriz quadrada com valores complexos a ser impressa.
    """
    # Número de colunas (e linhas, pois a matriz é quadrada)
    colunas = len(matriz[0])
    
    # Calculando a largura máxima de cada coluna
    larguras = []
    for j in range(colunas):
        max_len = 0
        for i in range(len(matriz)):
            if isinstance(matriz[i][j], complex):  # Se o valor for um número complexo
                parte_real = f"{matriz[i][j].real:.2f}"
                parte_imag = f"{matriz[i][j].imag:.2f}"
                max_len = max(max_len, len(parte_real) + len(parte_imag) + 3)  # espaço para o ' + ' ou ' - '
            else:  # Caso o valor seja string ou outro tipo
                max_len = max(max_len, len(str(matriz[i][j])))
        larguras.append(max_len)

    # Agora, imprimimos a matriz linha por linha, com alinhamento central e espaçamento extra
    for linha in matriz:
        for j, valor in enumerate(linha):
            # Para valores complexos, formatamos a parte real e imaginária com 2 casas decimais
            if isinstance(valor, complex):
                parte_real = f"{valor.real:.2f}"
                parte_imag = f"{valor.imag:.2f}"
                if valor.imag >= 0:
                    print(f"{parte_real} + {parte_imag}j", end=f"{' ' * (larguras[j] - len(parte_real) - len(parte_imag) - 3 + 2)}")  # Aumenta 2 espaços
                else:
                    print(f"{parte_real} - {parte_imag[1:]}j", end=f"{' ' * (larguras[j] - len(parte_real) - len(parte_imag) - 3 + 2)}")  # Aumenta 2 espaços
            else:
                # Para números não complexos, alinhamento central com 2 espaços extras
                print(f"{valor:^{larguras[j]}}", end='  ')  # Centraliza o valor e coloca 2 espaços adicionais
        print()  # Nova linha após imprimir todos os valores de uma linha
    return()

def plotar_entidadesEL(DeltaV, Delta0, PotP, PotQ,count):
    print('\n')
    print('INFORMAÇÕES RELEVANTES:')
    
    # Cabeçalho com os índices
    print(f"{'Index':<10}{'DeltaV':<15}{'Delta0 (graus)':<20}{'PotP':<15}{'PotQ':<15}")
    print("-" * 70)

    # Garantindo que todos os vetores têm o mesmo tamanho
    n = min(len(DeltaV), len(Delta0), len(PotP), len(PotQ))

    for i in range(n):
        print(f"{i:<10}{DeltaV[i]:<15.4f}{radianos_to_grausN(Delta0[i]):<20.4f}{PotP[i]:<15.4f}{PotQ[i]:<15.4f}")
    print('\n')
    print('-------------------------- contador de iterações: ',count,'--------------------------')

    return()

def radianos_to_grausN(radianos):
    # Se for um número escalar, converta e retorne um único valor
    if isinstance(radianos, (int, float)):
        return radianos * 180 / np.pi
    # Caso contrário, converta todos os valores no vetor/lista
    return [r * (180 / np.pi) for r in radianos]



def plot(DeltaV, Delta0, PotP, PotQ, info_controle,count):
    print('\n')
    print('INFORMAÇÕES RELEVANTES:')

    # Cabeçalho com os índices
    print(f"{'Index':<10}{'DeltaV':<15}{'Delta0 (graus)':<20}{'PotP':<15}{'PotQ':<15}| {'Informações de controles de tensão (lidos)'}")
    print("-" * 85)
    
    # Garantindo que todos os vetores têm o mesmo tamanho
    n = min(len(DeltaV), len(Delta0), len(PotP), len(PotQ))

    for i in range(n):
        # Obtenção das informações de controle de tensão
        info1 = info_controle[0][i] if i < len(info_controle[0]) else ""
        info2 = info_controle[1][i] if i < len(info_controle[1]) else ""
        
        # Imprimir os dados de cada linha
        print(f"{i+1:<10}{DeltaV[i]:<15.4f}{radianos_to_grausN(Delta0[i]):<20.4f}{PotP[i]:<15.4f}{PotQ[i]:<15.4f}| {info1:<15}{info2:<15}")
    
    print('\n')
    print('---------------------------------------------- contador de iterações: ',count,'----------------------------------------------')
    return()



def plot_PotGer(PotP, PotQ, info_controle, Barras_PQ, matriz_DadosBarra):
    # Cabeçalho com os índices
    print(f"{'Index':<10}| {'Controles de tensão (efetivo) '} | {'Barras_PQ FINAL':<15} | {'Pot. P Ger.':<20} | {'Pot. Q Ger.':<20} | {'Limites de reativos':<25}")
    print("-" * 120)
    
    # Garantindo que todos os vetores têm o mesmo tamanho
    n = min(len(info_controle[0]), len(info_controle[1]), len(Barras_PQ), len(PotP), len(PotQ))
    
    # Ajustando para o tamanho de 'matriz_DadosBarra' (considerando suas chaves)
    # m1 = len(matriz_DadosBarra[1]) if 1 in matriz_DadosBarra else 0
    # m2 = len(matriz_DadosBarra[2]) if 2 in matriz_DadosBarra else 0
    # m4 = len(matriz_DadosBarra[4]) if 4 in matriz_DadosBarra else 0
    # m5 = len(matriz_DadosBarra[5]) if 5 in matriz_DadosBarra else 0
    
    # n = min(n, m1, m2, m4, m5)
    for i in range(n):
        if ((info_controle[0][i]=='G' or info_controle[0][i]=='CS') and info_controle[1][i]==0):
            info_controle[1][i]=1.0


    for i in range(n):
        # Obtenção das informações de controle de tensão
        info1 = info_controle[0][i] if i < len(info_controle[0]) else ""
        info2 = info_controle[1][i] if i < len(info_controle[1]) else ""
        
        # Obtenção das informações de potência
        barra_pq = Barras_PQ[i] if i < len(Barras_PQ) else ""
        
        # Cálculo das potências geradas
        if info_controle[0][i]=='G' or info_controle[0][i]=='CS':
            pot_p_gerada = PotP[i] - matriz_DadosBarra[1][i]  # Potência P gerada
            pot_q_gerada = PotQ[i] - matriz_DadosBarra[2][i]  # Potência Q gerada
        else:
            pot_p_gerada = PotP[i]
            pot_q_gerada = PotQ[i]   
        
        # Limites mínimos e máximos de reativos
        limite_min = matriz_DadosBarra[4][i] if i < len(matriz_DadosBarra[4]) else 0
        limite_max = matriz_DadosBarra[5][i] if i < len(matriz_DadosBarra[5]) else 0
        
        # Verifica se o limite é 0/0 para não exibir
        limite_min_max = f"{limite_min} / {limite_max}" if (limite_min != 0 or limite_max != 0) else ""
        
        # Imprimir os dados de cada linha
        print(f"{i+1:<10}| {info1:<15}{info2:<15} | {barra_pq:<15} | {pot_p_gerada:<20.4f} | {pot_q_gerada:<20.4f} | {limite_min_max:<25}")



def arrumar_DadosDeModelagem_LinhaPItoT(DeltaV, Delta0, PotP, PotQ, Barras_PQ, BarraQViola_estatica, matrizSystem, MODELin):
    if MODELin=='T':
        DeltaVt=[]
        Delta0t=[]
        PotPt=[]
        PotQt=[]
        Barras_PQt=[]
        BarraQViola_estaticat=[]
        VerificaSeViolat=[]    
        
        for auxiliar_corrigirDeacordoComALinha in range(len(matrizSystem)):
            if matrizSystem[auxiliar_corrigirDeacordoComALinha][1]!='MID':
                DeltaVt.append(DeltaV[auxiliar_corrigirDeacordoComALinha])
                Delta0t.append(Delta0[auxiliar_corrigirDeacordoComALinha])
                PotPt.append(PotP[auxiliar_corrigirDeacordoComALinha])
                PotQt.append(PotQ[auxiliar_corrigirDeacordoComALinha])
                Barras_PQt.append(Barras_PQ[auxiliar_corrigirDeacordoComALinha])
                BarraQViola_estaticat.append(BarraQViola_estatica[auxiliar_corrigirDeacordoComALinha])
                #VerificaSeViolat.append(VerificaSeViola[auxiliar_corrigirDeacordoComALinha])
    
        return(DeltaVt, Delta0t, PotPt, PotQt, Barras_PQt, BarraQViola_estaticat)
    else:
        return(DeltaV, Delta0, PotP, PotQ, Barras_PQ, BarraQViola_estatica)

def limpa_jacobs(JACOBIANA_INICIAL, JACOBIANA_FINAL):
    for auxiliar in range(len(JACOBIANA_INICIAL)):
        if auxiliar!=0:
            JACOBIANA_INICIAL[auxiliar]= [JACOBIANA_INICIAL[auxiliar][0]] + [float(x) for x in JACOBIANA_INICIAL[auxiliar][1:]]

    for auxiliar in range(len(JACOBIANA_FINAL)):
        if auxiliar!=0:
            JACOBIANA_FINAL[auxiliar]= [JACOBIANA_FINAL[auxiliar][0]] + [float(x) for x in JACOBIANA_FINAL[auxiliar][1:]]
    
    return(JACOBIANA_INICIAL, JACOBIANA_FINAL)






''' ------------------------------------------------------------------------------------------------ '''
''' ------------------------------------ FUNÇÕES DE GoS -------------------------------------------- '''
''' ------------------------------------------------------------------------------------------------ '''



def interpretar_entrad_rodarManual(entrad_rodarManual, lim_sup):
    vetor_barr = []
    vetor_percent = []

    # Split the input string by underscores to separate entries
    entradas = entrad_rodarManual.split('_')

    for entrada in entradas:
        if '*' in entrada:
            intervalo, porcentagem = entrada.split('*')
        else:
            intervalo, porcentagem = entrada.split('-')

        porcentagem = float(porcentagem) / 100  # Convert percentage to a float and divide by 100

        # Handle range intervals
        if '-' in intervalo:
            inicio, fim = map(int, intervalo.split('-'))

            if inicio < 0 or inicio > lim_sup or fim < 0 or fim > lim_sup:
                raise ValueError("Intervalos devem ser inteiros não negativos e menores que lim_sup.")

            vetor_barr.extend(range(inicio, fim + 1))
            vetor_percent.extend([porcentagem] * (fim - inicio + 1))

        else:  # Handle single values
            valor = int(intervalo)

            if valor < 0 or valor > lim_sup:
                raise ValueError("Valores devem ser inteiros não negativos e menores que lim_sup.")

            vetor_barr.append(valor)
            vetor_percent.append(porcentagem)

    # Remove duplicates, preferring smaller intervals
    unique_barr_percent = {}
    for barr, percent in zip(vetor_barr, vetor_percent):
        if barr not in unique_barr_percent or percent < unique_barr_percent[barr]:
            unique_barr_percent[barr] = percent

    # Sort the results to ensure order
    vetor_barr = sorted(unique_barr_percent.keys())
    vetor_percent = [unique_barr_percent[barr] for barr in vetor_barr]

    #print(vetor_percent)
    vetor_percent_up=[]
    vetor_percent_down=[]
    for aux in range(len(vetor_percent)):
        vetor_percent_up.append(1+vetor_percent[aux])
        vetor_percent_down.append(1-vetor_percent[aux])

    return vetor_barr, vetor_percent, vetor_percent_up, vetor_percent_down


def ajustar_ATIVA_ESPEC0(ATIVA_ESPEC0, vetor_barr, vetor_percent_up, vetor_percent_down):
    # Criar o vetor de índices começando de 1
    ATIVA_ESPEC0_index = list(range(1, len(ATIVA_ESPEC0) + 1))

    # Inicializar os vetores resultantes
    ATIVA_ESPEC_ManUp = ATIVA_ESPEC0[:]
    ATIVA_ESPEC_ManDown = ATIVA_ESPEC0[:]

    # Iterar sobre vetor_barr e aplicar os ajustes
    for i, barr in enumerate(vetor_barr):
        if barr in ATIVA_ESPEC0_index:
            idx = ATIVA_ESPEC0_index.index(barr)  # Obter o índice correspondente
            ATIVA_ESPEC_ManUp[idx] = ATIVA_ESPEC0[idx] * vetor_percent_up[i]
            ATIVA_ESPEC_ManDown[idx] = ATIVA_ESPEC0[idx] * vetor_percent_down[i]

    return ATIVA_ESPEC_ManUp, ATIVA_ESPEC_ManDown


def extrair_potencias_negativas(matrizSystem):
    # Extração da coluna 9 (índice zero é 8) e ajuste para valores negativos apenas se não forem zeros
    potencias_ajustadas = [-abs(linha[9]) if linha[9] != 0 else 0 for linha in matrizSystem]
    return potencias_ajustadas


def detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BqV_T, VsV_T):
    """
    Detecta mudanças entre duas matrizes iniciais e duas matrizes teste.

    :param BarraQViola_estatica_0: Lista inicial de valores para BarraQViola_estatica.
    :param VerificaSeViola_0: Lista inicial de valores para VerificaSeViola_PQPV.
    :param BqV_T: Lista de teste para BarraQViola_estatica.
    :param VsV_T: Lista de teste para VerificaSeViola_PQPV.
    :return: Tuple (True/False, indicador).
    """
    mudanca_BarraQViola = BarraQViola_estatica_0 != BqV_T
    mudanca_VerificaSeViola = VerificaSeViola_0 != VsV_T

    if mudanca_BarraQViola and mudanca_VerificaSeViola:
        return True, 'BqV_VsV'
    elif mudanca_BarraQViola:
        return True, 'BqV'
    elif mudanca_VerificaSeViola:
        return True, 'VsV'
    else:
        return False, None
    

def analisa_BqV(D_BqV_PES):
    vetor_posicoes = []

    # Percorrendo cada linha da matriz
    for linha in D_BqV_PES:
        # Encontrar os índices dos valores não nulos
        indices_nao_nulos = [str(idx+1) for idx, valor in enumerate(linha) if valor != 0]

        # for auxiliar_MudaIndexTo1 in range(len(indices_nao_nulos)):
        #     indices_nao_nulos[auxiliar_MudaIndexTo1]=indices_nao_nulos[auxiliar_MudaIndexTo1]+1

        # Concatenar os índices encontrados com '_'
        posicoes_concatenadas = "_".join(indices_nao_nulos)

        # Adicionar ao vetor
        vetor_posicoes.append(posicoes_concatenadas)

    return vetor_posicoes


def analisadora_DeResultados(BarraQViola_estatica_0, PVbarIndex, D_BqV_PES):
    # Calculate quantidadeViolada
    for aux in range(len(PVbarIndex)):
        PVbarIndex[aux]= PVbarIndex[aux]-1

    X = sum(1 for value in PVbarIndex if value in BarraQViola_estatica_0)
    Y = len(PVbarIndex)
    
    if PVbarIndex[0]==0:
        if BarraQViola_estatica_0[0]==PVbarIndex[0]:
            Z=X-1
            W=Y-1
            quantidadeViolada_0 = f"{Z} de {W}"
        else:
            Z=X
            W=Y
            quantidadeViolada_0 = f"{X} de {Y}"
    else:
        Z=X
        W=Y
        quantidadeViolada_0 = f"{X} de {Y}"        
    
    # Create matriz_de_diferencas
    matriz_de_diferencas = []
    Indicador_de_QUALIDADE=[]
    Quantidade_Violada=[]
    for linha in D_BqV_PES:

        Aux = sum(1 for value in PVbarIndex if value in linha)
        if PVbarIndex[0]==0:
            if linha[0]==PVbarIndex[0]:
                Z_n=Aux-1
                Y_n=Y-1
            else:
                Z_n=Aux
                Y_n=Y
        else:
            Z_n=Aux
            Y_n=Y 

        if Z_n>Z:
            nova_linha = [valor if valor not in BarraQViola_estatica_0 else 0 for valor in linha]
            for aux in range(len(nova_linha)):
                if nova_linha[aux]!=0:
                    nova_linha[aux]= nova_linha[aux]+1
            matriz_de_diferencas.append(nova_linha)
            Indicador_de_QUALIDADE.append('PIOR')
            Quantidade_Violada.append(f"{Z_n} de {Y_n}")
        elif Z_n<Z:
            nova_linha = [valor if valor not in linha else 0 for valor in BarraQViola_estatica_0]
            for aux in range(len(nova_linha)):
                if nova_linha[aux]!=0:
                    nova_linha[aux]= nova_linha[aux]+1            
            matriz_de_diferencas.append(nova_linha)
            Indicador_de_QUALIDADE.append('MELHOR')
            Quantidade_Violada.append(f"{Z_n} de {Y_n}") 
        elif Z_n==Z:
            nova_linha = [valor if valor not in linha else 0 for valor in BarraQViola_estatica_0]
            for aux in range(len(nova_linha)):
                if nova_linha[aux]!=0:
                    nova_linha[aux]= nova_linha[aux]+1            
            matriz_de_diferencas.append(nova_linha)
            Indicador_de_QUALIDADE.append('INDIFERENTE')                   
            Quantidade_Violada.append(f"{Z_n} de {Y_n}") 
    # Create vetor_de_diferencas

    vetor_de_diferencas = ["_".join(map(str, filter(lambda x: x != 0, linha))) for linha in matriz_de_diferencas]
    # for aux in range(len(vetor_de_diferencas)):
    #     vetor_de_diferencas[aux]= vetor_de_diferencas[aux]+1

    return quantidadeViolada_0, matriz_de_diferencas, vetor_de_diferencas, Indicador_de_QUALIDADE, Quantidade_Violada


def extrair_vetores_da_matrizSystem(matrizSystem):
    # Inicialização dos vetores
    PVbarIndex = []
    TENSAO_ESPEC = []
    QIndex = []
    REATIVA_ESPEC = []
    GIndex = []
    GERADOR = []
    MinMaxIndex = []
    Qmin = []
    Qmax = []

    # Iteração sobre a matrizSystem
    for idx, linha in enumerate(matrizSystem):
        # Coluna 14 (zero_index é 13): PVbarIndex e TENSAO_ESPEC
        if linha[14] != 0:
            PVbarIndex.append(idx)
            TENSAO_ESPEC.append(linha[14])

        # Coluna 10 (zero_index é 9): QIndex e REATIVA_ESPEC
        if linha[10] != 0:
            QIndex.append(idx)
            REATIVA_ESPEC.append(-abs(linha[10]))  # Tornar valores negativos

        # Coluna 11 (zero_index é 10): GIndex e GERADOR
        if linha[11] != 0:
            GIndex.append(idx)
            GERADOR.append(linha[11])

        # Colunas 15 e 16 (zero_index é 14 e 15): MinMaxIndex, Qmin, Qmax
        if linha[16] != 0 or linha[15] != 0:
            MinMaxIndex.append(idx)
            Qmax.append(linha[15])
            Qmin.append(linha[16])

    return PVbarIndex, TENSAO_ESPEC, QIndex, REATIVA_ESPEC, GIndex, GERADOR, MinMaxIndex, Qmin, Qmax



def comparar_BarraQViola(BarraQViola_estatica, BarraQViola_estatica_up, PVbarIndex):
    # Criar vetores modificados
    BarraQViola_estatica_up_modific = []
    BarraQViola_estatica_modific = []

    for est, est_up in zip(BarraQViola_estatica, BarraQViola_estatica_up):
        if est != 0 and est_up != 0 and est == est_up:
            BarraQViola_estatica_up_modific.append(0)
            BarraQViola_estatica_modific.append(0)
        else:
            BarraQViola_estatica_up_modific.append(est_up if est_up != 0 and est == 0 else 0)
            BarraQViola_estatica_modific.append(est if est != 0 and est_up == 0 else 0)

    # Criar strings de concatenados valores não nulos
    stingBarraQViola_estatica = "_".join(str(x) for x in BarraQViola_estatica if x != 0)
    stringBarraQViola_estatica_up_modific = "_".join(str(x) for x in BarraQViola_estatica_up_modific if x != 0)
    stringBarraQViola_estatica_modific = "_".join(str(x) for x in BarraQViola_estatica_modific if x != 0)

    # Determinar stringIndicadeQualidade
    non_zero_estatica = sum(1 for x in BarraQViola_estatica if x != 0)
    non_zero_estatica_up = sum(1 for x in BarraQViola_estatica_up if x != 0)
    if non_zero_estatica_up > non_zero_estatica or non_zero_estatica_up < non_zero_estatica:
        stringIndicadeQualidade = "PIOR" if non_zero_estatica_up > non_zero_estatica else "MELHOR"
    elif non_zero_estatica_up == non_zero_estatica:
        stringIndicadeQualidade = "INDIFERENTE"

    # Determinar stringQauntidadeQViolaInical e stringQauntidadeQViolaFinal
    non_zero_pvbar = sum(1 for x in PVbarIndex if x != 0)
    stringQauntidadeQViolaInical = f"{non_zero_estatica} de {non_zero_pvbar}"
    stringQauntidadeQViolaFinal = f"{non_zero_estatica_up} de {non_zero_pvbar}"

    return (BarraQViola_estatica_up_modific, BarraQViola_estatica_modific, 
            stingBarraQViola_estatica, stringBarraQViola_estatica_up_modific, 
            stringBarraQViola_estatica_modific, stringIndicadeQualidade, 
            stringQauntidadeQViolaInical, stringQauntidadeQViolaFinal)





def Encabecalha_plot(DeltaV, Delta0, PotP, PotQ, info_controle,count, matriz_DadosBarra):
    #print('\n')
    #print('INFORMAÇÕES RELEVANTES:')

    # Cabeçalho com os índices
    #print(f"{'Index':<10}|{'DeltaV':<15}|{'Delta0 (graus)':<20}|{'PotP':<15}|{'PotQ':<15}| {'Informações de controles de tensão (lidos)'}")
    #print("-" * 85)
    matrizTitulo=['Index','DeltaV','Delta0 (graus)','PotP','PotQ','Limite Inferior (Ger)','Limite Superior (Ger)']
    
    # Garantindo que todos os vetores têm o mesmo tamanho
    n = min(len(DeltaV), len(Delta0), len(PotP), len(PotQ))

    matrizCampos=[]
    for i in range(n):
        # Obtenção das informações de controle de tensão
        #info1 = info_controle[0][i] if i < len(info_controle[0]) else ""
        #info2 = info_controle[1][i] if i < len(info_controle[1]) else ""
        info1 = matriz_DadosBarra[4][i] if i < len(matriz_DadosBarra[4]) else 0
        info2 = matriz_DadosBarra[5][i] if i < len(matriz_DadosBarra[5]) else 0


        # Imprimir os dados de cada linha
        #print(f"{i+1:<10}|{DeltaV[i]:<15.4f}|{radianos_to_grausN(Delta0[i]):<20.4f}|{PotP[i]:<15.4f}|{PotQ[i]:<15.4f}| {info1:<15}|{info2:<15}")
        matrizCampos.append([i+1,DeltaV[i],radianos_to_grausN(Delta0[i]),PotP[i],PotQ[i],info1,info2])    
    #print('\n')
    #print('---------------------------------------------- contador de iterações: ',count,'----------------------------------------------')
    return(matrizTitulo,matrizCampos)



def Encabecalha_plot_PotGer(PotP, PotQ, info_controle, Barras_PQ, matriz_DadosBarra):
    # Cabeçalho com os índices
    #print(f"{'Index':<10}| {'Controles de tensão (efetivo) '} | {'Barras_PQ FINAL':<15} | {'Pot. P Ger.':<20} | {'Pot. Q Ger.':<20} | {'Limites de reativos':<25}")
    #print("-" * 120)
    
    matrizCabecalho=['Index','Controles de tensão (efetivo)','Tipo de Barra','Tipo Final','Pot. P Ger.','Pot. Q Ger.','Limite min/Max']
    # Garantindo que todos os vetores têm o mesmo tamanho
    n = min(len(info_controle[0]), len(info_controle[1]), len(Barras_PQ), len(PotP), len(PotQ))
    
    # Ajustando para o tamanho de 'matriz_DadosBarra' (considerando suas chaves)
    # m1 = len(matriz_DadosBarra[1]) if 1 in matriz_DadosBarra else 0
    # m2 = len(matriz_DadosBarra[2]) if 2 in matriz_DadosBarra else 0
    # m4 = len(matriz_DadosBarra[4]) if 4 in matriz_DadosBarra else 0
    # m5 = len(matriz_DadosBarra[5]) if 5 in matriz_DadosBarra else 0
    
    # n = min(n, m1, m2, m4, m5)
    matrizCampos=[]
    for i in range(n):
        if ((info_controle[0][i]=='G' or info_controle[0][i]=='CS') and info_controle[1][i]==0):
            info_controle[1][i]=1.0


    for i in range(n):
        # Obtenção das informações de controle de tensão
        info1 = info_controle[0][i] if i < len(info_controle[0]) else ""
        info2 = info_controle[1][i] if i < len(info_controle[1]) else ""
        
        # Obtenção das informações de potência
        barra_pq = Barras_PQ[i] if i < len(Barras_PQ) else ""
        
        # Cálculo das potências geradas
        if info_controle[0][i]=='G' or info_controle[0][i]=='CS' or info_controle[0][i]=='swing':
            pot_p_gerada = PotP[i] - matriz_DadosBarra[1][i]  # Potência P gerada
            pot_q_gerada = PotQ[i] - matriz_DadosBarra[2][i]  # Potência Q gerada
        else:
            pot_p_gerada = 0.00
            pot_q_gerada = 0.00  
        
        # Limites mínimos e máximos de reativos
        limite_min = matriz_DadosBarra[4][i] if i < len(matriz_DadosBarra[4]) else 0
        limite_max = matriz_DadosBarra[5][i] if i < len(matriz_DadosBarra[5]) else 0
        #limite_min=1.2
        #limite_max=1.1

        # Verifica se o limite é 0/0 para não exibir
        limite_min_max = f"{limite_min} / {limite_max}" if (limite_min != 0 or limite_max != 0) else ""
        
        # Imprimir os dados de cada linha
        #print(f"{i+1:<10} | {info1:<15}| {info2:<15} | {barra_pq:<15} | {pot_p_gerada:<20.4f} | {pot_q_gerada:<20.4f} | {limite_min_max:<25}")
        matrizCampos.append([i+1,info2,info1,barra_pq,pot_p_gerada,pot_q_gerada,limite_min_max])

    return(matrizCabecalho,matrizCampos)






def remover_duplicatas_sincronizado(vetor1, vetor2):
    """
    Remove duplicatas do vetor1 e remove os elementos correspondentes em vetor2.

    Parâmetros:
        vetor1 (list): Lista de elementos (ex.: números) que podem ter duplicatas.
        vetor2 (list): Lista de outros dados (ex.: strings) de mesmo tamanho que vetor1.

    Retorna:
        tuple: Dois novos vetores (novos_vetor1, novos_vetor2) com os elementos únicos de vetor1
               e os elementos correspondentes de vetor2.
    """
    if len(vetor1) != len(vetor2):
        raise ValueError("Os vetores devem ter o mesmo tamanho.")

    vistos = set()
    novos_vetor1 = []
    novos_vetor2 = []

    for i, valor in enumerate(vetor1):
        if i!=0:
            if valor not in vistos:
                vistos.add(valor)
                novos_vetor1.append(valor)
                novos_vetor2.append(vetor2[i])
    
    return novos_vetor1, novos_vetor2



def unir_valores_nao_repetidos(matriz):
    """
    Para cada linha da matriz, extrai os valores distintos (não repete nenhum valor),
    ignora o valor 0 e retorna um vetor com a união de todos esses valores.
    
    Parâmetros:
        matriz (list of list): Matriz em que cada linha é uma lista de números.
        
    Retorna:
        list: Vetor contendo os valores distintos encontrados em todas as linhas.
    """
    resultado = set()
    
    for linha in matriz:
        # Obtém os valores únicos da linha e remove o 0, se estiver presente
        valores_distintos = set(linha)
        valores_distintos.discard(0)
        # Atualiza o conjunto resultado com os valores desta linha
        resultado.update(valores_distintos)
    
    # Retorna uma lista ordenada (opcional)
    return sorted(resultado)



def processar_matrizes(lista_index, lista_valor):
    """
    Processa duas matrizes com o mesmo tamanho:
      - lista_index: matriz de índices (números inteiros).
      - lista_valor: matriz de valores associados (números reais).
    
    Para cada linha de lista_index, extrai os valores distintos (ignorando o 0) e,
    em seguida, realiza a união entre as linhas para obter o vetor 'resultado'.
    
    Em 'resultado2', para cada valor presente em 'resultado', busca o maior valor
    associado (na mesma posição) em lista_valor.
    
    Parâmetros:
      lista_index (list of list of int): matriz com valores inteiros.
      lista_valor (list of list of float): matriz com valores reais associados.
      
    Retorna:
      resultado  : np.array (dtype=int) contendo os valores distintos encontrados (sem o 0).
      resultado2 : np.array (dtype=float) contendo, para cada valor de resultado, o maior valor
                   associado em lista_valor.
    """
    # 1. Extrair a união dos valores (descartando 0) de todas as linhas da matriz de índices.
    resultado_set = set()
    for linha in lista_index:
        # Remove o 0 e atualiza o conjunto
        resultado_set.update(set(linha) - {0})
    
    # Converter para vetor (array) ordenado e com dtype inteiro
    #resultado = np.array(sorted(resultado_set), dtype=int)
    resultado = sorted(resultado_set)
    
    # 2. Para cada valor em 'resultado', buscar o maior valor associado na outra matriz.
    resultado2 = []
    for valor in resultado:
        max_valor = None
        # Percorre todas as linhas e colunas
        for i in range(len(lista_index)):
            for j in range(len(lista_index[0])):
                if lista_index[i][j] == valor:
                    valor_associado = lista_valor[i][j]
                    if max_valor is None or valor_associado > max_valor:
                        max_valor = valor_associado
        resultado2.append(max_valor)
    
    # Converter resultado2 para np.array com dtype float
    #resultado2 = np.array(resultado2, dtype=float)
    
    return resultado, resultado2

# # Exemplo de uso:
# LISTAindex_maior_valor_estatica = [
#     [0, 4, 4, 3, 4, 4, 4, 3, 3, 3, 3, 3, 3, 13],
#     [3, 3, 3, 3, 4, 4, 4, 3, 3, 3, 3, 3, 3, 3],
#     [3, 3, 3, 3, 4, 4, 4, 3, 3, 3, 3, 3, 3, 3],
#     [3, 3, 3, 3, 4, 4, 4, 3, 3, 3, 3, 3, 4, 3],
#     [3, 3, 4, 3, 4, 4, 4, 3, 3, 3, 3, 4, 4, 4],
#     [4, 4, 4, 4, 4, 4, 4, 3, 3, 3, 3, 3, 3, 3],
#     [3, 3, 3, 3, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9],
#     [11, 9, 9, 9, 9, 11, 11, 9, 9, 9, 9, 11, 11, 11]
# ]

# LISTA_maior_valor_estatica = [
#     [0.0, 3.890609401091538e-06, 2.610814035297615e-05, 0.00018389138695007468, 0.00030510259165272835, 0.00047119613808099814, 0.0006322278344370602, 0.0008122780826800291, 0.0010225895924360628, 0.0012236706300772227, 0.0013923026693349883, 0.0015299718477699287, 0.0016784480884499686, 0.0018941669628016466],
#     [0.0020700718685811026, 0.0020711758261380275, 0.002088209816297537, 0.002258754340188629, 0.002366578672423625, 0.002544057762301044, 0.0027625119766665485, 0.00301332933373466, 0.0032834333578461994, 0.0035440409147675656, 0.00376851602443784, 0.003958764348555022, 0.004161532091822906, 0.004418344066872137],
#     [0.004676959859377439, 0.0047316198316484925, 0.004787041362607658, 0.005007485833383951, 0.005158493360628347, 0.005386399768408268, 0.005614899801076101, 0.005876324503670816, 0.006157350945893647, 0.0064291880431017745, 0.006664326624105987, 0.006864838095037129, 0.007078113650529572, 0.007347644401592079],
#     [0.007619053791137809, 0.007675148644280982, 0.007734276773318838, 0.00796069308025027, 0.008122711295731166, 0.00836166197220356, 0.008600596544083627, 0.008865920724170584, 0.009158275001598382, 0.009441768272272943, 0.009687982194895861, 0.009899171990984446, 0.010127889027261139, 0.010406175123357064],
#     [0.010690930134696464, 0.01074853746448401, 0.010816908725568064, 0.01104380133162497, 0.011224617424103522, 0.011475020567787597, 0.011724804474774198, 0.011986792663148949, 0.012290899356686813, 0.012586496097575228, 0.0128967433286582, 0.013309474638004692, 0.013762137705513489, 0.014206369466122304],
#     [0.014655171207522688, 0.01473896950876652, 0.014837571243330405, 0.015200202084771908, 0.01558112471298223, 0.016166564696340258, 0.016864705319014295, 0.017596598729521684, 0.018481548597384267, 0.019389844488549524, 0.020264693827138913, 0.021146123849181464, 0.022052924206217628, 0.023091321828168088],
#     [0.02414494408230128, 0.024356402787865328, 0.024924779575200562, 0.02555997660583187, 0.026075422799573644, 0.027093801640676762, 0.028186484775720055, 0.029332272469068554, 0.030662309012010835, 0.03231757500484944, 0.03375528426131558, 0.035019621134225076, 0.036344152723846834, 0.03799908606146629],
#     [0.0396875442102993, 0.03993880264977423, 0.04061580229511419, 0.041372055505300986, 0.04198545749144911, 0.043343315820017825, 0.04439490595490336, 0.04560687460428081, 0.04708081768665662, 0.04890041211916496, 0.050501453593593704, 0.052273713854208204, 0.0541743415343392, 0.05608601910843858]
# ]

# res1, res2 = processar_matrizes(LISTAindex_maior_valor_estatica, LISTA_maior_valor_estatica)

# print("Resultado 1 (vetor de valores distintos, sem 0):")
# print(res1)
# print("\nResultado 2 (maior valor associado para cada valor de Resultado 1):")
# print(res2)

def write_matrix_to_csv(matrix, filename):
    """Escreve uma matriz de números em um arquivo CSV."""
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        for row in matrix:
            writer.writerow(row)
    print(f"Matriz salva em {filename}")



def organiza_e_filtra_DADOS_das_Evolucoes(ENTRAD_00, ENTRAD_01):

    selection_curve=ENTRAD_00[0]
    CHOOSE_BAR=ENTRAD_00[1]
    EvolutionMatrixVECTORS=ENTRAD_01[0]
    infoVctrl=ENTRAD_01[1]
    DeltaV=ENTRAD_01[2]

    if selection_curve=='TODAS':
        DeltaV_sets = {}
        DeltaV_sets=add_to_DeltaV_sets(EvolutionMatrixVECTORS[0], DeltaV_sets)
        DeltaV_sets=add_to_DeltaV_sets(EvolutionMatrixVECTORS[1], DeltaV_sets)
        DeltaV_sets=add_to_DeltaV_sets(EvolutionMatrixVECTORS[2], DeltaV_sets)
        DeltaV_sets=add_to_DeltaV_sets(EvolutionMatrixVECTORS[3], DeltaV_sets)
        BarrasPV= np.arange(1, len(DeltaV) + 1)

    elif selection_curve=='PV':

        BarrasPV=[]
        for auxiliar_col in range(len(infoVctrl[1])):
            if infoVctrl[1][auxiliar_col]==0:
                for auxliar_lin in range(len(EvolutionMatrixVECTORS[0])):
                    EvolutionMatrixVECTORS[0][auxliar_lin][auxiliar_col]=0
                    EvolutionMatrixVECTORS[1][auxliar_lin][auxiliar_col]=0
                    EvolutionMatrixVECTORS[2][auxliar_lin][auxiliar_col]=0
                    EvolutionMatrixVECTORS[3][auxliar_lin][auxiliar_col]=0
            else:
                BarrasPV.append(auxiliar_col+1)
                    #print('wait')
        EvolutionMatrixVECTORS[0], _ = ceifar_matriz_vetor(EvolutionMatrixVECTORS[0], None, remover_linhas_correspondentes=False)

        DeltaV_sets = {}
        DeltaV_sets=add_to_DeltaV_sets(EvolutionMatrixVECTORS[0], DeltaV_sets)
        DeltaV_sets=add_to_DeltaV_sets(EvolutionMatrixVECTORS[1], DeltaV_sets)
        DeltaV_sets=add_to_DeltaV_sets(EvolutionMatrixVECTORS[2], DeltaV_sets)
        DeltaV_sets=add_to_DeltaV_sets(EvolutionMatrixVECTORS[3], DeltaV_sets)

    elif selection_curve=='PQ':
        
        BarrasPV=[]
        for auxiliar_col in range(len(infoVctrl[1])):
            if infoVctrl[1][auxiliar_col]!=0:
                for auxliar_lin in range(len(EvolutionMatrixVECTORS[0])):
                    EvolutionMatrixVECTORS[0][auxliar_lin][auxiliar_col]=0
                    EvolutionMatrixVECTORS[1][auxliar_lin][auxiliar_col]=0
                    EvolutionMatrixVECTORS[2][auxliar_lin][auxiliar_col]=0
                    EvolutionMatrixVECTORS[3][auxliar_lin][auxiliar_col]=0
            else:
                BarrasPV.append(auxiliar_col+1)
                    #print('wait')
        EvolutionMatrixVECTORS[0], _ = ceifar_matriz_vetor(EvolutionMatrixVECTORS[0], None, remover_linhas_correspondentes=False)

        DeltaV_sets = {}
        DeltaV_sets=add_to_DeltaV_sets(EvolutionMatrixVECTORS[0], DeltaV_sets)
        DeltaV_sets=add_to_DeltaV_sets(EvolutionMatrixVECTORS[1], DeltaV_sets)
        DeltaV_sets=add_to_DeltaV_sets(EvolutionMatrixVECTORS[2], DeltaV_sets)
        DeltaV_sets=add_to_DeltaV_sets(EvolutionMatrixVECTORS[3], DeltaV_sets)

    elif selection_curve=='CHOOSE_BAR':

        vetCHOOSE_BAR=interpret_choose_bar(CHOOSE_BAR)
        for aux in range(len(vetCHOOSE_BAR)):
            vetCHOOSE_BAR[aux]=vetCHOOSE_BAR[aux]-1

        #print(vetCHOOSE_BAR)
        BarrasPV=[]
        for auxiliar_col in range(len(infoVctrl[1])):
            if auxiliar_col not in vetCHOOSE_BAR:
                for auxliar_lin in range(len(EvolutionMatrixVECTORS[0])):
                    EvolutionMatrixVECTORS[0][auxliar_lin][auxiliar_col]=0
                    EvolutionMatrixVECTORS[1][auxliar_lin][auxiliar_col]=0
                    EvolutionMatrixVECTORS[2][auxliar_lin][auxiliar_col]=0
                    EvolutionMatrixVECTORS[3][auxliar_lin][auxiliar_col]=0
            else:
                BarrasPV.append(auxiliar_col+1)
                    #print('wait')
        EvolutionMatrixVECTORS[0], _ = ceifar_matriz_vetor(EvolutionMatrixVECTORS[0], None, remover_linhas_correspondentes=False)

        DeltaV_sets = {}
        DeltaV_sets=add_to_DeltaV_sets(EvolutionMatrixVECTORS[0], DeltaV_sets)
        DeltaV_sets=add_to_DeltaV_sets(EvolutionMatrixVECTORS[1], DeltaV_sets)
        DeltaV_sets=add_to_DeltaV_sets(EvolutionMatrixVECTORS[2], DeltaV_sets)
        DeltaV_sets=add_to_DeltaV_sets(EvolutionMatrixVECTORS[3], DeltaV_sets)
    
    return (DeltaV_sets, BarrasPV)



def formatar_valor(new_value, original_token):
    """
    Formata new_value para que o número de casas decimais seja exatamente o mesmo do token original
    e o comprimento total (field width) seja igual.
    Se o novo valor formatado ultrapassar o comprimento, ele será truncado.
    Se tiver menos, será preenchido à esquerda com espaços.
    """
    field_width = len(original_token)
    if '.' in original_token:
        partes = original_token.split('.')
        d = len(partes[1])
        novo_str = f"{new_value:.{d}f}"
    else:
        novo_str = str(int(round(new_value)))
    if len(novo_str) > field_width:
        novo_str = novo_str[:field_width]
    else:
        novo_str = novo_str.rjust(field_width)
    return novo_str

def modificar_cdf(caminho, camposPlot, camposPlotGer, matriz_DadosBarra, S_base, output_dir, PotPswing):
    """
    Lê o arquivo CDF e, na seção "BUS DATA FOLLOWS", altera os seguintes campos para cada barra:
      - Tensão: token imediatamente após o campo de tipo ("0", "2" ou "3")
      - Ângulo: token imediatamente após a tensão
      - Potência ativa das cargas: token imediatamente após o ângulo  
         (este valor será obtido a partir de matriz_DadosBarra[1][i] multiplicado por -S_base)
      - Potência reativa da geração: token na posição (tensão_index + 5)
         (valor obtido de camposPlotGer[i][5] multiplicado por S_base)
      
    Para a barra swing (primeira linha), o campo da potência ativa gerada – que deve estar na
    quinta coluna a partir da tensão (token em [tensão_index + 4]) – é substituído pelo valor
    de camposPlotGer[0][4] multiplicado por S_base.
    
    A função preserva exatamente os espaçamentos originais do arquivo CDF.
    O arquivo modificado é salvo no diretório 'plot/cdfsGerados/P_PRINCIPAL' com o mesmo nome do arquivo original.
    """
    with open(caminho, 'r') as f:
        linhas = f.readlines()

    # Identifica as linhas da seção "BUS DATA FOLLOWS"
    in_bus_data = False
    bus_line_indices = []
    for i, linha in enumerate(linhas):
        if "BUS DATA FOLLOWS" in linha.upper():
            in_bus_data = True
            continue
        if in_bus_data:
            if linha.strip().startswith("-999"):
                in_bus_data = False
                continue
            bus_line_indices.append(i)

    #print("Processando", len(bus_line_indices), "linhas de BUS DATA FOLLOWS.")

    for idx, line_index in enumerate(bus_line_indices):
        linha_original = linhas[line_index]
        tokens = list(re.finditer(r'\S+', linha_original))
        tension_token_index = None

        # Encontra o token de tipo ("0", "2" ou "3") e assume que o próximo token é a tensão.
        for j in range(len(tokens) - 1):
            if tokens[j].group() in {"0", "2", "3"}:
                try:
                    float(tokens[j+1].group())
                    tension_token_index = j + 1
                    break
                except ValueError:
                    continue

        if tension_token_index is not None:
            # Mapeamento dos índices (usando split() do CDF):
            # Supondo que, na linha original, a sequência é:
            # ... [tipo] [tensão] [ângulo] [pot. ativa cargas] [pot. ativa gerada] [pot. reativa geração] ...
            # Assim:
            voltage_index      = tension_token_index           # tensão
            angle_index        = tension_token_index + 1       # ângulo
            load_active_index  = tension_token_index + 2       # potência ativa das cargas
            # Para a barra swing, o valor único da potência ativa gerada está na quinta coluna a partir da tensão:
            swing_index        = tension_token_index + 4       # potência ativa gerada (swing)
            reactive_gen_index = tension_token_index + 5       # potência reativa da geração

            replacements = {}
            # Valores a partir das matrizes (cada linha corresponde à barra na ordem)
            new_voltage  = camposPlot[idx][1]
            new_angle    = camposPlot[idx][2]
            new_load     = matriz_DadosBarra[1][idx] * (-1)
            new_reactive = camposPlotGer[idx][5] * S_base

            replacements[voltage_index]      = new_voltage
            replacements[angle_index]        = new_angle
            replacements[load_active_index]  = new_load
            replacements[reactive_gen_index] = new_reactive

            # print(f"Bus {idx+1}:")
            # print(f"  Tensão: original='{tokens[voltage_index].group()}' nova={new_voltage}")
            # print(f"  Ângulo: original='{tokens[angle_index].group()}' nova={new_angle}")
            # print(f"  LoadAtiva: original='{tokens[load_active_index].group()}' nova={new_load}")
            # print(f"  GenReativa: original='{tokens[reactive_gen_index].group()}' nova={new_reactive}")

            # Para a barra swing (primeira linha), substituir também o campo da potência ativa gerada
            if idx == 0 and (tension_token_index + 4) < len(tokens):
                new_swing = PotPswing
                replacements[tension_token_index + 4] = new_swing
                #print(f"  SwingGerada: original='{tokens[tension_token_index+4].group()}' nova={new_swing}")

            # Reconstrói a linha, preservando os espaços originais
            nova_linha_parts = []
            prev_end = 0
            for i_tok, m in enumerate(tokens):
                nova_linha_parts.append(linha_original[prev_end:m.start()])
                if i_tok in replacements:
                    novo_token = formatar_valor(replacements[i_tok], m.group())
                else:
                    novo_token = m.group()
                nova_linha_parts.append(novo_token)
                prev_end = m.end()
            nova_linha_parts.append(linha_original[prev_end:])
            linhas[line_index] = "".join(nova_linha_parts)
        else:
            print(f"Não foi possível identificar a coluna de tensão na linha {line_index+1}.")

    # output_dir = os.path.join("plot", "cdfsGerados", "G_TELA1")
    # if not os.path.exists(output_dir):
    #     os.makedirs(output_dir)
    # nome_arquivo = os.path.basename(caminho)
    # output_path = os.path.join(output_dir, nome_arquivo)

    # with open(output_path, 'w') as f:
    #     f.writelines(linhas)

    # print("Arquivo modificado salvo em:", output_path)

    #output_dir = os.path.join("plot", "cdfsGerados", "G_TELA1")
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    nome_arquivo = os.path.basename(caminho)
    base, ext = os.path.splitext(nome_arquivo)
    output_path = os.path.join(output_dir, nome_arquivo)

    contador = 1
    while os.path.exists(output_path):
        output_path = os.path.join(output_dir, f"{base}_{contador}{ext}")
        contador += 1
    #print(f"{base}_{contador}{ext}")
    with open(output_path, 'w') as f:
        f.writelines(linhas)

    #print("Arquivo modificado salvo em:", output_path)
    return(f"{base}_{contador-1}")