# Interface GoCases - baseada nos modelos GoCurvs (Código 1) e GoSimul (Código 2)

import tkinter as tk
from tkinter import ttk


def mostrar_splash_temporario(root):
    splash = tk.Toplevel(root)
    splash.overrideredirect(True)
    largura, altura = 460, 180
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    splash.geometry(f"{largura}x{altura}+{(sw-largura)//2}+{(sh-altura)//2}")
    LILAS_CLARO, VERDE, VERMELHO = "#e6ccff", "#008548", "#c21807"
    splash.configure(bg=LILAS_CLARO)

    canvas = tk.Canvas(splash, width=260, height=80, bg=LILAS_CLARO, highlightthickness=0)
    canvas.place(x=15, y=20)

    y_green, offset, step = 45, 20, 13
    canvas.create_line(offset-10, y_green, offset+6*step+30, y_green, fill="black", width=1)
    canvas.create_line(offset, y_green+25, offset, y_green-35, fill="black", width=1)

    for i in range(6):
        xa, ya = offset + i*step, y_green
        xd, yd = xa + 8, ya - 18
        canvas.create_line(xa, ya, xd, yd, fill=VERDE, width=2)
        canvas.create_oval(xa-3, ya-3, xa+3, ya+3, fill=VERDE, outline=VERDE)
        canvas.create_oval(xd-3, yd-3, xd+3, yd+3, fill=VERMELHO, outline=VERMELHO)

    # Estrela
    import math
    cx, cy, R_out, R_in = offset+6*step+20, y_green-17, 7, 3
    vertices = []
    for k in range(10):
        ang = math.radians(-90 + k*36)
        r = R_out if k % 2 == 0 else R_in
        vertices += [cx + r*math.cos(ang), cy + r*math.sin(ang)]
    canvas.create_polygon(vertices, fill="black", outline="black")

    ttk.Label(splash, text="Iniciando GoCases...",
              font=("Segoe UI", 13, "bold"), background=LILAS_CLARO).place(relx=0.55, rely=0.25, anchor="w")
    msg_label = ttk.Label(splash, text="Carregando bibliotecas…", font=("Segoe UI", 10), background=LILAS_CLARO)
    msg_label.place(relx=0.55, rely=0.52, anchor="w")
    barra = ttk.Progressbar(splash, mode="indeterminate", length=180)
    barra.place(relx=0.55, rely=0.75, anchor="w")
    barra.start(12)

    mensagens = [
        "Carregando bibliotecas…",
        "Verificando dependências…",
        "Extraindo arquivos embutidos…",
        "Preparando interface…"
    ]
    def avançar(i=0):
        if i < len(mensagens):
            msg_label.config(text=mensagens[i])
            splash.after(800, lambda: avançar(i+1))
    splash.after(50, avançar)

    return splash


import os
import sys
import zipfile


def extrair_recursos_embutidos():
    # Diretório onde o .exe está rodando
    if getattr(sys, 'frozen', False):
        executavel_path = sys.executable
        base_dir = os.path.dirname(executavel_path)
        recurso_zip = os.path.join(sys._MEIPASS, 'recursos_embutidos.zip')
    else:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        recurso_zip = os.path.join(base_dir, 'recursos_embutidos.zip')

    # Pasta de destino para extração
    destinos = [
        os.path.join(base_dir, 'ieee9_Marcelo.cdf'),
        os.path.join(base_dir, 'ieee14.cdf'),
        os.path.join(base_dir, 'ieee30.cdf'),
        os.path.join(base_dir, 'ieee118.cdf'),
        os.path.join(base_dir, 'plot'),
    ]

    # Verifica se já existe
    if not all(os.path.exists(d) for d in destinos):
        print("Extraindo arquivos necessários...")
        with zipfile.ZipFile(recurso_zip, 'r') as zip_ref:
            zip_ref.extractall(base_dir)


from verificacoes_iniciais import verificar_bibliotecas, verificar_e_criar_pastas

#verificar_bibliotecas()
#verificar_e_criar_pastas()
import io
import math
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import os
import numpy as np
from matplotlib import pyplot as plt
from matplotlib import _pylab_helpers
import sys
import datetime
import traceback

from G_FUNCAO_A import create_unique_tag2, Ler_Arquivo
from G_FUNCAO_B import controle_reativo, pega_nome_maiusculo
from G_FUNCAO_B import CHAMA_saveCases_CDF, save_plot_info
from G_FUNCAO_B import CHAMA_PLOT2, extrair_potencias_negativas
from G_FUNCAO_B import process_intervals, extrair_vetores_da_matrizSystem
import platform

def abrir_tela_expandida(janela):
    sistema = platform.system()

    if sistema == "Windows":
        try:
            janela.state('zoomed')  # Melhor forma no Windows
        except:
            # Fallback caso o método falhe
            largura = janela.winfo_screenwidth()
            altura = janela.winfo_screenheight()
            janela.geometry(f"{largura}x{altura}+0+0")
    else:
        # Para Linux/macOS e outros
        largura = janela.winfo_screenwidth()
        altura = janela.winfo_screenheight()
        janela.geometry(f"{largura}x{altura}+0+0")



def executar_com_debug(funcao, status_label=None):
    try:
        funcao()
    except Exception:
        tipo_erro, valor_erro, tb = sys.exc_info()
        ult_traco = traceback.extract_tb(tb)[-1]
        nome_arquivo = ult_traco.filename
        linha = ult_traco.lineno
        texto = ult_traco.line
        msg = f"Erro na linha {linha} do arquivo '{nome_arquivo}':\n→ {valor_erro}\n\nCódigo:\n{texto}"

        messagebox.showerror("Erro durante execução", msg)
        if status_label:
            status_label.config(text=f"Erro na linha {linha}: {valor_erro}")
        print(traceback.format_exc())



# def salvar_log_completo(tag, save_dir, parametros, dados_lev, dados_pes, terminal_output):
#     log_path = os.path.join(save_dir, f"{tag}.log")
#     with open(log_path, "w", encoding="utf-8") as f:
#         f.write("# LOG DO ESTUDO GERADO PELO GoCases\n")
#         f.write(f"# Data/Hora: {datetime.datetime.now()}\n\n")

#         f.write("# PARÂMETROS DO ESTUDO\n")
#         for k, v in parametros.items():
#             f.write(f"{k} = {v}\n")

#         f.write("\n# RESULTADO - CASOS REGIME LEVE\n")
#         for linha in dados_lev:
#             f.write(";".join(str(x) for x in linha) + "\n")

#         f.write("\n# RESULTADO - CASOS REGIME PESADO\n")
#         for linha in dados_pes:
#             f.write(";".join(str(x) for x in linha) + "\n")

#         f.write("\n# SAÍDA DO TERMINAL DURANTE O ESTUDO\n")
#         f.write(terminal_output)


# def ler_log_salvo(caminho):
#     parametros = {}
#     dados_lev = []
#     dados_pes = []
#     terminal = []
#     secao = None
#     with open(caminho, "r", encoding="utf-8") as f:
#         for linha in f:
#             linha = linha.strip()
#             if linha.startswith("# RESULTADO - CASOS REGIME LEVE"):
#                 secao = "LEV"
#                 continue
#             elif linha.startswith("# RESULTADO - CASOS REGIME PESADO"):
#                 secao = "PES"
#                 continue
#             elif linha.startswith("# SAÍDA DO TERMINAL"):
#                 secao = "TERM"
#                 continue
#             elif linha.startswith("#") or not linha:
#                 continue

#             if secao == "LEV":
#                 dados_lev.append(linha.split(";"))
#             elif secao == "PES":
#                 dados_pes.append(linha.split(";"))
#             elif secao == "TERM":
#                 terminal.append(linha)
#             elif "=" in linha:
#                 k, v = linha.split("=", 1)
#                 parametros[k.strip()] = v.strip()

#     return parametros, dados_lev, dados_pes, "\n".join(terminal)







def salvar_log_completo(tag, save_dir, parametros, dados_lev, dados_pes, terminal_output):
    log_path = os.path.join(save_dir, f"{tag}.log")
    with open(log_path, "w", encoding="utf-8") as f:
        f.write("# LOG DO ESTUDO GERADO PELO GoCases\n")
        f.write(f"# Data/Hora: {datetime.datetime.now()}\n\n")

        f.write("# PARÂMETROS DO ESTUDO\n")
        for k, v in parametros.items():
            f.write(f"{k} = {v}\n")

        f.write("\n# RESULTADO - CASOS REGIME LEVE\n")
        for linha in dados_lev:
            f.write(";".join(str(x) for x in linha) + "\n")

        f.write("\n# RESULTADO - CASOS REGIME PESADO\n")
        for linha in dados_pes:
            f.write(";".join(str(x) for x in linha) + "\n")

        f.write("\n# SAÍDA DO TERMINAL DURANTE O ESTUDO\n")
        f.write(terminal_output)


def ler_log_salvo(caminho):
    parametros = {}
    dados_lev = []
    dados_pes = []
    terminal = []
    secao = None
    with open(caminho, "r", encoding="utf-8") as f:
        for linha in f:
            linha = linha.strip()
            if linha.startswith("# RESULTADO - CASOS REGIME LEVE"):
                secao = "LEV"
                continue
            elif linha.startswith("# RESULTADO - CASOS REGIME PESADO"):
                secao = "PES"
                continue
            elif linha.startswith("# SAÍDA DO TERMINAL"):
                secao = "TERM"
                continue
            elif linha.startswith("#") or not linha:
                continue

            if secao == "LEV":
                dados_lev.append(linha.split(";"))
            elif secao == "PES":
                dados_pes.append(linha.split(";"))
            elif secao == "TERM":
                terminal.append(linha)
            elif "=" in linha:
                k, v = linha.split("=", 1)
                parametros[k.strip()] = v.strip()

    return parametros, dados_lev, dados_pes, "\n".join(terminal)


def popup_ler_logs(app_instance, mostrar_callback, console_widget):
    popup = tk.Toplevel(app_instance.root)
    popup.title("Ler Casos Salvos")
    popup.configure(bg="#f0f0ff")
    popup.geometry("700x540")
    popup.resizable(False, False)

    if hasattr(app_instance, 'janelas_popups'):
        app_instance.janelas_popups.append(popup)

    ttk.Label(popup, text="Selecione um arquivo de log salvo:", background="#f0f0ff", font=("Arial", 10)).pack(pady=10)
    lista_logs = [f for f in os.listdir("plot/GenOfCases") if f.endswith(".log")]
    lista_logs.sort()

    cb_logs = ttk.Combobox(popup, values=lista_logs, state="readonly", width=55)
    cb_logs.pack(pady=5)
    if lista_logs:
        cb_logs.set(lista_logs[0])

    info_frame = tk.Frame(popup, bg="#f0f0ff")
    info_frame.pack(fill="both", expand=True, padx=10, pady=(5, 0))

    info_text = tk.Text(info_frame, height=20, bg="#ffffff", state="disabled")
    info_text.pack(fill="both", expand=True)

    def carregar_info_ao_selecionar(event=None):
        arquivo = cb_logs.get()
        if not arquivo:
            return
        caminho = os.path.join(BASE_DIR, "plot", "GenOfCases", arquivo)

        # app_instance.console_log.config(state="normal")
        # app_instance.console_log.delete("1.0", tk.END)
        # app_instance.console_log.config(state="disabled")

        parametros, dados_lev, dados_pes, terminal_output = ler_log_salvo(caminho)

        info_text.config(state="normal")
        info_text.delete("1.0", "end")
        info_text.insert("end", "Parâmetros do estudo carregado:\n")
        for k, v in parametros.items():
            info_text.insert("end", f"{k} = {v}\n")
        info_text.insert("end", "\nSaída do terminal:\n")
        info_text.insert("end", terminal_output)
        info_text.config(state="disabled")

    def gerar():
        arquivo = cb_logs.get()
        if not arquivo:
            messagebox.showwarning("Aviso", "Selecione um arquivo.")
            return
        caminho = os.path.join(BASE_DIR, "plot", "GenOfCases", arquivo)
        app_instance.console_log.config(state="normal")
        app_instance.console_log.delete("1.0", tk.END)
        app_instance.console_log.config(state="disabled")        
        parametros, dados_lev, dados_pes, terminal_output = ler_log_salvo(caminho)
        mostrar_callback(parametros.get("SYSname", "Desconhecido"), "-", "-", "-", dados_lev, dados_pes)

        if console_widget:
            console_widget.config(state="normal")
            console_widget.insert("end", "\n# Recarregado do log:\n" + terminal_output + "\n")
            console_widget.see("end")
            console_widget.config(state="disabled")

    cb_logs.bind("<<ComboboxSelected>>", carregar_info_ao_selecionar)
    
    carregar_info_ao_selecionar()

    ttk.Button(popup, text="Gerar", command=gerar).pack(pady=10)






class RedirectConsole:
    def __init__(self, text_widget):
        self.text_widget = text_widget

    def write(self, string):
        self.text_widget.config(state="normal")
        self.text_widget.insert("end", string)
        self.text_widget.see("end")
        self.text_widget.config(state="disabled")

    def flush(self):  # Necessário para compatibilidade
        pass





def colaca_notas_noTerminal ():
    print("📘 NOTAS GERAIS:\n")

    print("1 - Caso o estudo selecionado em \"Arquivo CDF\" seja um dos arquivos testes,")
    print("    o GoCases autoajusta para os padrões do estudo automaticamente. Entretanto")
    print("    É NECESSÁRIO, garantir que os arquivos CDF básicos estejam na mesma pasta")
    print("    de execução do simulador. O .exe visa empacotar todos os arquivos em um")
    print("    único executável de modo que as aplicações sejam plenamente funcionais")
    print("    desde que sejam instaladas as adequadas bibliotecas.\n")

    print("2 - O simulador só permite a execução se todos os campos estiverem")
    print("    preenchidos. Entretanto, isto NÃO GARANTE que não haja erros de")
    print("    preenchimento. É necessário pleno conhecimento do sistema a ser")
    print("    estudado e o correto preenchimento do arquivo CSV bem como seleção")
    print("    adequada de parâmetros.\n")

    print("3 - Ao rodar um novo estudo, um terminal na TELA 3 mostra a evolução do")
    print("    estudo realizado. Ao final do processo, os dados são salvos para")
    print("    a montagem das tabelas e do gráfico. ATENÇÃO: após a realização do")
    print("    estudo, apenas a tabela de resultados é mostrada em sequência.")
    print("    Para visualizar o gráfico gerado é preciso clicar em \"Gerar Gráfico\".")
    print("    Todos os dados do Terminal também são coletados e salvos para futuras")
    print("    apresentações.\n")

    print("4 - O histórico do estudo é salvo e apresentado via um terminal na tela")
    print("    de \"Casos Salvos\".\n")

    print("5 - É importante salientar que o programa calcula todas as combinações possíveis de cargas")
    print("    e uma seleção inadequada de barras pode levar o programa a ficar muito tempo realizando")
    print("    os cálculos. Por default, o programa limita em 20 barras no máximo.\n")

    print("6 - A seleção de casos de fronteira está intimamente ligada às diferentes possíveis formas")
    print("    de alteração das cargas do sistema, e por isso este programa visa apenas a seleção")
    print("    de algumas destas fronteiras. Para mais informações é recomendável ler a monografia.\n")

    print("7 - Metas de paradas: os cálculos param quando...")
    print("    1 - todos os candidatos encontrados sejam avaliados com sucesso.\n")
    return()






class GoCasesApp:
    ARQUIVOS_FIXOS = {
        'ieee9_Marcelo.cdf': {
            "S_base": "100",
            "Tolerancia": "0.0001",
            "MODELin": "PI",
            "Ativar_inverter": "no",
            "GirarTrafo": "no"
        },

        'ieee14.cdf': {
            "S_base": "100",
            "Tolerancia": "0.0001",
            "MODELin": "PI",
            "Ativar_inverter": "yes",
            "GirarTrafo": "no"
        },

        'ieee30.cdf': {
            "S_base": "100",
            "Tolerancia": "0.0001",
            "MODELin": "PI",
            "Ativar_inverter": "yes",
            "GirarTrafo": "no"
        },

        'ieee118.cdf': {
            "S_base": "100",
            "Tolerancia": "0.0001",
            "MODELin": "PI",
            "Ativar_inverter": "no",
            "GirarTrafo": "yes"
        }
    }


    def coloca_notas_noTerminal (self):
        print("📘 NOTAS GERAIS:\n")

        print("1 - Caso o estudo selecionado em \"Arquivo CDF\" seja um dos arquivos testes,")
        print("    o GoCases autoajusta para os padrões do estudo automaticamente. Entretanto")
        print("    É NECESSÁRIO, garantir que os arquivos CDF básicos estejam na mesma pasta")
        print("    de execução do simulador. O .exe visa empacotar todos os arquivos em um")
        print("    único executável de modo que as aplicações sejam plenamente funcionais")
        print("    desde que sejam instaladas as adequadas bibliotecas.\n")

        print("2 - O simulador só permite a execução se todos os campos estiverem")
        print("    preenchidos. Entretanto, isto NÃO GARANTE que não haja erros de")
        print("    preenchimento. É necessário pleno conhecimento do sistema a ser")
        print("    estudado e o correto preenchimento do arquivo CSV bem como seleção")
        print("    adequada de parâmetros.\n")

        print("3 - Ao rodar um novo estudo, um terminal na TELA 3 mostra a evolução do")
        print("    estudo realizado. Ao final do processo, os dados são salvos para")
        print("    a montagem das tabelas e do gráfico. ATENÇÃO: após a realização do")
        print("    estudo, apenas a tabela de resultados é mostrada em sequência.")
        print("    Para visualizar o gráfico gerado é preciso clicar em \"Gerar Gráfico\".")
        print("    Todos os dados do Terminal também são coletados e salvos para futuras")
        print("    apresentações.\n")

        print("4 - O histórico do estudo é salvo e apresentado via um terminal na tela")
        print("    de \"Casos Salvos\".\n")

        print("5 - É importante salientar que o programa calcula todas as combinações possíveis de cargas")
        print("    e uma seleção inadequada de barras pode levar o programa a ficar muito tempo realizando")
        print("    os cálculos. Por default, o programa limita em 20 barras no máximo.\n")

        print("6 - A seleção de casos de fronteira está intimamente ligada às diferentes possíveis formas")
        print("    de alteração das cargas do sistema, e por isso este programa visa apenas a seleção")
        print("    de algumas destas fronteiras. Para mais informações é recomendável ler a monografia.\n")

        print("7 - Metas de paradas: os cálculos param quando...")
        print("    1 - todos os candidatos encontrados sejam avaliados com sucesso.\n")
        return()
    
    def __init__(self, root):
        self.root = root
        self.root.title("TELA 2 - GoCases")
        self.root.configure(bg="#e6ccff")
        self.janelas_resultados = []
        self.janelas_popups = []
        abrir_tela_expandida(self.root)

        # CORES PADRÃO
        LILAS_CLARO = "#e6ccff"      # fundo geral
        ROXO_ESCURO = "#2e005d"      # título e texto principal
        VERDE = "#008548"            # pontos “antes”
        VERMELHO = "#c21807"         # pontos “depois”

        # ======== CABEÇALHO ========
        # Dentro do seu __init__
        # Fundo do cabeçalho
        header = tk.Frame(self.root, height=80, bg=LILAS_CLARO)
        header.pack(fill="x")

        # Canvas para desenhar a figura
        canvas = tk.Canvas(header, width=260, height=80, bg=LILAS_CLARO, highlightthickness=0)
        canvas.place(x=10, y=0)

        # -------------------------------------------------
        # Desenhar “vassoura PV” – pontos verdes alinhados
        # -------------------------------------------------
        y_green = 45          # linha reta dos pontos verdes
        offset  = 20          # deslocamento inicial em x
        step    = 13          # espaçamento entre pares

        # EIXOS cartesianos (simples cruz)
        canvas.create_line(offset - 10, y_green, offset + 6 * step + 30, y_green, fill="black", width=1)  # eixo X
        canvas.create_line(offset, y_green + 25, offset, y_green - 35, fill="black", width=1)             # eixo Y

        # PV: pontos antes (verde) e depois (vermelho)
        for i in range(6):
            xa = offset + i * step
            ya = y_green
            xd = xa + 8       # ponto “depois” um pouco à frente
            yd = ya - 18      # ponto “depois” mais alto (subida da curva)
            canvas.create_line(xa, ya, xd, yd, fill=VERDE, width=2)
            canvas.create_oval(xa-3, ya-3, xa+3, ya+3, fill=VERDE, outline=VERDE)
            canvas.create_oval(xd-3, yd-3, xd+3, yd+3, fill=VERMELHO, outline=VERMELHO)

        # --------------------------------------------
        # Estrela preta mais definida (5 pontas)
        # --------------------------------------------
        
        cx, cy = offset + 6*step + 20, y_green - 17  # ajustado para linha
        R_out, R_in = 7, 3

        vertices = []
        for k in range(10):
            ang = math.radians(-90 + k * 36)
            r = R_out if k % 2 == 0 else R_in
            vertices.extend([cx + r * math.cos(ang), cy + r * math.sin(ang)])

        canvas.create_polygon(vertices, fill="black", outline="black")


        # Frame para texto ao lado da figura, centralizado
        frame_texto = tk.Frame(header, bg=LILAS_CLARO)
        frame_texto.place(relx=0.5, rely=0.5, anchor="center")

        # Título principal
        titulo1 = tk.Label(frame_texto, text="TELA 2 - GoCases", font=("Segoe UI", 18, "bold"), bg=LILAS_CLARO, fg=ROXO_ESCURO)
        titulo1.pack()

        # Subtítulo
        titulo2 = tk.Label(frame_texto, text="Gerador de Casos", font=("Segoe UI", 14), bg=LILAS_CLARO, fg=ROXO_ESCURO)
        titulo2.pack()


        self.params = {
            "SYSname": tk.StringVar(value="ieee118.cdf"),
            "MODELin": tk.StringVar(value="PI"),
            "Tolerancia": tk.DoubleVar(value=0.001),
            "S_base": tk.DoubleVar(value=100),
            "Ativar_inverter": tk.StringVar(value="no"),
            "GirarTrafo": tk.StringVar(value="yes"),
            "limite_variacao": tk.IntVar(value=100),
            "tipo_de_ESTUDO": tk.StringVar(value="Todo Espaco Amostral"),
            "PassoEstudo_DasCombinacoes": tk.IntVar(value=2),
            "Minimizar_EspacoAmostral": tk.StringVar(value="1-5_7"),
            "tipo_de_REGIME": tk.StringVar(value="ambos"),
            "saveCaseUntil": tk.IntVar(value=1000),
            "tolApresent": tk.IntVar(value=3)
        }

        self.create_widgets()
        sys.stdout = RedirectConsole(self.console_log)
        sys.stderr = RedirectConsole(self.console_log)

    def validar_float(self, texto):
        if texto == "":
            return True  # Permite campo vazio temporariamente
        try:
            float(texto)
            return True
        except ValueError:
            return False



    def create_widgets(self):
        self.widgets = {}
        # titulo = ttk.Label(self.root, text="GoCases", background="#e6ccff")
        # titulo.pack(pady=(10, 5))
        # titulo.configure(
        #     font=("Segoe Script", 20, "bold"),
        #     anchor="center"
        # )

        frame = ttk.Frame(self.root, padding=10)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure((0, 1), weight=1)

        vcmd_int = (self.root.register(self.validar_inteiro), '%P')

        nomes_amigaveis = {
            "SYSname": "Arquivo CDF",
            "MODELin": "Modelo de Linha",
            "Tolerancia": "Tolerância",
            "S_base": "S base (MVA)",
            "Ativar_inverter": "Inverter TAP",
            "GirarTrafo": "Girar Trafo",
            "limite_variacao": "Limite de Variação (%)",
            "tipo_de_ESTUDO": "Tipo de Barras",
            "PassoEstudo_DasCombinacoes": "Passo (MW)",
            "Minimizar_EspacoAmostral": "Barras Escolhidas",
            "tipo_de_REGIME": "Tipo de Regime",
            "saveCaseUntil": "Qtd. de Casos para Salvar",
            "tolApresent": "Tolerância para Apresentação"
        }

        dropdowns = {
            "MODELin": ["T", "PI"],
            "Ativar_inverter": ["yes", "no"],
            "GirarTrafo": ["yes", "no"],
            "tipo_de_ESTUDO": ["Segregar (PV)", "Segregar (PQ)", "Todo Espaco Amostral"],
            "tipo_de_REGIME": ["leve", "pesado", "ambos"]
        }

        # -----------------------------------------------------------------
        # 1)  Dicionário com explicações – vem do help_G2.md
        # -----------------------------------------------------------------
        explicacoes_parametros = {
            "SYSname": "1 - Tanto pode selecionar item da lista suspensa quanto\noutros arquivos CDF de qualquer outro diretório.\n2 - Para utilizar a lista suspensa, mantenha os arquivos-teste\nna pasta do executável.",
            "MODELin": "Modelo elétrico das linhas.\n1 - Não se observou grande diferenças entre PI e T\n2 - PI é preferível por tornar o problema menor (T cria barras fictícias). ",
            "Tolerancia": "Tolerância em pu para o erro do fluxo de potência.",
            "S_base": "Potência base do sistema. Tipicamente 100 MVA.",
            "Ativar_inverter": "\"yes\" para ieee14 e ieee30.\n\"no\"  para ieee9_Marcelo e ieee118.",
            "GirarTrafo": "\"yes\" apenas para ieee118.cdf.\n\"no\"  para os demais arquivos-teste.",
            "limite_variacao": "Porcentagem máxima para alteração das cargas.",
            "tipo_de_ESTUDO": "Define se deseja analisar todo o espaço ou\nsegregar PQ / PV.",
            "PassoEstudo_DasCombinacoes": "Degrau (MW) para gerar combinações. \nÉ recomendado que o Passo adotado seja maior que a Tolerância.",
            "tipo_de_REGIME": "Tipo de alteração das cargas ativas das barras escolhidas:\n• pesado → liga carga\n• leve   → desliga carga\n• ambos  → desliga e depois liga",
            "Minimizar_EspacoAmostral": "Ex.: 1-5_7  → altera barras 1-5 e a barra 7.",
            "saveCaseUntil":"Quantidade de casos máximos a serem salvos em formato CDF",
            "tolApresent":"Tolerância para apresentação dos resultados\n(confirmação de status das barras que já haviam limites infligidos)"
        }
        # -----------------------------------------------------------------

        parametros_sistema = ["SYSname", "MODELin", "Tolerancia", "S_base", "Ativar_inverter", "GirarTrafo"]
        parametros_estudo = ["limite_variacao", "tipo_de_ESTUDO", "PassoEstudo_DasCombinacoes",
                              "tipo_de_REGIME", "Minimizar_EspacoAmostral"]
        parametros_salvar = ["saveCaseUntil", "tolApresent"]

        frame_sistema = ttk.LabelFrame(frame, text="PARÂMETROS DO SISTEMA", padding=10)
        frame_estudo = ttk.LabelFrame(frame, text="PARÂMETROS DO ESTUDO", padding=10)
        frame_sistema.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
        frame_estudo.grid(row=0, column=1, padx=10, pady=10, sticky="nsew")
        frame_sistema.columnconfigure((0, 1), weight=1)
        frame_estudo.columnconfigure((0, 1), weight=1)

        # for idx, key in enumerate(parametros_sistema):
        #     row, col = divmod(idx, 2)
        #     sub = ttk.Frame(frame_sistema)
        #     sub.grid(row=row, column=col, padx=8, pady=6, sticky="w")
        #     ttk.Label(sub, text=nomes_amigaveis[key]).pack(anchor="w")

        #     if key == "SYSname":
        #         combo_sys = ttk.Combobox(sub, textvariable=self.params[key], width=25, state="readonly")
        #         combo_sys['values'] = list(self.ARQUIVOS_FIXOS.keys()) + ["Selecionar outro arquivo..."]
        #         combo_sys.pack(side="left")
        #         self.widgets[key] = combo_sys

        #         def ao_mudar_sysname(event=None):
        #             nome = self.params["SYSname"].get()
        #             if nome == "Selecionar outro arquivo...":
        #                 self.selecionar_arquivo()
        #             elif nome in self.ARQUIVOS_FIXOS:
        #                 config = self.ARQUIVOS_FIXOS[nome]
        #                 for k, v in config.items():
        #                     if k in self.params:
        #                         self.params[k].set(v)

        #         combo_sys.bind("<<ComboboxSelected>>", ao_mudar_sysname)
        #         ttk.Button(sub, text="...", command=self.selecionar_arquivo).pack(side="left")
        #     elif key in dropdowns:
        #         ttk.Combobox(sub, textvariable=self.params[key], values=dropdowns[key], width=20, state="readonly").pack()
        #     else:
        #         ttk.Entry(sub, textvariable=self.params[key], width=23).pack()





        for idx, key in enumerate(parametros_sistema):
            row, col = divmod(idx, 2)
            sub = ttk.Frame(frame_sistema)
            sub.grid(row=row, column=col, padx=8, pady=6, sticky="w")
            ttk.Label(sub, text=nomes_amigaveis[key]).pack(anchor="w")

            # -------------- widget específico --------------
            if key == "SYSname":
                widget = ttk.Combobox(
                    sub, textvariable=self.params[key],
                    width=25, state="readonly",
                    values=list(self.ARQUIVOS_FIXOS.keys()) + ["Selecionar outro arquivo..."]
                )
                widget.pack(side="left")
                self.widgets[key] = widget

                def ao_mudar_sysname(event=None):
                    nome = self.params["SYSname"].get()
                    if nome == "Selecionar outro arquivo...":
                        self.selecionar_arquivo()
                    elif nome in self.ARQUIVOS_FIXOS:
                        for k, v in self.ARQUIVOS_FIXOS[nome].items():
                            if k in self.params:
                                self.params[k].set(v)

                widget.bind("<<ComboboxSelected>>", ao_mudar_sysname)
                ttk.Button(sub, text="…", command=self.selecionar_arquivo).pack(side="left")

            elif key in dropdowns:
                widget = ttk.Combobox(
                    sub, textvariable=self.params[key],
                    values=dropdowns[key], width=20, state="readonly"
                )
                widget.pack()
                self.widgets[key] = widget

            else:
                widget = ttk.Entry(sub, textvariable=self.params[key], width=23)
                widget.pack()
                self.widgets[key] = widget

            # -------------- tooltip --------------
            if key in explicacoes_parametros:
                self.adicionar_tooltip(widget, explicacoes_parametros[key])





        # for idx, key in enumerate(parametros_estudo):
        #     row, col = divmod(idx, 2)
        #     sub = ttk.Frame(frame_estudo)
        #     sub.grid(row=row, column=col, padx=8, pady=6, sticky="w")
        #     ttk.Label(sub, text=nomes_amigaveis[key]).pack(anchor="w")

        #     if key in dropdowns:
        #         cb = ttk.Combobox(sub, textvariable=self.params[key], values=dropdowns[key], width=20, state="readonly")
        #         cb.pack()
        #         # if key == "ReduzirEspacoAmostral":
        #         #     cb.bind("<<ComboboxSelected>>", lambda e: self.atualizar_estado_barras_para_amostragem())
        #     else:
        #         if key == "Minimizar_EspacoAmostral":
        #             entry = ttk.Entry(sub, textvariable=self.params[key], width=23)
        #             entry.pack()
        #             self.widgets[key] = entry
        #         elif key in ["saveCaseUntil", "tolApresent"]:
        #             entry = ttk.Entry(sub, textvariable=self.params[key], width=23, validate="key", validatecommand=vcmd_int)
        #             entry.pack()
        #             self.widgets[key] = entry
        #         else:
        #             entry = ttk.Entry(sub, textvariable=self.params[key], width=23)
        #             entry.pack()
        #             self.widgets[key] = entry

        # frame_salvar = ttk.LabelFrame(frame, text="PARÂMETROS DE SALVAR E APRESENTAR", padding=10)
        # frame_salvar.grid(row=1, column=0, columnspan=2, padx=10, pady=5, sticky="nsew")
        # frame_salvar.columnconfigure((0, 1), weight=1)

        # for idx, key in enumerate(parametros_salvar):
        #     sub = ttk.Frame(frame_salvar)
        #     sub.grid(row=0, column=idx, padx=8, pady=6, sticky="w")
        #     ttk.Label(sub, text=nomes_amigaveis[key]).pack(anchor="w")
        #     entry = ttk.Entry(sub, textvariable=self.params[key], width=23, validate="key", validatecommand=vcmd_int)
        #     entry.pack()
        #     self.widgets[key] = entry

        # self.params["tipo_de_ESTUDO"].trace_add("write", lambda *args: self.atualizar_estado_barras_para_amostragem())
        # self.params["tipo_de_REGIME"].trace_add("write", lambda *args: self.atualizar_estado_barras_para_amostragem())


        for idx, key in enumerate(parametros_estudo):
            row, col = divmod(idx, 2)
            sub = ttk.Frame(frame_estudo)
            sub.grid(row=row, column=col, padx=8, pady=6, sticky="w")
            ttk.Label(sub, text=nomes_amigaveis[key]).pack(anchor="w")

            if key in dropdowns:
                cb = ttk.Combobox(sub, textvariable=self.params[key], values=dropdowns[key], width=20, state="readonly")
                cb.pack()
                self.widgets[key] = cb
                if key in explicacoes_parametros:
                    self.adicionar_tooltip(cb, explicacoes_parametros[key])
            else:
                if key == "Minimizar_EspacoAmostral":
                    entry = ttk.Entry(sub, textvariable=self.params[key], width=23)
                elif key in ["saveCaseUntil", "tolApresent"]:
                    entry = ttk.Entry(sub, textvariable=self.params[key], width=23, validate="key", validatecommand=vcmd_int)
                else:
                    entry = ttk.Entry(sub, textvariable=self.params[key], width=23)
                entry.pack()
                self.widgets[key] = entry
                if key in explicacoes_parametros:
                    self.adicionar_tooltip(entry, explicacoes_parametros[key])

        frame_salvar = ttk.LabelFrame(frame, text="PARÂMETROS DE SALVAR E APRESENTAR", padding=10)
        frame_salvar.grid(row=1, column=0, columnspan=2, padx=10, pady=5, sticky="nsew")
        frame_salvar.columnconfigure((0, 1), weight=1)


        for idx, key in enumerate(parametros_salvar):
            sub = ttk.Frame(frame_salvar)
            sub.grid(row=0, column=idx, padx=8, pady=6, sticky="w")
            ttk.Label(sub, text=nomes_amigaveis[key]).pack(anchor="w")
            entry = ttk.Entry(sub, textvariable=self.params[key], width=23, validate="key", validatecommand=vcmd_int)
            entry.pack()
            self.widgets[key] = entry
            if key in explicacoes_parametros:
                self.adicionar_tooltip(entry, explicacoes_parametros[key])




        botoes = tk.Frame(self.root, bg="#e6ccff")
        botoes.pack(pady=10)

        style = ttk.Style()
        style.configure("LilazEscuro.TButton", background="#9932CC", foreground="black", font=("TkDefaultFont", 10, "bold"))
        style.configure("AzulEscuro.TButton", background="#1E90FF", foreground="black", font=("TkDefaultFont", 10, "bold"))
        style.configure("Vermelho.TButton", background="red", foreground="black", font=("TkDefaultFont", 10, "bold"))

        self.btn_exec = ttk.Button(botoes, text="Executar Estudo", style="LilazEscuro.TButton",
                            command=lambda: executar_com_debug(self.executar_estudo_thread, self.status))
        
        self.btn_exec.grid(row=0, column=0, padx=10)

        self.btn_plot = ttk.Button(botoes, text="Gerar Gráfico", style="LilazEscuro.TButton", command=self.popup_grafico)
        self.btn_plot.grid(row=0, column=1, padx=10)

        # self.btn_casesSaved=ttk.Button(botoes, text="Casos Salvos", style="LilazEscuro.TButton",
        #         command=lambda: popup_ler_logs(self, self.mostrar_tabelas_resultado, self.console_log)).grid(row=0, column=2, padx=10)

        self.btn_casesSaved = ttk.Button(
            botoes,
            text="Casos Salvos",
            style="LilazEscuro.TButton",
            command=lambda: popup_ler_logs(self, self.mostrar_tabelas_resultado, self.console_log)
        )
        self.btn_casesSaved.grid(row=0, column=2, padx=10)


        self.btn_limpar = ttk.Button(botoes, text="Fechar", style="Vermelho.TButton", command=self.limpar)
        self.btn_limpar.grid(row=0, column=3, padx=10)

        self.botoes_interativos = [
            self.btn_exec,
            self.btn_plot,
            self.btn_casesSaved,
            self.btn_limpar
        ]


        self.adicionar_tooltip(self.btn_exec,
            "1 - Busca condições onde barras PV violam limites de potência reativa.\n2 - Mostra tabela de resultados e imprime resumo no terminal.")

        self.adicionar_tooltip(self.btn_plot,
            "Permite mostrar os gráficos de resultados dos estudos \njá realizados e salvos na pasta 'plot \\ GoCases \\ name.log'")
        
        self.adicionar_tooltip(self.btn_casesSaved,
            "Permite mostrar tabelas de resultados dos estudos \njá realizados e salvos na pasta 'plot \\ GoCases \\ name.log'")        

        self.adicionar_tooltip(self.btn_limpar,
            "Fecha todas as figuras e tabelas abertas e limpa o terminal.")



        self.status = tk.Label(self.root, text="Aguardando...", bg="#e6ccff", fg="black", font=("Arial", 10, "italic"))
        self.status.pack(fill="x", pady=(5, 10))

        self.console_frame = tk.Frame(self.root, bg="#e6ccff")
        self.console_frame.pack(fill="both", expand=False, padx=10, pady=(0, 25))

        self.console_log = tk.Text(self.console_frame, height=10, bg="#f8f8f8", fg="black", font=("Courier New", 9), wrap="word")
        self.console_log.pack(fill="both", expand=True)
        self.console_log.insert("end", "Console do programa:\n")
        self.console_log.config(state="disabled")


       


        # Dentro de create_widgets()
        buffer = io.StringIO()
        sys_stdout_original = sys.stdout
        sys.stdout = buffer

        try:
            self.coloca_notas_noTerminal()  # A função usa vários prints
        finally:
            sys.stdout = sys_stdout_original  # Restaura o stdout original

        # Escreve no Text console_log
        self.console_log.config(state="normal")
        self.console_log.insert("end", buffer.getvalue())
        self.console_log.config(state="disabled")


    def desativar_botoes(self):
        for botao in self.botoes_interativos:
            botao.config(state="disabled")

    def ativar_botoes(self):
        for botao in self.botoes_interativos:
            botao.config(state="normal")


    def validar_inteiro(self, valor):
        return valor.isdigit() or valor == ""

    def get_widget(self, key):
        return self.widgets.get(key)
    
    def atualizar_estado_barras_para_amostragem(self, *args):
        reduzir_valor = self.params["ReduzirEspacoAmostral"].get().lower()
        widget = self.get_widget("Minimizar_EspacoAmostral")
        if reduzir_valor == "no":
            widget.config(state="disabled")
            self.params["Minimizar_EspacoAmostral"].set("")
        else:
            widget.config(state="normal")
            self.params["Minimizar_EspacoAmostral"].set("1-5_9")


    def selecionar_arquivo(self):
        caminho = filedialog.askopenfilename(filetypes=[("CDF Files", "*.cdf")])
        if caminho:
            self.params["SYSname"].set(caminho)

    def executar_estudo_thread(self):
        self.console_log.config(state="normal")
        self.console_log.delete("1.0", tk.END)
        self.console_log.config(state="disabled")

        threading.Thread(target=self.executar_estudo, daemon=True).start()


    def executar_estudo(self):
        cdf_nome = self.params["SYSname"].get().strip()

        if "Selecionar outro arquivo..." in cdf_nome and not os.path.isfile(cdf_nome):
            messagebox.showerror("Erro de entrada", "Você selecionou 'Selecionar outro' mas não forneceu um arquivo .CDF válido.")
            self.status.config(text="⚠️ Corrija o campo 'Arquivo CDF'.")
            print('❗❗❗❗❗❗❗❗❗❗❗❗   ERRO GRAVE DE EXECUÇÃO IDENTIFICADO   ❗❗❗❗❗❗❗❗❗❗❗❗')
            print('\n   - Preencheu adequadamente todos os campos?')
            print('   - Arquivo CDF convergindo inicialmente?')  
            self.btn_exec.config(state=tk.NORMAL)
            #self..state(["!disabled"])
            #self.botao_parar.config(state=tk.DISABLED)
            return


        def tratar_erro(e):
            tipo_erro, valor_erro, tb = sys.exc_info()
            ult_traco = traceback.extract_tb(tb)[-1]
            nome_arquivo = ult_traco.filename
            linha = ult_traco.lineno
            texto = ult_traco.line
            msg = f"Erro na linha {linha} do arquivo '{nome_arquivo}':\n→ {valor_erro}\n\nCódigo:\n{texto}"
            messagebox.showerror("Erro durante execução", msg)
            self.status.config(text=f"Erro na linha {linha}: {valor_erro}")
            print(traceback.format_exc())



        # 2. Campos obrigatórios comuns
        campos_obrigatorios = {
            "Tolerancia": "Tolerância",
            "S_base": "S base (MVA)",
            "limite_variacao": "Limite de Variação (%)",
            "PassoEstudo_DasCombinacoes": "Passo (MW)",
            "saveCaseUntil": "Qtd. Casos para Salvar",
            "tolApresent": "Tolerância para Apresentar"            
        }
        
        try:
            def raise_erro():
                messagebox.showerror("Erro de entrada", f"O campo obrigatório '{nome}' está vazio ou inválido. Por favor, preencha corretamente.")
                self.status.config(text=f"⚠️ Preencha o campo '{nome}' para continuar.")
                self.btn_exec.config(state=tk.NORMAL)
                #self.botao_parar.config(state=tk.DISABLED)
                raise Exception("Interrompido por campo obrigatório inválido.")
                    
            for chave, nome in campos_obrigatorios.items():
                valor = self.params[chave].get()
                if isinstance(valor, str):
                    if not valor.strip():
                        raise_erro()
                else:
                    if valor is None or valor == 0:
                        raise_erro()
            liberar='yes'
        except:
            liberar='no'
            messagebox.showerror("Erro de entrada", f"O campo obrigatório '{nome}' está vazio ou inválido. Por favor, preencha corretamente.")
            self.status.config(text=f"⚠️ Preencha o campo '{nome}' para continuar.")
            self.btn_exec.config(state=tk.NORMAL)
            #self.botao_parar.config(state=tk.DISABLED)

        if liberar=='yes':
            self.desativar_botoes()
            self.console_log.config(state="normal")
            self.console_log.delete("1.0", "end")
            self.console_log.insert("end", "Console do programa:\n")
            self.console_log.config(state="disabled")

            self.status.config(text="Executando estudo... Aguarde.")
            self.btn_exec.state(["disabled"])
            p = {k: v.get() for k, v in self.params.items()}
            try:
                ([matrizSystem],[matrizSystem2])=Ler_Arquivo(p["SYSname"])
                ATIVA_ESPEC00A=extrair_potencias_negativas(matrizSystem)
                PVbarIndex, *_ = extrair_vetores_da_matrizSystem(matrizSystem)

                try:
                    _ , ATIVA_ESPEC00A_index_modific, ATIVA_ESPEC00A_modific=process_intervals(
                        ATIVA_ESPEC00A, PVbarIndex, p["Minimizar_EspacoAmostral"], len(ATIVA_ESPEC00A)
                    )

                    # print(PVbarIndex_modific)
                    # print(ATIVA_ESPEC00A_index_modific)
                    titulo = "INICIANDO ESTUDO DE CASOS"
                    print(titulo)
                    print("=" * len(titulo))
                    print('\n🔧 Principais parâmetros do estudo: ')
                    print("       - Sistema:", p["SYSname"])
                    print("       - Barras:",p["Minimizar_EspacoAmostral"])
                    print("       - Passo:",p["PassoEstudo_DasCombinacoes"])
                    print("       - Regime:",p["tipo_de_REGIME"])
                    print("       - Regime:", p["limite_variacao"])

                    print("\n🔢 Barras Escolhidas:")
                    for barra, pot in zip(ATIVA_ESPEC00A_index_modific, ATIVA_ESPEC00A_modific):
                        print(f"         -> Barra: {barra+1} - Potência ativa de carga: {-1 * pot:.4f} MW")
                    print("\n")
                except Exception as e:
                    print('CORRIJA A VARIÁVEL: "Barras Escolhidas"') 
                    print('  ✅ Formato Válido: 1-5 (da barra 1 à 5)')  
                    print('  ✅ Formato Válido: 1-5_7 (da barra 1 à 5 com a inclusão da barra 7)') 
                    print('  🚫 Formato Inválido: 0-5_7 (inclusão do 0 ou negativos)') 
                    print('  🚫 Formato Inválido: 1-5_180 (inclusão além do necessário)')
                    print('  🚫 Formato Inválido: " " (deixar em vazio)')
                    print('  🚫 Formato Inválido: "1-21" (Acima de 20 barras)')
                    messagebox.showerror("Erro de entrada", f"O campo obrigatório 'Barras Escolhidas' está vazio ou inválido. Por favor, preencha corretamente.")
                    self.status.config(text=f"⚠️ Preencha o campo para continuar.")
                    self.btn_exec.config(state=tk.NORMAL)                    
                    exit()           
                print('⚙️ Processando Estudo: ')
                sistema=[matrizSystem, matrizSystem2]
                MATRIZ_TOTAL_PES, MATRIZ_TOTAL_LEV, BarraQViola_estatica_0_STRG, quantidadeViolada_0, MATRIZ_TOTAL_INICIAL, PACOTE_OUT_FIGtype2, LEG_P_FIG_FP= controle_reativo(
                    sistema , p["MODELin"], p["Tolerancia"], p["limite_variacao"],
                    p["tipo_de_ESTUDO"], p["PassoEstudo_DasCombinacoes"], p["Minimizar_EspacoAmostral"],
                    "yes", p["tipo_de_REGIME"], 'desabilitar', p["S_base"], p["tolApresent"],
                    None, 14, 'N', p["Ativar_inverter"], pega_nome_maiusculo(p["SYSname"]), 'yes', p["GirarTrafo"]
                )

                            # =============================================================================
                # SEÇÃO 4: SALVAR CASOS .CDF
                # =============================================================================
                A_CARGA_PES_de_diferencas=PACOTE_OUT_FIGtype2[0]
                A_TENSAO_PES_de_diferencas=PACOTE_OUT_FIGtype2[1]
                D_CARGA_PES_de_diferencas=PACOTE_OUT_FIGtype2[2]
                D_TENSAO_PES_de_diferencas=PACOTE_OUT_FIGtype2[3]
                analysis_results_antes=PACOTE_OUT_FIGtype2[4]
                vet_grupo=PACOTE_OUT_FIGtype2[5]
                CARG_0vet=PACOTE_OUT_FIGtype2[6]
                TENSAO_0=PACOTE_OUT_FIGtype2[7]
                CENARIO_BASE=PACOTE_OUT_FIGtype2[8]
                FilterDat=PACOTE_OUT_FIGtype2[9]
                FilterDat_LEV=PACOTE_OUT_FIGtype2[10]
                FilterDat_PES=PACOTE_OUT_FIGtype2[11]

                save_dir = os.path.join(BASE_DIR)
                pattern = os.path.join(save_dir, f"{p["SYSname"]}")
                
                try:
                    vet_name_PES=[]
                    output_dir = os.path.join(BASE_DIR,"plot", "cdfsGerados", "G_TELA2", pega_nome_maiusculo(p["SYSname"]))
                    if MATRIZ_TOTAL_PES!=[]:
                        vet_name_PES=CHAMA_saveCases_CDF(MATRIZ_TOTAL_PES, p["saveCaseUntil"], output_dir, pattern, FilterDat_PES, p["S_base"])

                    vet_name_LEV=[]
                    #print(p["saveCaseUntil"])
                    if MATRIZ_TOTAL_LEV!=[]:
                        vet_name_LEV=CHAMA_saveCases_CDF(MATRIZ_TOTAL_LEV, p["saveCaseUntil"], output_dir, pattern, FilterDat_LEV, p["S_base"])
                    
                    print('\n✅ Arquivos CDF de casos gerados salvos com sucesso no diretório:')
                    print(output_dir)
                except:
                    print('\n❗Erro ao tentar salvar arquivos CDFs dos casos gerados!')

                vet_name2_LEV=[]
                vet_name2_PES=[]
                vet_name2=[]
                vet_name2_LEVval=[]
                vet_name2_PESval=[]
                if vet_name_PES!=[] and vet_name_LEV==[]:
                    for aux in range(len(vet_name_PES)):
                        vet_name2.append(vet_name_PES[aux][0])
                        vet_name2_PES.append(vet_name_PES[aux][0])
                        vet_name2_PESval.append(vet_name_PES[aux][1]) 
                elif vet_name_PES==[] and vet_name_LEV!=[]:
                    for aux in range(len(vet_name_LEV)):
                        vet_name2.append(vet_name_LEV[aux][0])
                        vet_name2_LEV.append(vet_name_LEV[aux][0])
                        vet_name2_LEVval.append(vet_name_LEV[aux][1])
                elif vet_name_PES!=[] and vet_name_LEV!=[]:
                    for aux in range(len(vet_name_LEV)):
                        vet_name2.append(vet_name_LEV[aux][0])
                        vet_name2_LEV.append(vet_name_LEV[aux][0])
                        vet_name2_LEVval.append(vet_name_LEV[aux][1])    
                    for aux in range(len(vet_name_PES)):
                        vet_name2.append(vet_name_PES[aux][0])
                        vet_name2_PES.append(vet_name_PES[aux][0])  
                        vet_name2_PESval.append(vet_name_PES[aux][1])  


                CARG_0=0
                for aux in range(len(MATRIZ_TOTAL_INICIAL[9])):
                    CARG_0=(-1/p["S_base"])*MATRIZ_TOTAL_INICIAL[9][aux]+CARG_0


                # =============================================================================
                # SEÇÃO 5: SALVAR GRÁFICO EM .TXT E ROTINA PARA LER O GRÁFICO SALVO (reconstruct_plot)
                # =============================================================================
                parameters = p

                # Monta o dicionário de dados para salvar; note que incluímos também o ponto inicial.
                plot_data = {
                    "A_CARGA": np.array(A_CARGA_PES_de_diferencas),
                    "A_TENSAO": np.array(A_TENSAO_PES_de_diferencas),
                    "D_CARGA": np.array(D_CARGA_PES_de_diferencas),
                    "D_TENSAO": np.array(D_TENSAO_PES_de_diferencas),
                    "analysis_results_antes": analysis_results_antes,
                    "vet_grupo": np.array(vet_grupo),
                    "CARG_0": np.array(CARG_0vet),
                    "TENSAO_0": np.array(TENSAO_0)
                }

                # Diretório de salvamento
                save_dir = os.path.join(BASE_DIR, "plot", "GenOfCases")
                os.makedirs(save_dir, exist_ok=True)

                # Nome do arquivo (gerado por sua função, aqui exemplo)
                tag = create_unique_tag2(save_dir, len(CENARIO_BASE)) 

                # Salva as informações do gráfico
                save_plot_info(tag, save_dir, parameters, plot_data)


                Tag_LEV, PotRemoved_LEV, BarrasAlt_LEV, VetPorct_LEV, LimiteViolado_LEV, IndQlt_LEV, Quanty_LEV, status_LEV = ([] for _ in range(8))
                aux_soma=0
                for linha in MATRIZ_TOTAL_LEV:
                    #print(aux_soma)
                    if aux_soma in vet_name2_LEVval:
                        Tag_LEV.append(linha[0])
                        PotRemoved_LEV.append(-linha[1])
                        BarrasAlt_LEV.append(linha[2])
                        VetPorct_LEV.append(linha[3])
                        LimiteViolado_LEV.append(linha[4])
                        IndQlt_LEV.append(linha[5])
                        Quanty_LEV.append(linha[6])
                        status_LEV.append(linha[8])
                    aux_soma=aux_soma+1

                Tag_PES, PotRemoved_PES, BarrasAlt_PES, VetPorct_PES, LimiteViolado_PES, IndQlt_PES, Quanty_PES, status_PES = ([] for _ in range(8))
                aux_soma=0
                for linha in MATRIZ_TOTAL_PES:
                    #print(aux_soma)
                    if aux_soma in vet_name2_PESval:
                        Tag_PES.append(linha[0])
                        PotRemoved_PES.append(-linha[1])
                        BarrasAlt_PES.append(linha[2])
                        VetPorct_PES.append(linha[3])
                        LimiteViolado_PES.append(linha[4])
                        IndQlt_PES.append(linha[5])
                        Quanty_PES.append(linha[6])
                        status_PES.append(linha[8])
                    aux_soma=aux_soma+1
                
                def ajustar_tamanho(vetores):
                    max_len = max(len(v) for v in vetores)
                    for i in range(len(vetores)):
                        while len(vetores[i]) < max_len:
                            vetores[i].append("")

                ajustar_tamanho([
                    Tag_LEV, PotRemoved_LEV, BarrasAlt_LEV, VetPorct_LEV,
                    LimiteViolado_LEV, IndQlt_LEV, Quanty_LEV, status_LEV, vet_name2_LEV
                ])

                ajustar_tamanho([
                    Tag_PES, PotRemoved_PES, BarrasAlt_PES, VetPorct_PES,
                    LimiteViolado_PES, IndQlt_PES, Quanty_PES, status_PES, vet_name2_PES
                ])

                terminal_output = self.console_log.get("1.0", "end")

                dados_lev = list(zip(Tag_LEV, PotRemoved_LEV, BarrasAlt_LEV, VetPorct_LEV,
                                    LimiteViolado_LEV, IndQlt_LEV, Quanty_LEV, status_LEV, vet_name2_LEV))

                dados_pes = list(zip(Tag_PES, PotRemoved_PES, BarrasAlt_PES, VetPorct_PES,
                                    LimiteViolado_PES, IndQlt_PES, Quanty_PES, status_PES, vet_name2_PES))
                try:
                    salvar_log_completo(tag, save_dir, p , dados_lev, dados_pes, terminal_output)
                    log_path = os.path.join(save_dir, f"{tag}.log")
                    print('\n✅ Arquivos LOG de casos gerados salvos com sucesso em:')
                    print(log_path)                    
                except:
                    print('\n❗Erro ao tentar salvar arquivos LOG dos casos gerados!')

                self.status.config(text="Estudo finalizado com sucesso!")
                self.mostrar_tabelas_resultado(p["SYSname"], quantidadeViolada_0, BarraQViola_estatica_0_STRG, MATRIZ_TOTAL_INICIAL[10],
                                            list(zip(Tag_LEV, PotRemoved_LEV, BarrasAlt_LEV, VetPorct_LEV, LimiteViolado_LEV, IndQlt_LEV, Quanty_LEV, status_LEV, vet_name2_LEV)),
                                            list(zip(Tag_PES, PotRemoved_PES, BarrasAlt_PES, VetPorct_PES, LimiteViolado_PES, IndQlt_PES, Quanty_PES, status_PES, vet_name2_PES)))
            except Exception as e:
                self.status.config(text=f"Erro: {e}")
            self.btn_exec.state(["!disabled"])
            self.ativar_botoes()
        else:
            print('\n❗❗❗❗❗❗❗❗❗❗❗❗❗❗  ERRO GRAVE DE EXECUÇÃO IDENTIFICADO   ❗❗❗❗❗❗❗❗❗❗❗❗❗❗')
            print('\n   - Preencheu adequadamente todos os campos?')
            print('   - Arquivo CDF convergindo inicialmente?')



    def mostrar_tabelas_resultado(self, SYSname, qtd_violacoes, barras_violadas, limite_infligido,
                                dados_lev, dados_pes, numero_simulacao=None):
        janela = tk.Toplevel(self.root)
        janela.title("Resultados do Estudo")
        janela.configure(bg="#f5f5ff")
        janela.state('zoomed')  # Abrir em tela cheia
        self.janelas_popups.append(janela)

        def criar_tabela_simples(parent, titulo, cabecalho, dados):
            ttk.Label(parent, text=titulo, font=("Arial", 10, "bold"), background="#f5f5ff").pack(anchor="w", pady=(10, 2))
            frame = ttk.Frame(parent)
            frame.pack(fill="x", padx=10)
            tree = ttk.Treeview(frame, columns=cabecalho, show="headings", height=min(8, len(dados)))

            for col in cabecalho:
                tree.heading(col, text=col)
                tree.column(col, anchor="center", width=160)

            for row in dados:
                linha_formatada = [f"{x:.4f}" if isinstance(x, float) else x for x in row]
                tree.insert("", "end", values=linha_formatada)

            tree.pack(side="left", fill="x", expand=True)

        def criar_tabela_com_scroll(parent, titulo, cabecalho, dados):
            ttk.Label(parent, text=titulo, font=("Arial", 10, "bold"), background="#f5f5ff").pack(anchor="w", pady=(10, 2))

            frame = ttk.Frame(parent)
            frame.pack(fill="both", expand=True, padx=10, pady=5)

            tree_frame = ttk.Frame(frame)
            tree_frame.pack(fill="both", expand=True)

            scrollbar = ttk.Scrollbar(tree_frame, orient="vertical")
            scrollbar.pack(side="right", fill="y")

            tree = ttk.Treeview(tree_frame, columns=cabecalho, show="headings", yscrollcommand=scrollbar.set)
            scrollbar.config(command=tree.yview)

            for col in cabecalho:
                tree.heading(col, text=col)
                tree.column(col, anchor="center", width=160)

            for row in dados:
                linha_formatada = [f"{x:.4f}" if isinstance(x, float) else x for x in row]
                tree.insert("", "end", values=linha_formatada)

            tree.pack(side="left", fill="both", expand=True)


        criar_tabela_simples(
            janela,
            "Informações Iniciais",
            ["Estudo inicial", "Qtd. Violações", "Barras Violadas", "Limite infligidos"],
            [(SYSname, qtd_violacoes, barras_violadas, limite_infligido)]
        )

        prefixo = f"Simulação #{numero_simulacao} – " if numero_simulacao else ""

        if dados_lev:
            criar_tabela_com_scroll(
                janela,
                prefixo + "Casos de regime leve detectados",
                ["Tag", "Pot. Ativa Removida", "Barras Alteradas", "Vetor Porcentagem", "Limite Violado",
                "Qualidade", "Qtd. Violações", "Status Demais", "Arquivo Salvo (GoCases)"],
                dados_lev
            )

        if dados_pes:
            criar_tabela_com_scroll(
                janela,
                prefixo + "Casos de regime pesado detectados",
                ["Tag", "Pot. Ativa Adicionada", "Barras Alteradas", "Vetor Porcentagem", "Limite Violado",
                "Qualidade", "Qtd. Violações", "Status Demais", "Arquivo Salvo (GoCases)"],
                dados_pes
            )







    def popup_grafico(self):
        popup = tk.Toplevel(self.root)
        popup.title("Selecionar Estudo Salvo")
        popup.configure(bg="#f0f8ff")
        self.janelas_popups.append(popup)
        popup.geometry("450x420")
        popup.resizable(False, False)

        style = ttk.Style(popup)
        style.configure("Popup.TLabel", background="#f0f8ff")
        style.configure("PretoBold.TButton", foreground="black", font=("TkDefaultFont", 10, "bold"))

        arquivos = [f for f in os.listdir("plot/GenOfCases") if f.endswith(".txt")]
        arquivos.sort()

        cb_estudo = ttk.Combobox(popup, values=arquivos, state="readonly", width=40)
        cb_estudo.pack(pady=(10, 5))
        cb_estudo.set(arquivos[0] if arquivos else "")

        info_text = tk.Text(popup, height=12, bg="#ffffff", state="disabled")
        info_text.pack(fill="both", expand=True, padx=10, pady=(5, 10))

        def carregar_info(event=None):
            arquivo = cb_estudo.get()
            if not arquivo: return
            caminho = os.path.join(BASE_DIR, "plot", "GenOfCases", arquivo)
            params = {}
            try:
                with open(caminho, "r") as f:
                    for linha in f:
                        if '=' in linha and not linha.startswith("''')"):
                            k, v = linha.strip().split("=", 1)
                            params[k.strip()] = v.strip()
            except:
                params = {}

            info_text.config(state="normal")
            info_text.delete("1.0", "end")
            info_text.insert("end", "Parâmetros do estudo selecionado:\n")
            for k, v in params.items():
                info_text.insert("end", f"{k} = {v}\n")
            info_text.config(state="disabled")

        cb_estudo.bind("<<ComboboxSelected>>", carregar_info)
        carregar_info()

        ttk.Button(popup, text="Gerar", style="PretoBold.TButton", command=lambda: self._confirmar_plot(cb_estudo, popup)).pack(pady=5)

    def _confirmar_plot(self, cb_estudo, popup):
        nome = cb_estudo.get()
        if not nome:
            messagebox.showwarning("Aviso", "Selecione um arquivo primeiro.")
            return
        
        DADOS_PLOT2_IN = [nome, "PxV"]
        self.console_log.config(state="normal")
        self.console_log.delete("1.0", tk.END)
        self.console_log.config(state="disabled")        
        CHAMA_PLOT2(DADOS_PLOT2_IN)
        #popup.destroy()

    
    def limpar(self):
        def limpar_console_log(self):
            self.console_log.config(state="normal")
            self.console_log.delete("1.0", tk.END)
            self.console_log.insert("end", "Console do programa:\n")
            self.console_log.config(state="disabled")

        self.status.config(text="Campos e janelas auxiliares foram limpos.")
        
        # ✅ Fecha todos os pop-ups registrados (inclui popup de logs)
        for janela in self.janelas_popups:
            if janela.winfo_exists():
                janela.destroy()
        self.janelas_popups.clear()
        
        # ✅ Fecha todos os gráficos
        for manager in _pylab_helpers.Gcf.get_all_fig_managers():
            fig = manager.canvas.figure
            if plt.fignum_exists(fig.number):
                plt.close(fig)
        limpar_console_log(self)
        colaca_notas_noTerminal ()
        self.console_log.see("1.0")  # <-- volta para o início
        self.status.config(text="Campos, gráficos e janelas auxiliares foram limpos.")


    def adicionar_tooltip(self, widget, texto):
        tooltip = tk.Toplevel(widget)
        tooltip.withdraw()
        tooltip.overrideredirect(True)
        tooltip_label = tk.Label(
            tooltip, text=texto, justify='left',
            background="#ffffe0", relief='solid', borderwidth=1,
            wraplength=300, font=("Segoe UI", 7)
        )
        tooltip_label.pack(ipadx=1)

        def mostrar_tooltip(event):
            x = event.x_root + 10
            y = event.y_root + 10
            tooltip.geometry(f"+{x}+{y}")
            tooltip.deiconify()

        def esconder_tooltip(event):
            tooltip.withdraw()

        widget.bind("<Enter>", mostrar_tooltip)
        widget.bind("<Leave>", esconder_tooltip)






# if __name__ == "__main__":
#     # 🔹 Chama extração automática dos recursos embutidos
#     extrair_recursos_embutidos()
#     # 👉 MOSTRA SPLASH ANTES DE CRIAR A INTERFACE PRINCIPAL
    
#     # 🔹 Ajusta o diretório base corretamente
#     BASE_DIR = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.dirname(__file__)
#     os.chdir(BASE_DIR)  # garante que os caminhos relativos funcionem mesmo em .exe
    
#     def on_closing():
#         root.quit()
#         root.destroy()
#         for manager in _pylab_helpers.Gcf.get_all_fig_managers():
#             fig = manager.canvas.figure
#             if plt.fignum_exists(fig.number):
#                 plt.close(fig)

#     root = tk.Tk()
#     app = GoCasesApp(root)
#     root.protocol("WM_DELETE_WINDOW", on_closing)
#     splash.destroy()
#     root.mainloop()
    

if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()  # Oculta a tela principal enquanto mostra o splash
    splash = mostrar_splash_temporario(root)

    extrair_recursos_embutidos()
    verificar_bibliotecas()
    verificar_e_criar_pastas()
    
    BASE_DIR = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.dirname(__file__)
    os.chdir(BASE_DIR)


    def iniciar_interface():
        splash.destroy()
        root.deiconify()  # Mostra a janela principal
        app = GoCasesApp(root)

    root.after(3500, iniciar_interface)  # espera 3.5s para mostrar a tela principal
    root.mainloop()
