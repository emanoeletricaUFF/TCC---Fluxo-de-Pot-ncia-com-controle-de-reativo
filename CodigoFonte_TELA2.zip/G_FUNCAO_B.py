import numpy as np
import matplotlib.pyplot as plt
import mplcursors
import os
import ast
import glob
import chardet
import csv
import statsmodels.api as sm
from collections import defaultdict
from matplotlib.widgets import CheckButtons
import matplotlib.patches as mpatches
from tkinter import messagebox

from matplotlib.collections import LineCollection
from matplotlib.colors import LinearSegmentedColormap
from datetime import datetime
from itertools import chain, combinations

from G_FUNCAO_A import CHAMA_FLNR_03_LTT, Ler_Arquivo, DefineMatrizDadosBarra
from G_FUNCAO_A import calcularMATRIZ_Y, alterar_matrizes
from G_FUNCAO_A import corrige_duplicidadeDeLinha
from G_FUNCAO_A import liga_desliga_CS
from G_FUNCAO_A import create_unique_tag2
from G_FUNCAO_A import Encabecalha_plot, Encabecalha_plot_PotGer, modificar_cdf



def read_all_csvs_and_merge(directory):
    grouped_data = defaultdict(lambda: {"X": [], "Y": []})
    initial_points = []

    csv_files = glob.glob(os.path.join(directory, "*.csv"))

    if not csv_files:
        raise FileNotFoundError(f"Nenhum arquivo CSV encontrado no diretório {directory}")

    for file in csv_files:
        with open(file, mode='r') as csvfile:
            reader = csv.reader(csvfile)
            section = None
            y_data, x_data, groups = [], [], []
            fpInicial, PotPInicial, vet_TagDoInicial = None, None, ""

            for row in reader:
                if not row:
                    continue

                if row[0] == "fpInicial":
                    fpInicial = float(row[1])
                elif row[0] == "PotPInicial":
                    PotPInicial = float(row[1])
                elif row[0] == "vet_TagDoInicial":
                    vet_TagDoInicial = row[1] if len(row) > 1 else ""  
                elif row[0] == "pontos_fatorDePotencia_PES_dep":
                    section = "pes_dep_y"
                    continue
                elif section == "pes_dep_y" and row[0].replace(".", "", 1).isdigit():
                    y_data = list(map(float, row))
                    section = "pes_dep_x"
                    continue
                elif section == "pes_dep_x" and row[0].replace(".", "", 1).isdigit():
                    x_data = list(map(float, row))
                    section = "pes_dep_groups"
                    continue
                elif section == "pes_dep_groups" and row[0].isdigit():
                    groups = list(map(int, row))
                    break

        if len(y_data) != len(x_data) or len(y_data) != len(groups):
            raise ValueError(f"Os dados de Y, X e Grupos possuem tamanhos diferentes no arquivo {file}")

        if fpInicial is not None and PotPInicial is not None:
            initial_points.append({"X": PotPInicial, "Y": fpInicial, "Tag": vet_TagDoInicial})

        for i in range(len(groups)):
            grouped_data[groups[i]]["X"].append(x_data[i])
            grouped_data[groups[i]]["Y"].append(y_data[i])

    return grouped_data, initial_points






def CHAMA_PLOT2(DADOS_PLOT2_IN):
    NAME=DADOS_PLOT2_IN[0]
    GrafficDesired=DADOS_PLOT2_IN[1]
    
    print('GRÁFICOS SALVOS DO GoCases - GENERATOR OF CASES')
    if GrafficDesired=="PxV":
        #print('------------------------------------------------ PxV selected ------------------------------------------\n')
        ''' LER O DIRETÓRIO E RETORNA TABELA DE CONTEÚDO '''
        #total_arquivos, nameChoosed, estudosE3_param, arquivos_info =ler_diretorio_plot2(selecionarPlt2)
        
        # if total_arquivos!=0:
        #     for idx, (nome, params) in enumerate(arquivos_info, start=1):
        #         # Cria uma string resumo com os parâmetros principais (pode ser adaptado conforme necessário)
        #         # Aqui, mostramos por exemplo SYSname, MODELin e Tolerancia
        #         resumo = f"{params.get('tipo_de_ESTUDO', 'N/A')}; LIM. ESPAÇO: {params.get('ReduzirEspacoAmostral', 'N/A')}; ESPAÇO: {params.get('Minimizar_EspacoAmostral', 'N/A')}; REG: {params.get('tipo_de_REGIME', 'N/A')}; VAR: {params.get('limite_variacao', 'N/A')}%; STP: {params.get('PassoEstudo_DasCombinacoes', 'N/A')}"
        #         print(f"{idx:3d}. {nome}  ->  {resumo}")

        ''' PLOTAGEM '''
        if NAME!=None:
            tag=NAME
            save_dir = os.path.join(os.getcwd(), "plot", "GenOfCases")
            os.makedirs(save_dir, exist_ok=True)

            # Reconstrói o gráfico a partir do arquivo salvo
            filepath = os.path.join(save_dir, f"{tag}")
            reconstruct_plot(filepath)
        else:
            print('SELECIONE UM NÚMERO VÁLIDO OU RODE PRIMEIRO O ESTUDO GoCases (TELA2)')
            exit()
    elif GrafficDesired=="PxfpEvolutionSet":
        print('------------------------------------------------ Pxfp selected -----------------------------------------\n')
        #save_dir = os.path.join(os.getcwd(), "plot", "GenOfCases")
        #total_pastas, nameChoosed, lista_pastas=ler_diretorio_plot2_pfCrvs(selecionarPlt2)
        if NAME!=None:
            name_Dir="plot/GenOfCases/pfCurve/"+NAME
            load_pfCurves_forPlot2(name_Dir)
        else:
            exit()
    elif GrafficDesired=='PxfpLinearRegression':

        #_ , nameChoosed, _ =ler_diretorio_plot2_pfCrvs(selecionarPlt2)
        save_dir = os.path.join(os.getcwd(), "plot", "GenOfCases","pfCurve")
        os.makedirs(save_dir, exist_ok=True)

        # Reconstrói o gráfico a partir do arquivo salvo
        filepath = os.path.join(save_dir, f"{NAME}")

        grouped_data, initial_points = read_all_csvs_and_merge(filepath)
        regression_results = calculate_regression(grouped_data)
        print(regression_results)
        plot_regression_with_filter(grouped_data, regression_results, initial_points)



def calculate_regression(grouped_data):
    results = {}

    for group, data in grouped_data.items():
        X = np.array(data["X"])
        Y = np.array(data["Y"])

        X = sm.add_constant(X)
        model = sm.OLS(Y, X).fit()

        intercept, slope = model.params
        r_squared = model.rsquared
        std_errors = model.bse

        Y_pred = intercept + slope * X[:, 1]
        residuals = Y - Y_pred
        variance_residuals = np.var(residuals, ddof=1)
        mse = np.mean(residuals**2)

        results[group] = {
            "intercept": intercept,
            "slope": slope,
            "r_squared": r_squared,
            "mse": mse,
            "variance_residuals": variance_residuals,
            "std_err_intercept": std_errors[0],
            "std_err_slope": std_errors[1]
        }

    return results

def plot_regression_with_filter(grouped_data, regression_results, initial_points):
    fig, ax = plt.subplots(figsize=(10, 6))
    plt.subplots_adjust(right=0.75)

    cmap = plt.get_cmap("Set2")
    unique_groups = list(grouped_data.keys())
    selected_groups = {g: True for g in unique_groups}

    def plot_data():
        ax.clear()
        colors = {}

        for i, group in enumerate(unique_groups):
            if not selected_groups[group]:
                continue  

            X = np.array(grouped_data[group]["X"])
            Y = np.array(grouped_data[group]["Y"])
            a = regression_results[group]["slope"]
            b = regression_results[group]["intercept"]
            variance_residuals = regression_results[group]["variance_residuals"]

            color = cmap(i % 8)
            colors[group] = color

            ax.scatter(X, Y, color=color, label=f"Grupo {group}", alpha=0.6)

            x_range = np.linspace(min(X), max(X), 100)
            y_pred = a * x_range + b
            ax.plot(x_range, y_pred, linestyle="--", color=color, label=f"Reg Grupo {group}")

            indices = np.random.choice(len(X), size=min(5, len(X)), replace=False)
            ax.errorbar(X[indices], Y[indices], yerr=np.sqrt(variance_residuals), fmt='o', capsize=4, color=color, alpha=0.5)

        for point in initial_points:
            x, y, tag = point["X"], point["Y"], point["Tag"]
            ax.scatter(x, y, color="black", marker="*", s=150, zorder=3)

            offset_x = 0.0006  # Distância mínima (~1/5 do ajuste anterior)
            offset_y = 0.0006
            ax.annotate(tag, xy=(x, y), xytext=(x + offset_x, y + offset_y),
                        arrowprops=dict(facecolor='black', arrowstyle="->"),
                        fontsize=9, bbox=dict(facecolor='white', alpha=0.8, edgecolor='black'))

        ax.set_xlabel("Potência das Cargas (p.u.)")
        ax.set_ylabel("Fator de Potência")
        ax.set_title("Regressão Linear por Grupo")
        ax.grid(True)

        legend_elements = [mpatches.Patch(color=colors[g], label=f"Grupo {g}") for g in colors]
        legend_elements.append(plt.Line2D([0], [0], color="black", linestyle="--", label="Regressão Linear"))
        legend_elements.append(plt.Line2D([0], [0], color="black", marker="*", markersize=10, linestyle="", label="Ponto Inicial"))
        
        # Barras de Controle Perdido: apenas um balão com borda preta
        example_balloon = mpatches.FancyBboxPatch((0, 0), 1, 1, boxstyle="round,pad=0.3",
                                                  edgecolor="black", facecolor="white",
                                                  label="Controle Perdido Inicial")
        legend_elements.append(example_balloon)

        ax.legend(handles=legend_elements, loc="lower left", fontsize=10)
        plt.draw()

    plot_data()

    ax_check = plt.axes([0.8, 0.2, 0.15, 0.6])
    labels = [f"Grupo {int(g)}" for g in unique_groups]
    visibility = [selected_groups[g] for g in unique_groups]
    check = CheckButtons(ax_check, labels, visibility)

    def update_group_visibility(label):
        group_number = int(label.split("Grupo ")[1])
        selected_groups[group_number] = not selected_groups[group_number]
        plot_data()

    check.on_clicked(update_group_visibility)
    plt.show()


def ler_diretorio_plot2(selecionarE3):
    """
    Varre o diretório 'plot/GoC-PLOT2' para identificar os arquivos txt,
    extrai os parâmetros do cabeçalho de cada arquivo e os armazena na lista
    estudosE3_param. Em seguida, imprime os nomes dos arquivos e um resumo dos
    seus parâmetros.
    
    Parâmetro:
      selecionarE3 (int): Índice (base 1) do arquivo a ser selecionado.
      
    Retorna:
      total_arquivos (int): Quantidade de arquivos txt encontrados.
      nameChoosed (str ou None): Nome do arquivo selecionado, se válido; caso
                                 contrário, None.
      estudosE3_param (list): Lista de dicionários com os parâmetros de cada arquivo.
    """
    # Define o diretório onde estão os arquivos txt
    base_dir = os.path.join(os.getcwd(), "plot", "GenOfCases")
    pattern = os.path.join(base_dir, "*.txt")
    file_list = sorted(glob.glob(pattern))
    
    estudosE3_param = []  # Lista para armazenar os parâmetros de cada estudo
    arquivos_info = []    # Lista de tuplas (arquivo, parâmetros) para exibição

    # Função auxiliar para extrair os parâmetros do cabeçalho do arquivo
    def extrair_parametros(filepath):
        parametros = {}
        with open(filepath, mode='r', encoding='latin-1') as file:
            lines = file.readlines()
        
        # Procura a linha que contém "''' ESPECIFICAÇÃO '''" e, a partir dela,
        # lê as linhas seguintes até encontrar uma linha vazia ou uma que inicie com "EvolutionMatrixMatriz2[0]"
        inicio = False
        for line in lines:
            stripped = line.strip()
            if stripped == "''' ESPECIFICAÇÃO '''":
                inicio = True
                continue
            if inicio:
                # Se a linha estiver vazia ou indicar o início dos dados, encerra a leitura dos parâmetros
                if stripped == "" or stripped== "''' PLOT DATA  '''":
                    break
                # Se houver o sinal de igualdade, processa como parâmetro
                if "=" in stripped:
                    try:
                        key, val = stripped.split("=", 1)
                        key = key.strip()
                        val = val.strip()
                        # Tenta interpretar o valor com ast.literal_eval para definir o tipo
                        try:
                            parametros[key] = ast.literal_eval(val)
                        except Exception:
                            parametros[key] = val
                    except Exception as e:
                        print(f"Erro processando a linha '{stripped}': {e}")
        return parametros

    # Varre os arquivos encontrados e extrai os parâmetros
    for arquivo in file_list:
        params = extrair_parametros(arquivo)
        estudosE3_param.append(params)
        arquivos_info.append((os.path.basename(arquivo), params))
    
    total_arquivos = len(file_list)
    
    # Exibe os arquivos encontrados e seus parâmetros (resumindo em poucas linhas)
    if total_arquivos == 0:
        print("\nNenhum arquivo txt encontrado em 'plot/GenOfCases'.")
        print("Realize antes o estudo 2 (TELA2_GoCases).")
        exit()
    else:
        print("CASOS ENCONTRADOS NO DIRETÓRIO (Plt2 - 'plot/GenOfCases'):")
        for idx, (nome, params) in enumerate(arquivos_info, start=1):
            # Cria uma string resumo com os parâmetros principais (pode ser adaptado conforme necessário)
            # Aqui, mostramos por exemplo SYSname, MODELin e Tolerancia
            resumo = f"{params.get('tipo_de_ESTUDO', 'N/A')}; LIM. ESPAÇO: {params.get('ReduzirEspacoAmostral', 'N/A')}; ESPAÇO: {params.get('Minimizar_EspacoAmostral', 'N/A')}; REG: {params.get('tipo_de_REGIME', 'N/A')}; VAR: {params.get('limite_variacao', 'N/A')}%; STP: {params.get('PassoEstudo_DasCombinacoes', 'N/A')}"
            print(f"{idx:3d}. {nome}  ->  {resumo}")
            #names.append(nome)
    
    # Verifica se a seleção é válida
    nameChoosed = None
    if total_arquivos == 0:
        print("\n")
    elif selecionarE3 < 1 or selecionarE3 > total_arquivos:
        print(f"Opção inválida. Foram encontrados {total_arquivos} estudos. Selecione um número entre 1 e {total_arquivos}.\n")
    else:
        # Lembrando que o índice para o usuário é baseado em 1, portanto subtraímos 1
        nameChoosed = os.path.basename(file_list[selecionarE3 - 1])
        print(f"Arquivo selecionado (opção {selecionarE3}): {nameChoosed}\n")
    
    return total_arquivos, nameChoosed, estudosE3_param, arquivos_info


import os

def ler_diretorio_plot2_pfCrvs(selecionarE3):
    """
    Varre o diretório 'plot/GenOfCases/pfCurve' para identificar as pastas presentes,
    listando-as com um número de identificação.
    
    Parâmetro:
      selecionarE3 (int): Índice (base 1) da pasta a ser selecionada.
      
    Retorna:
      total_pastas (int): Quantidade de pastas encontradas.
      nameChoosed (str ou None): Nome da pasta selecionada, se válido; caso contrário, None.
      lista_pastas (list): Lista dos nomes das pastas encontradas.
    """
    base_dir = os.path.join(os.getcwd(), "plot", "GenOfCases", "pfCurve")
    
    if not os.path.isdir(base_dir):
        print(f"O diretório base não existe: {base_dir}")
        return 0, None, []
    
    # Lista apenas os itens que são diretórios (pastas)
    lista_pastas = [item for item in sorted(os.listdir(base_dir))
                    if os.path.isdir(os.path.join(base_dir, item))]
    
    total_pastas = len(lista_pastas)
    
    print("PASTAS ENCONTRADAS NO DIRETÓRIO (Plt2 - 'plot/GenOfCases/pfCurve'):")
    if total_pastas == 0:
        print("  Nenhuma pasta encontrada em 'plot/GenOfCases/pfCurve'.")
    else:
        for idx, pasta in enumerate(lista_pastas, start=1):
            print(f"{idx:3d}. {pasta}")
    
    nameChoosed = None
    if total_pastas == 0:
        print("Nenhuma pasta para selecionar. Realize antes o estudo 2 (TELA2_GoCases)\n")
        exit()
    elif selecionarE3 < 1 or selecionarE3 > total_pastas:
        print("\nPasta Selecionada (selecionarPlt2): ", selecionarE3)
        print(f"Opção inválida!")
        print(f"Foram encontradas {total_pastas} pastas. Selecione um número entre 1 e {total_pastas}.\n")
        exit()
    else:
        nameChoosed = lista_pastas[selecionarE3 - 1]
        print(f"Pasta selecionada (opção {selecionarE3}): {nameChoosed}\n")
    
    return total_pastas, nameChoosed, lista_pastas







import os
import glob
import numpy as np
import matplotlib.pyplot as plt

def read_csv_two_sections(file):
    """
    Lê um arquivo CSV que contém duas seções de pontos, separadas por linhas vazias.
    Cada seção deve ter:
      - Uma linha de cabeçalho (nome do conjunto, ignorado)
      - Linha 1: valores de fator de potência (y) (float)
      - Linha 2: valores de potência (x) (float)
      - Linha 3: grupo de cada ponto (int)
    
    Retorna uma tupla (antes_data, depois_data), onde cada um é um array numpy de shape (3, N).
    """
    with open(file, 'r') as f:
        # Lê todas as linhas e remove as vazias
        lines = [line.strip() for line in f.readlines() if line.strip() != '']
    
    # Verifica se há linhas suficientes: esperamos 1 (cabeçalho) + 3 (dados) para cada seção = 8 linhas
    if len(lines) < 8:
        raise ValueError(f"O arquivo {os.path.basename(file)} não possui linhas suficientes para duas seções.")
    
    # Primeira seção ("antes"):
    # Linha 0: cabeçalho (ex: "pontos_fatorDePotencia_PES") - pode ser ignorado
    # Linhas 1 a 3: dados
    antes = []
    for line in lines[1:4]:
        partes = [p.strip() for p in line.split(',') if p.strip() != '']
        antes.append(partes)
    
    # Segunda seção ("depois"):
    # Linha 4: cabeçalho (ex: "pontos_fatorDePotencia_PES_dep") - pode ser ignorado
    # Linhas 5 a 7: dados
    depois = []
    for line in lines[5:8]:
        partes = [p.strip() for p in line.split(',') if p.strip() != '']
        depois.append(partes)
    
    # Verifica se todas as linhas de cada seção possuem o mesmo número de colunas
    n_cols_antes = len(antes[0])
    for i, row in enumerate(antes):
        if len(row) != n_cols_antes:
            raise ValueError(f"Número de colunas inconsistentes na seção 'antes' (linha {i+2}) do arquivo {os.path.basename(file)}.")
    
    n_cols_depois = len(depois[0])
    for i, row in enumerate(depois):
        if len(row) != n_cols_depois:
            raise ValueError(f"Número de colunas inconsistentes na seção 'depois' (linha {i+6}) do arquivo {os.path.basename(file)}.")
    
    try:
        antes_data = np.vstack([
            np.array(antes[0], dtype=float),   # y
            np.array(antes[1], dtype=float),   # x
            np.array(antes[2], dtype=int)        # grupo
        ])
        depois_data = np.vstack([
            np.array(depois[0], dtype=float),   # y
            np.array(depois[1], dtype=float),   # x
            np.array(depois[2], dtype=int)        # grupo
        ])
    except Exception as e:
        raise ValueError(f"Erro ao converter os dados do arquivo {os.path.basename(file)}: {e}")
    
    return antes_data, depois_data


# def load_pfCurves_forPlot2(folder_path="plot/GenOfCases/pfCurve/IEEE9_MARCELO"):
#     """
#     Procura na pasta folder_path por arquivos CSV contendo os pontos.
#     Cada arquivo deve conter duas seções:
#       - Seção 1: pontos "antes" (pontos_fatorDePotencia_PES)
#       - Seção 2: pontos "depois" (pontos_fatorDePotencia_PES_dep)
      
#     Cada seção possui um cabeçalho seguido de 3 linhas de dados:
#       - Linha 1: Fator de potência (y)
#       - Linha 2: Potência (x)
#       - Linha 3: Grupo (para identificar os pontos na legenda)
    
#     Se houver mais de um arquivo, os pontos de cada seção serão concatenados
#     e plotados juntos num único gráfico.
#     """
#     # Busca todos os arquivos CSV na pasta
#     file_list = glob.glob(os.path.join(folder_path, "*.csv"))
#     if len(file_list) == 0:
#         print(f"Nenhum arquivo CSV encontrado em: {folder_path}")
#         return

#     antes_list = []  # Lista para armazenar os arrays dos pontos "antes"
#     depois_list = [] # Lista para armazenar os arrays dos pontos "depois"

#     for file in file_list:
#         try:
#             antes_data, depois_data = read_csv_two_sections(file)
#             antes_list.append(antes_data)
#             depois_list.append(depois_data)
#         except Exception as e:
#             print(f"Erro ao ler o arquivo {os.path.basename(file)}: {e}")
#             continue

#     if not antes_list or not depois_list:
#         print("Dados insuficientes. Verifique se há arquivos com as duas seções ('antes' e 'depois').")
#         return

#     try:
#         # Concatena os arrays horizontalmente: cada coluna é um ponto
#         antes_data_total = np.hstack(antes_list)   # shape: (3, total_de_pontos)
#         depois_data_total = np.hstack(depois_list)
#     except Exception as e:
#         print("Erro ao concatenar os dados dos arquivos:", e)
#         return

#     try:
#         # Extrai as linhas correspondentes a cada informação
#         # "antes": linha 0 -> y, linha 1 -> x, linha 2 -> grupo
#         ml_y      = antes_data_total[0, :].astype(float)
#         ml_x      = antes_data_total[1, :].astype(float)
#         ml_groups = antes_data_total[2, :].astype(int)
        
#         # "depois": linha 0 -> y, linha 1 -> x, linha 2 -> grupo
#         mdl_y      = depois_data_total[0, :].astype(float)
#         mdl_x      = depois_data_total[1, :].astype(float)
#         mdl_groups = depois_data_total[2, :].astype(int)
#     except Exception as e:
#         print("Erro ao converter os dados para os tipos esperados:", e)
#         return

#     if not (ml_x.shape == ml_y.shape == ml_groups.shape and 
#             mdl_x.shape == mdl_y.shape == mdl_groups.shape):
#         print("As matrizes dos pontos 'antes' e 'depois' não possuem as mesmas dimensões.")
#         return

#     # Cria o gráfico
#     plt.figure(figsize=(8, 6))
#     unique_groups = np.unique(ml_groups)
#     extra_cmap = plt.get_cmap("Set2")

#     for g in unique_groups:
#         indices = np.where(ml_groups == g)[0]
#         color_extra = extra_cmap(int(g) % extra_cmap.N)
#         plt.scatter(ml_x[indices], ml_y[indices],
#                     color=color_extra, s=120, marker='o',
#                     label=f"Antes - Grupo {g}")
#         plt.scatter(mdl_x[indices], mdl_y[indices],
#                     color=color_extra, s=120, marker='s',
#                     label=f"Depois - Grupo {g}")
#         # Conecta cada par de pontos (antes e depois) com uma linha preta
#         for idx in indices:
#             plt.plot([ml_x[idx], mdl_x[idx]], [ml_y[idx], mdl_y[idx]], color='k', linestyle='-')

#     plt.xlabel("Potência das Cargas (p.u.)")
#     plt.ylabel("Fator de Potência")
#     plt.title("Fator de Potência vs Potência das Cargas (Somente Pontos)")
#     plt.grid(True)
#     plt.legend()
#     plt.show()




















# import os
# import csv
# import glob
# import numpy as np
# import matplotlib.pyplot as plt
# from matplotlib.widgets import Cursor
# from mpl_toolkits.mplot3d import Axes3D

# def read_csv_with_metadata(filepath):
#     """
#     Lê um arquivo CSV estruturado com metadados e duas seções de pontos.

#     Retorna:
#     - Metadados como um dicionário
#     - pontos_fatorDePotencia_PES (lista de 3 listas)
#     - pontos_fatorDePotencia_PES_dep (lista de 3 listas)
#     - vet_name (lista de nomes dos pontos)
#     """
#     with open(filepath, mode='r') as csvfile:
#         reader = csv.reader(csvfile)
#         metadados = {}
#         pontos_fatorDePotencia_PES = []
#         pontos_fatorDePotencia_PES_dep = []
#         vet_name = []
#         section = None

#         for row in reader:
#             if not row:
#                 continue

#             if row[0] == "Metadados":
#                 section = "metadata"
#                 continue
#             elif row[0] == "pontos_fatorDePotencia_PES":
#                 section = "pes"
#                 continue
#             elif row[0] == "pontos_fatorDePotencia_PES_dep":
#                 section = "pes_dep"
#                 continue

#             if section == "metadata":
#                 key, value = row[0], row[1]
#                 if key == "forFilter":
#                     metadados[key] = list(map(int, value.split(',')))
#                 elif key == "vet_name":
#                     vet_name = value.split(',')
#                 elif key == "vet_TagDoInicial":
#                     metadados[key] = value.split(',')
#                 elif key in ["fpInicial", "PotPInicial"]:
#                     metadados[key] = float(value)
#                 else:
#                     metadados[key] = value
#             elif section == "pes":
#                 pontos_fatorDePotencia_PES.append(list(map(float, row)))
#             elif section == "pes_dep":
#                 pontos_fatorDePotencia_PES_dep.append(list(map(float, row)))

#     return metadados, pontos_fatorDePotencia_PES, pontos_fatorDePotencia_PES_dep, vet_name

# def load_pfCurves_forPlot2(folder_path="plot/GenOfCases/pfCurve/IEEE9_MARCELO"):
#     """
#     Lê os arquivos CSV na pasta especificada e plota os pontos antes e depois, adicionando interatividade.
#     """
#     file_list = glob.glob(os.path.join(folder_path, "*.csv"))
#     if len(file_list) == 0:
#         print(f"Nenhum arquivo CSV encontrado em: {folder_path}")
#         return

#     antes_list = []
#     depois_list = []
#     vet_names_list = []
#     metadados_list = []

#     for file in file_list:
#         try:
#             metadados, antes_data, depois_data, vet_name = read_csv_with_metadata(file)
#             antes_list.append(antes_data)
#             depois_list.append(depois_data)
#             vet_names_list.append(vet_name)
#             metadados_list.append(metadados)
#         except Exception as e:
#             print(f"Erro ao ler o arquivo {os.path.basename(file)}: {e}")
#             continue

#     if not antes_list or not depois_list:
#         print("Dados insuficientes para plotagem.")
#         return

#     # Concatenar os dados
#     antes_data_total = np.hstack(antes_list)
#     depois_data_total = np.hstack(depois_list)
#     vet_names_total = sum(vet_names_list, [])  # Junta todas as listas de nomes

#     # Extrair coordenadas dos pontos
#     ml_y, ml_x, ml_groups = antes_data_total
#     mdl_y, mdl_x, mdl_groups = depois_data_total

#     # Criar gráfico interativo
#     fig, ax = plt.subplots(figsize=(10, 7))
#     unique_groups = np.unique(ml_groups)
#     cmap = plt.get_cmap("Set2")

#     # Plotando pontos "antes" e "depois" com linhas conectando
#     for g in unique_groups:
#         indices = np.where(ml_groups == g)[0]
#         color = cmap(int(g) % cmap.N)

#         # Plot antes
#         ax.scatter(ml_x[indices], ml_y[indices], color=color, s=100, marker='o', label=f"Antes - Grupo {int(g)}")

#         # Plot depois
#         scatter = ax.scatter(mdl_x[indices], mdl_y[indices], color=color, s=100, marker='s', label=f"Depois - Grupo {int(g)}")

#         # Adicionar interatividade para vet_name
#         annot = ax.annotate("", xy=(0,0), xytext=(15,15), textcoords="offset points",
#                             bbox=dict(boxstyle="round", fc="w"), arrowprops=dict(arrowstyle="->"))
#         annot.set_visible(False)

#         def update_annot(ind):
#             index = ind["ind"][0]
#             pos = scatter.get_offsets()[index]
#             annot.xy = pos
#             annot.set_text(vet_names_total[index])
#             annot.get_bbox_patch().set_alpha(0.9)

#         def hover(event):
#             vis = annot.get_visible()
#             if event.inaxes == ax:
#                 cont, ind = scatter.contains(event)
#                 if cont:
#                     update_annot(ind)
#                     annot.set_visible(True)
#                     fig.canvas.draw_idle()
#                 else:
#                     if vis:
#                         annot.set_visible(False)
#                         fig.canvas.draw_idle()

#         fig.canvas.mpl_connect("motion_notify_event", hover)

#         # Conectar os pares de pontos com uma linha
#         for idx in indices:
#             ax.plot([ml_x[idx], mdl_x[idx]], [ml_y[idx], mdl_y[idx]], color='k', linestyle='-')

#     # Plotar ponto inicial
#     for metadados in metadados_list:
#         fpInicial = metadados.get("fpInicial", None)
#         PotPInicial = metadados.get("PotPInicial", None)
#         vet_TagDoInicial = metadados.get("vet_TagDoInicial", [])

#         if fpInicial is not None and PotPInicial is not None:
#             star = ax.scatter(PotPInicial, fpInicial, color='black', s=150, marker='*', label="Ponto Inicial")

#             if vet_TagDoInicial:
#                 annot_star = ax.annotate("", xy=(0,0), xytext=(15,15), textcoords="offset points",
#                                          bbox=dict(boxstyle="round", fc="w"), arrowprops=dict(arrowstyle="->"))
#                 annot_star.set_visible(False)

#                 def update_annot_star(event):
#                     if event.inaxes == ax:
#                         cont, _ = star.contains(event)
#                         if cont:
#                             annot_star.xy = (PotPInicial, fpInicial)
#                             annot_star.set_text(", ".join(vet_TagDoInicial))
#                             annot_star.set_visible(True)
#                             fig.canvas.draw_idle()
#                         else:
#                             annot_star.set_visible(False)
#                             fig.canvas.draw_idle()

#                 fig.canvas.mpl_connect("motion_notify_event", update_annot_star)

#     # Configuração do gráfico
#     ax.set_xlabel("Potência das Cargas (p.u.)")
#     ax.set_ylabel("Fator de Potência")
#     ax.set_title("Fator de Potência vs Potência das Cargas")
#     ax.grid(True)
#     ax.legend()
#     plt.show()
























# import os
# import csv
# import glob
# import numpy as np
# import matplotlib.pyplot as plt

# def read_csv_with_metadata(filepath):
#     """
#     Lê um arquivo CSV estruturado com metadados e duas seções de pontos.

#     Retorna:
#     - Metadados como um dicionário
#     - pontos_fatorDePotencia_PES (lista de 3 listas)
#     - pontos_fatorDePotencia_PES_dep (lista de 3 listas)
#     - vet_name (lista de nomes dos pontos)
#     """
#     with open(filepath, mode='r') as csvfile:
#         reader = csv.reader(csvfile)
#         metadados = {}
#         pontos_fatorDePotencia_PES = []
#         pontos_fatorDePotencia_PES_dep = []
#         vet_name = []
#         section = None

#         for row in reader:
#             if not row:
#                 continue

#             if row[0] == "Metadados":
#                 section = "metadata"
#                 continue
#             elif row[0] == "pontos_fatorDePotencia_PES":
#                 section = "pes"
#                 continue
#             elif row[0] == "pontos_fatorDePotencia_PES_dep":
#                 section = "pes_dep"
#                 continue

#             if section == "metadata":
#                 key, value = row[0], row[1]
#                 if key == "forFilter":
#                     metadados[key] = list(map(int, value.split(',')))
#                 elif key == "vet_name":
#                     vet_name = value.split(',')
#                 elif key == "vet_TagDoInicial":
#                     metadados[key] = value.split(',')
#                 elif key in ["fpInicial", "PotPInicial"]:
#                     metadados[key] = float(value)
#                 else:
#                     metadados[key] = value
#             elif section == "pes":
#                 pontos_fatorDePotencia_PES.append(list(map(float, row)))
#             elif section == "pes_dep":
#                 pontos_fatorDePotencia_PES_dep.append(list(map(float, row)))

#     return metadados, pontos_fatorDePotencia_PES, pontos_fatorDePotencia_PES_dep, vet_name

# def load_pfCurves_forPlot2(folder_path="plot/GenOfCases/pfCurve/IEEE9_MARCELO"):
#     """
#     Lê os arquivos CSV na pasta especificada e plota os pontos antes e depois, adicionando interatividade.
#     """
#     file_list = glob.glob(os.path.join(folder_path, "*.csv"))
#     if len(file_list) == 0:
#         print(f"Nenhum arquivo CSV encontrado em: {folder_path}")
#         return

#     antes_list = []
#     depois_list = []
#     vet_names_list = []
#     metadados_list = []

#     for file in file_list:
#         try:
#             metadados, antes_data, depois_data, vet_name = read_csv_with_metadata(file)
#             antes_list.append(antes_data)
#             depois_list.append(depois_data)
#             vet_names_list.append(vet_name)
#             metadados_list.append(metadados)
#         except Exception as e:
#             print(f"Erro ao ler o arquivo {os.path.basename(file)}: {e}")
#             continue

#     if not antes_list or not depois_list:
#         print("Dados insuficientes para plotagem.")
#         return

#     # Concatenar os dados
#     antes_data_total = np.hstack(antes_list)
#     depois_data_total = np.hstack(depois_list)
#     vet_names_total = sum(vet_names_list, [])  # Junta todas as listas de nomes

#     # Extrair coordenadas dos pontos
#     ml_y, ml_x, ml_groups = antes_data_total
#     mdl_y, mdl_x, mdl_groups = depois_data_total

#     fig, ax = plt.subplots(figsize=(10, 7))
#     unique_groups = np.unique(ml_groups)
#     cmap = plt.get_cmap("Set2")

#     # Criar dicionário para armazenar os scatters (para tooltips)
#     scatters = {}

#     for g in unique_groups:
#         indices = np.where(ml_groups == g)[0]
#         color = cmap(int(g) % cmap.N)

#         # Plot antes
#         ax.scatter(ml_x[indices], ml_y[indices], color=color, s=100, marker='o', label=f"Antes - Grupo {int(g)}")

#         # Plot depois
#         scatter = ax.scatter(mdl_x[indices], mdl_y[indices], color=color, s=100, marker='s', label=f"Depois - Grupo {int(g)}")

#         # Armazena scatter com índice correto para tooltips
#         scatters[scatter] = indices

#         # Conectar os pares de pontos com uma linha
#         for idx in indices:
#             ax.plot([ml_x[idx], mdl_x[idx]], [ml_y[idx], mdl_y[idx]], color='k', linestyle='-')

#     # Tooltip para os nomes dos pontos depois
#     annot = ax.annotate("", xy=(0,0), xytext=(15,15), textcoords="offset points",
#                         bbox=dict(boxstyle="round", fc="w"), arrowprops=dict(arrowstyle="->"))
#     annot.set_visible(False)

#     def update_annot(event):
#         vis = annot.get_visible()
#         for scatter, indices in scatters.items():
#             cont, ind = scatter.contains(event)
#             if cont:
#                 index = indices[ind["ind"][0]]  # Pega o índice correto do vet_name
#                 pos = scatter.get_offsets()[ind["ind"][0]]
#                 annot.xy = pos
#                 annot.set_text(vet_names_total[index])
#                 annot.get_bbox_patch().set_alpha(0.9)
#                 annot.set_visible(True)
#                 fig.canvas.draw_idle()
#                 return
#         if vis:
#             annot.set_visible(False)
#             fig.canvas.draw_idle()

#     fig.canvas.mpl_connect("motion_notify_event", update_annot)

#     # Plotar ponto inicial
#     for metadados in metadados_list:
#         fpInicial = metadados.get("fpInicial", None)
#         PotPInicial = metadados.get("PotPInicial", None)
#         vet_TagDoInicial = metadados.get("vet_TagDoInicial", [])

#         if fpInicial is not None and PotPInicial is not None:
#             star = ax.scatter(PotPInicial, fpInicial, color='black', s=150, marker='*', label="Ponto Inicial")

#             if vet_TagDoInicial:
#                 annot_star = ax.annotate("", xy=(0,0), xytext=(15,15), textcoords="offset points",
#                                          bbox=dict(boxstyle="round", fc="w"), arrowprops=dict(arrowstyle="->"))
#                 annot_star.set_visible(False)

#                 def update_annot_star(event):
#                     cont, _ = star.contains(event)
#                     if cont:
#                         annot_star.xy = (PotPInicial, fpInicial)
#                         annot_star.set_text(", ".join(vet_TagDoInicial))
#                         annot_star.set_visible(True)
#                         fig.canvas.draw_idle()
#                     else:
#                         annot_star.set_visible(False)
#                         fig.canvas.draw_idle()

#                 fig.canvas.mpl_connect("motion_notify_event", update_annot_star)

#     ax.set_xlabel("Potência das Cargas (p.u.)")
#     ax.set_ylabel("Fator de Potência")
#     ax.set_title("Fator de Potência vs Potência das Cargas")
#     ax.grid(True)
#     ax.legend()
#     plt.show()











import os
import csv
import glob
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import CheckButtons

def read_csv_with_metadata(filepath):
    """
    Lê um arquivo CSV estruturado com metadados e duas seções de pontos.

    Retorna:
    - Metadados como um dicionário
    - pontos_fatorDePotencia_PES (lista de 3 listas)
    - pontos_fatorDePotencia_PES_dep (lista de 3 listas)
    - vet_name (lista de nomes dos pontos)
    """
    with open(filepath, mode='r') as csvfile:
        reader = csv.reader(csvfile)
        metadados = {}
        pontos_fatorDePotencia_PES = []
        pontos_fatorDePotencia_PES_dep = []
        vet_name = []
        section = None

        for row in reader:
            if not row:
                continue

            if row[0] == "Metadados":
                section = "metadata"
                continue
            elif row[0] == "pontos_fatorDePotencia_PES":
                section = "pes"
                continue
            elif row[0] == "pontos_fatorDePotencia_PES_dep":
                section = "pes_dep"
                continue

            if section == "metadata":
                key, value = row[0], row[1]
                if key == "forFilter":
                    metadados[key] = list(map(int, value.split(',')))
                elif key == "vet_name":
                    vet_name = value.split(',')
                elif key == "vet_TagDoInicial":
                    metadados[key] = value.split(',')
                elif key in ["fpInicial", "PotPInicial"]:
                    metadados[key] = float(value)
                else:
                    metadados[key] = value
            elif section == "pes":
                pontos_fatorDePotencia_PES.append(list(map(float, row)))
            elif section == "pes_dep":
                pontos_fatorDePotencia_PES_dep.append(list(map(float, row)))

    return metadados, pontos_fatorDePotencia_PES, pontos_fatorDePotencia_PES_dep, vet_name

def load_pfCurves_forPlot2(folder_path="plot/GenOfCases/pfCurve/IEEE9_MARCELO"):
    """
    Lê os arquivos CSV na pasta especificada e plota os pontos antes e depois, adicionando interatividade.
    Permite filtrar a visualização por grupo de pontos.
    """
    file_list = glob.glob(os.path.join(folder_path, "*.csv"))
    if len(file_list) == 0:
        print(f"Nenhum arquivo CSV encontrado em: {folder_path}")
        return

    antes_list = []
    depois_list = []
    vet_names_list = []
    metadados_list = []

    for file in file_list:
        try:
            metadados, antes_data, depois_data, vet_name = read_csv_with_metadata(file)
            antes_list.append(antes_data)
            depois_list.append(depois_data)
            vet_names_list.append(vet_name)
            metadados_list.append(metadados)
        except Exception as e:
            print(f"Erro ao ler o arquivo {os.path.basename(file)}: {e}")
            continue

    if not antes_list or not depois_list:
        print("Dados insuficientes para plotagem.")
        return

    # Concatenar os dados
    antes_data_total = np.hstack(antes_list)
    depois_data_total = np.hstack(depois_list)
    vet_names_total = sum(vet_names_list, [])  # Junta todas as listas de nomes

    # Extrair coordenadas dos pontos
    ml_y, ml_x, ml_groups = antes_data_total
    mdl_y, mdl_x, mdl_groups = depois_data_total

    # Identificar grupos únicos
    unique_groups = np.unique(ml_groups)
    selected_groups = {g: True for g in unique_groups}  # Todos os grupos visíveis por padrão

    # Criar figura e eixos
    fig, ax = plt.subplots(figsize=(10, 7))
    plt.subplots_adjust(right=0.75)  # Ajuste para acomodar os botões de filtro
    cmap = plt.get_cmap("Set2")

    # Criar dicionário para armazenar os scatters (para tooltips)
    scatters = {}

    def plot_data():
        """Função para desenhar os pontos filtrados"""
        ax.clear()
        for g in unique_groups:
            if not selected_groups[g]:
                continue  # Ignorar grupos não selecionados

            indices = np.where(ml_groups == g)[0]
            color = cmap(int(g) % cmap.N)

            # Plot antes
            ax.scatter(ml_x[indices], ml_y[indices], color=color, s=100, marker='o', label=f"Antes - Grupo {int(g)}")

            # Plot depois
            scatter = ax.scatter(mdl_x[indices], mdl_y[indices], color=color, s=100, marker='s', label=f"Depois - Grupo {int(g)}")

            # Armazena scatter com índice correto para tooltips
            scatters[scatter] = indices

            # Conectar os pares de pontos com uma linha
            for idx in indices:
                ax.plot([ml_x[idx], mdl_x[idx]], [ml_y[idx], mdl_y[idx]], color='k', linestyle='-')

        # Plotar ponto inicial
        for metadados in metadados_list:
            fpInicial = metadados.get("fpInicial", None)
            PotPInicial = metadados.get("PotPInicial", None)
            vet_TagDoInicial = metadados.get("vet_TagDoInicial", [])

            if fpInicial is not None and PotPInicial is not None:
                star = ax.scatter(PotPInicial, fpInicial, color='black', s=150, marker='*', label="Ponto Inicial")

                if vet_TagDoInicial:
                    ax.annotate(", ".join(vet_TagDoInicial), xy=(PotPInicial, fpInicial),
                                xytext=(10,10), textcoords="offset points",
                                bbox=dict(boxstyle="round", fc="white"), arrowprops=dict(arrowstyle="->"))

        ax.set_xlabel("Potência das Cargas (p.u.)")
        ax.set_ylabel("Fator de Potência")
        ax.set_title("Fator de Potência vs Potência das Cargas")
        ax.grid(True)
        ax.legend()
        plt.draw()

    plot_data()

    # Criar checkboxes para seleção de grupos no lado direito
    ax_check = plt.axes([0.8, 0.2, 0.15, 0.6])  # Área ajustada para botões
    labels = [f"Grupo {int(g)}" for g in unique_groups]
    visibility = [selected_groups[g] for g in unique_groups]
    check = CheckButtons(ax_check, labels, visibility)

    def update_group_visibility(label):
        """Callback para atualizar a visualização ao alterar os filtros"""
        group_number = int(label.split("Grupo ")[1])
        selected_groups[group_number] = not selected_groups[group_number]
        plot_data()

    check.on_clicked(update_group_visibility)

    # Criar tooltip para os pontos
    annot = ax.annotate("", xy=(0,0), xytext=(15,15), textcoords="offset points",
                        bbox=dict(boxstyle="round", fc="w"), arrowprops=dict(arrowstyle="->"))
    annot.set_visible(False)

    def update_annot(event):
        for scatter, indices in scatters.items():
            cont, ind = scatter.contains(event)
            if cont:
                index = indices[ind["ind"][0]]
                pos = scatter.get_offsets()[ind["ind"][0]]
                annot.xy = pos
                try:
                    annot.set_text(vet_names_total[index])
                except:
                    annot.set_text('')
                annot.set_visible(True)
                fig.canvas.draw_idle()
                return
        annot.set_visible(False)
        fig.canvas.draw_idle()

    fig.canvas.mpl_connect("motion_notify_event", update_annot)

    plt.show()










































def encontrar_hifen_e_indice(matriz):
    """
    Procura pelo primeiro '-' na primeira linha da matriz e retorna
    o índice e um sinal positivo quando encontrado.
    
    :param matriz: Lista de listas (matriz) com duas linhas.
    :return: Uma tupla com o sinal positivo (+1) e o índice, ou None se não encontrar.
    """
    primeira_linha = matriz[0]
    for indice, valor in enumerate(primeira_linha):
        if valor == '-':
            return +1, indice  # Retorna sinal positivo e índice encontrado
    return None  # Retorna None se '-' não for encontrado



def eliminar_colunas_correspondentes(matriz_resposta, indices):
    """
    Verifica se algum valor de indices corresponde a um valor na primeira linha da matriz_resposta
    e, se encontrar, elimina a coluna correspondente.

    Args:
        matriz_resposta (numpy.ndarray): Matriz de dados (de onde as colunas serão removidas).
        indices (list): Lista de índices a serem verificados contra a primeira linha da matriz.

    Returns:
        numpy.ndarray: Matriz modificada com as colunas removidas.
    """
    # Extraímos a primeira linha da matriz_resposta
    primeira_linha = matriz_resposta[0]

    # Identificando as colunas que serão removidas
    colunas_para_remover = []
    for i, valor in enumerate(primeira_linha):
        if valor in indices:
            colunas_para_remover.append(i)

    # Removendo as colunas encontradas, começando da última para a primeira para evitar o deslocamento
    matriz_modificada = np.delete(matriz_resposta, colunas_para_remover, axis=1)

    return matriz_modificada


def monitorar_vetor_percentual(vetor_percentual, limite_variacao=100):
    """
    Monitora o vetor_percentual em busca de valores que ultrapassem o limite de variação.

    Args:
        vetor_percentual (list): Vetor de variações percentuais a ser monitorado.
        limite_variacao (float): O limite máximo de variação permitido. O padrão é 100%.

    Returns:
        list: Lista com os índices onde o limite de variação foi ultrapassado.
    """
    indices_ultrapassados = []

    for i, valor in enumerate(vetor_percentual):
        if abs(valor) > limite_variacao:
            indices_ultrapassados.append(i)

    return indices_ultrapassados


def ajustar_sensibilidade(vetor_sensibilidade, matriz_y, pot_q, DeltaQ_anterior):
    """
    Substitui os valores zero em vetor_sensibilidade pelos valores ajustados
    com base em PotQ e MatrizY (usando o módulo da parte imaginária).

    Args:
        vetor_sensibilidade (list of float): Vetor de sensibilidade atual.
        matriz_y (list of list of complex): MatrizY contendo valores complexos.
        pot_q (list of float): Vetor PotQ com os valores de potência.

    Returns:
        list of float: Vetor ajustado (Vetor_Sensibilidade2).
    """
    vetor_sensibilidade2 = vetor_sensibilidade.copy()

    for n in range(1, len(vetor_sensibilidade)):  # Pula o primeiro elemento
        if vetor_sensibilidade[n] == 0:
            # Obtém o valor da diagonal da MatrizY correspondente
            y_nn = matriz_y[n][n]
            
            # Usa o módulo da parte imaginária da diagonal
            y_nn_imag_mod = abs(y_nn.imag)
            
            # Garante que o valor da raiz seja positivo
            ajustado = (abs(pot_q[n]) * y_nn_imag_mod) ** 0.5
            ajustado_anterior=(abs(DeltaQ_anterior[n]) * y_nn_imag_mod) ** 0.5
            calc=np.abs((ajustado - ajustado_anterior) / (ajustado_anterior))*100
            print(ajustado)
            print(ajustado_anterior)
            print(calc)
            #print('aqui')
            # Substitui no vetor de sensibilidade ajustado
            vetor_sensibilidade2[n] = calc
    
    return vetor_sensibilidade2



def calcular_sensibilidadeDeQ(potq_atual, potq_anterior=None):
    """
    Calcula o vetor de sensibilidade percentual entre dois vetores consecutivos.
    
    Args:
        potq_atual (list of float): Vetor no instante atual.
        potq_anterior (list of float, optional): Vetor no instante anterior.
    
    Returns:
        list of float: Vetor de sensibilidade percentual.
    """
    if potq_anterior is None:
        # Caso inicial: sem vetor anterior, a sensibilidade é 0.
        return [0.0] * len(potq_atual)
    
    # Garantir que os dois vetores tenham o mesmo tamanho
    if len(potq_atual) != len(potq_anterior):
        raise ValueError("Os vetores devem ter o mesmo tamanho.")
    
    # Calcula a sensibilidade
    sensibilidade = []
    for atual, anterior in zip(potq_atual, potq_anterior):
        if anterior == 0:
            sensibilidade.append(float('inf') if atual != 0 else 0.0)  # Evita divisão por zero
        else:
            variacao = ((atual - anterior) / anterior) *100
            sensibilidade.append(variacao)
    
    return sensibilidade  

###############

# Função de sensibilidade
def calcula_sensibilidade(DeltaV_anterior, DeltaV_atual):
    """Calcula o vetor de sensibilidade percentual entre dois vetores DeltaV."""
    DeltaV_anterior = np.array(DeltaV_anterior)
    DeltaV_atual = np.array(DeltaV_atual)
    return np.abs((DeltaV_atual - DeltaV_anterior) / (DeltaV_anterior))*100
    

def extrair_potencias_negativas(matrizSystem):
    # Extração da coluna 9 (índice zero é 8) e ajuste para valores negativos apenas se não forem zeros
    potencias_ajustadas = [-abs(linha[9]) if linha[9] != 0 else 0 for linha in matrizSystem]
    return potencias_ajustadas

# def extrair_vetores_da_matrizSystem(matrizSystem):
#     # Inicialização dos vetores
#     PVbarIndex = []
#     TENSAO_ESPEC = []
#     QIndex = []
#     REATIVA_ESPEC = []
#     GIndex = []
#     GERADOR = []
#     MinMaxIndex = []
#     Qmin = []
#     Qmax = []

#     # Iteração sobre a matrizSystem
#     for idx, linha in enumerate(matrizSystem):
#         # Coluna 14 (zero_index é 13): PVbarIndex e TENSAO_ESPEC
#         if linha[14] != 0:
#             PVbarIndex.append(idx)
#             TENSAO_ESPEC.append(linha[14])

#         # Coluna 10 (zero_index é 9): QIndex e REATIVA_ESPEC
#         if linha[10] != 0:
#             QIndex.append(idx)
#             REATIVA_ESPEC.append(-abs(linha[10]))  # Tornar valores negativos

#         # Coluna 11 (zero_index é 10): GIndex e GERADOR
#         if linha[11] != 0:
#             GIndex.append(idx)
#             GERADOR.append(linha[11])

#         # Colunas 15 e 16 (zero_index é 14 e 15): MinMaxIndex, Qmin, Qmax
#         if linha[16] != 0 or linha[15] != 0:
#             MinMaxIndex.append(idx)
#             Qmax.append(linha[15])
#             Qmin.append(linha[16])
        
#         # PVbarIndex_n=[]
#         # for auxiliar_retiraPrimeiroElemento in range(len(PVbarIndex)):
#         #     if (auxiliar_retiraPrimeiroElemento==0 and PVbarIndex[0]==0):
#         #         print('\n')
#         #     else: 
#         #         PVbarIndex_n.append(PVbarIndex) 

#         # PVbarIndex=PVbarIndex_n                           

#     return PVbarIndex, TENSAO_ESPEC, QIndex, REATIVA_ESPEC, GIndex, GERADOR, MinMaxIndex, Qmin, Qmax


def ranking_sensibilidade(Vetor_Sensibilidade, peso):
    # Encontrar os índices dos elementos não nulos
    indices_nao_nulos = np.nonzero(Vetor_Sensibilidade)[0]
    valores_nao_nulos = Vetor_Sensibilidade[indices_nao_nulos]
    
    # Ordenar índices em ordem decrescente dos valores de sensibilidade
    indices_ordenados = indices_nao_nulos[np.argsort(-valores_nao_nulos)]
    
    # Construir a matriz de resposta
    num_elementos = len(indices_ordenados)
    matriz_resposta = np.zeros((2, num_elementos))
    
    # Primeira linha: índices ordenados (inteiros)
    matriz_resposta[0] = indices_ordenados
    
    # Segunda linha: pesos decrescentes
    for i in range(num_elementos):
        matriz_resposta[1, i] = peso / (2 ** i)
    
    # Converter explicitamente a primeira linha para inteiros
    matriz_resposta[0] = matriz_resposta[0].astype(int)
    
    return matriz_resposta

def atualizar_ativa_espec(ATIVA_ESPEC, matriz_resposta, PassoEstudo):
    # Copiar o vetor ATIVA_ESPEC para não alterar o original
    ATIVA_ESPEC_atualizado = ATIVA_ESPEC.copy()
    
    # Primeira linha da matriz_resposta (índices a serem modificados)
    indices_matriz = matriz_resposta[0].astype(int)
    
    # Segunda linha da matriz_resposta (valores a serem somados)
    valores_matriz = matriz_resposta[1]
    
    # Atualizar os valores de ATIVA_ESPEC
    for idx, valor in zip(indices_matriz, valores_matriz):
        if 0 <= idx < len(ATIVA_ESPEC_atualizado):
            ATIVA_ESPEC_atualizado[idx] += (valor)/ PassoEstudo

    return ATIVA_ESPEC_atualizado


def criar_matriz_resposta_pu(Vetor_Sensibilidade):
    # Encontrar os índices dos elementos não nulos (não igual a zero)
    indices_nao_nulos = np.where(Vetor_Sensibilidade != 0)[0]
    
    # Se não houver valores não nulos, retornar uma matriz vazia
    if len(indices_nao_nulos) == 0:
        return np.array([[], []])  # Retorna uma matriz vazia
    
    # Obter os valores não nulos
    valores_nao_nulos = Vetor_Sensibilidade[indices_nao_nulos]
    
    # Ordenar os índices em ordem decrescente com base nos valores de sensibilidade
    indices_ordenados = indices_nao_nulos[np.argsort(-valores_nao_nulos)]
    
    # Encontrar o maior valor para calcular o valor em p.u. (se não for vazio)
    max_valor = np.max(valores_nao_nulos)
    
    # Calcular os valores em p.u. (dividindo cada valor pelo maior valor)
    valores_pu = valores_nao_nulos[np.argsort(-valores_nao_nulos)] / max_valor
    
    # Montar a matriz de resposta
    matriz_resposta = np.vstack([indices_ordenados, valores_pu])
    
    return matriz_resposta

def comparar_e_calcular_diferencas(ATIVA_ESPEC, ATIVA_ESPEC0):
    # Verificar se os vetores têm o mesmo tamanho
    if len(ATIVA_ESPEC) != len(ATIVA_ESPEC0):
        raise ValueError("Os vetores devem ter o mesmo tamanho para comparação")
    
    # Calcular a diferença elemento a elemento
    vetor_resposta = np.array(ATIVA_ESPEC) - np.array(ATIVA_ESPEC0)
    
    # Calcular a soma das diferenças
    soma_diferencas = np.sum(vetor_resposta)
    
    # Calcular a diferença percentual (evitar divisão por zero)
    vetor_percentual = []
    for i in range(len(ATIVA_ESPEC)):
        if ATIVA_ESPEC0[i] != 0:  # Evitar divisão por zero
            percentual = (vetor_resposta[i] / ATIVA_ESPEC0[i]) * 100
        else:
            percentual = 0  # Se o valor inicial for 0, não há variação percentual
        vetor_percentual.append(round(percentual))  # Arredonda para o inteiro mais próximo
    
    # Exibir resultados
    print("Vetor de diferenças:", vetor_resposta)
    print("Soma das diferenças:", soma_diferencas)
    print("Vetor de diferenças percentuais (%):", [f"{p}%" for p in vetor_percentual])
    
    return vetor_resposta, soma_diferencas, vetor_percentual



def buscar_indices_zeros(potp, gindex, minmaxindex):
    """
    Busca índices de valores iguais a zero no vetor PotP, ignorando os índices
    especificados em GIndex e MinMaxIndex.
    
    :param potp: Lista de valores de potência ativa (PotP).
    :param gindex: Lista de índices a serem ignorados.
    :param minmaxindex: Lista de índices adicionais a serem ignorados.
    :return: Lista com os índices dos valores iguais a zero que atendem às condições.
    """
    # Combina os índices a serem ignorados
    ignorar_indices = set(gindex + minmaxindex)
    # Busca os índices que atendem às condições
    return [i for i, valor in enumerate(potp) if valor == 0 and i not in ignorar_indices]


def buscar_indice(vetor, valor):
    """
    Busca o índice de um determinado valor no vetor.
    
    :param vetor: Lista de valores.
    :param valor: Valor a ser procurado.
    :return: Índice do valor encontrado ou -1 se não encontrado.
    """
    try:
        return vetor.index(valor)  # Retorna o índice do valor
    except ValueError:
        return -1  # Retorna -1 se o valor não for encontrado


def buscar_mid_indices(matriz):
    """
    Busca por linhas onde a coluna 3 (zero_index) contém o valor 'MID'
    e retorna os índices dessas linhas.
    
    :param matriz: Matriz de dados (lista de listas).
    :return: Lista de índices das linhas onde a coluna 3 contém 'MID'.
    """
    Eliminar_MID = []  # Lista para armazenar os índices encontrados
    for i, linha in enumerate(matriz):
        if linha[3] == 'MID':  # Verifica se a coluna 3 contém 'MID'
            Eliminar_MID.append(i)  # Salva o índice da linha
    return Eliminar_MID


def BuscaPassagaem (matriz):
    """
    Retorna uma lista com os índices das linhas que satisfazem as condições:
    - Coluna 9 (índice 8) diferente de 0.
    - Coluna 3 (índice 2) diferente de 'MID'.
    - Coluna 14 (índice 13) igual a 0.
    
    Args:
        matriz (list): Matriz de entrada (lista de listas).
    
    Returns:
        list: Lista de índices das linhas que atendem aos critérios.
    """
    BarraPassagem = []
    
    for i, linha in enumerate(matriz):
        if (
            linha[9] == (0) and     # Valor na coluna 9 igual de 0
            linha[3] != 'MID' and # Valor na coluna 3 diferente de 'MID'
            linha[14] == 0        # Valor na coluna 14 igual a 0
        ):
            BarraPassagem.append(i)
    
    return BarraPassagem


def indice_maior_valor_coluna9(matriz):
    """
    Retorna o índice da linha com o maior valor na coluna 9 (índice 8) da matriz.
    
    Args:
        matriz (list): Matriz de entrada (lista de listas).
    
    Returns:
        int: Índice da linha com o maior valor na coluna 9.
    """
    maior_valor = float('-inf')  # Inicializa com o menor valor possível
    indice_maior = -1            # Inicializa com um índice inválido
    
    for i, linha in enumerate(matriz):
        if linha[9] > maior_valor:  # Verifica se o valor atual é maior que o maior encontrado
            maior_valor = linha[9]
            indice_maior = i
    
    return indice_maior











def corrigir_resultado_melhorado(resultado, ATIVA_ESPEC, REGIME_de_CARGA, tipo_BARRA_de_ESTUDO):
    """
    Preenche com zeros os vetores da tupla resultado para igualar ao tamanho especificado.

    Args:
        resultado (tuple): Tupla contendo os índices e dois vetores (`leve` e `pesada`).
        tamanho_final (int): Tamanho desejado para os vetores corrigidos.

    Returns:
        tuple: Tupla corrigida com vetores de tamanho igual ao especificado.
    """
    ATIVA_ESPEC0=[0]*len(ATIVA_ESPEC)
    for auxiliar in range(len(ATIVA_ESPEC)):
        if  auxiliar!=0:
            ATIVA_ESPEC0[auxiliar]=ATIVA_ESPEC[auxiliar]
    # ATIVA_ESPEC00=ATIVA_ESPEC
    # ATIVA_ESPEC000=ATIVA_ESPEC
    # if ATIVA_ESPEC[0]!=0:
    #     ATIVA_ESPEC[0]==0

    tamanho_final = len(ATIVA_ESPEC)
    if (REGIME_de_CARGA=='ambos'):
        if (tipo_BARRA_de_ESTUDO=='PQ' or tipo_BARRA_de_ESTUDO=='PQPV'):    
            indices, leve, pesada = resultado
            
            # Criar vetores corrigidos com zeros
            indices_corrigidos = list(range(tamanho_final))
            # leve_corrigido = ATIVA_ESPEC0
            # pesada_corrigido = ATIVA_ESPEC00
            # print(ATIVA_ESPEC0)
            # print('ATIVA_ESPEC=', ATIVA_ESPEC00)
            # print('indices=', indices) 
            # print('leve=', leve) 
            # print('pesada=', pesada)   

            # Preencher posições com os valores do resultado original
            # for i, idx in enumerate(indices):
            #     leve_corrigido[idx] = leve[i]
            #     pesada_corrigido[idx] = pesada[i]
            # Inicializando os vetores corrigidos com os valores originais de ATIVA_ESPEC
            
            leve_corrigido = ATIVA_ESPEC0[:]
            pesada_corrigido = ATIVA_ESPEC0[:]

            # Preenchendo o vetor leve_corrigido
            for i in range(len(indices)):
                idx = indices[i]
                leve_corrigido[idx] = leve[i]

            # Preenchendo o vetor pesada_corrigido
            for i in range(len(indices)):
                idx = indices[i]
                pesada_corrigido[idx] = pesada[i]

            # print(ATIVA_ESPEC0)
            # print(ATIVA_ESPEC00)
            # print(leve_corrigido) 
            # print(pesada_corrigido)    
            # exit()
            return indices_corrigidos, leve_corrigido, pesada_corrigido
        
        if (tipo_BARRA_de_ESTUDO=='PQPVfacultativo'):     
            indices, leve, pesada, indicesPQ, levePQ, pesadaPQ = resultado
            
            # Criar vetores corrigidos com zeros
            indices_corrigidos = list(range(tamanho_final))
            #leve_corrigido = ATIVA_ESPEC
            #pesada_corrigido = ATIVA_ESPEC
            #levePQ_corrigido = ATIVA_ESPEC
            #pesadaPQ_corrigido = ATIVA_ESPEC


            leve_corrigido = ATIVA_ESPEC0[:]
            pesada_corrigido = ATIVA_ESPEC0[:]

            # Preenchendo o vetor leve_corrigido
            for i in range(len(indices)):
                idx = indices[i]
                leve_corrigido[idx] = leve[i]

            # Preenchendo o vetor pesada_corrigido
            for i in range(len(indices)):
                idx = indices[i]
                pesada_corrigido[idx] = pesada[i]


            levePQ_corrigido = ATIVA_ESPEC0[:]
            pesadaPQ_corrigido = ATIVA_ESPEC0[:]

            # Preenchendo o vetor leve_corrigido
            for i in range(len(indicesPQ)):
                idx = indicesPQ[i]
                levePQ_corrigido[idx] = levePQ[i]

            # Preenchendo o vetor pesada_corrigido
            for i in range(len(indicesPQ)):
                idx = indicesPQ[i]
                pesadaPQ_corrigido[idx] = pesadaPQ[i]            

            return indices_corrigidos, leve_corrigido, pesada_corrigido, indices_corrigidos, levePQ_corrigido, pesadaPQ_corrigido
     
    if (REGIME_de_CARGA=='leve'):
        if (tipo_BARRA_de_ESTUDO=='PQ' or tipo_BARRA_de_ESTUDO=='PQPV'):    
            indices, leve = resultado
            
            # Criar vetores corrigidos com zeros
            indices_corrigidos = list(range(tamanho_final))
            leve_corrigido = ATIVA_ESPEC0
            #pesada_corrigido = [0] * tamanho_final

            # Preencher posições com os valores do resultado original
            for i, idx in enumerate(indices):
                leve_corrigido[idx] = leve[i]
                #pesada_corrigido[idx] = pesada[i]

            return indices_corrigidos, leve_corrigido 
        
        if (tipo_BARRA_de_ESTUDO=='PQPVfacultativo'):
            indices, leve, indicesPQ, levePQ = resultado
            
            # Criar vetores corrigidos com zeros
            indices_corrigidos = list(range(tamanho_final))
            # leve_corrigido =ATIVA_ESPEC
            # #pesada_corrigido = [0] * tamanho_final
            # levePQ_corrigido = ATIVA_ESPEC
            #pesadaPQ_corrigido = [0] * tamanho_final


            # # Preencher posições com os valores do resultado original
            # for i, idx in enumerate(indices):
            #     leve_corrigido[idx] = leve[i]
            #     #pesada_corrigido[idx] = pesada[i]

            # # Preencher posições com os valores do resultado original
            # for i, idx in enumerate(indicesPQ):
            #     levePQ_corrigido[idx] = levePQ[i]
            #     #pesadaPQ_corrigido[idx] = pesadaPQ[i]
            leve_corrigido = ATIVA_ESPEC0[:]
            levePQ_corrigido = ATIVA_ESPEC0[:]

            # Preenchendo o vetor leve_corrigido
            for i in range(len(indices)):
                idx = indices[i]
                leve_corrigido[idx] = leve[i]

            # Preenchendo o vetor leve_corrigido
            for i in range(len(indicesPQ)):
                idx = indicesPQ[i]
                levePQ_corrigido[idx] = levePQ[i]       

            return indices_corrigidos, leve_corrigido, indices_corrigidos, levePQ_corrigido   
    
    if (REGIME_de_CARGA=='pesada'):
        if (tipo_BARRA_de_ESTUDO=='PQ' or tipo_BARRA_de_ESTUDO=='PQPV'):  
            indices, pesada = resultado
            
            # Criar vetores corrigidos com zeros
            indices_corrigidos = list(range(tamanho_final))
            #leve_corrigido = [0] * tamanho_final
            pesada_corrigido = ATIVA_ESPEC

            # Preencher posições com os valores do resultado original
            for i, idx in enumerate(indices):
                #leve_corrigido[idx] = leve[i]
                pesada_corrigido[idx] = pesada[i]

            return indices_corrigidos, pesada_corrigido
        
        if (tipo_BARRA_de_ESTUDO=='PQPVfacultativo'):
            indices, pesada, indicesPQ, pesadaPQ = resultado
        
            # Criar vetores corrigidos com zeros
            indices_corrigidos = list(range(tamanho_final))
            #leve_corrigido = [0] * tamanho_final
            # pesada_corrigido = ATIVA_ESPEC
            # #levePQ_corrigido = [0] * tamanho_final
            # pesadaPQ_corrigido = ATIVA_ESPEC


            # # Preencher posições com os valores do resultado original
            # for i, idx in enumerate(indices):
            #     #leve_corrigido[idx] = leve[i]
            #     pesada_corrigido[idx] = pesada[i]

            # # Preencher posições com os valores do resultado original
            # for i, idx in enumerate(indicesPQ):
            #     #levePQ_corrigido[idx] = levePQ[i]
            #     pesadaPQ_corrigido[idx] = pesadaPQ[i]

            pesada_corrigido = ATIVA_ESPEC[:]

            # Preenchendo o vetor pesada_corrigido
            for i in range(len(indices)):
                idx = indices[i]
                pesada_corrigido[idx] = pesada[i]

            pesadaPQ_corrigido = ATIVA_ESPEC[:]

            # Preenchendo o vetor pesada_corrigido
            for i in range(len(indicesPQ)):
                idx = indicesPQ[i]
                pesadaPQ_corrigido[idx] = pesadaPQ[i]                      

            return indices_corrigidos, pesada_corrigido, indices_corrigidos, pesadaPQ_corrigido           
 


def corrigir_resultado(resultado, tamanho_final, REGIME_de_CARGA, tipo_BARRA_de_ESTUDO):
    """
    Preenche com zeros os vetores da tupla resultado para igualar ao tamanho especificado.

    Args:
        resultado (tuple): Tupla contendo os índices e dois vetores (`leve` e `pesada`).
        tamanho_final (int): Tamanho desejado para os vetores corrigidos.

    Returns:
        tuple: Tupla corrigida com vetores de tamanho igual ao especificado.
    """
    if (REGIME_de_CARGA=='ambos'):
        if (tipo_BARRA_de_ESTUDO=='PQ' or tipo_BARRA_de_ESTUDO=='PQPV'):    
            indices, leve, pesada = resultado
            
            # Criar vetores corrigidos com zeros
            indices_corrigidos = list(range(tamanho_final))
            leve_corrigido = [0] * tamanho_final
            pesada_corrigido = [0] * tamanho_final

            # Preencher posições com os valores do resultado original
            for i, idx in enumerate(indices):
                leve_corrigido[idx] = leve[i]
                pesada_corrigido[idx] = pesada[i]

            return indices_corrigidos, leve_corrigido, pesada_corrigido
        
        if (tipo_BARRA_de_ESTUDO=='PQPVfacultativo'):     
            indices, leve, pesada, indicesPQ, levePQ, pesadaPQ = resultado
            
            # Criar vetores corrigidos com zeros
            indices_corrigidos = list(range(tamanho_final))
            leve_corrigido = [0] * tamanho_final
            pesada_corrigido = [0] * tamanho_final
            levePQ_corrigido = [0] * tamanho_final
            pesadaPQ_corrigido = [0] * tamanho_final


            # Preencher posições com os valores do resultado original
            for i, idx in enumerate(indices):
                leve_corrigido[idx] = leve[i]
                pesada_corrigido[idx] = pesada[i]

            # Preencher posições com os valores do resultado original
            for i, idx in enumerate(indicesPQ):
                levePQ_corrigido[idx] = levePQ[i]
                pesadaPQ_corrigido[idx] = pesadaPQ[i]            

            return indices_corrigidos, leve_corrigido, pesada_corrigido, indices_corrigidos, levePQ_corrigido, pesadaPQ_corrigido
     
    if (REGIME_de_CARGA=='leve'):
        if (tipo_BARRA_de_ESTUDO=='PQ' or tipo_BARRA_de_ESTUDO=='PQPV'):    
            indices, leve = resultado
            
            # Criar vetores corrigidos com zeros
            indices_corrigidos = list(range(tamanho_final))
            leve_corrigido = [0] * tamanho_final
            #pesada_corrigido = [0] * tamanho_final

            # Preencher posições com os valores do resultado original
            for i, idx in enumerate(indices):
                leve_corrigido[idx] = leve[i]
                #pesada_corrigido[idx] = pesada[i]

            return indices_corrigidos, leve_corrigido 
        
        if (tipo_BARRA_de_ESTUDO=='PQPVfacultativo'):
            indices, leve, indicesPQ, levePQ = resultado
            
            # Criar vetores corrigidos com zeros
            indices_corrigidos = list(range(tamanho_final))
            leve_corrigido = [0] * tamanho_final
            #pesada_corrigido = [0] * tamanho_final
            levePQ_corrigido = [0] * tamanho_final
            #pesadaPQ_corrigido = [0] * tamanho_final


            # Preencher posições com os valores do resultado original
            for i, idx in enumerate(indices):
                leve_corrigido[idx] = leve[i]
                #pesada_corrigido[idx] = pesada[i]

            # Preencher posições com os valores do resultado original
            for i, idx in enumerate(indicesPQ):
                levePQ_corrigido[idx] = levePQ[i]
                #pesadaPQ_corrigido[idx] = pesadaPQ[i]            

            return indices_corrigidos, leve_corrigido, indices_corrigidos, levePQ_corrigido   
    
    if (REGIME_de_CARGA=='pesada'):
        if (tipo_BARRA_de_ESTUDO=='PQ' or tipo_BARRA_de_ESTUDO=='PQPV'):  
            indices, leve = resultado
            
            # Criar vetores corrigidos com zeros
            indices_corrigidos = list(range(tamanho_final))
            #leve_corrigido = [0] * tamanho_final
            pesada_corrigido = [0] * tamanho_final

            # Preencher posições com os valores do resultado original
            for i, idx in enumerate(indices):
                #leve_corrigido[idx] = leve[i]
                pesada_corrigido[idx] = pesada[i]

            return indices_corrigidos, pesada_corrigido
        
        if (tipo_BARRA_de_ESTUDO=='PQPVfacultativo'):
            indices, pesada, indicesPQ, pesadaPQ = resultado
        
            # Criar vetores corrigidos com zeros
            indices_corrigidos = list(range(tamanho_final))
            #leve_corrigido = [0] * tamanho_final
            pesada_corrigido = [0] * tamanho_final
            #levePQ_corrigido = [0] * tamanho_final
            pesadaPQ_corrigido = [0] * tamanho_final


            # Preencher posições com os valores do resultado original
            for i, idx in enumerate(indices):
                #leve_corrigido[idx] = leve[i]
                pesada_corrigido[idx] = pesada[i]

            # Preencher posições com os valores do resultado original
            for i, idx in enumerate(indicesPQ):
                #levePQ_corrigido[idx] = levePQ[i]
                pesadaPQ_corrigido[idx] = pesadaPQ[i]            

            return indices_corrigidos, pesada_corrigido, indices_corrigidos, pesadaPQ_corrigido           
 

def extrair_vetores_da_matrizSystem(matrizSystem):
    # Inicialização dos vetores
    PVbarIndex = []
    TENSAO_ESPEC = []
    QIndex = []
    REATIVA_ESPEC = []
    GIndex = []
    GERADOR = []
    MinMaxIndex = []
    Qmin = []
    Qmax = []

    # Iteração sobre a matrizSystem
    for idx, linha in enumerate(matrizSystem):
        # Coluna 14 (zero_index é 13): PVbarIndex e TENSAO_ESPEC
        if linha[14] != 0:
            PVbarIndex.append(idx)
            TENSAO_ESPEC.append(linha[14])

        # Coluna 10 (zero_index é 9): QIndex e REATIVA_ESPEC
        if linha[10] != 0:
            QIndex.append(idx)
            REATIVA_ESPEC.append(-abs(linha[10]))  # Tornar valores negativos

        # Coluna 11 (zero_index é 10): GIndex e GERADOR
        if linha[11] != 0:
            GIndex.append(idx)
            GERADOR.append(linha[11])

        # Colunas 15 e 16 (zero_index é 14 e 15): MinMaxIndex, Qmin, Qmax
        if linha[16] != 0 or linha[15] != 0:
            MinMaxIndex.append(idx)
            Qmax.append(linha[15])
            Qmin.append(linha[16])

    return PVbarIndex, TENSAO_ESPEC, QIndex, REATIVA_ESPEC, GIndex, GERADOR, MinMaxIndex, Qmin, Qmax

def extrair_potencias_negativas(matrizSystem):
    # Extração da coluna 9 (índice zero é 8) e ajuste para valores negativos apenas se não forem zeros
    potencias_ajustadas = [-abs(linha[9]) if linha[9] != 0 else 0 for linha in matrizSystem]
    return potencias_ajustadas


def criar_vetores_carga(ATIVA_ESPEC, eliminar_se_NAO_tem_CARGA, limite_variacao, REGIME_de_CARGA, tipo_BARRA_de_ESTUDO, PVbarIndex):
    """
    Cria e retorna vetores de carga com base nas condições especificadas, incluindo a filtragem para o tipo de barra de estudo.

    Args:
        ATIVA_ESPEC (list): Lista de cargas ativas especificadas.
        eliminar_se_NAO_tem_CARGA (str): Se 'yes', ignora os valores zero em ATIVA_ESPEC.
        limite_variacao (float): Percentual de variação aplicado aos valores negativos.
        REGIME_de_CARGA (str): Define o regime de carga ('leve', 'pesada', ou 'ambos').
        tipo_BARRA_de_ESTUDO (str): Pode ser 'PQ', 'PQPV' ou 'PQPVfacultativo'.
        PVbarIndex (list): Lista de índices das barras PV.

    Returns:
        tuple: Vetores dependendo das condições de entrada.
    """
    indices_filtrados = []

    # Filtragem inicial de ATIVA_ESPEC
    if eliminar_se_NAO_tem_CARGA == 'yes':
        ATIVA_ESPEC_filtrado = [valor for i, valor in enumerate(ATIVA_ESPEC) if valor != 0]
        indices_filtrados = [i for i, valor in enumerate(ATIVA_ESPEC) if valor != 0]
    else:
        ATIVA_ESPEC_filtrado = ATIVA_ESPEC[1:]  # Ignora apenas o primeiro elemento
        indices_filtrados = list(range(1, len(ATIVA_ESPEC)))

    #for auxiliar_filtragem_0 in range(len(ATIVA_ESPEC_filtrado)):
    indices_filtrados = [x for x in indices_filtrados if x != 0]
        
    valores_sem_zero=[]
    for auxiliar_filtragem_0 in range(len(ATIVA_ESPEC_filtrado)):
        if ATIVA_ESPEC_filtrado[auxiliar_filtragem_0]!=0:
            valores_sem_zero.append(float(ATIVA_ESPEC_filtrado[auxiliar_filtragem_0]))       

    ATIVA_ESPEC_filtrado=valores_sem_zero
    
    # Cálculo de variações
    ATIVA_ESPEC_leve = []
    ATIVA_ESPEC_pesada = []
    
    for valor in ATIVA_ESPEC_filtrado:
        if valor < 0:
            variacao = abs(valor) * (limite_variacao / 100)
            ATIVA_ESPEC_leve.append(valor + variacao)
            ATIVA_ESPEC_pesada.append(valor - variacao)
        else:
            ATIVA_ESPEC_leve.append(valor)
            ATIVA_ESPEC_pesada.append(valor)

    # Processamento adicional para tipo_BARRA_de_ESTUDO = 'PQ'
    if tipo_BARRA_de_ESTUDO == 'PQ':
        indices_filtradosPQ = [i for i in indices_filtrados if i not in PVbarIndex]
        PQ_ATIVA_ESPEC_leve = [ATIVA_ESPEC[i] + (abs(ATIVA_ESPEC[i]) * (limite_variacao / 100)) if ATIVA_ESPEC[i] < 0 else ATIVA_ESPEC[i] for i in indices_filtradosPQ]
        PQ_ATIVA_ESPEC_pesada = [ATIVA_ESPEC[i] - (abs(ATIVA_ESPEC[i]) * (limite_variacao / 100)) if ATIVA_ESPEC[i] < 0 else ATIVA_ESPEC[i] for i in indices_filtradosPQ]

        if REGIME_de_CARGA == 'leve':
            return indices_filtradosPQ, PQ_ATIVA_ESPEC_leve
        elif REGIME_de_CARGA == 'pesada':
            return indices_filtradosPQ, PQ_ATIVA_ESPEC_pesada
        elif REGIME_de_CARGA == 'ambos':
            return indices_filtradosPQ, PQ_ATIVA_ESPEC_leve, PQ_ATIVA_ESPEC_pesada

    # Retorno para 'PQPV' 
    if tipo_BARRA_de_ESTUDO == 'PQPV':
        if REGIME_de_CARGA == 'leve':
            return indices_filtrados, ATIVA_ESPEC_leve
        elif REGIME_de_CARGA == 'pesada':
            return indices_filtrados, ATIVA_ESPEC_pesada
        elif REGIME_de_CARGA == 'ambos':
            return indices_filtrados, ATIVA_ESPEC_leve, ATIVA_ESPEC_pesada
        
    # Retorno para 'PQPVfacultativo'
    if tipo_BARRA_de_ESTUDO == 'PQPVfacultativo':
        indices_filtradosPQ = [i for i in indices_filtrados if i not in PVbarIndex]
        PQ_ATIVA_ESPEC_leve = [ATIVA_ESPEC[i] + (abs(ATIVA_ESPEC[i]) * (limite_variacao / 100)) if ATIVA_ESPEC[i] < 0 else ATIVA_ESPEC[i] for i in indices_filtradosPQ]
        PQ_ATIVA_ESPEC_pesada = [ATIVA_ESPEC[i] - (abs(ATIVA_ESPEC[i]) * (limite_variacao / 100)) if ATIVA_ESPEC[i] < 0 else ATIVA_ESPEC[i] for i in indices_filtradosPQ]
    
        if REGIME_de_CARGA == 'leve':
            return indices_filtrados, ATIVA_ESPEC_leve, indices_filtradosPQ, PQ_ATIVA_ESPEC_leve
        elif REGIME_de_CARGA == 'pesada':
            return indices_filtrados, ATIVA_ESPEC_pesada, indices_filtradosPQ, PQ_ATIVA_ESPEC_pesada
        elif REGIME_de_CARGA == 'ambos':
            return indices_filtrados, ATIVA_ESPEC_leve, ATIVA_ESPEC_pesada, indices_filtradosPQ, PQ_ATIVA_ESPEC_leve, PQ_ATIVA_ESPEC_pesada    


# def criar_vetores_carga2(ATIVA_ESPEC, eliminar_se_NAO_tem_CARGA, limite_variacao, REGIME_de_CARGA, tipo_BARRA_de_ESTUDO, PVbarIndex):
#     """
#     Cria e retorna vetores de carga com base nas condições especificadas, incluindo a filtragem para o tipo de barra de estudo.

#     Args:
#         ATIVA_ESPEC (list): Lista de cargas ativas especificadas.
#         eliminar_se_NAO_tem_CARGA (str): Se 'yes', ignora os valores zero em ATIVA_ESPEC.
#         limite_variacao (float): Percentual de variação aplicado aos valores negativos.
#         REGIME_de_CARGA (str): Define o regime de carga ('leve', 'pesada', ou 'ambos').
#         tipo_BARRA_de_ESTUDO (str): Pode ser 'PQ', 'PQPV' ou 'PQPVfacultativo'.
#         PVbarIndex (list): Lista de índices das barras PV.

#     Returns:
#         tuple: Vetores dependendo das condições de entrada.
#     """
#     indices_filtrados = []

#     # Filtragem inicial de ATIVA_ESPEC
#     if eliminar_se_NAO_tem_CARGA == 'yes':
#         ATIVA_ESPEC_filtrado = [valor for i, valor in enumerate(ATIVA_ESPEC) if valor != 0]
#         indices_filtrados = [i for i, valor in enumerate(ATIVA_ESPEC) if valor != 0]
#     else:
#         ATIVA_ESPEC_filtrado = ATIVA_ESPEC[1:]  # Ignora apenas o primeiro elemento
#         indices_filtrados = list(range(1, len(ATIVA_ESPEC)))

#     #for auxiliar_filtragem_0 in range(len(ATIVA_ESPEC_filtrado)):
#     indices_filtrados = [x for x in indices_filtrados if x != 0]
        
#     valores_sem_zero=[]
#     for auxiliar_filtragem_0 in range(len(ATIVA_ESPEC_filtrado)):
#         if ATIVA_ESPEC_filtrado[auxiliar_filtragem_0]!=0:
#             valores_sem_zero.append(float(ATIVA_ESPEC_filtrado[auxiliar_filtragem_0]))       

#     ATIVA_ESPEC_filtrado=valores_sem_zero
    
#     # Cálculo de variações
#     ATIVA_ESPEC_leve = []
#     ATIVA_ESPEC_pesada = []
    
#     for valor in ATIVA_ESPEC_filtrado:
#         if valor < 0:
#             variacao = abs(valor) * (limite_variacao / 100)
#             ATIVA_ESPEC_leve.append(valor + variacao)
#             ATIVA_ESPEC_pesada.append(valor - variacao)
#         else:
#             ATIVA_ESPEC_leve.append(valor)
#             ATIVA_ESPEC_pesada.append(valor)

#     # Processamento adicional para tipo_BARRA_de_ESTUDO = 'PQ'
#     if tipo_BARRA_de_ESTUDO == 'PQ':
#         indices_filtradosPQ = [i for i in indices_filtrados if i not in PVbarIndex]
#         PQ_ATIVA_ESPEC_leve = [ATIVA_ESPEC[i] + (abs(ATIVA_ESPEC[i]) * (limite_variacao / 100)) if ATIVA_ESPEC[i] < 0 else ATIVA_ESPEC[i] for i in indices_filtradosPQ]
#         PQ_ATIVA_ESPEC_pesada = [ATIVA_ESPEC[i] - (abs(ATIVA_ESPEC[i]) * (limite_variacao / 100)) if ATIVA_ESPEC[i] < 0 else ATIVA_ESPEC[i] for i in indices_filtradosPQ]

#         if REGIME_de_CARGA == 'leve':
#             return indices_filtradosPQ, PQ_ATIVA_ESPEC_leve
#         elif REGIME_de_CARGA == 'pesada':
#             return indices_filtradosPQ, PQ_ATIVA_ESPEC_pesada
#         elif REGIME_de_CARGA == 'ambos':
#             return indices_filtradosPQ, PQ_ATIVA_ESPEC_leve, PQ_ATIVA_ESPEC_pesada

#     # Retorno para 'PQPV' 
#     if tipo_BARRA_de_ESTUDO == 'PQPV':
#         if REGIME_de_CARGA == 'leve':
#             return indices_filtrados, ATIVA_ESPEC_leve
#         elif REGIME_de_CARGA == 'pesada':
#             return indices_filtrados, ATIVA_ESPEC_pesada
#         elif REGIME_de_CARGA == 'ambos':
#             return indices_filtrados, ATIVA_ESPEC_leve, ATIVA_ESPEC_pesada
        
#     # Retorno para 'PQPVfacultativo'
#     if tipo_BARRA_de_ESTUDO == 'PQPVfacultativo':
#         indices_filtradosPQ = [i for i in indices_filtrados if i not in PVbarIndex]
#         PQ_ATIVA_ESPEC_leve = [ATIVA_ESPEC[i] + (abs(ATIVA_ESPEC[i]) * (limite_variacao / 100)) if ATIVA_ESPEC[i] < 0 else ATIVA_ESPEC[i] for i in indices_filtradosPQ]
#         PQ_ATIVA_ESPEC_pesada = [ATIVA_ESPEC[i] - (abs(ATIVA_ESPEC[i]) * (limite_variacao / 100)) if ATIVA_ESPEC[i] < 0 else ATIVA_ESPEC[i] for i in indices_filtradosPQ]
    
#         if REGIME_de_CARGA == 'leve':
#             return indices_filtrados, ATIVA_ESPEC_leve, indices_filtradosPQ, PQ_ATIVA_ESPEC_leve
#         elif REGIME_de_CARGA == 'pesada':
#             return indices_filtrados, ATIVA_ESPEC_pesada, indices_filtradosPQ, PQ_ATIVA_ESPEC_pesada
#         elif REGIME_de_CARGA == 'ambos':
#             return indices_filtrados, ATIVA_ESPEC_leve, ATIVA_ESPEC_pesada, indices_filtradosPQ, PQ_ATIVA_ESPEC_leve, PQ_ATIVA_ESPEC_pesada    
    


def checar_elementos_nulos(lista):
    """
    Verifica se todos os elementos de uma lista são nulos (iguais a zero).

    Args:
        lista (list): Lista a ser verificada.

    Returns:
        bool: True se todos os elementos forem nulos, False caso contrário.
    """
    return all(elemento == 0 for elemento in lista)

def identificar_indices_e_valores(ATIVA_ESPEC):
    ATIVA_ESPEC_index = []
    ATIVA_ESPEC_reduzida = []

    for i, valor in enumerate(ATIVA_ESPEC):
        if valor != 0:  # Identifica posições não nulas
            ATIVA_ESPEC_index.append(i)  # Armazena o índice
            ATIVA_ESPEC_reduzida.append(valor)  # Armazena o valor

    return ATIVA_ESPEC_index, ATIVA_ESPEC_reduzida



# Função para aplicar o limite de variação
def aplicar_limite_variacao(ATIVA_ESPEC, limite_variacao_percentual):
    limite_variacao = limite_variacao_percentual / 100
    #return [abs(valor) * limite_variacao if abs(valor) > abs(valor) * limite_variacao else valor for valor in ATIVA_ESPEC]
    ATIVA_ESPEC_com_variacao=[0]*len(ATIVA_ESPEC)
    for auxiliar in range(len(ATIVA_ESPEC)):
        ATIVA_ESPEC_com_variacao[auxiliar]=ATIVA_ESPEC[auxiliar]* (1+limite_variacao)
    
    return ATIVA_ESPEC_com_variacao


# Função para substituir índices por valores de ATIVA_ESPEC_index
def substituir_indices_por_ATIVA_ESPEC_index(matrizes_indices, ATIVA_ESPEC_index):
    return [[ATIVA_ESPEC_index[i] if valor == 1 else 0 for i, valor in enumerate(matriz)] for matriz in matrizes_indices]

# Gera combinações de índices
def gerar_combinacoes(indices):
    return chain.from_iterable(combinations(indices, r) for r in range(1, len(indices) + 1))

# Aplica delta e gera matrizes de índices
# def aplicar_delta_e_matriz(vetor, combinacoes, ATIVA_ESPEC_index, delta):
#     resultados_vetores = []
#     resultados_matrizes = []
#     for combinacao in combinacoes:
#         novo_vetor = vetor[:]
#         matriz_indices = [0] * len(vetor)
#         for idx in combinacao:
#             posicao_vetor = ATIVA_ESPEC_index.index(idx)
#             novo_vetor[posicao_vetor] += delta[posicao_vetor]
#             matriz_indices[posicao_vetor] = 1
#         resultados_vetores.append(novo_vetor)
#         resultados_matrizes.append(matriz_indices)
#     return resultados_vetores, resultados_matrizes

# def aplicar_delta_e_matriz(vetor, combinacoes, ATIVA_ESPEC_index, delta):
#     resultados_vetores = []
#     resultados_matrizes = []
    
#     for combinacao in combinacoes:
#         novo_vetor = [0] * len(delta)  # Cria um vetor zerado do tamanho de delta
#         matriz_indices = [0] * len(delta)  # Matriz de índices inicialmente zerada
        
#         for idx in combinacao:
#             posicao_vetor = ATIVA_ESPEC_index.index(idx)  # Localiza a posição do índice no vetor de referência
#             novo_vetor[posicao_vetor] = delta[posicao_vetor]  # Aplica o delta correspondente
#             matriz_indices[posicao_vetor] = 1  # Marca a posição como ativa
        
#         resultados_vetores.append(novo_vetor)
#         resultados_matrizes.append(matriz_indices)
    
#     return resultados_vetores, resultados_matrizes

def aplicar_delta_e_matriz(vetor, combinacoes, ATIVA_ESPEC_index, delta):
    resultados_vetores = []
    resultados_matrizes = []
    
    for combinacao in combinacoes:
        novo_vetor = vetor[:]  # Cria uma cópia do vetor original
        matriz_indices = [0] * len(vetor)  # Inicializa matriz de índices com zeros
        
        for idx in combinacao:
            if idx in ATIVA_ESPEC_index:  # Verifica se o índice está presente em ATIVA_ESPEC_index
                posicao_vetor = ATIVA_ESPEC_index.index(idx)  # Encontra a posição no vetor
                novo_vetor[posicao_vetor] = delta[posicao_vetor]  # Aplica o delta ao vetor original
                matriz_indices[posicao_vetor] = 1  # Marca a posição como ativa
                
        resultados_vetores.append(novo_vetor)
        resultados_matrizes.append(matriz_indices)
    
    return resultados_vetores, resultados_matrizes

# Divide as matrizes em PV, PQ e PQPV
def dividir_matrizes(matrizes, PVbarIndex, ATIVA_ESPEC_index):
    PQbarIndex = [i for i in ATIVA_ESPEC_index if i not in PVbarIndex]
    matrizes_PV, matrizes_PQ, matrizes_PQPV = [], [], []
    for matriz in matrizes:
        elementos_presentes = [ATIVA_ESPEC_index[i] for i, valor in enumerate(matriz) if valor != 0]
        pertence_PV = all(el in PVbarIndex for el in elementos_presentes)
        pertence_PQ = all(el in PQbarIndex for el in elementos_presentes)
        if pertence_PV and not pertence_PQ:
            matrizes_PV.append(matriz)
        elif pertence_PQ and not pertence_PV:
            matrizes_PQ.append(matriz)
        else:
            matrizes_PQPV.append(matriz)
    return matrizes_PV, matrizes_PQ, matrizes_PQPV, PQbarIndex

# Identifica índices e valores não nulos
def identificar_indices_e_valores(ATIVA_ESPEC):
    ATIVA_ESPEC_index = []
    ATIVA_ESPEC_reduzida = []
    for i, valor in enumerate(ATIVA_ESPEC):
        if valor != 0:
            ATIVA_ESPEC_index.append(i)
            ATIVA_ESPEC_reduzida.append(valor)
    return ATIVA_ESPEC_index, ATIVA_ESPEC_reduzida


def verificar_eliminar_zero_e_atualizar(ATIVA_ESPEC_index, ATIVA_ESPEC):
    if 0 not in ATIVA_ESPEC_index:
        return "no", ATIVA_ESPEC_index, ATIVA_ESPEC
    else:
        # Remove o índice 0 e valores correspondentes de ATIVA_ESPEC
        indices_sem_zero = [x for x in ATIVA_ESPEC_index if x != 0]
        
        valores_sem_zero=[]
        for auxiliar in range(len(ATIVA_ESPEC)):
            if auxiliar!=0:
                valores_sem_zero.append(float(ATIVA_ESPEC[auxiliar]))

        return "yes", indices_sem_zero, valores_sem_zero




# def filtrar_linhas_com_elementosPQouPVtotal(matriz, elementos):
#     """
#     Filtra as linhas da matriz que contêm todos os elementos especificados.

#     Args:
#         matriz (list of list of int): A matriz original.
#         elementos (list of int): Elementos a serem encontrados em cada linha.

#     Returns:
#         list of list of int: Linhas que contêm todos os elementos.
#     """
#     linhas_filtradas = []

#     for linha in matriz:
#         # Verifica se todos os elementos estão presentes na linha
#         if all(elem in linha for elem in elementos):
#             linhas_filtradas.append(linha)

#     return linhas_filtradas


def filtrar_linhas_com_elementosPQouPVtotal(matriz, elementos):
    """
    Filtra as linhas da matriz que contêm todos os elementos especificados,
    respeitando a ordem e a presença de elementos não nulos.

    Args:
        matriz (list of list of int): A matriz original.
        elementos (list of int): Elementos a serem encontrados em cada linha.

    Returns:
        list of list of int: Linhas que contêm todos os elementos.
    """
    linhas_filtradas = []

    for linha in matriz:
        # Remove zeros da linha para focar nos elementos relevantes
        linha_sem_zeros = [x for x in linha if x != 0]

        # Verifica se a linha contém todos os elementos necessários, na mesma ordem
        if all(elem in linha_sem_zeros for elem in elementos):
            indices = [linha_sem_zeros.index(elem) for elem in elementos]
            if indices == sorted(indices):  # Checa se estão na mesma ordem relativa
                linhas_filtradas.append(linha)

    return linhas_filtradas


def corrigir_PVbarIndex(PVbarIndex, ATIVA_ESPEC):
    """
    Remove o índice 0 e índices cujos valores correspondentes em ATIVA_ESPEC sejam zeros.

    Args:
        PVbarIndex (list of int): Vetor original de índices.
        ATIVA_ESPEC (list of float): Vetor com valores associados aos índices.

    Returns:
        list of int: Vetor corrigido com índices relevantes.
    """
    PVbarIndex_corrigido = [
        idx for idx in PVbarIndex
        if idx != 0 and ATIVA_ESPEC[idx] != 0
    ]
    return PVbarIndex_corrigido


# def buscar_indices_matrizes(PQtotal_U_PV, Matrizes_PV_025):
#     """
#     Retorna os índices das linhas de PQtotal_U_PV que estão presentes em Matrizes_PV_025.

#     Args:
#         PQtotal_U_PV (list of list of int): Matriz contendo listas de elementos.
#         Matrizes_PV_025 (list of list of int): Matriz onde serão feitas as buscas.

#     Returns:
#         list of int: Lista dos índices das linhas de PQtotal_U_PV presentes em Matrizes_PV_025.
#     """
#     indices_encontrados = []
    
#     for i, linha_PQ in enumerate(PQtotal_U_PV):
#         if linha_PQ in Matrizes_PV_025:
#             indices_encontrados.append(i)
    
#     return indices_encontrados

# def buscar_indices_matrizes(PQtotal_U_PV, Matrizes_PV_025):
#     """
#     Retorna os índices das linhas de PQtotal_U_PV que estão presentes em Matrizes_PV_025.

#     Args:
#         PQtotal_U_PV (list of list of int): Matriz contendo listas de elementos.
#         Matrizes_PV_025 (list of list of int): Matriz onde serão feitas as buscas.

#     Returns:
#         list of int: Lista dos índices das linhas de PQtotal_U_PV presentes em Matrizes_PV_025.
#     """
#     # Converter Matrizes_PV_025 em um conjunto de tuplas para buscas rápidas
#     set_matrizes_PV_025 = {tuple(linha) for linha in Matrizes_PV_025}
    
#     indices_encontrados = []
    
#     for i, linha_PQ in enumerate(PQtotal_U_PV):
#         # Verificar se a tupla da linha de PQtotal_U_PV está no conjunto
#         if tuple(linha_PQ) in set_matrizes_PV_025:
#             indices_encontrados.append(i)
    
#     return indices_encontrados


def buscar_indices_matrizes(PQtotal_U_PV, Matrizes_PV_025):
    """
    Retorna os índices das linhas de PQtotal_U_PV que estão presentes em Matrizes_PV_025.

    Args:
        PQtotal_U_PV (list of list of int): Matriz contendo listas de elementos.
        Matrizes_PV_025 (list of list of int): Matriz onde serão feitas as buscas.

    Returns:
        list of int: Lista dos índices das linhas de PQtotal_U_PV presentes em Matrizes_PV_025.
    """
    # Converter Matrizes_PV_025 em um conjunto de tuplas para buscas rápidas
    set_matrizes_PV_025 = {tuple(linha) for linha in Matrizes_PV_025}
    
    indices_encontrados = []
    
    for i, linha_PQ in enumerate(PQtotal_U_PV):
        # Verificar se a tupla da linha de PQtotal_U_PV está no conjunto
        if tuple(linha_PQ) in set_matrizes_PV_025:
            indices_encontrados.append(i)
    
    return indices_encontrados


def monitorar_candidateviola(candidateviola):
    encontrado_primeira_vez = False

    for i in range(len(candidateviola) - 1):  # Exclui o último elemento
        if candidateviola[i] == 'yes':
            if not encontrado_primeira_vez:
                print("encontrei pela primeira vez")
                encontrado_primeira_vez = True



def arrumadadosDados (matriz,candidate_bloc_anterior):
    elementos = []  # Para armazenar todos os elementos
    indices_doBloco = []    # Para armazenar o índice da linha correspondente
    candidates_vetor = []
    for i, vetor in enumerate(matriz):  # 'i' é o número da linha
        for elemento in vetor:
            elementos.append(elemento)  # Adiciona o elemento ao vetor de elementos
            indices_doBloco.append(i)           # Adiciona o índice da linha correspondente

    
    for bloco in candidate_bloc_anterior:
        for linha in bloco:
            vetor = [elemento for elemento in linha]
            candidates_vetor.append(vetor)


    return elementos, indices_doBloco, candidates_vetor


def extrair_vetores_ObjetoAEstudado(elementos, candidates_vetor):
    """
    Retorna vetores baseados em condições na matriz elementos e candidates_vetor.

    Parâmetros:
    - elementos (list of str): Lista de strings com 'yes' e 'no'.
    - candidates_vetor (list of list): Matriz de vetores de inteiros.

    Retorna:
    - vet_objeto (list of list): Lista de vetores que atendem à condição 'no' seguido de 'yes'.
    - vetor_inicio (list of int): Índices das posições 'no' que iniciam o padrão.
    - vetor_ponta (list of int): Quantidade de 'yes' consecutivos após cada 'no'.
    """
    vet_objeto = []
    vetor_inicio = []
    vetor_ponta = []

    i = 0
    while i < len(elementos) - 1:
        if elementos[i] == "no" and elementos[i + 1] == "yes":
            # Determina o índice do 'no'
            vetor_inicio.append(i)
            
            # Conta o número de 'yes' consecutivos após o 'no'
            yes_count = 0
            j = i + 1
            while j < len(elementos) and elementos[j] == "yes":
                yes_count += 1
                j += 1
            
            vetor_ponta.append(yes_count)
            
            # Adiciona o vetor correspondente de candidates_vetor
            vet_objeto.append(candidates_vetor[i])

        i += 1

    return vet_objeto, vetor_inicio, vetor_ponta


def criar_matriz_de_pontos_testes(candidates_vetor, vetor_inicio, vetor_ponta):
    # Calcula o tamanho da matriz de pontos de teste
    tamanho_matriz = sum(vetor_ponta[:-1])  # Exclui o último elemento de vetor_ponta
    matriz_de_pontos_testes = []
    diferencas = []  # Para armazenar as diferenças encontradas

    indice_matriz = 0

    for i, inicio in enumerate(vetor_inicio[:-1]):  # Ignora o último elemento de vetor_inicio
        referencia = candidates_vetor[inicio]  # Pega o vetor de referência
        quantidade = vetor_ponta[i]  # Quantidade de vetores para análise
        
        for j in range(quantidade):
            indice_atual = inicio + j + 1  # Calcula o índice atual a ser comparado
            vetor_atual = candidates_vetor[indice_atual]  # Pega o vetor atual
            vetor_modificado = vetor_atual[:]  # Cria uma cópia do vetor atual

            # Encontra as diferenças e zera as posições alteradas
            diferenca_atual = []
            for k in range(len(referencia)):
                if referencia[k] != vetor_atual[k]:
                    vetor_modificado[k] = 0
                    diferenca_atual.append(k)

            # Adiciona o vetor modificado e as diferenças
            matriz_de_pontos_testes.append(vetor_modificado)
            diferencas.append(diferenca_atual)

            indice_matriz += 1

    return matriz_de_pontos_testes, diferencas


def identifica_PQambos_valor_que_faz_cair(candidates_vetor, vetor_inicio, vetor_ponta):
    matriz_de_pontos_testes_antes = []
    valores_diferentes = []

    # Somente processar até o penúltimo elemento de vetor_inicio e vetor_ponta
    for i in range(len(vetor_inicio)):
        indice_base = vetor_inicio[i]
        
        # Garantir que o índice base está dentro do intervalo
        if indice_base < 0 or indice_base >= len(candidates_vetor):
            print(f"Índice base fora do intervalo: {indice_base}")
            continue

        vetor_base = candidates_vetor[indice_base]
        quantidade = vetor_ponta[i]
        
        for j in range(1, quantidade + 1):
            indice_comparacao = indice_base + j
            
            # Garantir que o índice de comparação está dentro do intervalo
            if indice_comparacao < 0 or indice_comparacao >= len(candidates_vetor):
                print(f"Índice de comparação fora do intervalo: {indice_comparacao}")
                continue

            vetor_comparacao = candidates_vetor[indice_comparacao]
            
            # Identificar as posições onde os valores mudam
            diferencas = [k for k in range(len(vetor_base)) if vetor_base[k] != vetor_comparacao[k]]
            
            # Criar uma cópia do vetor de comparação e zerar as diferenças
            vetor_modificado = vetor_comparacao[:]
            for k in diferencas:
                vetor_modificado[k] = 0
            
            # Adicionar o vetor modificado e as diferenças às respectivas listas
            matriz_de_pontos_testes_antes.append(vetor_modificado)
            valores_diferentes.append(diferencas)



    matriz_de_pontos_testes_depois = []
    #valores_diferentes = []

    # Processar até o penúltimo elemento de vetor_inicio e vetor_ponta
    for i in range(len(vetor_inicio)):
        indice_base = vetor_inicio[i]
        
        # Garantir que o índice base está dentro do intervalo
        if indice_base < 0 or indice_base >= len(candidates_vetor):
            print(f"Índice base fora do intervalo: {indice_base}")
            continue

        #vetor_base = candidates_vetor[indice_base]
        quantidade = vetor_ponta[i]
        
        for j in range(1, quantidade + 1):
            indice_comparacao = indice_base + j
            
            # Garantir que o índice de comparação está dentro do intervalo
            if indice_comparacao < 0 or indice_comparacao >= len(candidates_vetor):
                print(f"Índice de comparação fora do intervalo: {indice_comparacao}")
                continue

            vetor_comparacao = candidates_vetor[indice_comparacao]
            
            # Identificar as posições onde os valores mudam
            #diferencas = [k for k in range(len(vetor_base)) if vetor_base[k] != vetor_comparacao[k] and vetor_base[k] != 0]
            
            # Criar uma cópia do vetor de comparação e zerar as diferenças
            vetor_modificado = vetor_comparacao[:]
            # for k in diferencas:
            #     vetor_modificado[k] = 0
            
            # Adicionar o vetor modificado e as diferenças às respectivas listas
            matriz_de_pontos_testes_depois.append(vetor_modificado)
            #valores_diferentes.append(diferencas)
    """
    Compara duas matrizes e retorna uma nova matriz contendo os valores que mudaram de uma para outra.

    Parâmetros:
        matriz_antes (list of list of int): A matriz original.
        matriz_depois (list of list of int): A matriz modificada.

    Retorna:
        list of list of int: Uma matriz contendo os valores que mudaram para cada linha.
    """
    # Verifica se as matrizes têm o mesmo tamanho
    if len(matriz_de_pontos_testes_antes) != len(matriz_de_pontos_testes_depois) or any(len(row1) != len(row2) for row1, row2 in zip(matriz_de_pontos_testes_antes, matriz_de_pontos_testes_depois)):
        print("Erro: As matrizes não têm o mesmo tamanho!")
        return None
    
    # Cria a matriz de diferenças
    matriz_diferencas = []
    for linha_antes, linha_depois in zip(matriz_de_pontos_testes_antes, matriz_de_pontos_testes_depois):
        diferencas = [linha_depois[i] for i in range(len(linha_antes)) if linha_antes[i] != linha_depois[i]]
        matriz_diferencas.append(diferencas)




    return matriz_de_pontos_testes_antes, matriz_diferencas



def gerar_vetores_com_variacao(vetor, ATIVA_ESPEC, limite_variacao):
    """
    Gera dois vetores, ATIVA_up e ATIVA_down, com base nos índices não zero do vetor e na lista ATIVA_ESPEC.
    A variação é aplicada de acordo com o limite_variacao para os índices não zero no vetor de entrada.
    As demais posições de ATIVA_ESPEC são mantidas.

    Args:
        vetor (list of int): Vetor de entrada com dados, contendo índices não zero.
        ATIVA_ESPEC (list of float): Lista com os valores a serem variáveis.
        limite_variacao (float): Percentual de variação aplicado para cima e para baixo.

    Returns:
        tuple: (ATIVA_up, ATIVA_down) - Vetores gerados com variação.
    """
    # Converte o vetor e ATIVA_ESPEC para arrays numpy para facilitar as operações
    #vetor = np.array(vetor)
    #ATIVA_ESPEC = np.array(ATIVA_ESPEC)

    # Inicializando os vetores de saída com os valores de ATIVA_ESPEC
    ATIVA_up=[0]*len(ATIVA_ESPEC)
    ATIVA_down=[0]*len(ATIVA_ESPEC)
    for auxiliar in range(len(ATIVA_ESPEC)):
        ATIVA_up[auxiliar]=ATIVA_ESPEC[auxiliar]
        ATIVA_down[auxiliar]= ATIVA_ESPEC[auxiliar]

    # Aplicando variação para cima e para baixo nas posições não zero nos índices do vetor
    for i in range(len(vetor)):  # Itera sobre os índices do vetor
        if vetor[i] != 0:  # Se o valor no vetor original for diferente de 0
            # O valor do índice no vetor é a posição que deve ser alterada em ATIVA_ESPEC
            j = i  # A posição de ATIVA_ESPEC que corresponde ao índice no vetor

            # Calculando a variação para cima e para baixo nas colunas correspondentes de ATIVA_ESPEC
            variacao_up = ATIVA_ESPEC[vetor[i]] * (1 + limite_variacao / 100)
            variacao_down = ATIVA_ESPEC[vetor[i]] * (1 - limite_variacao / 100)

            # Atualizando os vetores apenas nas posições correspondentes
            ATIVA_up[vetor[i]] = variacao_up
            ATIVA_down[vetor[i]] = variacao_down

    return ATIVA_up, ATIVA_down


def encontrar_interseccao_e_diferencas(Lista_de_Candidatos_T2_siOrno, Lista_de_Candidatos_T2_index):
    """
    Encontra o último 'no' na lista 'Lista_de_Candidatos_T2_siOrno', 
    e retorna a interseção entre o vetor do 'no' e o vetor do 'yes' seguinte.
    A interseção mantém as dimensões do vetor e coloca '0' nas posições onde não há interseção.
    Além disso, retorna as diferenças entre o vetor 'yes' e 'no' apenas para os valores do 'yes'.

    Args:
        Lista_de_Candidatos_T2_siOrno (list): Lista contendo os valores 'yes' e 'no'.
        Lista_de_Candidatos_T2_index (list of lists): Lista de listas de índices.

    Returns:
        tuple: (Lista_intersecao, Lista_diferencas) - Interseção e diferenças entre 'yes' e 'no'.
    """
    
    # Encontrar o índice do último 'no'
    ultimo_no_index = -1
    for i in range(len(Lista_de_Candidatos_T2_siOrno) - 1, -1, -1):
        if Lista_de_Candidatos_T2_siOrno[i] == 'no':
            ultimo_no_index = i
            break

    if ultimo_no_index == -1:
        return [], []  # Se não encontrar 'no', retorna listas vazias

    # Encontrar o índice do 'yes' seguinte após o último 'no'
    proximo_yes_index = -1
    for i in range(ultimo_no_index + 1, len(Lista_de_Candidatos_T2_siOrno)):
        if Lista_de_Candidatos_T2_siOrno[i] == 'yes':
            proximo_yes_index = i
            break

    if proximo_yes_index == -1:
        return [], []  # Se não encontrar 'yes' após 'no', retorna listas vazias

    # Pegar os vetores de 'no' e 'yes' encontrados
    no_vector = Lista_de_Candidatos_T2_index[ultimo_no_index]
    yes_vector = Lista_de_Candidatos_T2_index[proximo_yes_index]

    # Interseção entre o vetor 'no' e 'yes'
    Lista_intersecao = []
    for i in range(len(no_vector)):
        # Se o valor está presente em ambos, coloca o valor; caso contrário, coloca 0
        if no_vector[i] in yes_vector:
            Lista_intersecao.append(no_vector[i])
        else:
            Lista_intersecao.append(0)

    # Diferenças entre os vetores 'yes' e 'no', apenas valores do vetor 'yes'
    Lista_diferencas = []
    for i in range(len(yes_vector)):
        # Se o valor de 'yes' não está em 'no', adiciona ele como diferença
        if yes_vector[i] not in no_vector:
            Lista_diferencas.append(yes_vector[i])

    return Lista_intersecao, Lista_diferencas

# # Exemplo de uso:

# Lista_de_Candidatos_T2_index = [
#     [1, 0, 3, 4, 0, 8, 9, 10, 11, 12, 13],
#     [0, 2, 3, 4, 0, 8, 9, 10, 11, 12, 13],
#     [0, 0, 3, 4, 5, 8, 9, 10, 11, 12, 13],
#     [1, 2, 3, 4, 0, 8, 9, 10, 11, 12, 13],
#     [1, 0, 3, 4, 5, 8, 9, 10, 11, 12, 13],
#     [0, 2, 3, 4, 5, 8, 9, 10, 11, 12, 13],
#     [1, 2, 3, 4, 5, 8, 9, 10, 11, 12, 13]
# ]

# Lista_de_Candidatos_T2_siOrno = ['no', 'yes', 'no', 'yes', 'no', 'yes', 'yes']

# # Chama a função
# Lista_intersecao, Lista_diferencas = encontrar_interseccao_e_diferencas(Lista_de_Candidatos_T2_siOrno, Lista_de_Candidatos_T2_index)

# print(f"Interseção: {Lista_intersecao}")
# print(f"Diferenças: {Lista_diferencas}")

""" def comparar_carregamento(D_CARREGAMENTO_PES, ATIVA_ESPEC):
    # Inicializando as matrizes e o vetor de saída
    D_CARREGAMENTO_PES_val = []
    D_CARREGAMENTO_PES_pos = []
    vetor_BarrasAdicionadas = []

    # Percorrendo cada vetor de D_CARREGAMENTO_PES
    for linha in D_CARREGAMENTO_PES:
        val_diff = []  # Armazena as diferenças
        pos_diff = []  # Armazena os índices onde há diferenças

        # Comparando elemento a elemento
        for idx, (d, a) in enumerate(zip(linha, ATIVA_ESPEC)):
            diff = d - a
            if diff != 0:
                val_diff.append(diff)
                pos_diff.append(idx)
            else:
                val_diff.append(0)
                pos_diff.append(0)

        # Adicionando os resultados à matriz de diferenças
        D_CARREGAMENTO_PES_val.append(val_diff)

        # Adicionando os índices de diferenças à matriz de posições
        D_CARREGAMENTO_PES_pos.append(pos_diff)

        # Criando a string de índices concatenados
        barras_adicionadas = "_".join(str(pos) for pos in pos_diff if pos != 0)
        vetor_BarrasAdicionadas.append(barras_adicionadas)

    return D_CARREGAMENTO_PES_val, D_CARREGAMENTO_PES_pos, vetor_BarrasAdicionadas
 """

def comparar_carregamento(D_CARREGAMENTO_PES, ATIVA_ESPEC):
    # Inicializando as matrizes e os vetores de saída
    D_CARREGAMENTO_PES_val = []
    D_CARREGAMENTO_PES_pos = []
    vetor_BarrasAdicionadas = []
    PotP_Adicionada = []
    MatrizPorcentagem = []
    VetorPorcentagem = []

    # Percorrendo cada vetor de D_CARREGAMENTO_PES
    for linha in D_CARREGAMENTO_PES:
        val_diff = []  # Armazena as diferenças
        pos_diff = []  # Armazena os índices onde há diferenças
        porcentagens = []  # Armazena as porcentagens
        soma_pot = 0  # Soma dos valores adicionados
        indices_porcentagens = []  # Índices com porcentagens

        # Comparando elemento a elemento
        for idx, (d, a) in enumerate(zip(linha, ATIVA_ESPEC)):
            diff = d - a
            if diff != 0:
                val_diff.append(diff)
                pos_diff.append(idx)
                soma_pot += diff
                porcentagem = (-1)*(diff / abs(a) * 100) if a != 0 else 100  # Calcula a porcentagem
                porcentagens.append(round(porcentagem))
                indices_porcentagens.append(round(porcentagem))
            else:
                val_diff.append(0)
                pos_diff.append(0)
                porcentagens.append(0)

        for auxiliar_mudaIndexPra1 in range(len(pos_diff)):
            if pos_diff[auxiliar_mudaIndexPra1]!=0:
                pos_diff[auxiliar_mudaIndexPra1]=pos_diff[auxiliar_mudaIndexPra1]+1

        # Adicionando os resultados às estruturas de saída
        D_CARREGAMENTO_PES_val.append(val_diff)
        D_CARREGAMENTO_PES_pos.append(pos_diff)
        MatrizPorcentagem.append(porcentagens)

        # Criando strings para os vetores
        barras_adicionadas = "_".join(str(pos) for pos in pos_diff if pos != 0)
        vetor_BarrasAdicionadas.append(barras_adicionadas)

        porcentagem_str = "_".join(str(por) for por in indices_porcentagens)
        VetorPorcentagem.append(porcentagem_str)

        # Soma dos valores adicionados
        PotP_Adicionada.append(soma_pot)

    return (
        D_CARREGAMENTO_PES_val,
        D_CARREGAMENTO_PES_pos,
        vetor_BarrasAdicionadas,
        PotP_Adicionada,
        MatrizPorcentagem,
        VetorPorcentagem,
    )

def analisa_BqV(D_BqV_PES):
    vetor_posicoes = []

    # Percorrendo cada linha da matriz
    for linha in D_BqV_PES:
        # Encontrar os índices dos valores não nulos
        indices_nao_nulos = [str(idx+1) for idx, valor in enumerate(linha) if valor != 0]

        # for auxiliar_MudaIndexTo1 in range(len(indices_nao_nulos)):
        #     indices_nao_nulos[auxiliar_MudaIndexTo1]=indices_nao_nulos[auxiliar_MudaIndexTo1]+1

        # Concatenar os índices encontrados com '_'
        posicoes_concatenadas = "_".join(indices_nao_nulos)

        # Adicionar ao vetor
        vetor_posicoes.append(posicoes_concatenadas)

    return vetor_posicoes

def geraTAG(D_CARREGAMENTO_PES_pos, PVbarIndex):
    vetorTAG = []
    
    for aux in range(len(PVbarIndex)):
        PVbarIndex[aux]=PVbarIndex[aux]+1

    # Percorrer cada vetor em D_CARREGAMENTO_PES_pos
    for linha in D_CARREGAMENTO_PES_pos:
        # Remover elementos nulos (0)
        elementos_validos = [elem for elem in linha if elem != 0]

        # Verificar condições para classificação
        if all(elem in PVbarIndex for elem in elementos_validos):
            vetorTAG.append("PV")
        elif all(elem not in PVbarIndex for elem in elementos_validos):
            vetorTAG.append("PQ")
        else:
            vetorTAG.append("PQPV")

    return vetorTAG

def corrigir_capturaPontos(elementos):
    if elementos!=[]:
        if elementos[0] != 'yes':
            return []  # Retorna um vetor vazio se o primeiro elemento não for 'yes'
    else:
        return []   

    contador = 0
    for elemento in elementos:
        if elemento == 'yes':
            contador += 1
        elif elemento == 'no':
            break  # Para a contagem ao encontrar o primeiro 'no'

    vetor_ponta_corrigido = [contador]
    return vetor_ponta_corrigido


def detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BqV_T, VsV_T):
    """
    Detecta mudanças entre duas matrizes iniciais e duas matrizes teste.

    :param BarraQViola_estatica_0: Lista inicial de valores para BarraQViola_estatica.
    :param VerificaSeViola_0: Lista inicial de valores para VerificaSeViola_PQPV.
    :param BqV_T: Lista de teste para BarraQViola_estatica.
    :param VsV_T: Lista de teste para VerificaSeViola_PQPV.
    :return: Tuple (True/False, indicador).
    """
    mudanca_BarraQViola = BarraQViola_estatica_0 != BqV_T
    mudanca_VerificaSeViola = VerificaSeViola_0 != VsV_T

    if mudanca_BarraQViola and mudanca_VerificaSeViola:
        return True, 'BqV_VsV'
    elif mudanca_BarraQViola:
        return True, 'BqV'
    elif mudanca_VerificaSeViola:
        return True, 'VsV'
    else:
        return False, None



def processar_intervalos(Minimizar_EspacoAmostral, ATIVA_ESPEC, limita):
    try:
        # Quebrar a string pelos separadores "_"
        intervalos = Minimizar_EspacoAmostral.split("_")

        # Conjunto para armazenar os valores únicos dos intervalos
        valores_unicos = set()

        # Processar cada parte (que pode ser um intervalo ou um valor único)
        for parte in intervalos:
            if '-' in parte:
                # Trata o caso de intervalo (por exemplo, "18-24")
                limites = parte.split("-")
                if len(limites) != 2 or not limites[0].isdigit() or not limites[1].isdigit():
                    raise ValueError(f"Intervalo inválido: {parte}")
                limite_inferior, limite_superior = map(int, limites)

                if limite_inferior < 1 or limite_superior < 1:
                    raise ValueError(f"Os valores devem ser inteiros positivos: {parte}")
                if limite_inferior > limite_superior:
                    raise ValueError(f"Limite inferior maior que limite superior: {parte}")
                if limite_superior > len(ATIVA_ESPEC):
                    raise ValueError(f"Limite superior maior que a quantidade de barras: {parte}")

                # O intervalo é inclusivo: adiciona todos os valores de limite_inferior até limite_superior
                valores_unicos.update(range(limite_inferior, limite_superior + 1))
            else:
                # Trata o caso de um valor único
                if not parte.isdigit():
                    raise ValueError(f"Valor inválido: {parte}")
                valor = int(parte)
                if valor < 1:
                    raise ValueError(f"O valor deve ser inteiro positivo: {parte}")
                if valor > len(ATIVA_ESPEC):
                    raise ValueError(f"Valor maior que a quantidade de barras: {parte}")
                valores_unicos.add(valor)

        # Converter o conjunto em uma lista ordenada
        Barras_a_Estarem_no_Estudo = sorted(valores_unicos)

        # Verificar se a quantidade de valores está entre 1 e 'limita' (inclusive)
        if not (0 < len(Barras_a_Estarem_no_Estudo) <= limita):
            messagebox.showerror("Erro de entrada", f"O campo obrigatório 'Barras Escolhidas' é de tamanho inválido. Por favor, preencha corretamente.")    
            raise ValueError(f"Quantidade de barras escolhidas: {len(Barras_a_Estarem_no_Estudo)}")
        for i in range(len(Barras_a_Estarem_no_Estudo)):
            Barras_a_Estarem_no_Estudo[i]=Barras_a_Estarem_no_Estudo[i]-1
            
        return Barras_a_Estarem_no_Estudo

    except Exception as e:
        print(f"\n>>> Erro: {e}")
        print(f"      - Quantidade de barras permitida (default): ", limita)
        print('\n>>> CORRIJA A VARIÁVEL: "Barras Escolhidas"') 
        print('  ✅ Formato Válido: 1-5 (da barra 1 à 5)')  
        print('  ✅ Formato Válido: 1-5_7 (da barra 1 à 5 com a inclusão da barra 7)') 
        print('  🚫 Formato Inválido: 0-5_7 (inclusão do 0 ou negativos)') 
        print('  🚫 Formato Inválido: 1-5_180 (inclusão além do necessário)')
        print('  🚫 Formato Inválido: " " (deixar em vazio)')
        print('  🚫 Formato Inválido: "1-21" (Acima de 20 barras)')
        print("\n")
        return []








def mapear_valores(Barras_a_Estarem_no_Estudo, indices_modificados, valores_modificados):
    try:
        # Garantir que os inputs são válidos
        if len(indices_modificados) != len(valores_modificados):
            raise ValueError("indices_modificados e valores_modificados devem ter o mesmo tamanho.")

        # Criar um dicionário para mapear índices aos valores modificados
        mapa_indices_valores = dict(zip(indices_modificados, valores_modificados))

        # Inicializar as listas para os valores que dão match
        Barras_a_Estarem_no_Estudo_outraVez = []
        valores_modificados_outraVez = []

        # Mapear os valores de Barras_a_Estarem_no_Estudo
        for barra in Barras_a_Estarem_no_Estudo:
            valor = mapa_indices_valores.get(barra+1, None)
            if valor is not None:
                Barras_a_Estarem_no_Estudo_outraVez.append(barra+1)
                valores_modificados_outraVez.append(valor)

        return Barras_a_Estarem_no_Estudo_outraVez, valores_modificados_outraVez

    except Exception as e:
        print(f"Erro: {e}")
        return [], []



def process_intervals(ATIVA_ESPEC00A, PVbarIndex, Minimizar_EspacoAmostral, limite_superior):
    # Função para interpretar a string de intervalos
    def parse_intervals(interval_string, limite_superior):
        intervals = []
        # Divide a string usando o separador '_'
        parts = interval_string.split('_')
        for part in parts:
            if '-' in part:
                # Trata a parte como um intervalo (por exemplo, "18-24")
                lower, upper = map(int, part.split('-'))
                # Apenas adiciona se os valores estiverem dentro do limite e se lower não for -1
                if lower != -1 and upper <= limite_superior:
                    intervals.append((lower, upper))
            else:
                # Trata a parte como um único valor
                value = int(part)
                if value <= limite_superior:
                    intervals.append((value, value))
        
        # Ordena os intervalos pelo limite inferior
        intervals.sort(key=lambda x: x[0])
        #print('Barras a modificar:', intervals)
        #print()
        # Junta intervalos sobrepostos (ou que se sobrepõem) – 
        # observe que se os intervalos são apenas pontos (ex: (20,20) e (21,21)),
        # NÃO os mesclamos, pois a condição abaixo é: se o próximo intervalo inicia
        # estritamente acima do fim do último intervalo adicionado.
        merged = []
        for start, end in intervals:
            if not merged or start > merged[-1][1]:
                merged.append((start, end))
            else:
                merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        return merged

    # Obtém os intervalos processados (os limites são mantidos como na string original – em base 1)
    intervals = parse_intervals(Minimizar_EspacoAmostral, limite_superior)

    # Cria a lista de índices para ATIVA_ESPEC00A (base 0)
    ATIVA_ESPEC00A_index = list(range(len(ATIVA_ESPEC00A)))

    # Filtra os índices com base nos intervalos definidos, ajustando para base 0.
    PVbarIndex_modific = []
    ATIVA_ESPEC00A_index_modific = []
    ATIVA_ESPEC00A_modific = []

    for idx in PVbarIndex:
        for lower, upper in intervals:
            # Como os intervalos estão em base 1, usamos lower-1 e upper-1 para comparar
            if (lower - 1) <= idx <= (upper - 1):
                PVbarIndex_modific.append(idx)
                break

    for idx in ATIVA_ESPEC00A_index:
        for lower, upper in intervals:
            if (lower - 1) <= idx <= (upper - 1):
                ATIVA_ESPEC00A_index_modific.append(idx)
                ATIVA_ESPEC00A_modific.append(ATIVA_ESPEC00A[idx])
                break

    return PVbarIndex_modific, ATIVA_ESPEC00A_index_modific, ATIVA_ESPEC00A_modific






def create_modified_vectors(ATIVA_ESPEC00A_modific, ATIVA_ESPEC00A_index_modific, PVbarIndex_modific, limite_variacao):
    # Helper function to calculate percentage variation
    def apply_variation(value, percentage, direction):
        if direction == "up":
            return value * (1 + percentage / 100)
        elif direction == "down":
            return value * (1 - percentage / 100)
    
    def identificar_diferenca_indices(ATIVA_ESPEC00A_index_modific, PVbarIndex_modific):
        # Identificar elementos que estão em ATIVA_ESPEC00A_index_modific mas não em PVbarIndex_modific
        diferenca = sorted(set(ATIVA_ESPEC00A_index_modific) - set(PVbarIndex_modific))
        return diferenca
    
    # Initialize vectors
    PQPV_ATIVA_ESPEC00A_modific_up = []
    PQPV_ATIVA_ESPEC00A_modific_down = []
    PV_ATIVA_ESPEC00A_modific_up = []
    PV_ATIVA_ESPEC00A_modific_down = []

    # Create PQPV vectors based on ATIVA_ESPEC00A_index_modific
    for value in ATIVA_ESPEC00A_modific:
        PQPV_ATIVA_ESPEC00A_modific_up.append(apply_variation(value, limite_variacao, "up"))
        PQPV_ATIVA_ESPEC00A_modific_down.append(apply_variation(value, limite_variacao, "down"))
    # print('PVbarIndex_modific=',PVbarIndex_modific)
    # print('ATIVA_ESPEC00A_index_modific=',ATIVA_ESPEC00A_index_modific)
    vetor_diferenca = identificar_diferenca_indices(ATIVA_ESPEC00A_index_modific, PVbarIndex_modific)
    #print('vetor_diferenca=',vetor_diferenca)
    # Create PV vectors based on PVbarIndex_modific
    for idx, value in enumerate(ATIVA_ESPEC00A_modific):
        if ATIVA_ESPEC00A_index_modific[idx] in vetor_diferenca:
            PV_ATIVA_ESPEC00A_modific_up.append(apply_variation(value, limite_variacao, "up"))
            PV_ATIVA_ESPEC00A_modific_down.append(apply_variation(value, limite_variacao, "down"))
        else:
            PV_ATIVA_ESPEC00A_modific_up.append(value)
            PV_ATIVA_ESPEC00A_modific_down.append(value)

    return (PQPV_ATIVA_ESPEC00A_modific_up, 
            PQPV_ATIVA_ESPEC00A_modific_down, 
            PV_ATIVA_ESPEC00A_modific_up, 
            PV_ATIVA_ESPEC00A_modific_down)


def create_new_vectors(ATIVA_ESPEC00A, ATIVA_ESPEC00A_index_modific, PQPV_down, PQPV_up, PV_down, PV_up):
    # Create index vector for ATIVA_ESPEC00A
    ATIVA_ESPEC00A_index = list(range(len(ATIVA_ESPEC00A)))

    # Initialize new vectors with original ATIVA_ESPEC00A values
    PQPV_down_new = ATIVA_ESPEC00A[:]
    PQPV_up_new = ATIVA_ESPEC00A[:]
    PV_down_new = ATIVA_ESPEC00A[:]
    PV_up_new = ATIVA_ESPEC00A[:]

    # Replace values in new vectors based on matches with ATIVA_ESPEC00A_index_modific
    for i, idx in enumerate(ATIVA_ESPEC00A_index):
        if idx in ATIVA_ESPEC00A_index_modific:
            modific_index = ATIVA_ESPEC00A_index_modific.index(idx)
            PQPV_down_new[i] = PQPV_down[modific_index]
            PQPV_up_new[i] = PQPV_up[modific_index]
            PV_down_new[i] = PV_down[modific_index]
            PV_up_new[i] = PV_up[modific_index]

    return PQPV_down_new, PQPV_up_new, PV_down_new, PV_up_new



def analisadora_DeResultados_POSTUMAS02( D_TENSAO, A_TENSAO, Tensao00, TensaoEspec):
    
    def vetores_iguais(vetor1, vetor2):
        # Verifica se os tamanhos são diferentes
        if len(vetor1) != len(vetor2):
            return False

        # Compara cada elemento dos vetores
        for i in range(len(vetor1)):
            if vetor1[i] != vetor2[i]:
                return False  # Encontrou uma diferença
        
        return True  
    
    def subtrair_vetores_incrementando(contVorNV_BqV, contVorNV_00):
        # Incrementa em 1 todos os elementos de contVorNV_BqV
        contVorNV_BqV_inc = [[x + 1 for x in vetor] for vetor in contVorNV_BqV]
        # Incrementa em 1 todos os elementos de contVorNV_00
        contVorNV_00_inc = [x + 1 for x in contVorNV_00]
        
        # Converter a lista base incrementada para um set para otimizar as buscas
        base_set = set(contVorNV_00_inc)
        
        resultados = []
        
        # Para cada vetor incrementado em contVorNV_BqV
        for vetor in contVorNV_BqV_inc:
            # Converter o vetor para set para facilitar a verificação
            vetor_set = set(vetor)
            
            # Elementos que estão no vetor, mas não na base
            diff_BqV_minus_base = [elem for elem in vetor if elem not in base_set]
            
            # Elementos que estão na base, mas não no vetor
            diff_base_minus_BqV = [elem for elem in contVorNV_00_inc if elem not in vetor_set]
            
            # Armazena os dois conjuntos de diferenças
            resultados.append({
                "BqV_minus_base": diff_BqV_minus_base,
                "base_minus_BqV": diff_base_minus_BqV
            })
        
        return resultados


    def extrair_bases_min(resultado):
        bases_nao_vazias = []
        
        for d in resultado:
            bqv = d.get('BqV_minus_base', [])
            base_minus = d.get('base_minus_BqV', [])
            
            # Se ambos não estiverem vazios, escolha aquele com menor quantidade de elementos
            if bqv and base_minus:
                if len(bqv) <= len(base_minus):
                    escolhido = bqv
                else:
                    escolhido = base_minus
            # Se apenas um dos dois não estiver vazio, pega esse
            elif bqv:
                escolhido = bqv
            elif base_minus:
                escolhido = base_minus
            # Se ambos forem vazios, retorna vazio
            else:
                escolhido = []
            
            bases_nao_vazias.append(escolhido)
        
        return bases_nao_vazias


    BarraQViola_estatica_00=[]
    contVorNV_00=[]
    for aux in range(len(TensaoEspec)):
        if TensaoEspec[aux]!=0:
            if TensaoEspec[aux]==Tensao00[aux]:
                BarraQViola_estatica_00.append('NV')
            else:
                BarraQViola_estatica_00.append('V')
                contVorNV_00.append(aux)
        else:
            BarraQViola_estatica_00.append('-')
    #print('contVorNV_00=',contVorNV_00)

    QuantyMaq=0
    for aux in range(len(TensaoEspec)):
        if TensaoEspec[aux]!=0:
            QuantyMaq=QuantyMaq+1

    contVorNV00=0
    for aux in range(len(BarraQViola_estatica_00)):
        if BarraQViola_estatica_00[aux]=='V':
            contVorNV00=contVorNV00+1

    contVorNV_QuantyVec=[]
    contVorNV_BqV=[]
    BarraQViola_estatica_din=[]
    for aux in range(len(D_TENSAO)):
        contVorNVdin1=0
        contVorNV_BqV_lin=[]
        BarraQViola_estatica_dinLin=[]
       
        for aux2 in range(len(D_TENSAO[aux])):
            if TensaoEspec[aux2]!=0:                 
                if TensaoEspec[aux2]!=D_TENSAO[aux][aux2]:
                    contVorNVdin1=contVorNVdin1+1
                    contVorNV_BqV_lin.append(aux2)
                    BarraQViola_estatica_dinLin.append('V')
                else:
                    BarraQViola_estatica_dinLin.append('NV')
            else:
                BarraQViola_estatica_dinLin.append('-')

        BarraQViola_estatica_din.append(BarraQViola_estatica_dinLin)
        contVorNV_BqV.append(contVorNV_BqV_lin)
        contVorNV_QuantyVec.append(contVorNVdin1)
        #print('contVorNV_BqV=',contVorNV_BqV)

    # for aux in range(len(A_TENSAO)):     
    #     for aux2 in range(len(A_TENSAO[aux])):
    #         if TensaoEspec[aux2]!=0 and TensaoEspec[aux2]!=A_TENSAO[aux][aux2]:
    #                A_TENSAO[aux][aux2]=0
    #         if TensaoEspec[aux2]!=0 and TensaoEspec[aux2]!=D_TENSAO[aux][aux2]:
    #                D_TENSAO[aux][aux2]=0                   


    # contVorNVdif_QuantyVec=[]
    # contVorNVdif_BqV=[]
    # for aux in range(len(A_TENSAO)):
    #     contVorNVdifdin1=0
    #     contVorNVdif_BqV_lin=[]        
    #     for aux2 in range(len(A_TENSAO[aux])):
    #         if TensaoEspec[aux2]!=0:               
    #             if A_TENSAO[aux][aux2]!=D_TENSAO[aux][aux2]:
    #                 contVorNVdifdin1=contVorNVdifdin1+1
    #                 contVorNVdif_BqV_lin.append(aux2)
    #     contVorNVdif_BqV.append(contVorNVdif_BqV_lin)
    #     contVorNVdif_QuantyVec.append(contVorNVdifdin1)
    


    Quantidade_Violada=[]
    for aux in range(len(contVorNV_QuantyVec)):
        Quantidade_Violada.append(f"{contVorNV_QuantyVec[aux]} de {QuantyMaq}")

    quantidadeViolada_0=f"{contVorNV00} de {QuantyMaq}"

    #matriz_de_diferencas=contVorNVdif_QuantyVec

    matriz_de_diferencas2=subtrair_vetores_incrementando(contVorNV_BqV, contVorNV_00)
    matriz_de_diferencas3 = extrair_bases_min(matriz_de_diferencas2)

    vetor_de_diferencas = ["_".join(map(str, filter(lambda x: x != 0, linha))) for linha in matriz_de_diferencas3]

    Indicador_de_QUALIDADE=[]
    for aux in range(len(A_TENSAO)):
        if contVorNV_QuantyVec[aux]==contVorNV00:
            if vetores_iguais(BarraQViola_estatica_din[aux], BarraQViola_estatica_00)==True:
                Indicador_de_QUALIDADE.append('QUANTIDADES IGUAIS') 
            else:
                Indicador_de_QUALIDADE.append('QUANTIDADES INDIFERENTE') 
        elif contVorNV_QuantyVec[aux]>contVorNV00:
            Indicador_de_QUALIDADE.append('PIOR') 
        elif contVorNV_QuantyVec[aux]<contVorNV00:
            Indicador_de_QUALIDADE.append('MELHOR')             
    
    return quantidadeViolada_0, matriz_de_diferencas2, vetor_de_diferencas, Indicador_de_QUALIDADE, Quantidade_Violada



def analisadora_DeResultados(BarraQViola_estatica_0, PVbarIndex, D_BqV_PES, D_TENSAO, A_TENSAO, BarraQViola_estatica_00):
    # Calculate quantidadeViolada
    for aux in range(len(PVbarIndex)):
        PVbarIndex[aux]= PVbarIndex[aux]-1

    X = sum(1 for value in PVbarIndex if value in BarraQViola_estatica_0)
    Y = len(PVbarIndex)
    

    if PVbarIndex[0]==0:
        if BarraQViola_estatica_0[0]==PVbarIndex[0]:
            Z=X-1
            W=Y-1
            quantidadeViolada_0 = f"{Z} de {W}"
        else:
            Z=X
            W=Y
            quantidadeViolada_0 = f"{X} de {Y}"
    else:
        Z=X
        W=Y
        quantidadeViolada_0 = f"{X} de {Y}"        

    if BarraQViola_estatica_00!=0:
        Z=Z+1   

    # Create matriz_de_diferencas
    matriz_de_diferencas = []
    Indicador_de_QUALIDADE=[]
    Quantidade_Violada=[]
    for linha in D_BqV_PES:
 
        Aux = sum(1 for value in PVbarIndex if value in linha)
     
        if PVbarIndex[0]==0:
            if linha[0]==PVbarIndex[0]:
                Z_n=Aux-1
                Y_n=Y-1
            else:
                Z_n=Aux
                Y_n=Y
        else:
            Z_n=Aux
            Y_n=Y 

        if D_TENSAO[D_BqV_PES.index(linha)][0]!=A_TENSAO[D_BqV_PES.index(linha)][0]:
           Z_n=Z_n+1
              
        if Z_n>Z:
            nova_linha = [valor if valor not in BarraQViola_estatica_0 else 0 for valor in linha]
            for aux in range(len(nova_linha)):
                if nova_linha[aux]!=0:
                    nova_linha[aux]= nova_linha[aux]+1
            matriz_de_diferencas.append(nova_linha)
            Indicador_de_QUALIDADE.append('PIOR')
            Quantidade_Violada.append(f"{Z_n} de {Y_n}")
        elif Z_n<Z:
            nova_linha = [valor if valor not in linha else 0 for valor in BarraQViola_estatica_0]
            for aux in range(len(nova_linha)):
                if nova_linha[aux]!=0:
                    nova_linha[aux]= nova_linha[aux]+1            
            matriz_de_diferencas.append(nova_linha)
            Indicador_de_QUALIDADE.append('MELHOR')
            Quantidade_Violada.append(f"{Z_n} de {Y_n}") 
        elif Z_n==Z:
            nova_linha = [valor if valor not in linha else 0 for valor in BarraQViola_estatica_0]
            for aux in range(len(nova_linha)):
                if nova_linha[aux]!=0:
                    nova_linha[aux]= nova_linha[aux]+1            
            matriz_de_diferencas.append(nova_linha)
            Indicador_de_QUALIDADE.append('INDIFERENTE')                   
            Quantidade_Violada.append(f"{Z_n} de {Y_n}") 
    # Create vetor_de_diferencas

    #if 
    vetor_de_diferencas = ["_".join(map(str, filter(lambda x: x != 0, linha))) for linha in matriz_de_diferencas]
    # for aux in range(len(vetor_de_diferencas)):
    #     vetor_de_diferencas[aux]= vetor_de_diferencas[aux]+1

    return quantidadeViolada_0, matriz_de_diferencas, vetor_de_diferencas, Indicador_de_QUALIDADE, Quantidade_Violada


def incrementar_BarraQViola(BarraQViola_estatica_0):
    # Increment non-zero values by 1
    valores_incrementados = [valor + 1 for valor in BarraQViola_estatica_0 if valor != 0]

    # Concatenate incremented values into a single string
    BarraQViola_estatica_0_STRG = "_".join(map(str, valores_incrementados))

    return BarraQViola_estatica_0_STRG


def confirmar_se_nao_CAI(matriz_diferencas_lev, matriz_de_pontos_testes_antes_lev, ATIVA_down, ATIVA_ESPEC, cadidat, limite_variacao, stopa_por_nao_encontrar):
    # Execução do fluxo de potência
    elemento_x=matriz_diferencas_lev[cadidat]  # Acessa a matriz de índice cadidat
                        

    verificador=0
    verificador_auxiliar=len(elemento_x)
    vetorVigia=[]
    for auxiliar_verificador in range(len(matriz_de_pontos_testes_antes_lev[cadidat])):
        if matriz_de_pontos_testes_antes_lev[cadidat][auxiliar_verificador]!=0:
            verificador_auxiliar=verificador_auxiliar+1
            vetorVigia.append(matriz_de_pontos_testes_antes_lev[cadidat][auxiliar_verificador])                    

    vetorVigia=vetorVigia+elemento_x
    for valor in vetorVigia:  # Itera sobre os elementos dessa matriz
        if ATIVA_down[valor]==ATIVA_ESPEC[valor]*(1-limite_variacao/100) or ATIVA_down[valor]==ATIVA_ESPEC[valor]*(1+limite_variacao/100):
            verificador=verificador+1
        

    if verificador==verificador_auxiliar:
        stopa_por_nao_encontrar='yes'  

    return stopa_por_nao_encontrar


def analisadora_DeResultados_POSTUMAS_01(BarraQViola_estatica_0, D_TENSAO_LEV_aux, DeltaV_0, infoVcontrol, tolApresent):
    
    # def calculate_percentages(vetor_SAF, vetor_SAP):
    #     # Contar ocorrências de "yes" em SAF e SAP
    #     total_elements = len(vetor_SAF)
    #     saf_count = vetor_SAF.count("yes")
    #     sap_count = vetor_SAP.count("yes")

    #     # Calcular porcentagens
    #     saf_percentage = (saf_count / total_elements) * 100 if total_elements > 0 else 0
    #     sap_percentage = (sap_count / total_elements) * 100 if total_elements > 0 else 0

    #     return saf_percentage, sap_percentage

    def criar_vetor_concat(vetTAGBqVrestante):
        vetor_concat = []
        for i in range(0, len(vetTAGBqVrestante), 5):  # Itera de 5 em 5
            grupo = vetTAGBqVrestante[i:i+5]  # Seleciona 5 elementos
            vetor_concat.append('_'.join(grupo))  # Concatena com '_'
        return vetor_concat

    # Limpar os dados de DeltaV_0
    DeltaV_0 = [float(x) for x in DeltaV_0]

    # Inicializar os vetores de saída
    vetor_Acomparar = []
    vetor_ref = []
    vetor_SAF = []
    vetor_SAP = []


    # Varredura para valores não nulos em BarraQViola_estatica_0
    for idx, value in enumerate(BarraQViola_estatica_0):
        if value != 0:
            # Obter os valores correspondentes
            D_TENSAO_LEV_value = D_TENSAO_LEV_aux[idx]
            DeltaV_0_value = DeltaV_0[idx]
            infoVcontrol_value = infoVcontrol[idx]

            # Calcular distâncias
            distancia_Acomparar = np.sqrt((D_TENSAO_LEV_value - infoVcontrol_value)**2)
            distancia_ref = np.sqrt((DeltaV_0_value - infoVcontrol_value)**2)

            # Adicionar distâncias aos vetores
            vetor_Acomparar.append(distancia_Acomparar)
            vetor_ref.append(distancia_ref)
            
            vetor_Acomparar=[float(round(aux, tolApresent)) for aux in vetor_Acomparar]
            vetor_ref=[float(round(aux, tolApresent)) for aux in vetor_ref]

            
            distancia_Acomparar=float(round(distancia_Acomparar, tolApresent)) 
            distancia_ref=float(round(distancia_ref, tolApresent)) 

            # Determinar SAF e SAP
            if distancia_Acomparar > distancia_ref:
                vetor_SAF.append("yes")
                vetor_SAP.append("no")
            elif distancia_Acomparar < distancia_ref:
                vetor_SAF.append("no")
                vetor_SAP.append("yes")
            elif distancia_Acomparar == distancia_ref: 
                vetor_SAF.append("yes")
                vetor_SAP.append("yes")
                 


    vetTAGBqVrestante=[]
    for aux in range(len(vetor_SAF)):
        if vetor_SAF[aux]=='yes' and vetor_SAP[aux]=='no':
            vetTAGBqVrestante.append('AF')
        if vetor_SAP[aux]=='yes' and vetor_SAF[aux]=='no':
            vetTAGBqVrestante.append('AP')
        if vetor_SAP[aux]=='yes' and vetor_SAF[aux]=='yes':
            vetTAGBqVrestante.append('IG')            

    vetor_concat = criar_vetor_concat(vetTAGBqVrestante)
    #print('vetTAGBqVrestante=',vetTAGBqVrestante)
    #stringvetTAGBqVrestante = '_'.join(vetTAGBqVrestante) 
    stringvetTAGBqVrestante=  '_'.join(vetor_concat)  


    return vetor_Acomparar, vetor_ref, vetor_SAF, vetor_SAP, vetTAGBqVrestante, stringvetTAGBqVrestante


def retinar_ponto_porBifurcar(valor):
    """
    Recebe uma string (valor) que deve conter um número ou dois números separados por "_".
    Retorna 'yes' se encontrar o caractere "_" (ou seja, bifurcação), e 'no' se for apenas um número.
    """
    if "_" in valor:
        return "yes"
    else:
        return "no"


def FiltroParaFIGType2(MATRIZ_TOTAL_LEV, S_base, filtrarDivergente):
    tol=0.001
    diferencas_LEV=[]
    for aux in range(len(MATRIZ_TOTAL_LEV)):

            diferencas_LEV.append(MATRIZ_TOTAL_LEV[aux][4])

    # diferencas_PES=MATRIZ_TOTAL_PES[4]
    
    tranformaInt=[]
    for aux in range(len(MATRIZ_TOTAL_LEV)):
        # if 'QUANTIDADES IGUAIS'!=MATRIZ_TOTAL_LEV[aux][5]:
        try:
            if int(diferencas_LEV[aux])<len(MATRIZ_TOTAL_LEV[0][11]):
                if retinar_ponto_porBifurcar(diferencas_LEV[aux])=='no':
                    tranformaInt.append(int(diferencas_LEV[aux]))
                else:
                    tranformaInt.append(None)
                
                # if MATRIZ_TOTAL_LEV[aux][28][0]==0:
                #     tranformaInt.append(None)
            else:
                tranformaInt.append(None)
        except Exception as e:
            tranformaInt.append(None)

    #print('segura')
    if filtrarDivergente=='yes':
        # for aux2 in range(len(MATRIZ_TOTAL_LEV)):
        #     for aux3 in range(len(MATRIZ_TOTAL_LEV[aux2][14])):
        #         if MATRIZ_TOTAL_LEV[aux2][14][aux3]<0 or MATRIZ_TOTAL_LEV[aux2][14][aux3]>2 or MATRIZ_TOTAL_LEV[aux2][15][aux3]<-3 or MATRIZ_TOTAL_LEV[aux2][15][aux3]>3:
        #             tranformaInt[aux2]=None
        for aux2 in range(len(MATRIZ_TOTAL_LEV)):
            for aux3 in range(len(MATRIZ_TOTAL_LEV[aux2][26][3])):
                if MATRIZ_TOTAL_LEV[aux2][26][3][aux3]=='Y':
                    potQger=MATRIZ_TOTAL_LEV[aux2][17][aux3]-MATRIZ_TOTAL_LEV[aux2][26][2][aux3]
                    if potQger<MATRIZ_TOTAL_LEV[aux2][26][4][aux3]-10*tol or potQger>MATRIZ_TOTAL_LEV[aux2][26][5][aux3]+10*tol:
                        tranformaInt[aux2]=None


    #print('segura')

    pega=[]
    for aux in range(len(MATRIZ_TOTAL_LEV)):
        if MATRIZ_TOTAL_LEV[aux][28][0]==0:
            tranformaInt[aux]=None   
            pega.append(aux)     
    
    A_TENSAO_LEV_de_diferencas=[]
    D_TENSAO_LEV_de_diferencas=[]
    A_CARGA_LEV_de_diferencas=[] 
    D_CARGA_LEV_de_diferencas=[]
    CENARIO_LEV=[]
    CENARIO_LEVantes=[]
    forfutureFilter=[]
    vet_grupo_LEV=[]
    cord_y=[]
    cord_y_dep=[]
    #cord_x=[]
    pontos_fatorDePotencia=[]
    pontos_fatorDePotencia_dep=[]
    tag_doPonto=[]
    #tag_doPonto_dep=[]

    for aux in range(len(MATRIZ_TOTAL_LEV)):
        #print('wait')
        if tranformaInt[aux]!=None:
            if MATRIZ_TOTAL_LEV[aux][28][int(diferencas_LEV[aux])-1]!=MATRIZ_TOTAL_LEV[aux][14][int(diferencas_LEV[aux])-1]:
                A_TENSAO_LEV_de_diferencas.append(MATRIZ_TOTAL_LEV[aux][28][int(diferencas_LEV[aux])-1])
                D_TENSAO_LEV_de_diferencas.append(MATRIZ_TOTAL_LEV[aux][14][int(diferencas_LEV[aux])-1])
                A_CARGA_LEV_de_diferencas.append((-1/S_base)*sum(MATRIZ_TOTAL_LEV[0][43][aux]))
                D_CARGA_LEV_de_diferencas.append((-1/S_base)*sum(MATRIZ_TOTAL_LEV[aux][11]))
                vet_grupo_LEV.append(tranformaInt[aux]) 
                CENARIO_LEV.append(MATRIZ_TOTAL_LEV[aux][11])  
                CENARIO_LEVantes.append(MATRIZ_TOTAL_LEV[0][43][aux]) 
                forfutureFilter.append(aux)


                pot_p_gerada=[]
                pot_q_gerada=[]
                for i in range(len(MATRIZ_TOTAL_LEV[aux][30])):
                    # Cálculo das potências geradas
                    if MATRIZ_TOTAL_LEV[aux][18][0][i]=='G' or MATRIZ_TOTAL_LEV[aux][18][0][i]=='CS' or MATRIZ_TOTAL_LEV[aux][18][0][i]=='swing':
                        pot_p_gerada.append(MATRIZ_TOTAL_LEV[aux][30][i] - (1/S_base)* MATRIZ_TOTAL_LEV [0][43][aux][i])  # Potência P gerada    
                        pot_q_gerada.append(MATRIZ_TOTAL_LEV[aux][31][i] - MATRIZ_TOTAL_LEV [aux][20][2][i])  # Potência Q gerada                            
                soma_p = np.sum(pot_p_gerada)
                soma_q = np.sum(pot_q_gerada)
                PotSger=np.sqrt(soma_p**2+soma_q**2)
                fpGlobal=soma_p/PotSger 
                cord_y.append(float(fpGlobal))


                pot_p_gerada_dep=[]
                pot_q_gerada_dep=[]
                for i in range(len(MATRIZ_TOTAL_LEV[aux][22])):
                    # Cálculo das potências geradas
                    if MATRIZ_TOTAL_LEV[aux][18][0][i]=='G' or MATRIZ_TOTAL_LEV[aux][18][0][i]=='CS' or MATRIZ_TOTAL_LEV[aux][18][0][i]=='swing':
                        pot_p_gerada_dep.append(MATRIZ_TOTAL_LEV[aux][22][i] - (1/S_base)* MATRIZ_TOTAL_LEV [aux][11][i])  # Potência P gerada    
                        pot_q_gerada_dep.append(MATRIZ_TOTAL_LEV[aux][23][i] - MATRIZ_TOTAL_LEV [aux][20][2][i])  # Potência Q gerada                            
                soma_p_dep = np.sum(pot_p_gerada_dep)
                soma_q_dep = np.sum(pot_q_gerada_dep)
                PotSger_dep=np.sqrt(soma_p_dep**2+soma_q_dep**2)
                fpGlobal_dep=soma_p_dep/PotSger_dep 
                cord_y_dep.append(float(fpGlobal_dep))

                # somaPger=0
                # for auxilair in range(len(MATRIZ_TOTAL_LEV[aux][20][1])):
                #     somaPger=somaPger+MATRIZ_TOTAL_LEV[aux][20][1][auxilair]  
                # cord_x.append((-1)*somaPger)

                tag_doPonto.append(tranformaInt[aux])

    pontos_fatorDePotencia.append(cord_y)
    pontos_fatorDePotencia.append(A_CARGA_LEV_de_diferencas)
    pontos_fatorDePotencia.append(tag_doPonto)            
    
    pontos_fatorDePotencia_dep.append(cord_y_dep)
    pontos_fatorDePotencia_dep.append(D_CARGA_LEV_de_diferencas)
    pontos_fatorDePotencia_dep.append(tag_doPonto)   

    FILTRO_out=[]
    FILTRO_out.append(A_TENSAO_LEV_de_diferencas)
    FILTRO_out.append(D_TENSAO_LEV_de_diferencas)
    FILTRO_out.append(A_CARGA_LEV_de_diferencas)
    FILTRO_out.append(D_CARGA_LEV_de_diferencas)
    FILTRO_out.append(CENARIO_LEV)
    FILTRO_out.append(CENARIO_LEVantes)
    FILTRO_out.append(forfutureFilter)
    FILTRO_out.append(vet_grupo_LEV)
    FILTRO_out.append(pontos_fatorDePotencia)
    FILTRO_out.append(pontos_fatorDePotencia_dep)

    return(FILTRO_out)



def definirLegendFIGType2(vet_grupo, MATRIZ_TOTAL_INICIAL, S_base):
    TENSAO_0=[]
    CARG_0vet=[]
    CARG_0=0
    CENARIO_BASE=[0]*len(MATRIZ_TOTAL_INICIAL[9])    

    if vet_grupo!=[]:
        #print('MATRIZ_TOTAL_INICIAL[9]',MATRIZ_TOTAL_INICIAL[9])
        for aux in range(len(MATRIZ_TOTAL_INICIAL[9])):
            CARG_0=(-1/S_base)*MATRIZ_TOTAL_INICIAL[9][aux]+CARG_0
            CENARIO_BASE[aux]=MATRIZ_TOTAL_INICIAL[9][aux]

        # Obtém os valores únicos e suas contagens
        unique_vals, counts = np.unique(vet_grupo, return_counts=True)

        # Filtra os valores que se repetem (contagem maior que 1)
        vet_repetidos = unique_vals[counts > 1]

        for aux in range(len(vet_repetidos)):
            vet_repetidos[aux]=vet_repetidos[aux]-1

        #print(vet_repetidos)     

        for aux in range(len(MATRIZ_TOTAL_INICIAL[0])):
            if aux in vet_repetidos:
                TENSAO_0.append(MATRIZ_TOTAL_INICIAL[0][aux])
                CARG_0vet.append(CARG_0)

        # print(CARG_0vet)
        # print(TENSAO_0)
        # #print('aqui')

        # print('CENARIO_PES=',CENARIO_PES)
        # print('CENARIO_PESantes=',CENARIO_PESantes)    
        # print('CENARIO_BASE=',CENARIO_BASE)
    return(CARG_0vet, TENSAO_0, CENARIO_BASE)


# =============================================================================
# Função de análise: compara cada vetor de CENARIO_PES com CENARIO_BASE e retorna
# uma tupla (lista de índices alterados, lista de variações percentuais)
# =============================================================================
def analizerResults03(cenario_pes, cenario_base):
    resultados = []
    for vetor in cenario_pes:
        indices_alterados = []
        porcentagens = []
        for i, (base_val, pes_val) in enumerate(zip(cenario_base, vetor)):
            if base_val != pes_val:
                indices_alterados.append(i + 1)  # índice 1-indexado
                if base_val == 0:
                    porcentagens.append(0)
                else:
                    diff_perc = abs(pes_val - base_val) / abs(base_val) * 100
                    if base_val < pes_val:
                        diff_perc = -diff_perc
                    porcentagens.append(diff_perc)
        resultados.append((indices_alterados, porcentagens))
    return resultados


# =======================================================================
# Função para salvar as informações (parâmetros, dados do gráfico e análise)
# =======================================================================
def save_plot_info(tag, save_dir, parameters, plot_data):
    filepath = os.path.join(save_dir, f"{tag}.txt")
    with open(filepath, 'w') as f:
        f.write("''' ESPECIFICAÇÃO '''\n")
        for key, value in parameters.items():
            f.write(f"{key}={repr(value)}\n")
        f.write("\n''' PLOT DATA '''\n")
        for key, data in plot_data.items():
            f.write(f"{key}:\n")
            # Se for array numérico, salva em formato CSV; caso contrário, usa repr
            if isinstance(data, np.ndarray) and data.dtype.kind in 'biufc':
                np.savetxt(f, data, delimiter=',', fmt='%s')
            else:
                f.write(repr(data))
            f.write("\n")
    print(f"\n✅ Arquivo TXT para a construção do gráfico salvas em:")
    print(f"{filepath}")

# =======================================================================
# Função para carregar as informações salvas
# =======================================================================
# def load_plot_info(filepath):
#     parameters = {}
#     plot_data = {}
#     with open(filepath, 'r') as f:
#         lines = f.readlines()


def detect_encoding(filepath):
    with open(filepath, 'rb') as f:
        raw_data = f.read(10000)  # Lê os primeiros 10k bytes
        result = chardet.detect(raw_data)
        return result['encoding']
    
def load_plot_info(filepath):
    encoding = detect_encoding(filepath)
    print(f"Detectado encoding: {encoding}")  # Apenas para depuração
    with open(filepath, 'r', encoding=encoding) as f:
        lines = f.readlines()    
    header_mode = True
    data_key = None
    data_lines = []
    parameters = {}
    plot_data = {}
    
    for line in lines:
        line = line.strip()
        if line.startswith("'''"):
            if "PLOT DATA" in line:
                header_mode = False
            continue
        if header_mode:
            if '=' in line:
                key, val = line.split('=', 1)
                try:
                    parameters[key.strip()] = ast.literal_eval(val.strip())
                except Exception:
                    parameters[key.strip()] = val.strip()
        else:
            if line.endswith(":"):
                if data_key is not None and data_lines:
                    # Se houver mais de uma linha, tenta ler como array; senão, avalia a linha
                    if len(data_lines) > 1:
                        try:
                            arr = np.genfromtxt(data_lines, delimiter=',')
                        except Exception:
                            arr = ast.literal_eval(" ".join(data_lines))
                    else:
                        arr = ast.literal_eval(data_lines[0])
                    plot_data[data_key] = arr
                data_key = line[:-1].strip()
                data_lines = []
            else:
                if line != "":
                    data_lines.append(line)
    if data_key is not None and data_lines:
        if len(data_lines) > 1:
            try:
                arr = np.genfromtxt(data_lines, delimiter=',')
            except Exception:
                arr = ast.literal_eval(" ".join(data_lines))
        else:
            arr = ast.literal_eval(data_lines[0])
        plot_data[data_key] = arr
    return parameters, plot_data


# =======================================================================
# Função para reconstruir o gráfico a partir do arquivo salvo
# Agora com reconstrução por grupos de pontos
# =======================================================================
# def reconstruct_plot(filepath):
#     parameters, plot_data = load_plot_info(filepath)
#     print("Parâmetros carregados:")
#     for key, value in parameters.items():
#         print(f"  {key} = {value}")
    
#     fig, ax = plt.subplots(figsize=(10, 6))
#     ax.set_xlabel('Potência das Cargas (p.u.)')
#     ax.set_ylabel('Tensão (p.u.)')
#     ax.set_title('Gráfico Reconstruído a partir do Arquivo Salvo')
#     ax.grid(True)
    
#     # Recupera os dados
#     A_carga = plot_data.get("A_CARGA")
#     A_tensao = plot_data.get("A_TENSAO")
#     D_carga = plot_data.get("D_CARGA")
#     D_tensao = plot_data.get("D_TENSAO")
#     analysis_results_antes = plot_data.get("analysis_results_antes")
#     #analysis_results_antes = plot_data.get("analysis_results_depois")
#     # Vetor de grupos
#     vet_grupo = plot_data.get("vet_grupo")
#     # Pontos iniciais:
#     CARG_0 = plot_data.get("CARG_0")
#     TENSAO_0 = plot_data.get("TENSAO_0")
    
#     # Se não houver informação de grupos, usa uma única cor padrão
#     if vet_grupo is None:
#         sc_antes = ax.scatter(A_carga, A_tensao, color="green", s=100, label="Antes")
#         ax.scatter(D_carga, D_tensao, color="red", s=100, label="Depois")
        
#         # Conecta os pontos com linhas degradê
#         num_interp = 100
#         cmap = LinearSegmentedColormap.from_list("degrade", ["green", "red"])
#         for x0, y0, x1, y1 in zip(A_carga, A_tensao, D_carga, D_tensao):
#             x_vals = np.linspace(x0, x1, num=num_interp)
#             y_vals = np.linspace(y0, y1, num=num_interp)
#             points = np.array([x_vals, y_vals]).T.reshape(-1, 1, 2)
#             segments = np.concatenate([points[:-1], points[1:]], axis=1)
#             colors = [cmap(t) for t in np.linspace(0, 1, len(segments))]
#             lc = LineCollection(segments, colors=colors, linewidth=2)
#             ax.add_collection(lc)
        
#         # Configura tooltips para os pontos "Antes"
#         cursor = mplcursors.cursor(sc_antes, hover=True)
#         @cursor.connect("add")
#         def on_add(sel):
#             ind = sel.index
#             res = analysis_results_antes[ind]
#             if res[0]:
#                 text = f"Índices alterados: {res[0]}\nVariação (%): " + ", ".join(f"{p:.2f}%" for p in res[1])
#             else:
#                 text = "Sem alteração"
#             sel.annotation.set_text(text)
#             sel.annotation.get_bbox_patch().set(alpha=0.8, fc="white")
#     else:
#         # Se existir informação de grupo, organiza os dados por grupo
#         vet_grupo = np.array(vet_grupo)
#         #vet_grupo = np.atleast_1d(vet_grupo) 
#         unique_groups = np.unique(vet_grupo)
        
        
#         # Define os pares de cores para cada grupo
#         color_pairs = [
#             ('green', 'red'),
#             ('blue', 'orange'),
#             ('purple', 'yellow'),
#             ('cyan', 'magenta'),
#             ('yellow', 'green'),
#             ('purple', 'red'),
#         ]
#         group_color_map = {}
#         for i, grupo in enumerate(unique_groups):
#             group_color_map[grupo] = color_pairs[i % len(color_pairs)]
        
#         num_interp = 100
#         scatter_objs_antes = []  # Armazenará os scatter dos pontos "Antes" para tooltips
        
#         for grupo in unique_groups:
#             before_color, after_color = group_color_map[grupo]
#             indices_group = np.where(vet_grupo == grupo)[0]
            
#             # Seleciona os dados dos pontos "Antes" e "Depois" do grupo
#             A_carga_group = np.array(A_carga)[indices_group]
#             A_tensao_group = np.array(A_tensao)[indices_group]
#             D_carga_group = np.array(D_carga)[indices_group]
#             D_tensao_group = np.array(D_tensao)[indices_group]
            
#             # Plota os pontos "Antes" e "Depois" com cores específicas e legenda indicando o grupo
#             sc_antes = ax.scatter(A_carga_group, A_tensao_group, color=before_color, s=100, label=f'Grupo {grupo} - Antes')
#             ax.scatter(D_carga_group, D_tensao_group, color=after_color, s=100, label=f'Grupo {grupo} - Depois')
#             scatter_objs_antes.append((sc_antes, indices_group))
            
#             # Cria um colormap específico para o grupo e desenha a linha de degradê para cada par de pontos
#             group_cmap = LinearSegmentedColormap.from_list(f'grupo_{grupo}_cmap', [before_color, after_color])
#             for i in indices_group:
#                 x0, y0 = A_carga[i], A_tensao[i]
#                 x1, y1 = D_carga[i], D_tensao[i]
#                 x_vals = np.linspace(x0, x1, num=num_interp)
#                 y_vals = np.linspace(y0, y1, num=num_interp)
#                 points = np.array([x_vals, y_vals]).T.reshape(-1, 1, 2)
#                 segments = np.concatenate([points[:-1], points[1:]], axis=1)
#                 colors_segment = [group_cmap(t) for t in np.linspace(0, 1, len(segments))]
#                 lc = LineCollection(segments, colors=colors_segment, linewidth=2)
#                 ax.add_collection(lc)
        
#         # Configura os tooltips para os pontos "Antes" de cada grupo
#         for sc, indices_group in scatter_objs_antes:
#             texts = []
#             for idx in indices_group:
#                 changed_idxs, percents = analysis_results_antes[idx]
#                 if changed_idxs:
#                     t = f"Índices alterados: {changed_idxs}\nVariação (%): " + ", ".join(f"{p:.2f}%" for p in percents)
#                 else:
#                     t = "Sem alteração"
#                 texts.append(t)
#             cursor = mplcursors.cursor(sc, hover=True)
#             @cursor.connect("add")
#             def on_add(sel, texts=texts):
#                 ind = sel.index
#                 sel.annotation.set_text(texts[ind])
#                 sel.annotation.get_bbox_patch().set(alpha=0.8, fc="white")
    
#     # Plota o ponto inicial (estrelinha preta), se disponível
#     if CARG_0 is not None and TENSAO_0 is not None:
#         ax.scatter(CARG_0, TENSAO_0, color='black', marker='*', s=150, label='(INICIAL)')
    
#     ax.legend()
#     plt.show()




def reconstruct_plot(filepath):
    parameters, plot_data = load_plot_info(filepath)
    print("Parâmetros carregados:")
    for key, value in parameters.items():
        print(f"  {key} = {value}")
    
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.set_xlabel('Potência das Cargas (p.u.)')
    ax.set_ylabel('Tensão (p.u.)')
    ax.set_title('Gráfico Reconstruído a partir do Arquivo Salvo')
    ax.grid(True)
    
    # Recupera os dados e garante que sejam arrays unidimensionais
    A_carga   = np.atleast_1d(plot_data.get("A_CARGA"))
    A_tensao  = np.atleast_1d(plot_data.get("A_TENSAO"))
    D_carga   = np.atleast_1d(plot_data.get("D_CARGA"))
    D_tensao  = np.atleast_1d(plot_data.get("D_TENSAO"))
    analysis_results_antes = plot_data.get("analysis_results_antes")
    
    if analysis_results_antes!=[]:
        # Vetor de grupos
        vet_grupo = plot_data.get("vet_grupo")
        # Pontos iniciais:
        CARG_0 = plot_data.get("CARG_0")
        TENSAO_0 = plot_data.get("TENSAO_0")
        
        # Caso não haja informação de grupos, plota tudo com cores padrão
        if vet_grupo is None:
            sc_antes = ax.scatter(A_carga, A_tensao, color="green", s=100, label="Antes")
            ax.scatter(D_carga, D_tensao, color="red", s=100, label="Depois")
            
            # Conecta os pontos com linhas degradê
            num_interp = 100
            cmap = LinearSegmentedColormap.from_list("degrade", ["green", "red"])
            for x0, y0, x1, y1 in zip(A_carga, A_tensao, D_carga, D_tensao):
                x_vals = np.linspace(x0, x1, num=num_interp)
                y_vals = np.linspace(y0, y1, num=num_interp)
                points = np.array([x_vals, y_vals]).T.reshape(-1, 1, 2)
                segments = np.concatenate([points[:-1], points[1:]], axis=1)
                colors = [cmap(t) for t in np.linspace(0, 1, len(segments))]
                lc = LineCollection(segments, colors=colors, linewidth=2)
                ax.add_collection(lc)
            
            # Configura tooltips para os pontos "Antes"
            cursor = mplcursors.cursor(sc_antes, hover=True)
            @cursor.connect("add")
            def on_add(sel):
                ind = sel.index
                res = analysis_results_antes[ind]
                if res[0]:
                    text = f"Índices alterados: {res[0]}\nVariação (%): " + ", ".join(f"{p:.2f}%" for p in res[1])
                else:
                    text = "Sem alteração"
                sel.annotation.set_text(text)
                sel.annotation.get_bbox_patch().set(alpha=0.8, fc="white")
        else:
            # Garante que vet_grupo seja pelo menos 1D
            vet_grupo = np.atleast_1d(vet_grupo)
            if vet_grupo.size == 0:
                sc_antes = ax.scatter(A_carga, A_tensao, color="green", s=100, label="Antes")
                ax.scatter(D_carga, D_tensao, color="red", s=100, label="Depois")
            else:
                unique_groups = np.unique(vet_grupo)
                
                # Define os pares de cores para cada grupo
                color_pairs = [
                    ('green', 'red'),
                    ('blue', 'orange'),
                    ('purple', 'yellow'),
                    ('cyan', 'magenta'),
                    ('yellow', 'green'),
                    ('purple', 'red'),
                ]
                group_color_map = {}
                for i, grupo in enumerate(unique_groups):
                    group_color_map[grupo] = color_pairs[i % len(color_pairs)]
                
                num_interp = 100
                scatter_objs_antes = []  # Para armazenar os objetos de scatter e os índices dos pontos
                
                for grupo in unique_groups:
                    before_color, after_color = group_color_map[grupo]
                    indices_group = np.where(vet_grupo == grupo)[0]
                    
                    # Seleciona os dados dos pontos "Antes" e "Depois" para o grupo
                    A_carga_group   = np.atleast_1d(A_carga)[indices_group]
                    A_tensao_group  = np.atleast_1d(A_tensao)[indices_group]
                    D_carga_group   = np.atleast_1d(D_carga)[indices_group]
                    D_tensao_group  = np.atleast_1d(D_tensao)[indices_group]
                    
                    sc_antes = ax.scatter(A_carga_group, A_tensao_group, color=before_color, s=100, label=f'Grupo {grupo} - Antes')
                    ax.scatter(D_carga_group, D_tensao_group, color=after_color, s=100, label=f'Grupo {grupo} - Depois')
                    scatter_objs_antes.append((sc_antes, indices_group))
                    
                    # Cria um colormap específico para o grupo e desenha a linha degradê entre cada par de pontos
                    group_cmap = LinearSegmentedColormap.from_list(f'grupo_{grupo}_cmap', [before_color, after_color])
                    for i in indices_group:
                        x0, y0 = A_carga[i], A_tensao[i]
                        x1, y1 = D_carga[i], D_tensao[i]
                        x_vals = np.linspace(x0, x1, num=num_interp)
                        y_vals = np.linspace(y0, y1, num=num_interp)
                        points = np.array([x_vals, y_vals]).T.reshape(-1, 1, 2)
                        segments = np.concatenate([points[:-1], points[1:]], axis=1)
                        colors_segment = [group_cmap(t) for t in np.linspace(0, 1, len(segments))]
                        lc = LineCollection(segments, colors=colors_segment, linewidth=2)
                        ax.add_collection(lc)
                
                # Configura os tooltips para os pontos "Antes" de cada grupo
                for sc, indices_group in scatter_objs_antes:
                    texts = []
                    for idx in indices_group:
                        changed_idxs, percents = analysis_results_antes[idx]
                        if changed_idxs:
                            t = f"Índices alterados: {changed_idxs}\nVariação (%): " + ", ".join(f"{p:.2f}%" for p in percents)
                        else:
                            t = "Sem alteração"
                        texts.append(t)
                    cursor = mplcursors.cursor(sc, hover=True)
                    @cursor.connect("add")
                    def on_add(sel, texts=texts):
                        ind = sel.index
                        sel.annotation.set_text(texts[ind])
                        sel.annotation.get_bbox_patch().set(alpha=0.8, fc="white")
        
        # Plota o ponto inicial (estrelinha preta), se disponível
        if CARG_0 is not None and TENSAO_0 is not None:
            ax.scatter(CARG_0, TENSAO_0, color='black', marker='*', s=150, label='(INICIAL)')
        
        ax.legend()
        plt.show()
    else:
        ax.legend()
        plt.show()        
        print('NAO HA PONTOS A SER PLOTADO. FALSOS PONTOS IDENTIFICADOS.')





def save_pontos_fatorDePotencia_total(pontos_fatorDePotencia_PES, pontos_fatorDePotencia_PES_dep, tag, save_dir, forFilter, vet_name, fpInicial, PotPInicial, vet_TagDoInicial):
    """
    Salva duas matrizes de pontos em um arquivo CSV, junto com metadados adicionais.
    
    Parâmetros:
      - pontos_fatorDePotencia_PES: matriz (lista de 3 listas) com os dados originais.
      - pontos_fatorDePotencia_PES_dep: matriz (lista de 3 listas) com os dados dependentes.
      - tag: string para nomear o arquivo.
      - save_dir: diretório onde salvar.
      - forFilter: lista de índices para filtragem.
      - vet_name: lista de nomes das execuções.
      - fpInicial: valor inicial do fator de potência.
      - PotPInicial: coordenada Y do ponto inicial.
      - vet_TagDoInicial: lista de tags iniciais.
    """
    vetor_str = list(map(str, vet_TagDoInicial))
    os.makedirs(save_dir, exist_ok=True)
    filepath = os.path.join(save_dir, f"{tag}.csv")
    
    with open(filepath, mode='w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        
        # Escreve metadados
        writer.writerow(["Metadados"])
        writer.writerow(["tag", tag])
        writer.writerow(["fpInicial", fpInicial])
        writer.writerow(["PotPInicial", PotPInicial])
        writer.writerow(["forFilter", ','.join(map(str, forFilter))])
        writer.writerow(["vet_name", ','.join(vet_name)])
        writer.writerow(["vet_TagDoInicial", ','.join(vetor_str)])
        writer.writerow([])  # Linha vazia para separação
        
        # Escreve uma seção para pontos_fatorDePotencia_PES
        writer.writerow(["pontos_fatorDePotencia_PES"])
        for row in pontos_fatorDePotencia_PES:
            writer.writerow(row)
        
        writer.writerow([])  # Linha vazia para separação
        
        # Escreve uma seção para pontos_fatorDePotencia_PES_dep
        writer.writerow(["pontos_fatorDePotencia_PES_dep"])
        for row in pontos_fatorDePotencia_PES_dep:
            writer.writerow(row)
    
    print(f"Matrizes e metadados salvos em: {filepath}")











# def pega_nome_maiusculo(nome_arquivo):
#     # Separa o nome do arquivo da sua extensão
#     nome, ext = os.path.splitext(nome_arquivo)
#     # Retorna o nome em letras maiúsculas
#     return nome.upper()


def pega_nome_maiusculo(nome_arquivo):
    # Pega apenas o nome do arquivo com extensão
    nome_com_ext = os.path.basename(nome_arquivo)
    # Separa o nome da extensão
    nome, _ = os.path.splitext(nome_com_ext)
    # Retorna o nome em letras maiúsculas
    return nome.upper()


# def extrair_nome_sem_extensao(texto):
#     pos = texto.lower().find('.cdf')
#     if pos != -1:
#         # Extrai a substring antes de ".cdf" e converte para maiúsculas
#         return texto[:pos].upper()
#     else:
#         return texto.upper()




def CHAMA_saveCases_CDF(MATRIZ_TOTAL_PES, saveCaseUntil, output_dir, pattern, FilterDat, S_base):
    saveUntil=0
    #dadoscarga=[[0],FilterDat[4]]
    dadoscarga=MATRIZ_TOTAL_PES[0][20]
    vet_name=[]
    if len(FilterDat[0])<saveCaseUntil:
        cont=0
        if FilterDat[0]!=[]:
            while cont<len(FilterDat[0]):
                if saveUntil in FilterDat[6]:
                    if saveUntil<len(MATRIZ_TOTAL_PES):
                        PotPswing=(MATRIZ_TOTAL_PES[saveUntil][16][0])*(S_base)-FilterDat[4][cont][0]
                        dadoscarga[1]=FilterDat[4][cont]
                        (_,camposPlot)=Encabecalha_plot(MATRIZ_TOTAL_PES[saveUntil][14], MATRIZ_TOTAL_PES[saveUntil][15], MATRIZ_TOTAL_PES[saveUntil][16], MATRIZ_TOTAL_PES[saveUntil][17],MATRIZ_TOTAL_PES[saveUntil][18],MATRIZ_TOTAL_PES[saveUntil][19],dadoscarga) #Tabela
                        (_,camposPlotGer)=Encabecalha_plot_PotGer(MATRIZ_TOTAL_PES[saveUntil][16], MATRIZ_TOTAL_PES[saveUntil][17], MATRIZ_TOTAL_PES[saveUntil][18], MATRIZ_TOTAL_PES[saveUntil][25], dadoscarga) #Tabela
                        name=modificar_cdf(pattern, camposPlot, camposPlotGer, MATRIZ_TOTAL_PES[saveUntil][20], S_base, output_dir, PotPswing)   
                        cont=cont+1
                        #print('wai')
                        #exit()
                        vet_name.append([name, saveUntil])
                    else:
                        cont=cont+1
                saveUntil=saveUntil+1
    else:
        cont=0
        if FilterDat[0]!=[]:
            while cont<saveCaseUntil:
                if saveUntil in FilterDat[6]:
                    if saveUntil<len(MATRIZ_TOTAL_PES):
                        PotPswing=(MATRIZ_TOTAL_PES[saveUntil][16][0])*(-S_base)-FilterDat[4][cont][0]
                        dadoscarga[1]=FilterDat[4][cont]              
                        (_,camposPlot)=Encabecalha_plot(MATRIZ_TOTAL_PES[saveUntil][14], MATRIZ_TOTAL_PES[saveUntil][15], MATRIZ_TOTAL_PES[saveUntil][16], MATRIZ_TOTAL_PES[saveUntil][17],MATRIZ_TOTAL_PES[saveUntil][18],MATRIZ_TOTAL_PES[saveUntil][19],dadoscarga) #Tabela
                        (_,camposPlotGer)=Encabecalha_plot_PotGer(MATRIZ_TOTAL_PES[saveUntil][16], MATRIZ_TOTAL_PES[saveUntil][17], MATRIZ_TOTAL_PES[saveUntil][18], MATRIZ_TOTAL_PES[saveUntil][25], dadoscarga) #Tabela
                        name=modificar_cdf(pattern, camposPlot, camposPlotGer, MATRIZ_TOTAL_PES[saveUntil][20], S_base, output_dir, PotPswing)   
                        cont=cont+1
                        vet_name.append([name, saveUntil])
                        #print('wai')
                        #exit()

                        #modificar_cdf(pattern, camposPlot, camposPlotGer, matriz_DadosBarra, 100, output_dir) 
                    else:
                        cont=cont+1                        
                saveUntil=saveUntil+1
    return(vet_name)




def POEMtodomundoJUNTO (FILTRO_out_LEV, FILTRO_out_PES):
    if FILTRO_out_LEV!=[] and FILTRO_out_PES!=[]:
        A_TENSAO_LEV_de_diferencas=FILTRO_out_LEV[0]
        D_TENSAO_LEV_de_diferencas=FILTRO_out_LEV[1]
        A_CARGA_LEV_de_diferencas= FILTRO_out_LEV[2]
        D_CARGA_LEV_de_diferencas=FILTRO_out_LEV[3]
        CENARIO_LEV=FILTRO_out_LEV[4]
        CENARIO_LEVantes=FILTRO_out_LEV[5]
        forfutureFilter_LEV=FILTRO_out_LEV[6]
        vet_grupo_LEV=FILTRO_out_LEV[7]
        pontos_fatorDePotencia_LEV=FILTRO_out_LEV[8] 
        pontos_fatorDePotencia_LEV_dep=FILTRO_out_LEV[9] 

        A_TENSAO_PES_de_diferencas=FILTRO_out_PES[0]
        D_TENSAO_PES_de_diferencas=FILTRO_out_PES[1]
        A_CARGA_PES_de_diferencas= FILTRO_out_PES[2]
        D_CARGA_PES_de_diferencas=FILTRO_out_PES[3]
        CENARIO_PES=FILTRO_out_PES[4]
        CENARIO_PESantes=FILTRO_out_PES[5]
        forfutureFilter_PES=FILTRO_out_PES[6]
        vet_grupo_PES=FILTRO_out_PES[7]
        pontos_fatorDePotencia_PES=FILTRO_out_PES[8] 
        pontos_fatorDePotencia_PES_dep=FILTRO_out_PES[9] 


        A_TENSAO_PES_de_diferencas=A_TENSAO_LEV_de_diferencas+A_TENSAO_PES_de_diferencas
        D_TENSAO_PES_de_diferencas=D_TENSAO_LEV_de_diferencas+D_TENSAO_PES_de_diferencas
        A_CARGA_PES_de_diferencas=A_CARGA_LEV_de_diferencas+A_CARGA_PES_de_diferencas
        D_CARGA_PES_de_diferencas=D_CARGA_LEV_de_diferencas+D_CARGA_PES_de_diferencas
        CENARIO_PES=CENARIO_LEV+CENARIO_PES
        CENARIO_PESantes=CENARIO_LEVantes+CENARIO_PESantes
        forfutureFilter_PES=forfutureFilter_LEV+forfutureFilter_PES
        vet_grupo_PES=vet_grupo_LEV+vet_grupo_PES
        pontos_fatorDePotencia_PES[0]=pontos_fatorDePotencia_LEV[0]+pontos_fatorDePotencia_PES[0]
        pontos_fatorDePotencia_PES[1]=pontos_fatorDePotencia_LEV[1]+pontos_fatorDePotencia_PES[1]
        pontos_fatorDePotencia_PES[2]=pontos_fatorDePotencia_LEV[2]+pontos_fatorDePotencia_PES[2]
        pontos_fatorDePotencia_PES_dep[0]=pontos_fatorDePotencia_LEV_dep[0]+pontos_fatorDePotencia_PES_dep[0]
        pontos_fatorDePotencia_PES_dep[1]=pontos_fatorDePotencia_LEV_dep[1]+pontos_fatorDePotencia_PES_dep[1]
        pontos_fatorDePotencia_PES_dep[2]=pontos_fatorDePotencia_LEV_dep[2]+pontos_fatorDePotencia_PES_dep[2]
        FILTRO_out = [A_TENSAO_PES_de_diferencas, D_TENSAO_PES_de_diferencas, A_CARGA_PES_de_diferencas,
                      D_CARGA_PES_de_diferencas, CENARIO_PES, CENARIO_PESantes, forfutureFilter_PES, vet_grupo_PES,
                      pontos_fatorDePotencia_PES, pontos_fatorDePotencia_PES_dep]

    elif FILTRO_out_LEV!=[] and FILTRO_out_PES==[]:
        FILTRO_out=FILTRO_out_LEV
    elif FILTRO_out_LEV==[] and FILTRO_out_PES!=[]:
        FILTRO_out=FILTRO_out_PES
    elif FILTRO_out_LEV==[] and FILTRO_out_PES==[]:
        FILTRO_out=[]

    return(FILTRO_out)






# Função de controle de reativo
def controle_reativo (SYSname, MODELin, Tolerancia, limite_variacao, tipo_de_ESTUDO, PassoEstudo_DasCombinacoes, 
                      Minimizar_EspacoAmostral, ReduzirEspacoAmostral, tipo_de_REGIME, habilitar_Bloqueio_Por_PreviaChecagem, 
                      S_base, tolApresent, Tipo_de_logicaSuplementar, ComutacaoMaxima, Desabilitar_CS, Ativar_inverter, 
                      Diret_forPfCrv, filtrarDivergente, GirarTrafo):
 

    ''' ------------------------------------------------------------------------------------------------ '''
    ''' ------------------------------------ INICIALIZAÇÃO --------------------------------------------- '''
    ''' ------------------------------------------------------------------------------------------------ '''
    # Start timer
    parametro_de_verificacao=[]
    time = datetime.now()
    #time_date = datetime.fromtimestamp(time)
    parametro_de_verificacao.append([time.strftime("%H:%M:%S"),' INICIALIZAÇÃO '])
    print([time.strftime("%H:%M:%S"),' INICIALIZAÇÃO '])

    HabiltAval_Lim_Reativo='Y' #---Y or N
    peso=10
    PassoEstudo=5
    status_program='CDF' #---MANUAL or CDF (DADOS DE BARRA)
    alterar_tensao_decontrole_doCDF='X' #---X, A or B 
    
    matrizSystem=SYSname[0]
    matrizSystem2=SYSname[1]

    matrizSystem2 = corrige_duplicidadeDeLinha(matrizSystem2)
    ([matriz_DadosBarra],[infoVctrl])=DefineMatrizDadosBarra(matrizSystem, S_base, HabiltAval_Lim_Reativo, status_program, MODELin, None, alterar_tensao_decontrole_doCDF)
    (infoVctrl, matriz_DadosBarra)=liga_desliga_CS(matrizSystem, status_program, MODELin, None , alterar_tensao_decontrole_doCDF, S_base, HabiltAval_Lim_Reativo, Desabilitar_CS, matriz_DadosBarra, infoVctrl)
    num_barras = len(matrizSystem)
    PIndex = list(range(num_barras))
    ATIVA_ESPEC=extrair_potencias_negativas(matrizSystem)
    ATIVA_ESPEC0=extrair_potencias_negativas(matrizSystem)
    ATIVA_ESPEC00A=extrair_potencias_negativas(matrizSystem)
   
    PVbarIndex, TENSAO_ESPEC, QIndex, REATIVA_ESPEC, GIndex, GERADOR, MinMaxIndex, Qmin, Qmax = extrair_vetores_da_matrizSystem(matrizSystem)
    ATIVA_ESPEC_index, ATIVA_ESPEC_reduzida = identificar_indices_e_valores(ATIVA_ESPEC)
    
    modelagem_linha = MODELin # Tipo de modelo da linha (PI ou T)
    matrizSystem, matrizSystem2, modelagem_resultante = alterar_matrizes(matrizSystem, matrizSystem2, modelagem_linha)
    MatrizY=calcularMATRIZ_Y(matrizSystem, matrizSystem2, Ativar_inverter, GirarTrafo)


    eliminar_se_NAO_tem_CARGA='yes'
    REGIME_de_CARGA='ambos' #leve, pesada, ambos     
    tipo_BARRA_de_ESTUDO='PQPVfacultativo' # PQ, PQPV, PQPVfacultativo
    ## APENAS barras com cargas NÃO NULAS:

    status_program = 'MANUAL'
    momentoTirarfoto='no'
    jatirouafoto='no'
    sinal='no'



    if jatirouafoto=='no':
        PotP_Lim_Func=None
        PotQ_Lim_Func=None
        infoVctrl_Lim_Func=None
        Barras_PQ_Lim_Func=None
        matriz_DadosBarra_Lim_Func=None
        cont_Lim_Func=None
        DeltaV_Lim_Func=None
        Delta0_Lim_Func=None

    limita_EspacoAmostral=20
    CONTAR_POTP=0
    for auxiliar_min_EspacoAmostral in range(len(ATIVA_ESPEC)):
        if auxiliar_min_EspacoAmostral!=0:
            if ATIVA_ESPEC[auxiliar_min_EspacoAmostral]!=0:
                CONTAR_POTP=CONTAR_POTP+1

    ''' ------------------------------------------------------------------------------------------------ '''
    ''' ------------------------------------ FLUXO INICIAL --------------------------------------------- '''
    ''' ------------------------------------------------------------------------------------------------ '''
    try:
        # MatrizCarregamento = criar_matriz_esparsa_com_indices(
        #     PVbarIndex, TENSAO_ESPEC, PIndex, ATIVA_ESPEC, GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
        # )
        # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
        #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
        # )

        # Execução do fluxo de potência
        # (DeltaV_0, Delta0_0, PotP_0, PotQ_0, _, _, cont_0, MatrizY_0, Barras_PQ_0 , _, _, BarraQViola_estatica_0, _, _, _, _, _, _, _, _, _, _, VerificaSeViola_0) = CHAMA_FLNR_03_LTT(
        #     matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal
        # )
        (DeltaV_0, Delta0_0, PotP_0, PotQ_0, _, _, cont_0, _, Barras_PQ_0, _, _,BarraQViola_estatica_0,_, _, _, _, _, _, _, _, _, _, VerificaSeViola_0, _, _, _)=CHAMA_FLNR_03_LTT (matrizSystem,matrizSystem2,matriz_DadosBarra,infoVctrl,MODELin,Tolerancia,'no', None, None, None, None, None, None, None, None, 'no', None, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY)
        
        # ##PLOTAGEM
        # print('\n')
        # print('------------------------------------------------------') 
        # print('---------------------(GRAVAÇÃO 0)---------------------') 
        # print('------------------------------------------------------')  
        # plot(DeltaV_0, Delta0_0, PotP_0, PotQ_0,infoVctrl,cont_0)
        # plot_PotGer(PotP_0, PotQ_0, infoVctrl, Barras_PQ_0 , matriz_DadosBarra)

    except Exception as e:
        Fluxo_divergente_0='yes'
        BarraQViola_estatica_0=[1]*len(ATIVA_ESPEC)
        VerificaSeViola_0=['FLUXO DIVERGENTE']*len(ATIVA_ESPEC)              
        #print('FLUXO DIVERGENTE EM REGIME DE CARGA INICIAL')
        DeltaV_0=[0]*len(ATIVA_ESPEC)
        Delta0_0=[0]*len(ATIVA_ESPEC)
        PotP_0=[0]*len(ATIVA_ESPEC)
        PotQ_0=[0]*len(ATIVA_ESPEC)
        Barras_PQ_0=['N']*len(ATIVA_ESPEC)
        cont_0=0



    
    
    ''' ------------------------------------------------------------------------------------------------ '''
    ''' ------------------------------------ INTERTRAVAMENTO ------------------------------------------- '''
    ''' ------------------------------------------------------------------------------------------------ '''
    # timer
    # time = datetime.now()
    # #time_date = datetime.fromtimestamp(time_N1)
    # parametro_de_verificacao.append([time,' INTERTRAVAMENTO '])
    # print([time,' INTERTRAVAMENTO '])

    if CONTAR_POTP<=limita_EspacoAmostral and ReduzirEspacoAmostral=='no':
        resultado = criar_vetores_carga(ATIVA_ESPEC00A, eliminar_se_NAO_tem_CARGA, limite_variacao, REGIME_de_CARGA, tipo_BARRA_de_ESTUDO, PVbarIndex)
        tamanho_final = len(ATIVA_ESPEC00A)

        resultado_corrigido_melhorado = corrigir_resultado_melhorado(resultado, ATIVA_ESPEC00A, REGIME_de_CARGA, tipo_BARRA_de_ESTUDO)
        #print("Resultado_corrigido:", resultado_corrigido_melhorado)
    
    else:
        try:
            PVbarIndex_modific, ATIVA_ESPEC00A_index_modific, ATIVA_ESPEC00A_modific = process_intervals(
                ATIVA_ESPEC00A, PVbarIndex, Minimizar_EspacoAmostral, len(ATIVA_ESPEC00A)
            )
        except Exception as e:
            print('CORRIJA A VARIÁVEL: Minimizar_EspacoAmostral') 
            print('                       ENTRADA INVÁLIDA'    )  
            exit()  
        
        PQPV_up, PQPV_down, PV_up, PV_down = create_modified_vectors(
            ATIVA_ESPEC00A_modific, ATIVA_ESPEC00A_index_modific, PVbarIndex_modific, limite_variacao
        )
        
        PQPV_down_new, PQPV_up_new, PV_down_new, PV_up_new = create_new_vectors(
            ATIVA_ESPEC00A, ATIVA_ESPEC00A_index_modific, PQPV_down, PQPV_up, PV_down, PV_up
        )
        
        resultado_corrigido_melhorado=[]       
        indices_de_barra=[]
        for auxiliar_intertravamento1 in range (len(ATIVA_ESPEC00A)):
            indices_de_barra.append(auxiliar_intertravamento1)

        resultado_corrigido_melhorado.append(indices_de_barra)
        resultado_corrigido_melhorado.append(PQPV_down_new)
        resultado_corrigido_melhorado.append(PQPV_up_new)
        resultado_corrigido_melhorado.append(indices_de_barra)
        resultado_corrigido_melhorado.append(PV_down_new)
        resultado_corrigido_melhorado.append(PV_up_new)  
        #print('ATIVA_ESPEC00A=',ATIVA_ESPEC00A) 
        # print('PVbarIndex=',PVbarIndex)
        # print('Minimizar_EspacoAmostral=',Minimizar_EspacoAmostral)
        #print('\n')
                 
        # print('ATIVA_ESPEC00A_modific=',ATIVA_ESPEC00A_modific)
        # print('ATIVA_ESPEC00A_index_modific=',ATIVA_ESPEC00A_index_modific) 
        # print('PVbarIndex_modific=',PVbarIndex_modific)
        # print('Minimizar_EspacoAmostral=',Minimizar_EspacoAmostral)

        # print('ATIVA_ESPEC00A_index_modific=',ATIVA_ESPEC00A_index_modific)
        # print('PVbarIndex_modific=',PVbarIndex_modific)
        # print('PQPV_down=',PQPV_down)
        # #print('PQPV_down=',PQPV_down)
        # print('PQPV_up=',PQPV_up) 
        # print('PV_down=',PV_down)
        # print('PV_up=',PV_up)        

  


    # for AUXILIAR in range(len(resultado_corrigido_melhorado[2])):
    #     matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[2][AUXILIAR]))/S_base
    #     matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
    #     matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
    #     matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
    #     matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
    #     infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
    #     matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[2][AUXILIAR]))


    # try: ## PQPV pesada
    #     # Execução do fluxo de potência
    #     (DeltaV_PQPVpes, Delta0_PQPVpes, PotP_PQPVpes, PotQ_PQPVpes, _, _, cont_PQPVpes, MatrizY_PQPVpes, Barras_PQ_PQPVpes , _, _, BarraQViola_estatica_PQPVpes, _, _, _, _, _, _, _, _, _, _, VerificaSeViola_PQPVpes, _, _, _) = CHAMA_FLNR_03_LTT(
    #         matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
    #     )

    #     # ##PLOTAGEM
    #     # print('\n')
    #     # print('------------------------------------------------------') 
    #     # print('---------------------(PQPV PESADA)--------------------') 
    #     # print('------------------------------------------------------')  
    #     # plot(DeltaV_PQPVpes, Delta0_PQPVpes, PotP_PQPVpes, PotQ_PQPVpes,infoVctrl,cont_PQPVpes)
    #     # plot_PotGer(PotP_PQPVpes, PotQ_PQPVpes, infoVctrl, Barras_PQ_PQPVpes , matriz_DadosBarra)


    #     # print(BarraQViola_estatica_PQPVpes)
    #     # print(Barras_PQ_PQPVpes)

    # except Exception as e:
    #     Fluxo_divergente_PQPVpes='yes'
    #     BarraQViola_estatica_PQPVpes=[1]*len(ATIVA_ESPEC)
    #     VerificaSeViola_PQPVpes=['FLUXO DIVERGENTE']*len(ATIVA_ESPEC)        
    #     # print('FLUXO DIVERGENTE EM REGIME DE CARGA (PQPV) PESADA.')
    #     # print('(reduza a porcentagem de variacao)')



    # for AUXILIAR in range(len(resultado_corrigido_melhorado[1])):
    #     matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[1][AUXILIAR]))/S_base
    #     matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
    #     matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
    #     matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
    #     matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
    #     infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
    #     matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[1][AUXILIAR]))

    # try: ## PQPV leve  
    #     # Execução do fluxo de potência
    #     (DeltaV_PQPVlev, Delta0_PQPVlev, PotP_PQPVlev, PotQ_PQPVlev, _, _, cont_PQPVlev, MatrizY_PQPVlev, Barras_PQ_PQPVlev , _, _, BarraQViola_estatica_PQPVlev, _, _, _, _, _, _, _, _, _, _, VerificaSeViola_PQPVlev, _, _, _) = CHAMA_FLNR_03_LTT(
    #         matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
    #     )
        
    #     # ##PLOTAGEM
    #     # print('\n')
    #     # print('------------------------------------------------------') 
    #     # print('----------------------(PQPV LEVE)---------------------') 
    #     # print('------------------------------------------------------')  
    #     # plot(DeltaV_PQPVlev, Delta0_PQPVlev, PotP_PQPVlev, PotQ_PQPVlev,infoVctrl,cont_PQPVlev)
    #     # plot_PotGer(PotP_PQPVlev, PotQ_PQPVlev, infoVctrl, Barras_PQ_PQPVlev , matriz_DadosBarra)

    # except Exception as e:
    #     Fluxo_divergente_PQPVlev='yes'
    #     BarraQViola_estatica_PQPVlev=[1]*len(ATIVA_ESPEC)
    #     VerificaSeViola_PQPVlev=['FLUXO DIVERGENTE']*len(ATIVA_ESPEC)        
    #     # print('FLUXO DIVERGENTE EM REGIME DE CARGA (PQPV) LEVE.')
    #     # print('(reduza a porcentagem de variacao)')



    # for AUXILIAR in range(len(resultado_corrigido_melhorado[5])):
    #     matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[5][AUXILIAR]))/S_base
    #     matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
    #     matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
    #     matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
    #     matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
    #     infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
    #     matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[5][AUXILIAR]))

    # try: ## PQ pesada
    #     # Execução do fluxo de potência
    #     (DeltaV_PQpes, Delta0_PQpes, PotP_PQpes, PotQ_PQpes, _, _, cont_PQpes, MatrizY_PVpes, Barras_PQ_PQpes , _, _, BarraQViola_estatica_PQpes, _, _, _, _, _, _, _, _, _, _, VerificaSeViola_PQpes, _, _, _) = CHAMA_FLNR_03_LTT(
    #         matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
    #     )

    #     # ##PLOTAGEM
    #     # print('\n')
    #     # print('------------------------------------------------------') 
    #     # print('----------------------(PQ PESADA)---------------------') 
    #     # print('------------------------------------------------------')  
    #     # plot(DeltaV_PQpes, Delta0_PQpes, PotP_PQpes, PotQ_PQpes,infoVctrl,cont_PQpes)
    #     # plot_PotGer(PotP_PQpes, PotQ_PQpes, infoVctrl, Barras_PQ_PQpes , matriz_DadosBarra)

    # except Exception as e:
    #     Fluxo_divergente_PQpes='yes'
    #     BarraQViola_estatica_PQpes=[1]*len(ATIVA_ESPEC)
    #     VerificaSeViola_PQpes=['FLUXO DIVERGENTE']*len(ATIVA_ESPEC)
    #     # print('FLUXO DIVERGENTE EM REGIME DE CARGA (PQ) PESADA.')
    #     # print('(reduza a porcentagem de variacao)')



    # for AUXILIAR in range(len(resultado_corrigido_melhorado[4])):
    #     matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[4][AUXILIAR]))/S_base
    #     matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
    #     matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
    #     matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
    #     matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
    #     infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
    #     matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[4][AUXILIAR]))

    # try: ## PQ leve
    #     # Execução do fluxo de potência
    #     (DeltaV_PQlev, Delta0_PQlev, PotP_PQlev, PotQ_PQlev, _, _, cont_PQlev, MatrizY_PQlev, Barras_PQ_PQlev , _, _, BarraQViola_estatica_PQlev, _, _, _, _, _, _, _, _, _, _, VerificaSeViola_PQlev, _, _, _) = CHAMA_FLNR_03_LTT(
    #         matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
    #     )

    #     # ##PLOTAGEM
    #     # print('\n')
    #     # print('------------------------------------------------------') 
    #     # print('----------------------(PQ LEVE)---------------------') 
    #     # print('------------------------------------------------------')  
    #     # plot(DeltaV_PQlev, Delta0_PQlev, PotP_PQlev, PotQ_PQlev,infoVctrl,cont_PQlev)
    #     # plot_PotGer(PotP_PQlev, PotQ_PQlev, infoVctrl, Barras_PQ_PQlev , matriz_DadosBarra)

    # except Exception as e:
    #     Fluxo_divergente_PQlev='yes'
    #     BarraQViola_estatica_PQlev=[1]*len(ATIVA_ESPEC)
    #     VerificaSeViola_PQlev=['FLUXO DIVERGENTE']*len(ATIVA_ESPEC)
    #     #print('FLUXO DIVERGENTE EM REGIME DE (PQ) LEVE.')
    #     #print('(reduza a porcentagem de variacao)')


    # print('BarraQViola_estatica_0=',BarraQViola_estatica_0)
    # print('BarraQViola_estatica_PQPVpes=',BarraQViola_estatica_PQPVpes)
    # print('BarraQViola_estatica_PQPVlev=',BarraQViola_estatica_PQPVlev)
    # print('BarraQViola_estatica_PQpes=',BarraQViola_estatica_PQpes)    
    # print('BarraQViola_estatica_PQlev=',BarraQViola_estatica_PQlev)
    # print('VerificaSeViola_PQPVpes=',VerificaSeViola_0)
    # print('VerificaSeViola_PQPVpes=',VerificaSeViola_PQPVpes)
    # print('VerificaSeViola_PQPVlev=',VerificaSeViola_PQPVlev)
    # print('VerificaSeViola_PQpes=',VerificaSeViola_PQpes)
    # print('VerificaSeViola_PQlev=',VerificaSeViola_PQlev)



    ''' ------------------------------------------------------------------------------------------------ '''
    ''' ------------------------------------ ANÁLISE COMBINATÓRIA -------------------------------------- '''
    ''' ------------------------------------------------------------------------------------------------ '''
    #  timer
    time = datetime.now()
    #time_date = datetime.fromtimestamp(time)
    parametro_de_verificacao.append([time.strftime("%H:%M:%S"),' ANÁLISE COMBINATÓRIA '])
    print([time.strftime("%H:%M:%S"),' ANÁLISE COMBINATÓRIA '])
 
    
    if CONTAR_POTP<=limita_EspacoAmostral and ReduzirEspacoAmostral=='no':
        identificou_swing, indices_modificados, valores_modificados = verificar_eliminar_zero_e_atualizar(ATIVA_ESPEC_index, ATIVA_ESPEC_reduzida)
        # for aux in range(len(indices_modificados)):
        #     indices_modificados[aux]=indices_modificados[aux]-1

        if identificou_swing=='no':
            # Cálculos para limite_variacao = 25%
            delta_025 = aplicar_limite_variacao(ATIVA_ESPEC_reduzida, -limite_variacao)
            combinacoes_025 = gerar_combinacoes(ATIVA_ESPEC_index)
            resultados_com_delta_025, matrizes_indices_025 = aplicar_delta_e_matriz(ATIVA_ESPEC_reduzida, combinacoes_025, ATIVA_ESPEC_index, delta_025)
            matrizes_substituidas_025 = substituir_indices_por_ATIVA_ESPEC_index(matrizes_indices_025, ATIVA_ESPEC_index)
            matrizes_PV_025, matrizes_PQ_025, matrizes_PQPV_025, PQbarIndex_025 = dividir_matrizes(matrizes_substituidas_025, PVbarIndex, ATIVA_ESPEC_index)

            # Cálculos para limite_variacao = -25%
            delta_125 = aplicar_limite_variacao(ATIVA_ESPEC_reduzida, limite_variacao)
            # print(delta_125)
            combinacoes_125 = gerar_combinacoes(ATIVA_ESPEC_index)
            resultados_com_delta_125, matrizes_indices_125 = aplicar_delta_e_matriz(ATIVA_ESPEC_reduzida, combinacoes_125, ATIVA_ESPEC_index, delta_125)
            matrizes_substituidas_125 = substituir_indices_por_ATIVA_ESPEC_index(matrizes_indices_125, ATIVA_ESPEC_index)
            matrizes_PV_125, matrizes_PQ_125, matrizes_PQPV_125, PQbarIndex_125  = dividir_matrizes(matrizes_substituidas_125, PVbarIndex, ATIVA_ESPEC_index)
            # print(resultados_com_delta_125[2022])
            # print(resultados_com_delta_025[2022])
            # print(matrizes_substituidas_025[2022])
            # print(matrizes_substituidas_125[2022])
            # print(ATIVA_ESPEC_index)
            # print('aqui')
        else:
            # Cálculos para limite_variacao = 25%
            delta_025 = aplicar_limite_variacao(valores_modificados, -limite_variacao)
            combinacoes_025 = gerar_combinacoes(indices_modificados)
            resultados_com_delta_025, matrizes_indices_025 = aplicar_delta_e_matriz(valores_modificados, combinacoes_025, indices_modificados, delta_025)
            matrizes_substituidas_025 = substituir_indices_por_ATIVA_ESPEC_index(matrizes_indices_025, indices_modificados)
            matrizes_PV_025, matrizes_PQ_025, matrizes_PQPV_025, PQbarIndex_025 = dividir_matrizes(matrizes_substituidas_025, PVbarIndex, indices_modificados)
            # print(resultados_com_delta_025[2022])
            # print(matrizes_substituidas_025[2022])

            # Cálculos para limite_variacao = -25%
            delta_125 = aplicar_limite_variacao(valores_modificados, limite_variacao)
            combinacoes_125 = gerar_combinacoes(indices_modificados)
            resultados_com_delta_125, matrizes_indices_125 = aplicar_delta_e_matriz(valores_modificados, combinacoes_125, indices_modificados, delta_125)
            matrizes_substituidas_125 = substituir_indices_por_ATIVA_ESPEC_index(matrizes_indices_125, indices_modificados)
            matrizes_PV_125, matrizes_PQ_125, matrizes_PQPV_125, PQbarIndex_125 = dividir_matrizes(matrizes_substituidas_125, PVbarIndex, indices_modificados)
    else:
        Barras_a_Estarem_no_Estudo = processar_intervalos(Minimizar_EspacoAmostral , ATIVA_ESPEC, limita_EspacoAmostral)
        identificou_swing, indices_modificados, valores_modificados = verificar_eliminar_zero_e_atualizar(Barras_a_Estarem_no_Estudo, ATIVA_ESPEC_reduzida)
        #if identificou_swing=='yes':
        
        valores_modificados2=[]
        for auxXx in indices_modificados:
            #if ATIVA_ESPEC0[auxXx]!=0:
            valores_modificados2.append(ATIVA_ESPEC0[auxXx])

        for aux in range(len(indices_modificados)):
            indices_modificados[aux]=indices_modificados[aux]+1

        valores_modificados_outraVez = mapear_valores(Barras_a_Estarem_no_Estudo, indices_modificados, valores_modificados2)
        valores_modificados=valores_modificados_outraVez[1]
        indices_modificados=valores_modificados_outraVez[0]
        for aux in range(len(indices_modificados)):
            indices_modificados[aux]=indices_modificados[aux]-1
        #print(resultado)
        # print('Barras_a_Estarem_no_Estudo=',Barras_a_Estarem_no_Estudo)
        # print('indices_modificados=',indices_modificados)
        # print('valores_modificados=',valores_modificados)

        if identificou_swing=='no':
            # Cálculos para limite_variacao = 25%
            delta_025 = aplicar_limite_variacao(valores_modificados, -limite_variacao)
            combinacoes_025 = gerar_combinacoes(indices_modificados)
            resultados_com_delta_025, matrizes_indices_025 = aplicar_delta_e_matriz(valores_modificados, combinacoes_025, indices_modificados, delta_025)
            matrizes_substituidas_025 = substituir_indices_por_ATIVA_ESPEC_index(matrizes_indices_025, indices_modificados)
            matrizes_PV_025, matrizes_PQ_025, matrizes_PQPV_025, PQbarIndex_025 = dividir_matrizes(matrizes_substituidas_025, PVbarIndex, indices_modificados)

            # Cálculos para limite_variacao = -25%
            delta_125 = aplicar_limite_variacao(valores_modificados, limite_variacao)
            # print(delta_125)
            combinacoes_125 = gerar_combinacoes(indices_modificados)
            resultados_com_delta_125, matrizes_indices_125 = aplicar_delta_e_matriz(valores_modificados, combinacoes_125, indices_modificados, delta_125)
            matrizes_substituidas_125 = substituir_indices_por_ATIVA_ESPEC_index(matrizes_indices_125, indices_modificados)
            matrizes_PV_125, matrizes_PQ_125, matrizes_PQPV_125, PQbarIndex_125  = dividir_matrizes(matrizes_substituidas_125, PVbarIndex, indices_modificados)
            # print(resultados_com_delta_125[2022])
            # print(resultados_com_delta_025[2022])
            # print(matrizes_substituidas_025[2022])
            # print(matrizes_substituidas_125[2022])
            # print(ATIVA_ESPEC_index)
            # print('aqui')
        else:
            # Cálculos para limite_variacao = 25%
            delta_025 = aplicar_limite_variacao(valores_modificados, -limite_variacao)
            combinacoes_025 = gerar_combinacoes(indices_modificados)
            resultados_com_delta_025, matrizes_indices_025 = aplicar_delta_e_matriz(valores_modificados, combinacoes_025, indices_modificados, delta_025)
            matrizes_substituidas_025 = substituir_indices_por_ATIVA_ESPEC_index(matrizes_indices_025, indices_modificados)
            matrizes_PV_025, matrizes_PQ_025, matrizes_PQPV_025, PQbarIndex_025 = dividir_matrizes(matrizes_substituidas_025, PVbarIndex, indices_modificados)
            # print(resultados_com_delta_025[2022])
            # print(matrizes_substituidas_025[2022])

            # Cálculos para limite_variacao = -25%
            delta_125 = aplicar_limite_variacao(valores_modificados, limite_variacao)
            combinacoes_125 = gerar_combinacoes(indices_modificados)
            resultados_com_delta_125, matrizes_indices_125 = aplicar_delta_e_matriz(valores_modificados, combinacoes_125, indices_modificados, delta_125)
            matrizes_substituidas_125 = substituir_indices_por_ATIVA_ESPEC_index(matrizes_indices_125, indices_modificados)
            matrizes_PV_125, matrizes_PQ_125, matrizes_PQPV_125, PQbarIndex_125 = dividir_matrizes(matrizes_substituidas_125, PVbarIndex, indices_modificados)
        
        #print('aqui')
    # print(PQbarIndex_025)
    # print(PQbarIndex_125)
    # # # Exibindo resultados
    # print("\nMatrizes PV 025:")
    # for matriz in matrizes_PV_025[:20]:
    #     print(matriz)

    # # print("\nMatrizes PQ 025:")
    # # for matriz in matrizes_PQ_025[:5]:
    # #     print(matriz)

    # print("\nMatrizes PQPV 025:")
    # for matriz in matrizes_PQPV_025[:20]:
    #     print(matriz)

    # print('PVbarIndex=', PVbarIndex)
    # print('ATIVA_ESPEC=', ATIVA_ESPEC)
    PVbarIndex_corrigido = corrigir_PVbarIndex(PVbarIndex, ATIVA_ESPEC)
    
    # Filtrando as linhas que contêm todos os elementos necessários
    PQtotal_U_PV = filtrar_linhas_com_elementosPQouPVtotal(matrizes_PQPV_025, PQbarIndex_025)
    PVtotal_U_PQ = filtrar_linhas_com_elementosPQouPVtotal(matrizes_PQPV_025, PVbarIndex_corrigido)
    # print("Linhas que contêm todos os elementos necessários:")
    # for linha in PVtotal_U_PQ:
    #     print(linha)
    indices_encontrados = buscar_indices_matrizes(matrizes_substituidas_125, PQtotal_U_PV)
    #indices_encontradosPVtot = buscar_indices_matrizes(matrizes_substituidas_125, PVtotal_U_PQ)
    indices_encontradosPVtot = buscar_indices_matrizes(matrizes_substituidas_125, matrizes_PV_125)
    indices_encontradosPQsomente = buscar_indices_matrizes(matrizes_substituidas_125, matrizes_PQ_125)
    # print("\nMatrizes PV 125:")
    # for matriz in matrizes_PV_125[:5]:
    #     print(matriz)

    # print("\nMatrizes PQ 125:")
    # for matriz in matrizes_PQ_125[:5]:
    #     print(matriz)

    # print("\nMatrizes PQPV 125:")
    # for matriz in matrizes_PQPV_125[:5]:
    #     print(matriz)

    # print(ATIVA_ESPEC_index)




    # if  habilitar_Bloqueio_Por_PreviaChecagem=='habilitar':
    #     resultado_PQPVpes, indicador_PQPVpes = detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_PQPVpes, VerificaSeViola_PQPVpes)
    #     resultado_PQPVlev, indicador_PQPVlev = detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_PQPVlev, VerificaSeViola_PQPVlev)
    #     resultado_PQpes, indicador_PQpes = detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_PQpes, VerificaSeViola_PQpes)
    #     resultado_PQlev, indicador_PQlev = detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_PQlev, VerificaSeViola_PQlev)  

    #     if resultado_PQPVpes==False:
    #         PQPVpes='no'
    #     else:
    #         PQPVpes='yes'

    #     if resultado_PQPVlev==False:
    #         PQPVlev='no'
    #     else:
    #         PQPVlev='yes'

    #     if resultado_PQpes==False:
    #         PQpes='no'
    #     else:
    #         PQpes='yes'
    
    #     if resultado_PQlev==False:
    #         PQlev='no'
    #     else:
    #         PQlev='yes'             
    # else:
    #     PQPVpes='yes'
    #     PQPVlev='yes'
    #     PQpes='yes'
    #     PQlev='yes' 

    PQPVpes='yes'
    PQPVlev='yes'
    PQpes='yes'
    PQlev='yes'

    Lista_de_Candidatos_T3=[] 
    Lista_de_Candidatos_T3_index=[]
    Lista_de_Candidatos_T4=[] 
    Lista_de_Candidatos_T4_index=[]    

    Lista_de_Candidatos_T1=[] 
    Lista_de_Candidatos_T1_index=[] 
    Lista_de_Candidatos_T2=[] 
    Lista_de_Candidatos_T2_index=[] 
    Lista_de_Candidatos_T1_siOrno=[]
    Lista_de_Candidatos_T2_siOrno=[]

    Lista_de_Candidatos_T1pv=[] 
    Lista_de_Candidatos_T1pv_index=[] 
    Lista_de_Candidatos_T2pv=[] 
    Lista_de_Candidatos_T2pv_index=[] 
    Lista_de_Candidatos_T1pv_siOrno=[]
    Lista_de_Candidatos_T2pv_siOrno=[]
   
    candidate_bloc=[]
    candidateviola=[]



    ''' ------------------------------------------------------------------------------------------------ '''
    ''' ------------------------------------ ANÁLISE DE CANDITADOS ------------------------------------- '''
    ''' ------------------------------------------------------------------------------------------------ '''
    if (tipo_de_ESTUDO=='Segregar (PQ)_(PV)') or (tipo_de_ESTUDO=='Segregar (PV)'):

        # D_Lista_de_Candidatos_T1=[] 
        # D_Lista_de_Candidatos_T1_index=[] 
        # D_Lista_de_Candidatos_T2=[] 
        # D_Lista_de_Candidatos_T2_index=[] 

        # D_Lista_de_Candidatos_T1pv=[] 
        # D_Lista_de_Candidatos_T1pv_index=[] 
        # D_Lista_de_Candidatos_T2pv=[] 
        # D_Lista_de_Candidatos_T2pv_index=[] 

        ## TESTES
        if len(matrizes_PV_125)!=0:
            if PQPVpes=='yes' and PQPVlev=='no':
                if tipo_de_REGIME=='pesado' or tipo_de_REGIME=='ambos':
                    #  timer
                    time = datetime.now()
                    #time_date = datetime.fromtimestamp(time)
                    parametro_de_verificacao.append([time.strftime("%H:%M:%S"),' ANÁLISE DE PONTOS CANDITADOS: REGIME PESADO ']) 
                    print([time.strftime("%H:%M:%S"),' ANÁLISE DE PONTOS CANDITADOS: REGIME PESADO '])              
                    
                    for k in range(len(indices_encontrados)):
                        if CONTAR_POTP<=limita_EspacoAmostral and ReduzirEspacoAmostral=='no':
                            resultado = (resultado[0],resultados_com_delta_025[indices_encontrados[k]], resultados_com_delta_125[indices_encontrados[k]])  
                        else:
                            resultado = (indices_modificados,resultados_com_delta_025[indices_encontrados[k]], resultados_com_delta_125[indices_encontrados[k]])
                        
                        resultado_corrigido_melhorado = corrigir_resultado_melhorado(resultado, ATIVA_ESPEC00A, REGIME_de_CARGA, 'PQPV')
                        #print("Resultado_corrigido:", resultado_corrigido_melhorado)

                        # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                        #     PVbarIndex, TENSAO_ESPEC, PIndex, resultado_corrigido_melhorado[2], GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                        # )
                        
                        # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                        #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                        # )
                        for AUXILIAR in range(len(resultado_corrigido_melhorado[2])):
                            matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[2][AUXILIAR]))/S_base
                            matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                            matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                            matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                            matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                            infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                            matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[2][AUXILIAR]))

                        try:
                            # Execução do fluxo de potência
                            (DeltaV_T1, Delta0_T1, PotP_T1, PotQ_T1, _, _, cont_T1, _, Barras_PQ_T1 , _, _, BarraQViola_estatica_T1, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola_T1, _, _, _) = CHAMA_FLNR_03_LTT(
                                matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                            )
                        except Exception as e:
                            Fluxo_divergente_T1='yes'
                            BarraQViola_estatica_T1=[1]*len(ATIVA_ESPEC)
                            VerificaSeViola_T1=['ViolaPB']*len(ATIVA_ESPEC)
                    
                        resultado_T1, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_T1, VerificaSeViola_T1)
                        if resultado_T1==False:
                            Lista_de_Candidatos_T1.append(resultado_corrigido_melhorado[2])
                            Lista_de_Candidatos_T1_index.append(resultados_com_delta_125[indices_encontrados[k]])
                            Lista_de_Candidatos_T1_siOrno.append('no')

                            # ##PLOTAGEM
                            # print('\n')
                            # print('------------------------------------------------------') 
                            # print('--------------------------(T1)------------------------') 
                            # print('--------------------- PQPV pesada --------------------')  
                            # plot(DeltaV_T1, Delta0_T1, PotP_T1, PotQ_T1,infoVctrl,cont_T1)
                            # plot_PotGer(PotP_T1, PotQ_T1, infoVctrl, Barras_PQ_T1 , matriz_DadosBarra)
                        else:
                            Lista_de_Candidatos_T1_siOrno.append('yes')
                            Lista_de_Candidatos_T1.append(resultado_corrigido_melhorado[2])    
                            Lista_de_Candidatos_T1_index.append(matrizes_substituidas_125[indices_encontrados[k]])

                    
                    if CONTAR_POTP<=limita_EspacoAmostral and ReduzirEspacoAmostral=='no':
                        resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]], resultados_com_delta_125[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]])  
                    else:
                        resultado = (indices_modificados, resultados_com_delta_025[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]], resultados_com_delta_125[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]])

                    #resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]], resultados_com_delta_125[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]])
                    resultado_corrigido_melhorado = corrigir_resultado_melhorado(resultado, ATIVA_ESPEC00A, REGIME_de_CARGA, 'PQPV')
                    #print("Resultado_corrigido:", resultado_corrigido_melhorado)

                    # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                    #     PVbarIndex, TENSAO_ESPEC, PIndex, resultado_corrigido_melhorado[2], GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                    # )
                    # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                    #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                    # )
                    for AUXILIAR in range(len(resultado_corrigido_melhorado[2])):
                        matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[2][AUXILIAR]))/S_base
                        matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                        matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                        matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                        matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                        infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                        matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[2][AUXILIAR]))

                    try:
                        # Execução do fluxo de potência
                        ( _, _, _, _, _, _, _ , _, _ , _, _, BarraQViola_estatica_T1pvpv, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola_T1pvpv, _, _, _) = CHAMA_FLNR_03_LTT(
                            matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                        )
                    except Exception as e:
                        Fluxo_divergente_T1pvpv='yes'
                        BarraQViola_estatica_T1pvpv=[1]*len(ATIVA_ESPEC)
                        VerificaSeViola_T1pvpv=['ViolaPB']*len(ATIVA_ESPEC)

                    resultado_T1pvpv, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_T1pvpv, VerificaSeViola_T1pvpv)
                    if resultado_T1pvpv==True:
                        for k in range(len(indices_encontradosPVtot)):
                            if CONTAR_POTP<=limita_EspacoAmostral and ReduzirEspacoAmostral=='no':
                                resultado =(resultado[0],resultados_com_delta_025[indices_encontradosPVtot[k]], resultados_com_delta_125[indices_encontradosPVtot[k]])
                            else:
                                resultado = (indices_modificados, resultados_com_delta_025[indices_encontradosPVtot[k]], resultados_com_delta_125[indices_encontradosPVtot[k]])

                            resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPVtot[k]], resultados_com_delta_125[indices_encontradosPVtot[k]])
                            resultado_corrigido_melhorado = corrigir_resultado_melhorado(resultado, ATIVA_ESPEC00A, REGIME_de_CARGA, 'PQPV')
                            #print("Resultado_corrigido:", resultado_corrigido_melhorado)

                            # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                            #     PVbarIndex, TENSAO_ESPEC, PIndex, resultado_corrigido_melhorado[2], GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                            # )
                            # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                            #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                            # )

                            for AUXILIAR in range(len(resultado_corrigido_melhorado[2])):
                                matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[2][AUXILIAR]))/S_base
                                matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                                matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                                matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                                matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                                infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                                matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[2][AUXILIAR]))

                            try:
                                # Execução do fluxo de potência
                                (DeltaV_T1pv, Delta0_T1pv, PotP_T1pv, PotQ_T1pv, _, _, cont_T1pv, MatrizY_T1pv, Barras_PQ_T1pv , _, _, BarraQViola_estatica_T1pv, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola_T1pv, _, _, _) = CHAMA_FLNR_03_LTT(
                                    matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                                )
                            except Exception as e:
                                Fluxo_divergente_T1pv='yes'
                                BarraQViola_estatica_T1pv=[1]*len(ATIVA_ESPEC)
                                VerificaSeViola_T1pv=['ViolaPB']*len(ATIVA_ESPEC)
                            
                            resultado_T1pv, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_T1pv, VerificaSeViola_T1pv)
                            if resultado_T1pv==False:
                                Lista_de_Candidatos_T1pv.append(resultado_corrigido_melhorado[2])
                                Lista_de_Candidatos_T1pv_index.append(resultados_com_delta_125[indices_encontradosPVtot[k]])
                                Lista_de_Candidatos_T1pv_siOrno.append('no')
                                # ##PLOTAGEM
                                # print('\n')
                                # print('--------------------------------------------------------') 
                                # print('--------------------------(T1pv)------------------------') 
                                # print('------------------------ PV pesada ---------------------')  
                                # plot(DeltaV_T1pv, Delta0_T1pv, PotP_T1pv, PotQ_T1pv,infoVctrl,cont_T1)
                                # plot_PotGer(PotP_T1pv, PotQ_T1pv, infoVctrl, Barras_PQ_T1pv , matriz_DadosBarra)
                            else:
                                Lista_de_Candidatos_T1pv.append(resultado_corrigido_melhorado[2])    
                                Lista_de_Candidatos_T1pv_index.append(matrizes_substituidas_125[indices_encontradosPVtot[k]])
                                Lista_de_Candidatos_T1pv_siOrno.append('yes')


            if PQPVpes=='no' and PQPVlev=='yes':
                if tipo_de_REGIME=='leve' or tipo_de_REGIME=='ambos': 
                    #  timer
                    time = datetime.now()
                    #time_date = datetime.fromtimestamp(time)
                    parametro_de_verificacao.append([time.strftime("%H:%M:%S"),' ANÁLISE DE PONTOS CANDITADOS: REGIME LEVE ']) 
                    print([time.strftime("%H:%M:%S"),' ANÁLISE DE PONTOS CANDITADOS: REGIME LEVE '])

                    for k in range(len(indices_encontrados)): 
                        if CONTAR_POTP<=limita_EspacoAmostral and ReduzirEspacoAmostral=='no':
                            resultado = (resultado[0],resultados_com_delta_025[indices_encontrados[k]], resultados_com_delta_125[indices_encontrados[k]])  
                        else:
                            resultado = (indices_modificados,resultados_com_delta_025[indices_encontrados[k]], resultados_com_delta_125[indices_encontrados[k]])
                                    
                        #resultado = (resultado[0],resultados_com_delta_025[indices_encontrados[k]], resultados_com_delta_125[indices_encontrados[k]])
                        resultado_corrigido_melhorado = corrigir_resultado_melhorado(resultado, ATIVA_ESPEC00A, REGIME_de_CARGA, 'PQPV')
                        # print("Resultado_corrigido:", resultado_corrigido_melhorado)
                        # print(resultados_com_delta_025[indices_encontrados[k]])
                        # print(matrizes_substituidas_025[indices_encontrados[k]])
                        # print(indices_encontrados[k])


                        # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                        #     PVbarIndex, TENSAO_ESPEC, PIndex, resultado_corrigido_melhorado[1], GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                        # )
                        # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                        #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                        # )
                        for AUXILIAR in range(len(resultado_corrigido_melhorado[1])):
                            matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[1][AUXILIAR]))/S_base
                            matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                            matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                            matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                            matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                            infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                            matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[1][AUXILIAR]))

                        try:
                            # Execução do fluxo de potência
                            (DeltaV_T2, Delta0_T2, PotP_T2, PotQ_T2, _, _, cont_T2, MatrizY_PQlev, Barras_PQ_T2 , _, _, BarraQViola_estatica_T2, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola_T2, _, _, _) = CHAMA_FLNR_03_LTT(
                                matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                            )
                        except Exception as e:
                            Fluxo_divergente_T2='yes'
                            BarraQViola_estatica_T2=[1]*len(ATIVA_ESPEC)
                            VerificaSeViola_T2=['ViolaPB']*len(ATIVA_ESPEC)

                        resultado_T2, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_T2, VerificaSeViola_T2)
                        if resultado_T2==False:
                            Lista_de_Candidatos_T2.append(resultado_corrigido_melhorado[1])
                            Lista_de_Candidatos_T2_index.append(matrizes_substituidas_025[indices_encontrados[k]])
                            Lista_de_Candidatos_T2_siOrno.append('no') 

                            #     ##PLOTAGEM
                            #     print('\n')
                            #     print('------------------------------------------------------') 
                            #     print('--------------------------(T2)------------------------') 
                            #     print('----------------------- PQPV leve --------------------')  
                            #     plot(DeltaV_T2, Delta0_T2, PotP_T2, PotQ_T2,infoVctrl,cont_T2)
                            #     plot_PotGer(PotP_T2, PotQ_T2, infoVctrl, Barras_PQ_T2 , matriz_DadosBarra)
                        else:
                            Lista_de_Candidatos_T2.append(resultado_corrigido_melhorado[1])    
                            Lista_de_Candidatos_T2_index.append(matrizes_substituidas_025[indices_encontrados[k]])
                            Lista_de_Candidatos_T2_siOrno.append('yes')    
                        
                        # print('\n')
                        # print('*********************** OUTRAS INFOS RELEVANTES *********************** ')
                        # print("Resultado_corrigido:", resultado_corrigido_melhorado)
                        # print(resultados_com_delta_025[indices_encontrados[k]])
                        # print(matrizes_substituidas_025[indices_encontrados[k]])
                        # print(indices_encontrados[k])

                    if CONTAR_POTP<=limita_EspacoAmostral and ReduzirEspacoAmostral=='no':
                        resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]], resultados_com_delta_125[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]])  
                    else:
                        resultado = (indices_modificados, resultados_com_delta_025[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]], resultados_com_delta_125[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]])

                    #resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]], resultados_com_delta_125[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]])
                    resultado_corrigido_melhorado = corrigir_resultado_melhorado(resultado, ATIVA_ESPEC00A, REGIME_de_CARGA, 'PQPV')
                    #print("Resultado_corrigido:", resultado_corrigido_melhorado)

                    # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                    #     PVbarIndex, TENSAO_ESPEC, PIndex, resultado_corrigido_melhorado[1], GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                    # )
                    # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                    #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                    # )

                    for AUXILIAR in range(len(resultado_corrigido_melhorado[1])):
                        matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[1][AUXILIAR]))/S_base
                        matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                        matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                        matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                        matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                        infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                        matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[1][AUXILIAR]))

                    try:
                        # Execução do fluxo de potência
                        ( _, _, _, _, _, _, _ , _, _ , _, _, BarraQViola_estatica_T2pvpv, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola_T2pvpv, _, _, _) = CHAMA_FLNR_03_LTT(
                            matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                        )
                    except Exception as e:
                        Fluxo_divergente_T2pvpv='yes'
                        BarraQViola_estatica_T2pvpv=[1]*len(ATIVA_ESPEC)
                        VerificaSeViola_T2pvpv=['ViolaPB']*len(ATIVA_ESPEC)
                    
                    resultado_T2pvpv, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_T2pvpv, VerificaSeViola_T2pvpv)                
                    if resultado_T2pvpv==True:
                        for k in range(len(indices_encontradosPVtot)):
                            if CONTAR_POTP<=limita_EspacoAmostral and ReduzirEspacoAmostral=='no':
                                resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPVtot[k]], resultados_com_delta_125[indices_encontradosPVtot[k]])  
                            else:
                                resultado = (indices_modificados,resultados_com_delta_025[indices_encontradosPVtot[k]], resultados_com_delta_125[indices_encontradosPVtot[k]])
                        
                            #resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPVtot[k]], resultados_com_delta_125[indices_encontradosPVtot[k]])
                            resultado_corrigido_melhorado = corrigir_resultado_melhorado(resultado, ATIVA_ESPEC00A, REGIME_de_CARGA, 'PQPV')
                            #print("Resultado_corrigido:", resultado_corrigido_melhorado)

                            # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                            #     PVbarIndex, TENSAO_ESPEC, PIndex, resultado_corrigido_melhorado[1], GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                            # )
                            # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                            #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                            # )

                            for AUXILIAR in range(len(resultado_corrigido_melhorado[1])):
                                matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[1][AUXILIAR]))/S_base
                                matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                                matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                                matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                                matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                                infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                                matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[1][AUXILIAR]))

                            try:
                                # Execução do fluxo de potência
                                (DeltaV_T2pv, Delta0_T2pv, PotP_T2pv, PotQ_T2pv, _, _, cont_T2pv, _, Barras_PQ_T2pv , _, _, BarraQViola_estatica_T2pv, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola_T2pv, _, _, _) = CHAMA_FLNR_03_LTT(
                                    matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                                )
                            except Exception as e:
                                Fluxo_divergente_T2pv='yes'
                                BarraQViola_estatica_T2pv=[1]*len(ATIVA_ESPEC)
                                VerificaSeViola_T2pv=['ViolaPB']*len(ATIVA_ESPEC)

                            resultado_T2pv, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_T2pv, VerificaSeViola_T2pv)
                            if resultado_T2pv==False:
                                Lista_de_Candidatos_T2pv_siOrno.append('no') 
                                Lista_de_Candidatos_T2pv.append(resultado_corrigido_melhorado[1])
                                Lista_de_Candidatos_T2pv_index.append(matrizes_substituidas_025[indices_encontradosPVtot[k]])

                                # ##PLOTAGEM
                                # print('\n')
                                # print('--------------------------------------------------------') 
                                # print('--------------------------(T2pv)------------------------') 
                                # print('------------------------- PV leve ----------------------')  
                                # plot(DeltaV_T2pv, Delta0_T2pv, PotP_T2pv, PotQ_T2pv,infoVctrl,cont_T2pv)
                                # plot_PotGer(PotP_T2pv, PotQ_T2pv, infoVctrl, Barras_PQ_T2pv , matriz_DadosBarra)
                            else:
                                Lista_de_Candidatos_T2pv_siOrno.append('yes') 
                                Lista_de_Candidatos_T2pv.append(resultado_corrigido_melhorado[1])    
                                Lista_de_Candidatos_T2pv_index.append(matrizes_substituidas_025[indices_encontradosPVtot[k]])
                                

            if PQPVpes=='yes' and PQPVlev=='yes':
                if tipo_de_REGIME=='pesado' or tipo_de_REGIME=='ambos':
                    #  timer
                    time = datetime.now()
                    #time_date = datetime.fromtimestamp(time)
                    parametro_de_verificacao.append([time.strftime("%H:%M:%S"),' ANÁLISE DE PONTOS CANDITADOS: REGIME PESADO '])
                    print([time.strftime("%H:%M:%S"),' ANÁLISE DE PONTOS CANDITADOS: REGIME PESADO '])

                    for k in range(len(indices_encontrados)):
                        if CONTAR_POTP<=limita_EspacoAmostral and ReduzirEspacoAmostral=='no':
                            resultado = (resultado[0],resultados_com_delta_025[indices_encontrados[k]], resultados_com_delta_125[indices_encontrados[k]])  
                        else:
                            resultado = (indices_modificados,resultados_com_delta_025[indices_encontrados[k]], resultados_com_delta_125[indices_encontrados[k]])
                                                
                        #resultado = (resultado[0],resultados_com_delta_025[indices_encontrados[k]], resultados_com_delta_125[indices_encontrados[k]])
                        resultado_corrigido_melhorado = corrigir_resultado_melhorado(resultado, ATIVA_ESPEC00A, REGIME_de_CARGA, 'PQPV')
                        #print("Resultado_corrigido:", resultado_corrigido_melhorado)

                        # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                        #     PVbarIndex, TENSAO_ESPEC, PIndex, resultado_corrigido_melhorado[2], GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                        # )
                        # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                        #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                        # )

                        for AUXILIAR in range(len(resultado_corrigido_melhorado[2])):
                            matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[2][AUXILIAR]))/S_base
                            matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                            matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                            matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                            matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                            infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                            matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[2][AUXILIAR]))

                        try:
                            # Execução do fluxo de potência
                            (DeltaV_T1, Delta0_T1, PotP_T1, PotQ_T1, _, _, cont_T1, _, Barras_PQ_T1 , _, _, BarraQViola_estatica_T1, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola_T1, _, _, _) = CHAMA_FLNR_03_LTT(
                                matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                            )
                        except Exception as e:
                            Fluxo_divergente_T1='yes'
                            BarraQViola_estatica_T1=[1]*len(ATIVA_ESPEC)
                            VerificaSeViola_T1=['ViolaPB']*len(ATIVA_ESPEC)
                        
                        resultado_T1, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_T1, VerificaSeViola_T1)
                        if resultado_T1==False:
                            Lista_de_Candidatos_T1_siOrno.append('no')
                            Lista_de_Candidatos_T1.append(resultado_corrigido_melhorado[2])
                            Lista_de_Candidatos_T1_index.append(matrizes_substituidas_125[indices_encontrados[k]])

                            # ##PLOTAGEM
                            # print('\n')
                            # print('------------------------------------------------------') 
                            # print('--------------------------(T1)_2----------------------') 
                            # print('----------------------- PQPV pesada ------------------')  
                            # plot(DeltaV_T1, Delta0_T1, PotP_T1, PotQ_T1,infoVctrl,cont_T1)
                            # plot_PotGer(PotP_T1, PotQ_T1, infoVctrl, Barras_PQ_T1 , matriz_DadosBarra)
                        else:
                            Lista_de_Candidatos_T1_siOrno.append('yes')
                            Lista_de_Candidatos_T1.append(resultado_corrigido_melhorado[2])    
                            Lista_de_Candidatos_T1_index.append(matrizes_substituidas_125[indices_encontrados[k]])
                    
                    if CONTAR_POTP<=limita_EspacoAmostral and ReduzirEspacoAmostral=='no':
                        resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]], resultados_com_delta_125[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]])  
                    else:
                        resultado = (indices_modificados, resultados_com_delta_025[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]], resultados_com_delta_125[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]])
                        
                    #resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]], resultados_com_delta_125[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]])
                    resultado_corrigido_melhorado = corrigir_resultado_melhorado(resultado, ATIVA_ESPEC00A, REGIME_de_CARGA, 'PQPV')
                    #print("Resultado_corrigido:", resultado_corrigido_melhorado)

                    # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                    #     PVbarIndex, TENSAO_ESPEC, PIndex, resultado_corrigido_melhorado[2], GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                    # )
                    # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                    #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                    # )
                    
                    for AUXILIAR in range(len(resultado_corrigido_melhorado[2])):
                        matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[2][AUXILIAR]))/S_base
                        matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                        matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                        matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                        matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                        infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                        matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[2][AUXILIAR]))
                    try:
                        # Execução do fluxo de potência
                        ( _, _, _, _, _, _, _ , _, _ , _, _, BarraQViola_estatica_T1pvpv, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola_T1pvpv, _, _, _) = CHAMA_FLNR_03_LTT(
                            matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                        )
                    except Exception as e:
                        Fluxo_divergente_T1pvpv='yes'
                        BarraQViola_estatica_T1pvpv=[1]*len(ATIVA_ESPEC)
                        VerificaSeViola_T1pvpv=['ViolaPB']*len(ATIVA_ESPEC)
                    
                    resultado_T1pvpv, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_T1pvpv, VerificaSeViola_T1pvpv)
                    if resultado_T1pvpv==True:
                        for k in range(len(indices_encontradosPVtot)):
                            if CONTAR_POTP<=limita_EspacoAmostral and ReduzirEspacoAmostral=='no':
                                resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPVtot[k]], resultados_com_delta_125[indices_encontradosPVtot[k]])  
                            else:
                                resultado = (indices_modificados,resultados_com_delta_025[indices_encontradosPVtot[k]], resultados_com_delta_125[indices_encontradosPVtot[k]])

                            resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPVtot[k]], resultados_com_delta_125[indices_encontradosPVtot[k]])
                            resultado_corrigido_melhorado = corrigir_resultado_melhorado(resultado, ATIVA_ESPEC00A, REGIME_de_CARGA, 'PQPV')
                            #print("Resultado_corrigido:", resultado_corrigido_melhorado)

                            # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                            #     PVbarIndex, TENSAO_ESPEC, PIndex, resultado_corrigido_melhorado[2], GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                            # )
                            # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                            #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                            # )
                            
                            for AUXILIAR in range(len(resultado_corrigido_melhorado[2])):
                                matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[2][AUXILIAR]))/S_base
                                matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                                matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                                matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                                matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                                infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                                matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[2][AUXILIAR]))

                            try:
                                # Execução do fluxo de potência
                                (DeltaV_T1pv, Delta0_T1pv, PotP_T1pv, PotQ_T1pv, _, _, cont_T1pv, MatrizY_T1pv, Barras_PQ_T1pv , _, _, BarraQViola_estatica_T1pv, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola_T1pv , _, _, _) = CHAMA_FLNR_03_LTT(
                                    matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                                )
                            except Exception as e:
                                Fluxo_divergente_T1pv='yes'
                                BarraQViola_estatica_T1pv=[1]*len(ATIVA_ESPEC)
                                VerificaSeViola_T1pv=['ViolaPB']*len(ATIVA_ESPEC)
                            
                            resultado_T1pv, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_T1pv, VerificaSeViola_T1pv)
                            if resultado_T1pv==False:
                                Lista_de_Candidatos_T1pv_siOrno.append('no')
                                Lista_de_Candidatos_T1pv.append(resultado_corrigido_melhorado[2])
                                Lista_de_Candidatos_T1pv_index.append(matrizes_substituidas_125[indices_encontradosPVtot[k]])

                                # ##PLOTAGEM
                                # print('\n')
                                # print('--------------------------------------------------------') 
                                # print('-------------------------(T1pv)_2-----------------------') 
                                # print('------------------------ PV pesada ---------------------')  
                                # plot(DeltaV_T1pv, Delta0_T1pv, PotP_T1pv, PotQ_T1pv,infoVctrl,cont_T1)
                                # plot_PotGer(PotP_T1pv, PotQ_T1pv, infoVctrl, Barras_PQ_T1pv , matriz_DadosBarra)
                            else:
                                Lista_de_Candidatos_T1pv_siOrno.append('yes')
                                Lista_de_Candidatos_T1pv.append(resultado_corrigido_melhorado[2])    
                                Lista_de_Candidatos_T1pv_index.append(matrizes_substituidas_125[indices_encontradosPVtot[k]])
                    #print('segura')

                if tipo_de_REGIME=='leve' or tipo_de_REGIME=='ambos':
                    #  timer
                    time = datetime.now()
                    #time_date = datetime.fromtimestamp(time)
                    parametro_de_verificacao.append([time.strftime("%H:%M:%S"),' ANÁLISE DE PONTOS CANDITADOS: REGIME LEVE ']) 
                    print([time.strftime("%H:%M:%S"),' ANÁLISE DE PONTOS CANDITADOS: REGIME LEVE '])
                    
                    for k in range(len(indices_encontrados)):
                        if CONTAR_POTP<=limita_EspacoAmostral and ReduzirEspacoAmostral=='no':
                            resultado = (resultado[0],resultados_com_delta_025[indices_encontrados[k]], resultados_com_delta_125[indices_encontrados[k]])
                        else:
                            resultado = (indices_modificados,resultados_com_delta_025[indices_encontrados[k]], resultados_com_delta_125[indices_encontrados[k]])
                    
                        #resultado = (resultado[0],resultados_com_delta_025[indices_encontrados[k]], resultados_com_delta_125[indices_encontrados[k]])
                        resultado_corrigido_melhorado = corrigir_resultado_melhorado(resultado, ATIVA_ESPEC00A, REGIME_de_CARGA, 'PQPV')
                        # print("Resultado_corrigido:", resultado_corrigido_melhorado)
                        # print(resultados_com_delta_025[indices_encontrados[k]])
                        # print(matrizes_substituidas_025[indices_encontrados[k]])
                        # print(indices_encontrados[k])


                        # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                        #     PVbarIndex, TENSAO_ESPEC, PIndex, resultado_corrigido_melhorado[1], GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                        # )
                        # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                        #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                        # )
                        for AUXILIAR in range(len(resultado_corrigido_melhorado[1])):
                            matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[1][AUXILIAR]))/S_base
                            matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                            matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                            matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                            matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                            infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                            matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[1][AUXILIAR]))                            
                        #print('resultado_corrigido_melhorado')
                        try:
                            # Execução do fluxo de potência
                            (DeltaV_T2, Delta0_T2, PotP_T2, PotQ_T2, _, _, cont_T2, MatrizY_PQlev, Barras_PQ_T2 , _, _, BarraQViola_estatica_T2, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola_T2, _, _, _) = CHAMA_FLNR_03_LTT(
                                matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                            )
                        except Exception as e:
                            Fluxo_divergente_T2='yes'
                            BarraQViola_estatica_T2=[1]*len(ATIVA_ESPEC)
                            VerificaSeViola_T2=['ViolaPB']*len(ATIVA_ESPEC)

                        resultado_T2, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_T2, VerificaSeViola_T2)
                        if resultado_T2==False:
                            Lista_de_Candidatos_T2.append(resultado_corrigido_melhorado[1])
                            Lista_de_Candidatos_T2_index.append(matrizes_substituidas_025[indices_encontrados[k]])
                            Lista_de_Candidatos_T2_siOrno.append('no')

                            # ##PLOTAGEM
                            # print('\n')
                            # print('------------------------------------------------------') 
                            # print('-------------------------(T2)_2-----------------------') 
                            # print('----------------------- PQPV leve --------------------')  
                            # plot(DeltaV_T2, Delta0_T2, PotP_T2, PotQ_T2,infoVctrl,cont_T2)
                            # plot_PotGer(PotP_T2, PotQ_T2, infoVctrl, Barras_PQ_T2 , matriz_DadosBarra)
                            # print('\n')
                            # print('*********************** OUTRAS INFOS RELEVANTES *********************** ')
                            # print("Resultado_corrigido:", resultado_corrigido_melhorado)
                            # print(resultados_com_delta_025[indices_encontrados[k]])
                            # print(matrizes_substituidas_025[indices_encontrados[k]])
                            # print(indices_encontrados[k])
                        else:
                            Lista_de_Candidatos_T2.append(resultado_corrigido_melhorado[1])    
                            Lista_de_Candidatos_T2_index.append(matrizes_substituidas_025[indices_encontrados[k]])
                            Lista_de_Candidatos_T2_siOrno.append('yes')
                    
                    if CONTAR_POTP<=limita_EspacoAmostral and ReduzirEspacoAmostral=='no':
                        resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]], resultados_com_delta_125[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]])
                    else:
                        resultado = (indices_modificados,resultados_com_delta_025[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]], resultados_com_delta_125[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]])
                
                    #resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]], resultados_com_delta_125[indices_encontradosPVtot[len(indices_encontradosPVtot)-1]])
                    resultado_corrigido_melhorado = corrigir_resultado_melhorado(resultado, ATIVA_ESPEC00A, REGIME_de_CARGA, 'PQPV')
                    #print("Resultado_corrigido:", resultado_corrigido_melhorado)

                    # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                    #     PVbarIndex, TENSAO_ESPEC, PIndex, resultado_corrigido_melhorado[1], GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                    # )
                    # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                    #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                    # )

                    for AUXILIAR in range(len(resultado_corrigido_melhorado[1])):
                        matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[1][AUXILIAR]))/S_base
                        matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                        matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                        matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                        matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                        infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                        matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[1][AUXILIAR]))
                                            
                    try:
                        # Execução do fluxo de potência
                        ( _, _, _, _, _, _, _ , _, _ , _, _, BarraQViola_estatica_T2pvpv, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola_T2pvpv, _, _, _) = CHAMA_FLNR_03_LTT(
                            matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                        )
                    except Exception as e:
                        Fluxo_divergente_T2pvpv='yes'
                        BarraQViola_estatica_T2pvpv=[1]*len(ATIVA_ESPEC)
                        VerificaSeViola_T2pvpv=['ViolaPB']*len(ATIVA_ESPEC)

                    resultado_T2pvpv, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_T2pvpv, VerificaSeViola_T2pvpv)
                    if resultado_T2pvpv==True:
                        for k in range(len(indices_encontradosPVtot)):
                            
                            if CONTAR_POTP<=limita_EspacoAmostral and ReduzirEspacoAmostral=='no':
                                resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPVtot[k]], resultados_com_delta_125[indices_encontradosPVtot[k]])
                            else:
                                resultado = (indices_modificados,resultados_com_delta_025[indices_encontradosPVtot[k]], resultados_com_delta_125[indices_encontradosPVtot[k]])
                                                
                            resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPVtot[k]], resultados_com_delta_125[indices_encontradosPVtot[k]])
                            resultado_corrigido_melhorado = corrigir_resultado_melhorado(resultado, ATIVA_ESPEC00A, REGIME_de_CARGA, 'PQPV')
                            #print("Resultado_corrigido:", resultado_corrigido_melhorado)

                            # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                            #     PVbarIndex, TENSAO_ESPEC, PIndex, resultado_corrigido_melhorado[1], GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                            # )
                            # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                            #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                            # )

                            for AUXILIAR in range(len(resultado_corrigido_melhorado[1])):
                                matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[1][AUXILIAR]))/S_base
                                matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                                matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                                matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                                matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                                infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                                matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[1][AUXILIAR]))

                            try:
                                # Execução do fluxo de potência
                                (_ , _ , _ , _ , _, _, _ , _, _ , _, _, BarraQViola_estatica_T2pv, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola_T2pv, _, _, _) = CHAMA_FLNR_03_LTT(
                                    matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                                )
                            except Exception as e:
                                Fluxo_divergente_T2pv='yes'
                                BarraQViola_estatica_T2pv=[1]*len(ATIVA_ESPEC)
                                VerificaSeViola_T2pv=['ViolaPB']*len(ATIVA_ESPEC)
                            
                            resultado_T2pv, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_T2pv, VerificaSeViola_T2pv)                            
                            if resultado_T2pv==False:
                                Lista_de_Candidatos_T2pv.append(resultado_corrigido_melhorado[1])
                                Lista_de_Candidatos_T2pv_index.append(matrizes_substituidas_025[indices_encontradosPVtot[k]])
                                Lista_de_Candidatos_T2pv_siOrno.append('no')

                                # ##PLOTAGEM
                                # print('\n')
                                # print('--------------------------------------------------------') 
                                # print('-------------------------(T2pv)_2-----------------------') 
                                # print('------------------------- PV leve ----------------------')  
                                # plot(DeltaV_T2pv, Delta0_T2pv, PotP_T2pv, PotQ_T2pv,infoVctrl,cont_T2pv)
                                # plot_PotGer(PotP_T2pv, PotQ_T2pv, infoVctrl, Barras_PQ_T2pv , matriz_DadosBarra)
                            else:
                                Lista_de_Candidatos_T2pv.append(resultado_corrigido_melhorado[1])    
                                Lista_de_Candidatos_T2pv_index.append(matrizes_substituidas_025[indices_encontradosPVtot[k]])
                                Lista_de_Candidatos_T2pv_siOrno.append('yes')
                    #print('segura')

    if (tipo_de_ESTUDO=='Segregar (PQ)_(PV)' or tipo_de_ESTUDO=='Segregar (PQ)'):
        if PQpes=='yes' and PQlev=='no':
            if tipo_de_REGIME=='pesado' or tipo_de_REGIME=='ambos':            
                #  timer
                time = datetime.now()
                #time_date = datetime.fromtimestamp(time)
                parametro_de_verificacao.append([time.strftime("%H:%M:%S"),' ANÁLISE DE PONTOS CANDITADOS: REGIME PESADO ']) 
                print([time.strftime("%H:%M:%S"),' ANÁLISE DE PONTOS CANDITADOS: REGIME PESADO '])

                quantidade_anterior_pes=-1
                candidate_bloc_anterior_pes=[]
                candidateviola_block_anterior_pes=[]
                primeiroAviolar_pes=0
                ultimoAviolar_pes=0        

                for k in range(len(indices_encontradosPQsomente)):
                    if ultimoAviolar_pes==0:
                        if CONTAR_POTP<=limita_EspacoAmostral and ReduzirEspacoAmostral=='no':
                            resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPQsomente[k]], resultados_com_delta_125[indices_encontradosPQsomente[k]])
                        else:
                            resultado = (indices_modificados,resultados_com_delta_025[indices_encontradosPQsomente[k]], resultados_com_delta_125[indices_encontradosPQsomente[k]])
                                
                        #resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPQsomente[k]], resultados_com_delta_125[indices_encontradosPQsomente[k]])
                        resultado_corrigido_melhorado = corrigir_resultado_melhorado(resultado, ATIVA_ESPEC00A, REGIME_de_CARGA, 'PQPV')
                        #print("Resultado_corrigido:", resultado_corrigido_melhorado)

                        # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                        #     PVbarIndex, TENSAO_ESPEC, PIndex, resultado_corrigido_melhorado[2], GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                        # )
                        # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                        #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                        # )

                        for AUXILIAR in range(len(resultado_corrigido_melhorado[2])):
                            matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[2][AUXILIAR]))/S_base
                            matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                            matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                            matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                            matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                            infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                            matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[2][AUXILIAR]))
                        try:
                            # Execução do fluxo de potência
                            (DeltaV_T3, Delta0_T3, PotP_T3, PotQ_T3, _, _, cont_T3, _, Barras_PQ_T3 , _, _, BarraQViola_estatica_T3, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola_T3, _, _, _) = CHAMA_FLNR_03_LTT(
                                matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                            )
                        except Exception as e:
                            Fluxo_divergente_T3='yes'
                            BarraQViola_estatica_T3=[1]*len(ATIVA_ESPEC)
                            VerificaSeViola_T3=['ViolaPB']*len(ATIVA_ESPEC)
                    
                        resultado_T3, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_T3, VerificaSeViola_T3)                
                        if resultado_T3==True:
                            candidateviola_value='yes'
                            Lista_de_Candidatos_T3.append(resultado_corrigido_melhorado[2])
                            Lista_de_Candidatos_T3_index.append(resultados_com_delta_125[indices_encontradosPQsomente[k]])

                            # ##PLOTAGEM
                            # print('\n')
                            # print('------------------------------------------------------') 
                            # print('-------------------------(T3)------------------------') 
                            # print('---------------------- PQ pesada ---------------------')  
                            # plot(DeltaV_T3, Delta0_T3, PotP_T3, PotQ_T3,infoVctrl,cont_T3)
                            # plot_PotGer(PotP_T3, PotQ_T3, infoVctrl, Barras_PQ_T3 , matriz_DadosBarra)

                        else:
                            candidateviola_value='no'

                        #if k>0: 
                        # Conta os valores diferentes de zero
                        quantidade_atual = sum(1 for valor in matrizes_substituidas_125[indices_encontradosPQsomente[k]] if valor != 0)    
                        # Verifica e emite alerta se houve mudança
                        candidate_bloc.append(matrizes_substituidas_125[indices_encontradosPQsomente[k]])
                        candidateviola.append(candidateviola_value)

                        if quantidade_atual != quantidade_anterior_pes:
                            candidate_bloc_anterior_pes.append(candidate_bloc)
                            candidateviola_block_anterior_pes.append(candidateviola)
                            # print(candidateviola)
                            # Verificando se todos os elementos são 'no'
                            # voltar aqui para replicar                
                            if all(element == 'no' for element in candidateviola[:-1]) or all(element == 'yes' for element in candidateviola[:-1]):
                                #print("bloco não viola")
                                if primeiroAviolar_pes!=0:
                                    if ultimoAviolar_pes==0:
                                        ultimoAviolar_pes=quantidade_anterior_pes         
                            else:
                                #print("bloco viola")
                                if primeiroAviolar_pes==0:
                                    primeiroAviolar_pes=quantidade_anterior_pes


                            #print(f"Alerta: Mudança detectada! Quantidade atual de valores diferentes de zero: {quantidade_atual}")
                            quantidade_anterior_pes = quantidade_atual
                            candidate_bloc=[]    
                            candidateviola=[]        
                        
                        # print('candidate_bloc_anterior_pes=',candidate_bloc_anterior_pes)
                        # print('*********************** OUTRAS INFOS RELEVANTES *********************** ')
                        # print("Resultado_corrigido:", resultado_corrigido_melhorado)
                        # print(resultados_com_delta_125[indices_encontradosPQsomente[k]])
                        # print(matrizes_substituidas_125[indices_encontradosPQsomente[k]])
                        # print(indices_encontradosPQsomente[k])
                        #print('aqui')


        if PQpes=='no' and PQlev=='yes':
            if tipo_de_REGIME=='leve' or tipo_de_REGIME=='ambos':
                #  timer
                time = datetime.now()
                #time_date = datetime.fromtimestamp(time)
                parametro_de_verificacao.append([time.strftime("%H:%M:%S"),' ANÁLISE DE PONTOS CANDITADOS: REGIME LEVE ']) 
                print([time.strftime("%H:%M:%S"),' ANÁLISE DE PONTOS CANDITADOS: REGIME LEVE '])

                quantidade_anterior_lev=-1
                candidate_bloc_anterior_lev=[]
                candidateviola_block_anterior_lev=[]
                primeiroAviolar_lev=0
                ultimoAviolar_lev=0 

                for k in range(len(indices_encontradosPQsomente)):
                    if ultimoAviolar_lev==0:
                        if CONTAR_POTP<=limita_EspacoAmostral and ReduzirEspacoAmostral=='no':
                            resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPQsomente[k]], resultados_com_delta_125[indices_encontradosPQsomente[k]])
                        else:
                            resultado = (indices_modificados,resultados_com_delta_025[indices_encontradosPQsomente[k]], resultados_com_delta_125[indices_encontradosPQsomente[k]])
                                            
                        #resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPQsomente[k]], resultados_com_delta_125[indices_encontradosPQsomente[k]])
                        resultado_corrigido_melhorado = corrigir_resultado_melhorado(resultado, ATIVA_ESPEC00A, REGIME_de_CARGA, 'PQPV')
                        #print("Resultado_corrigido:", resultado_corrigido_melhorado)

                        # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                        #     PVbarIndex, TENSAO_ESPEC, PIndex, resultado_corrigido_melhorado[1], GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                        # )
                        # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                        #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                        # )

                        for AUXILIAR in range(len(resultado_corrigido_melhorado[1])):
                            matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[1][AUXILIAR]))/S_base
                            matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                            matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                            matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                            matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                            infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                            matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[1][AUXILIAR]))

                        try:
                            # Execução do fluxo de potência
                            (DeltaV_T4, Delta0_T4, PotP_T4, PotQ_T4, _, _, cont_T4, _, Barras_PQ_T4 , _, _, BarraQViola_estatica_T4, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola_T4, _, _, _) = CHAMA_FLNR_03_LTT(
                                matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                            )
                        except Exception as e:
                            Fluxo_divergente_T4='yes'
                            BarraQViola_estatica_T4=[1]*len(ATIVA_ESPEC)
                            VerificaSeViola_T4=['ViolaPB']*len(ATIVA_ESPEC)
                        
                        resultado_T4, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_T4, VerificaSeViola_T4)                 
                        if resultado_T4==True:
                            candidateviola_value='yes'
                            Lista_de_Candidatos_T4.append(resultado_corrigido_melhorado[1])
                            Lista_de_Candidatos_T4_index.append(matrizes_substituidas_025[indices_encontradosPQsomente[k]])

                            #PLOTAGEM
                            # print('\n')
                            # print('------------------------------------------------------') 
                            # print('--------------------------(T4)------------------------') 
                            # print('----------------------  PQ leve ----------------------')  
                            # plot(DeltaV_T4, Delta0_T4, PotP_T4, PotQ_T4,infoVctrl,cont_T4)
                            # plot_PotGer(PotP_T4, PotQ_T4, infoVctrl, Barras_PQ_T4 , matriz_DadosBarra)
                        else:
                            candidateviola_value='no'

                        #if k>0: 
                        # Conta os valores diferentes de zero
                        quantidade_atual = sum(1 for valor in matrizes_substituidas_025[indices_encontradosPQsomente[k]] if valor != 0)    
                        # Verifica e emite alerta se houve mudança
                        candidate_bloc.append(matrizes_substituidas_025[indices_encontradosPQsomente[k]])
                        candidateviola.append(candidateviola_value)

                        if quantidade_atual != quantidade_anterior_lev:
                            candidate_bloc_anterior_lev.append(candidate_bloc)
                            candidateviola_block_anterior_lev.append(candidateviola)
                            # print(candidateviola)
                            # Verificando se todos os elementos são 'no'
                            # voltar aqui para replicar                
                            if all(element == 'no' for element in candidateviola[:-1]) or all(element == 'yes' for element in candidateviola[:-1]):
                                #print("bloco não viola")
                                if primeiroAviolar_lev!=0:
                                    if ultimoAviolar_lev==0:
                                        ultimoAviolar_lev=quantidade_anterior_lev         
                            else:
                                #print("bloco viola")
                                if primeiroAviolar_lev==0:
                                    primeiroAviolar_lev=quantidade_anterior_lev


                            #print(f"Alerta: Mudança detectada! Quantidade atual de valores diferentes de zero: {quantidade_atual}")
                            quantidade_anterior_lev = quantidade_atual
                            candidate_bloc=[]    
                            candidateviola=[]        
                        
                        # print('candidate_bloc_anterior=',candidate_bloc_anterior_lev)
                        # print('*********************** OUTRAS INFOS RELEVANTES *********************** ')
                        # print("Resultado_corrigido:", resultado_corrigido_melhorado)
                        # print(resultados_com_delta_025[indices_encontradosPQsomente[k]])
                        # print(matrizes_substituidas_025[indices_encontradosPQsomente[k]])
                        # print(indices_encontradosPQsomente[k])
                        # print('aqui')


        if PQpes=='yes' and PQlev=='yes':
            quantidade_anterior_pes=-1
            candidate_bloc_anterior_pes=[]
            candidateviola_block_anterior_pes=[]
            primeiroAviolar_pes=0
            ultimoAviolar_pes=0
            quantidade_anterior_lev=-1
            candidate_bloc_anterior_lev=[]
            candidateviola_block_anterior_lev=[]
            primeiroAviolar_lev=0
            ultimoAviolar_lev=0
            if tipo_de_REGIME=='pesado' or tipo_de_REGIME=='ambos':  
                #  timer
                time = datetime.now()
                #time_date = datetime.fromtimestamp(time)
                parametro_de_verificacao.append([time.strftime("%H:%M:%S"),' ANÁLISE DE PONTOS CANDITADOS: REGIME PESADO '])
                print([time.strftime("%H:%M:%S"),' ANÁLISE DE PONTOS CANDITADOS: REGIME PESADO '])

                for k in range(len(indices_encontradosPQsomente)):
                    if ultimoAviolar_pes==0:
                        if CONTAR_POTP<=limita_EspacoAmostral and ReduzirEspacoAmostral=='no':
                            resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPQsomente[k]], resultados_com_delta_125[indices_encontradosPQsomente[k]])
                        else:
                            resultado = (indices_modificados,resultados_com_delta_025[indices_encontradosPQsomente[k]], resultados_com_delta_125[indices_encontradosPQsomente[k]])
                                                    
                        #resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPQsomente[k]], resultados_com_delta_125[indices_encontradosPQsomente[k]])
                        resultado_corrigido_melhorado = corrigir_resultado_melhorado(resultado, ATIVA_ESPEC00A, REGIME_de_CARGA, 'PQPV')
                        #print("Resultado_corrigido:", resultado_corrigido_melhorado)

                        # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                        #     PVbarIndex, TENSAO_ESPEC, PIndex, resultado_corrigido_melhorado[2], GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                        # )
                        # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                        #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                        # )

                        for AUXILIAR in range(len(resultado_corrigido_melhorado[2])):
                            matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[2][AUXILIAR]))/S_base
                            matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                            matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                            matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                            matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                            infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                            matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[2][AUXILIAR]))

                        try:
                            # Execução do fluxo de potência
                            (DeltaV_T3, Delta0_T3, PotP_T3, PotQ_T3, _, _, cont_T3, _, Barras_PQ_T3 , _, _, BarraQViola_estatica_T3, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola_T3, _, _, _) = CHAMA_FLNR_03_LTT(
                                matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                            )
                        except Exception as e:
                            Fluxo_divergente_T3='yes'
                            BarraQViola_estatica_T3=[1]*len(ATIVA_ESPEC)
                            VerificaSeViola_T3=['ViolaPB']*len(ATIVA_ESPEC)
                        
                        resultado_T3, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_T3, VerificaSeViola_T3)                  
                        if resultado_T3==True:
                            candidateviola_value='yes'
                            Lista_de_Candidatos_T3.append(resultado_corrigido_melhorado[2])
                            Lista_de_Candidatos_T3_index.append(resultados_com_delta_125[indices_encontradosPQsomente[k]])

                            ##PLOTAGEM
                            # print('\n')
                            # print('------------------------------------------------------') 
                            # print('-------------------------(T3)_2-----------------------') 
                            # print('---------------------- PQ pesada ---------------------')  
                            # plot(DeltaV_T3, Delta0_T3, PotP_T3, PotQ_T3,infoVctrl,cont_T3)
                            # plot_PotGer(PotP_T3, PotQ_T3, infoVctrl, Barras_PQ_T3 , matriz_DadosBarra)

                        else:
                            candidateviola_value='no'

                        #if k>0: 
                        # Conta os valores diferentes de zero
                        quantidade_atual = sum(1 for valor in matrizes_substituidas_125[indices_encontradosPQsomente[k]] if valor != 0)    
                        # Verifica e emite alerta se houve mudança
                        candidate_bloc.append(matrizes_substituidas_125[indices_encontradosPQsomente[k]])
                        candidateviola.append(candidateviola_value)

                        if quantidade_atual != quantidade_anterior_pes:
                            candidate_bloc_anterior_pes.append(candidate_bloc)
                            candidateviola_block_anterior_pes.append(candidateviola)
                            # print(candidateviola)
                            # Verificando se todos os elementos são 'no'
                            # voltar aqui para replicar                
                            if all(element == 'no' for element in candidateviola[:-1]) or all(element == 'yes' for element in candidateviola[:-1]):
                                #print("bloco não viola")
                                if primeiroAviolar_pes!=0:
                                    if ultimoAviolar_pes==0:
                                        ultimoAviolar_pes=quantidade_anterior_pes         
                            else:
                                #print("bloco viola")
                                if primeiroAviolar_pes==0:
                                    primeiroAviolar_pes=quantidade_anterior_pes


                            #print(f"Alerta: Mudança detectada! Quantidade atual de valores diferentes de zero: {quantidade_atual}")
                            quantidade_anterior_pes = quantidade_atual
                            candidate_bloc=[]    
                            candidateviola=[]        
                        
                        # print('candidate_bloc_anterior_pes=',candidate_bloc_anterior_pes)
                        # print('*********************** OUTRAS INFOS RELEVANTES *********************** ')
                        # print("Resultado_corrigido:", resultado_corrigido_melhorado)
                        # print(resultados_com_delta_125[indices_encontradosPQsomente[k]])
                        # print(matrizes_substituidas_125[indices_encontradosPQsomente[k]])
                        # print(indices_encontradosPQsomente[k])
                        #print('aqui')
                # elementos, indices_doBloco, candidates_vetor = arrumadadosDados(candidateviola_block_anterior_pes,candidate_bloc_anterior_pes)
                # print('elementos=',elementos)
                # print(indices_doBloco)
                # #print('candidates_vetor=',candidates_vetor)
                # #print(candidateviola_block_anterior_pes)
                # vet_objeto, vetor_inicio, vetor_ponta = extrair_vetores_ObjetoAEstudado(elementos, candidates_vetor)

            if tipo_de_REGIME=='leve' or tipo_de_REGIME=='ambos':
                #  timer
                time = datetime.now()
                #time_date = datetime.fromtimestamp(time)
                parametro_de_verificacao.append([time.strftime("%H:%M:%S"),' ANÁLISE DE PONTOS CANDITADOS: REGIME LEVE ']) 
                print([time.strftime("%H:%M:%S"),' ANÁLISE DE PONTOS CANDITADOS: REGIME LEVE '])

                for k in range(len(indices_encontradosPQsomente)):
                    if ultimoAviolar_lev==0:
                        if CONTAR_POTP<=limita_EspacoAmostral and ReduzirEspacoAmostral=='no':
                            resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPQsomente[k]], resultados_com_delta_125[indices_encontradosPQsomente[k]])
                        else:
                            resultado = (indices_modificados,resultados_com_delta_025[indices_encontradosPQsomente[k]], resultados_com_delta_125[indices_encontradosPQsomente[k]])
                                                
                        #resultado = (resultado[0],resultados_com_delta_025[indices_encontradosPQsomente[k]], resultados_com_delta_125[indices_encontradosPQsomente[k]])
                        resultado_corrigido_melhorado = corrigir_resultado_melhorado(resultado, ATIVA_ESPEC00A, REGIME_de_CARGA, 'PQPV')
                        #print("Resultado_corrigido:", resultado_corrigido_melhorado)

                        # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                        #     PVbarIndex, TENSAO_ESPEC, PIndex, resultado_corrigido_melhorado[1], GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                        # )
                        # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                        #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                        # )

                        for AUXILIAR in range(len(resultado_corrigido_melhorado[1])):
                            matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[1][AUXILIAR]))/S_base
                            matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                            matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                            matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                            matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                            infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                            matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[1][AUXILIAR]))

                        try:
                            # Execução do fluxo de potência
                            (DeltaV_T4, Delta0_T4, PotP_T4, PotQ_T4, _, _, cont_T4, _, Barras_PQ_T4 , _, _, BarraQViola_estatica_T4, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola_T4, _, _, _) = CHAMA_FLNR_03_LTT(
                                matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                            )
                        except Exception as e:
                            Fluxo_divergente_T4='yes'
                            BarraQViola_estatica_T4=[1]*len(ATIVA_ESPEC)
                            VerificaSeViola_T4=['ViolaPB']*len(ATIVA_ESPEC)
                        
                        resultado_T4, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_T4, VerificaSeViola_T4)                
                        if resultado_T4==True:
                            candidateviola_value='yes'
                            Lista_de_Candidatos_T4.append(resultado_corrigido_melhorado[1])
                            Lista_de_Candidatos_T4_index.append(matrizes_substituidas_025[indices_encontradosPQsomente[k]])

                            # #PLOTAGEM
                            # print('\n')
                            # print('------------------------------------------------------') 
                            # print('--------------------------(T4)_2----------------------') 
                            # print('------------------------- PQ leve --------------------')  
                            # plot(DeltaV_T4, Delta0_T4, PotP_T4, PotQ_T4,infoVctrl,cont_T4)
                            # plot_PotGer(PotP_T4, PotQ_T4, infoVctrl, Barras_PQ_T4 , matriz_DadosBarra)
                        else:
                            candidateviola_value='no'

                        #if k>0: 
                        # Conta os valores diferentes de zero
                        quantidade_atual = sum(1 for valor in matrizes_substituidas_025[indices_encontradosPQsomente[k]] if valor != 0)    
                        # Verifica e emite alerta se houve mudança
                        candidate_bloc.append(matrizes_substituidas_025[indices_encontradosPQsomente[k]])
                        candidateviola.append(candidateviola_value)

                        if quantidade_atual != quantidade_anterior_lev:
                            candidate_bloc_anterior_lev.append(candidate_bloc)
                            candidateviola_block_anterior_lev.append(candidateviola)
                            # print(candidateviola)
                            # Verificando se todos os elementos são 'no'
                            # voltar aqui para replicar                
                            if all(element == 'no' for element in candidateviola[:-1]) or all(element == 'yes' for element in candidateviola[:-1]):
                                #print("bloco não viola")
                                if primeiroAviolar_lev!=0:
                                    if ultimoAviolar_lev==0:
                                        ultimoAviolar_lev=quantidade_anterior_lev         
                            else:
                                #print("bloco viola")
                                if primeiroAviolar_lev==0:
                                    primeiroAviolar_lev=quantidade_anterior_lev


                            #print(f"Alerta: Mudança detectada! Quantidade atual de valores diferentes de zero: {quantidade_atual}")
                            quantidade_anterior_lev = quantidade_atual
                            candidate_bloc=[]    
                            candidateviola=[]        
                        
                        # print('candidate_bloc_anterior_lev=',candidate_bloc_anterior_lev)
                        # print('*********************** OUTRAS INFOS RELEVANTES *********************** ')
                        # print("Resultado_corrigido:", resultado_corrigido_melhorado)
                        # print(resultados_com_delta_025[indices_encontradosPQsomente[k]])
                        # print(matrizes_substituidas_025[indices_encontradosPQsomente[k]])
                        # print(indices_encontradosPQsomente[k])
                        # print('aqui')
                    
    A_matrizT1_pes_carregamento=[]
    A_matrizT1_pes_POTP=[]
    A_matrizT1_pes_POTQ=[]
    A_matrizT1_pes_TENSAO=[]
    A_matrizT1_pes_BqV=[]
    A_matrizT1_pes_ANGULO=[]
    A_matrizT1_pes_BPQ=[]
    A_matrizT1_pes_CONT=[]
    A_matrizT1_pes_OBS=[]

    D_matrizT1_pes_carregamento=[]
    D_matrizT1_pes_POTP=[]
    D_matrizT1_pes_POTQ=[]
    D_matrizT1_pes_TENSAO=[]
    D_matrizT1_pes_BqV=[]    
    D_matrizT1_pes_ANGULO=[]
    D_matrizT1_pes_BPQ=[]
    D_matrizT1_pes_CONT=[]
    D_matrizT1_pes_OBS=[]
    
    
    
    ''' ------------------------------------------------------------------------------------------------ '''
    ''' ------------------------------------ ANÁLISE DE FRONTEIRA -------------------------------------- '''
    ''' ------------------------------------------------------------------------------------------------ '''
    if Lista_de_Candidatos_T1!=[] or Lista_de_Candidatos_T1pv!=[]:

        
        if Lista_de_Candidatos_T1!=[] and Lista_de_Candidatos_T1pv==[]:              
            #print('Lista_de_Candidatos_T2_index=',Lista_de_Candidatos_T1_index)
            #print('Lista_de_Candidatos_T2_siOrno=',Lista_de_Candidatos_T1_siOrno)

            _ , vetor_inicio, vetor_ponta = extrair_vetores_ObjetoAEstudado(Lista_de_Candidatos_T1_siOrno, Lista_de_Candidatos_T1_index)
            vetor_ponta_corrigido = corrigir_capturaPontos(Lista_de_Candidatos_T1_siOrno)

            if vetor_ponta_corrigido!=[]:
                Lista_de_Candidatos_T1_index=[[0]*len(Lista_de_Candidatos_T1_index[0])]+Lista_de_Candidatos_T1_index
                vetor_inicio=[0]+vetor_inicio
                vetor_ponta=vetor_ponta_corrigido+vetor_ponta
                ##Corrigindo Vetor_Inicio
                for AUXILIAR2 in range(len(vetor_inicio)):
                    if AUXILIAR2>0:
                        vetor_inicio[AUXILIAR2]= vetor_inicio[AUXILIAR2]+1                      

            matriz_de_pontos_testes_antes_pes, matriz_diferencas_pes = identifica_PQambos_valor_que_faz_cair(Lista_de_Candidatos_T1_index, vetor_inicio, vetor_ponta)
            Lista_intersecao, Lista_diferencas = encontrar_interseccao_e_diferencas(Lista_de_Candidatos_T1_siOrno, Lista_de_Candidatos_T1_index)
            if Lista_intersecao!=[] and Lista_diferencas!=[]:
                matriz_de_pontos_testes_antes_pes.append(Lista_intersecao)
                matriz_diferencas_pes.append(Lista_diferencas)
            
            #  timer
            time =datetime.now()
            #time_date = datetime.fromtimestamp(time)
            parametro_de_verificacao.append([time.strftime("%H:%M:%S"),' ANÁLISE DE FRONTREIRA: REGIME PESADO ', len(matriz_de_pontos_testes_antes_pes),' -PONTOS DETECTADOS' ])  
            print([time.strftime("%H:%M:%S"),' ANÁLISE DE FRONTREIRA: REGIME PESADO ', len(matriz_de_pontos_testes_antes_pes),' -PONTOS DETECTADOS' ])    

            for cadidat in range(len(matriz_de_pontos_testes_antes_pes)):
                procura_fronteira_up='no'
                ATIVA_up , _ = gerar_vetores_com_variacao(matriz_de_pontos_testes_antes_pes[cadidat], ATIVA_ESPEC, limite_variacao)
                # for auxiliar in range(len(ATIVA_up)):
                #     ATIVA_up[auxiliar]=[float(x) for x in ATIVA_up[auxiliar]]                 
                A_carga_pes=[0]*len(ATIVA_ESPEC)
                A_DeltaV_pes=[0]*len(ATIVA_ESPEC)
                A_PotP_pes=[0]*len(ATIVA_ESPEC)
                A_PotQ_pes=[0]*len(ATIVA_ESPEC)
                A_BqV_pes=[0]*len(ATIVA_ESPEC)
                A_Ang_pes=[0]*len(ATIVA_ESPEC)
                A_Bpq_pes=[0]*len(ATIVA_ESPEC)
                A_cont_pes=0
                stopa_por_nao_encontrar='no'
                while procura_fronteira_up=='no':
                    # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                    #     PVbarIndex, TENSAO_ESPEC, PIndex, ATIVA_up, GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                    # )
                    # for AUXILIAR in range(len(ATIVA_up)):
                    #     matriz_DadosBarra[1][AUXILIAR]=ATIVA_up[AUXILIAR]

                    # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                    #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                    # )
                    for AUXILIAR in range(len(ATIVA_up)):
                        matriz_DadosBarra[1][AUXILIAR]=(float(ATIVA_up[AUXILIAR]))/S_base
                        matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                        matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                        matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                        matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                        infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                        matrizSystem[AUXILIAR][9]=(-1)*(float(ATIVA_up[AUXILIAR]))
                    
                    stopa_por_nao_encontrar=confirmar_se_nao_CAI(matriz_diferencas_pes, matriz_de_pontos_testes_antes_pes, ATIVA_up, ATIVA_ESPEC, cadidat, limite_variacao, stopa_por_nao_encontrar)
                    Fluxo_divergente='no'
                    try:
                        # Execução do fluxo de potência
                        (DeltaV, Delta0, PotP, PotQ, _, _, cont, _, Barras_PQ , _, _, BarraQViola_estatica, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola, _, _, _) = CHAMA_FLNR_03_LTT(
                            matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                        )
                    except Exception as e:
                        Fluxo_divergente='yes'
                    
                    if Fluxo_divergente=='no' and stopa_por_nao_encontrar=='no':
                        Observation='None'
                        resultado_fronteira, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica, VerificaSeViola) 
                        if resultado_fronteira==False:
                            procura_fronteira_up='no'
                            for aux in range(len(ATIVA_ESPEC)):
                                A_carga_pes[aux]=ATIVA_up[aux]
                                A_DeltaV_pes[aux]=DeltaV[aux]
                                A_PotP_pes[aux]=PotP[aux]
                                A_PotQ_pes[aux]=PotQ[aux]
                                A_BqV_pes[aux]=BarraQViola_estatica[aux] 
                                A_Ang_pes[aux]=Delta0[aux]
                                A_Bpq_pes[aux]=Barras_PQ[aux]
                                A_cont_pes=cont

                            elemento_x=matriz_diferencas_pes[cadidat]  # Acessa a matriz de índice cadidat
                            for valor in elemento_x:  # Itera sobre os elementos dessa matriz
                                if ATIVA_up[valor]>ATIVA_ESPEC[valor]*(1+limite_variacao/100):
                                    ATIVA_up[valor] = ATIVA_up[valor] - PassoEstudo_DasCombinacoes 
                                else:
                                    ATIVA_up[valor]=ATIVA_ESPEC[valor]*(1+limite_variacao/100) 
                        else:
                            procura_fronteira_up='yes'
                    else:
                        #ATIVA_up=[0]*len(ATIVA_ESPEC)
                        if  stopa_por_nao_encontrar=='no':
                            Observation='Fluxo divergente.'
                        else:
                            Observation='Fluxo Indiferente'
                        cont=0
                        DeltaV=[0]*len(ATIVA_ESPEC)
                        PotP=[0]*len(ATIVA_ESPEC)
                        PotQ=[0]*len(ATIVA_ESPEC)
                        BarraQViola_estatica=[0]*len(ATIVA_ESPEC)
                        Delta0=[0]*len(ATIVA_ESPEC)
                        Barras_PQ=[0]*len(ATIVA_ESPEC)
                        procura_fronteira_up='yes'

                D_matrizT1_pes_carregamento.append(ATIVA_up)
                D_matrizT1_pes_POTP.append(PotP)
                D_matrizT1_pes_POTQ.append(PotQ)
                D_matrizT1_pes_TENSAO.append(DeltaV)
                D_matrizT1_pes_BqV.append(BarraQViola_estatica)
                D_matrizT1_pes_ANGULO.append(Delta0)
                D_matrizT1_pes_BPQ.append(Barras_PQ)
                D_matrizT1_pes_CONT.append(cont)
                D_matrizT1_pes_OBS.append(Observation)

                A_matrizT1_pes_carregamento.append(A_carga_pes)
                A_matrizT1_pes_POTP.append(A_PotP_pes)
                A_matrizT1_pes_POTQ.append(A_PotQ_pes)
                A_matrizT1_pes_TENSAO.append(A_DeltaV_pes)
                A_matrizT1_pes_BqV.append(A_BqV_pes)
                A_matrizT1_pes_ANGULO.append(A_Ang_pes)
                A_matrizT1_pes_BPQ.append(A_Bpq_pes)
                A_matrizT1_pes_CONT.append(A_cont_pes)
                A_matrizT1_pes_OBS.append(Observation)

            # vetPswing_D_pes=[]
            # for i in range(len(D_matrizT1_pes_POTP)): 
            #     vetPswing_D_pes.append(D_matrizT1_pes_POTP[i][0])
            # print(vetPswing_D_pes)
            
            # D_Pswing_pes_max = max(vetPswing_D_pes)  # Encontra o valor máximo
            # D_Pswing_pes_min = min(vetPswing_D_pes)  # Encontra o valor mínim
            # indice_Pswing_pes_max = vetPswing_D_pes.index(D_Pswing_pes_max)  # Encontra o índice do valor máximo
            # indice_Pswing_pes_min = vetPswing_D_pes.index(D_Pswing_pes_min)  # Encontra o índice do valor mínimo      
        

        if Lista_de_Candidatos_T1==[] and Lista_de_Candidatos_T1pv!=[]:
            #print('Lista_de_Candidatos_T1pv_index=',Lista_de_Candidatos_T1pv_index)
            #print('Lista_de_Candidatos_T1pv_siOrno=',Lista_de_Candidatos_T1pv_siOrno)

            _ , vetor_inicio, vetor_ponta = extrair_vetores_ObjetoAEstudado(Lista_de_Candidatos_T1pv_siOrno, Lista_de_Candidatos_T1pv_index)
            vetor_ponta_corrigido = corrigir_capturaPontos(Lista_de_Candidatos_T1pv_siOrno)

            if vetor_ponta_corrigido!=[]:
                Lista_de_Candidatos_T1pv_index=[[0]*len(Lista_de_Candidatos_T1pv_index[0])]+Lista_de_Candidatos_T1pv_index
                vetor_inicio=[0]+vetor_inicio
                vetor_ponta=vetor_ponta_corrigido+vetor_ponta
                ##Corrigindo Vetor_Inicio
                for AUXILIAR2 in range(len(vetor_inicio)):
                    if AUXILIAR2>0:
                        vetor_inicio[AUXILIAR2]= vetor_inicio[AUXILIAR2]+1                        
            
            matriz_de_pontos_testes_antes_pes, matriz_diferencas_pes = identifica_PQambos_valor_que_faz_cair(Lista_de_Candidatos_T1pv_index, vetor_inicio, vetor_ponta)
            Lista_intersecao, Lista_diferencas = encontrar_interseccao_e_diferencas(Lista_de_Candidatos_T1pv_siOrno, Lista_de_Candidatos_T1pv_index)
            if Lista_intersecao!=[] and Lista_diferencas!=[]:
                matriz_de_pontos_testes_antes_pes.append(Lista_intersecao)
                matriz_diferencas_pes.append(Lista_diferencas)
            
            for cadidat in range(len(matriz_de_pontos_testes_antes_pes)):
                procura_fronteira_up='no'
                ATIVA_up , _ = gerar_vetores_com_variacao(matriz_de_pontos_testes_antes_pes[cadidat], ATIVA_ESPEC, limite_variacao)
                # for auxiliar in range(len(ATIVA_up)):
                #     ATIVA_up[auxiliar]=[float(x) for x in ATIVA_up[auxiliar]]                 
                A_carga_pes=[0]*len(ATIVA_ESPEC)
                A_DeltaV_pes=[0]*len(ATIVA_ESPEC)
                A_PotP_pes=[0]*len(ATIVA_ESPEC)
                A_PotQ_pes=[0]*len(ATIVA_ESPEC)
                A_BqV_pes=[0]*len(ATIVA_ESPEC)
                A_Ang_pes=[0]*len(ATIVA_ESPEC)
                A_Bpq_pes=[0]*len(ATIVA_ESPEC)
                A_cont_pes=0
                stopa_por_nao_encontrar='no'
                while procura_fronteira_up=='no':
                    # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                    #     PVbarIndex, TENSAO_ESPEC, PIndex, ATIVA_up, GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                    # )
                    # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                    #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                    # )
                    for AUXILIAR in range(len(ATIVA_up)):
                        matriz_DadosBarra[1][AUXILIAR]=(float(ATIVA_up[AUXILIAR]))/S_base
                        matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                        matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                        matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                        matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                        infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                        matrizSystem[AUXILIAR][9]=(-1)*(float(ATIVA_up[AUXILIAR]))

                    # Execução do fluxo de potência
                    stopa_por_nao_encontrar=confirmar_se_nao_CAI(matriz_diferencas_pes, matriz_de_pontos_testes_antes_pes, ATIVA_up, ATIVA_ESPEC, cadidat, limite_variacao, stopa_por_nao_encontrar)
                    Fluxo_divergente='no'
                    try:
                        (DeltaV, Delta0, PotP, PotQ, _, _, cont, _, Barras_PQ , _, _, BarraQViola_estatica, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola, _, _, _) = CHAMA_FLNR_03_LTT(
                            matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                        )
                    except Exception as e:
                        Fluxo_divergente='yes'
                    
                    if Fluxo_divergente=='no' and stopa_por_nao_encontrar=='no':
                        Observation='None'                                                
                        resultado_fronteira, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica, VerificaSeViola) 
                        if resultado_fronteira==False:
                            procura_fronteira_up='no'
                            for aux in range(len(ATIVA_ESPEC)):
                                A_carga_pes[aux]=ATIVA_up[aux]
                                A_DeltaV_pes[aux]=DeltaV[aux]
                                A_PotP_pes[aux]=PotP[aux]
                                A_PotQ_pes[aux]=PotQ[aux]
                                A_BqV_pes[aux]=BarraQViola_estatica[aux]  
                                A_Ang_pes[aux]=Delta0[aux]
                                A_Bpq_pes[aux]=Barras_PQ[aux]
                                A_cont_pes=cont

                            elemento_x=matriz_diferencas_pes[cadidat]  # Acessa a matriz de índice cadidat
                            for valor in elemento_x:  # Itera sobre os elementos dessa matriz
                                if ATIVA_up[valor]>ATIVA_ESPEC[valor]*(1+limite_variacao/100):
                                    ATIVA_up[valor] = ATIVA_up[valor] - PassoEstudo_DasCombinacoes 
                                else:
                                    ATIVA_up[valor]=ATIVA_ESPEC[valor]*(1+limite_variacao/100)
                        else:
                            procura_fronteira_up='yes'
                    else:
                        #ATIVA_up=[0]*len(ATIVA_ESPEC)
                        DeltaV=[0]*len(ATIVA_ESPEC)
                        PotP=[0]*len(ATIVA_ESPEC)
                        PotQ=[0]*len(ATIVA_ESPEC)
                        BarraQViola_estatica=[0]*len(ATIVA_ESPEC)
                        Delta0=[0]*len(ATIVA_ESPEC)
                        Barras_PQ=[0]*len(ATIVA_ESPEC)
                        if  stopa_por_nao_encontrar=='no':
                            Observation='Fluxo divergente.'
                        else:
                            Observation='Fluxo Indiferente'
                        cont=0
                        procura_fronteira_up='yes'

                D_matrizT1_pes_carregamento.append(ATIVA_up)
                D_matrizT1_pes_POTP.append(PotP)
                D_matrizT1_pes_POTQ.append(PotQ)
                D_matrizT1_pes_TENSAO.append(DeltaV)
                D_matrizT1_pes_BqV.append(BarraQViola_estatica)
                D_matrizT1_pes_ANGULO.append(Delta0)
                D_matrizT1_pes_BPQ.append(Barras_PQ)
                D_matrizT1_pes_CONT.append(cont)
                D_matrizT1_pes_OBS.append(Observation)

                A_matrizT1_pes_carregamento.append(A_carga_pes)
                A_matrizT1_pes_POTP.append(A_PotP_pes)
                A_matrizT1_pes_POTQ.append(A_PotQ_pes)
                A_matrizT1_pes_TENSAO.append(A_DeltaV_pes)
                A_matrizT1_pes_BqV.append(A_BqV_pes)
                A_matrizT1_pes_ANGULO.append(A_Ang_pes)
                A_matrizT1_pes_BPQ.append(A_Bpq_pes)
                A_matrizT1_pes_CONT.append(A_cont_pes)
                A_matrizT1_pes_OBS.append(Observation)

            # vetPswing_D_pes=[]
            # for i in range(len(D_matrizT1_pes_POTP)): 
            #     vetPswing_D_pes.append(D_matrizT1_pes_POTP[i][0])
            # print(vetPswing_D_pes)
            
            # D_Pswing_pes_max = max(vetPswing_D_pes)  # Encontra o valor máximo
            # D_Pswing_pes_min = min(vetPswing_D_pes)  # Encontra o valor mínim
            # indice_Pswing_pes_max = vetPswing_D_pes.index(D_Pswing_pes_max)  # Encontra o índice do valor máximo
            # indice_Pswing_pes_min = vetPswing_D_pes.index(D_Pswing_pes_min)  # Encontra o índice do valor mínimo                


        if Lista_de_Candidatos_T1!=[] and Lista_de_Candidatos_T1pv!=[]:  
            
            Lista_de_Candidatos_T1_index =Lista_de_Candidatos_T1pv_index+Lista_de_Candidatos_T1_index
            Lista_de_Candidatos_T1_siOrno= Lista_de_Candidatos_T1pv_siOrno+Lista_de_Candidatos_T1_siOrno

            _ , vetor_inicio, vetor_ponta = extrair_vetores_ObjetoAEstudado(Lista_de_Candidatos_T1_siOrno, Lista_de_Candidatos_T1_index)
            vetor_ponta_corrigido = corrigir_capturaPontos(Lista_de_Candidatos_T1_siOrno)

            if vetor_ponta_corrigido!=[]:
                Lista_de_Candidatos_T1_index=[[0]*len(Lista_de_Candidatos_T1_index[0])]+Lista_de_Candidatos_T1_index
                vetor_inicio=[0]+vetor_inicio
                vetor_ponta=vetor_ponta_corrigido+vetor_ponta
                ##Corrigindo Vetor_Inicio
                for AUXILIAR2 in range(len(vetor_inicio)):
                    if AUXILIAR2>0:
                        vetor_inicio[AUXILIAR2]= vetor_inicio[AUXILIAR2]+1    

            matriz_de_pontos_testes_antes_pes, matriz_diferencas_pes = identifica_PQambos_valor_que_faz_cair(Lista_de_Candidatos_T1_index, vetor_inicio, vetor_ponta)
            Lista_intersecao, Lista_diferencas = encontrar_interseccao_e_diferencas(Lista_de_Candidatos_T1_siOrno, Lista_de_Candidatos_T1_index)
            if Lista_intersecao!=[] and Lista_diferencas!=[]:
                matriz_de_pontos_testes_antes_pes.append(Lista_intersecao)
                matriz_diferencas_pes.append(Lista_diferencas)
            
            for cadidat in range(len(matriz_de_pontos_testes_antes_pes)):

                procura_fronteira_up='no'
                ATIVA_up , _ = gerar_vetores_com_variacao(matriz_de_pontos_testes_antes_pes[cadidat], ATIVA_ESPEC, limite_variacao)
                # for auxiliar in range(len(ATIVA_up)):
                #     ATIVA_up[auxiliar]=[float(x) for x in ATIVA_up[auxiliar]]                  
                A_carga_pes=[0]*len(ATIVA_ESPEC)
                A_DeltaV_pes=[0]*len(ATIVA_ESPEC)
                A_PotP_pes=[0]*len(ATIVA_ESPEC)
                A_PotQ_pes=[0]*len(ATIVA_ESPEC)
                A_BqV_pes=[0]*len(ATIVA_ESPEC)
                A_Ang_pes=[0]*len(ATIVA_ESPEC)
                A_Bpq_pes=[0]*len(ATIVA_ESPEC)
                A_cont_pes=0
                stopa_por_nao_encontrar='no'                    
                while procura_fronteira_up=='no':
                    # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                    #     PVbarIndex, TENSAO_ESPEC, PIndex, ATIVA_up, GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                    # )
                    for AUXILIAR in range(len(ATIVA_up)):
                        matriz_DadosBarra[1][AUXILIAR]=(float(ATIVA_up[AUXILIAR]))/S_base
                        matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                        matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                        matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                        matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                        infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                        matrizSystem[AUXILIAR][9]=(-1)*(float(ATIVA_up[AUXILIAR]))

                    # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                    #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                    # )
                    if cadidat==13:
                        print('pause')
                    # Execução do fluxo de potência
                    stopa_por_nao_encontrar=confirmar_se_nao_CAI(matriz_diferencas_pes, matriz_de_pontos_testes_antes_pes, ATIVA_up, ATIVA_ESPEC, cadidat, limite_variacao, stopa_por_nao_encontrar)
                    Fluxo_divergente='no'
                    try:                        
                        (DeltaV, Delta0, PotP, PotQ, _, _, cont, _, Barras_PQ , _, _, BarraQViola_estatica, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola, _, _, _) = CHAMA_FLNR_03_LTT(
                            matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                        )
                    except Exception as e:
                        Fluxo_divergente='yes'
                    
                    if Fluxo_divergente=='no' and stopa_por_nao_encontrar=='no':
                        Observation='None'                                                                            
                        resultado_fronteira, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica, VerificaSeViola) 
                        if resultado_fronteira==False:
                            procura_fronteira_up='no'
                            for aux in range(len(ATIVA_ESPEC)):
                                A_carga_pes[aux]=ATIVA_up[aux]
                                A_DeltaV_pes[aux]=DeltaV[aux]
                                A_PotP_pes[aux]=PotP[aux]
                                A_PotQ_pes[aux]=PotQ[aux]
                                A_BqV_pes[aux]=BarraQViola_estatica[aux]
                                A_Ang_pes[aux]=Delta0[aux]
                                A_Bpq_pes[aux]=Barras_PQ[aux]
                                A_cont_pes=cont

                            elemento_x=matriz_diferencas_pes[cadidat]  # Acessa a matriz de índice cadidat
                            for valor in elemento_x:  # Itera sobre os elementos dessa matriz
                                if ATIVA_up[valor]>ATIVA_ESPEC[valor]*(1+limite_variacao/100):
                                    ATIVA_up[valor] = ATIVA_up[valor] - PassoEstudo_DasCombinacoes 
                                else:
                                    ATIVA_up[valor]=ATIVA_ESPEC[valor]*(1+limite_variacao/100)     
                                # print(ATIVA_ESPEC[valor]*(1+limite_variacao/100))
                                # print(ATIVA_ESPEC[valor]*(1-limite_variacao/100))
                                # print(ATIVA_up[valor])
                                # print('aqui')
                        else:
                            procura_fronteira_up='yes'
                    else:
                        #ATIVA_up=[0]*len(ATIVA_ESPEC)
                        DeltaV=[0]*len(ATIVA_ESPEC)
                        PotP=[0]*len(ATIVA_ESPEC)
                        PotQ=[0]*len(ATIVA_ESPEC)
                        BarraQViola_estatica=[0]*len(ATIVA_ESPEC)
                        Delta0=[0]*len(ATIVA_ESPEC)
                        Barras_PQ=[0]*len(ATIVA_ESPEC)
                        if  stopa_por_nao_encontrar=='no':
                            Observation='Fluxo divergente.'
                        else:
                            Observation='Fluxo Indiferente'
                        cont=0
                        procura_fronteira_up='yes'

                D_matrizT1_pes_carregamento.append(ATIVA_up)
                D_matrizT1_pes_POTP.append(PotP)
                D_matrizT1_pes_POTQ.append(PotQ)
                D_matrizT1_pes_TENSAO.append(DeltaV)
                D_matrizT1_pes_BqV.append(BarraQViola_estatica)
                D_matrizT1_pes_ANGULO.append(Delta0)
                D_matrizT1_pes_BPQ.append(Barras_PQ)
                D_matrizT1_pes_CONT.append(cont)
                D_matrizT1_pes_OBS.append(Observation)

                A_matrizT1_pes_carregamento.append(A_carga_pes)
                A_matrizT1_pes_POTP.append(A_PotP_pes)
                A_matrizT1_pes_POTQ.append(A_PotQ_pes)
                A_matrizT1_pes_TENSAO.append(A_DeltaV_pes)
                A_matrizT1_pes_BqV.append(A_BqV_pes)
                A_matrizT1_pes_ANGULO.append(A_Ang_pes)
                A_matrizT1_pes_BPQ.append(A_Bpq_pes)
                A_matrizT1_pes_CONT.append(A_cont_pes)
                A_matrizT1_pes_OBS.append(Observation)
            #print('aqui')
            # vetPswing_D_pes=[]
            # for i in range(len(D_matrizT1_pes_POTP)): 
            #     vetPswing_D_pes.append(D_matrizT1_pes_POTP[i][0])
            # print(vetPswing_D_pes)
            
            # D_Pswing_pes_max = max(vetPswing_D_pes)  # Encontra o valor máximo
            # D_Pswing_pes_min = min(vetPswing_D_pes)  # Encontra o valor mínim
            # indice_Pswing_pes_max = vetPswing_D_pes.index(D_Pswing_pes_max)  # Encontra o índice do valor máximo
            # indice_Pswing_pes_min = vetPswing_D_pes.index(D_Pswing_pes_min)  # Encontra o índice do valor mínimo  


    A_matrizT2_lev_carregamento=[]
    A_matrizT2_lev_POTP=[]
    A_matrizT2_lev_POTQ=[]
    A_matrizT2_lev_TENSAO=[]
    A_matrizT2_lev_BqV=[]
    A_matrizT2_lev_ANGULO=[]
    A_matrizT2_lev_BPQ=[]
    A_matrizT2_lev_CONT=[]
    A_matrizT2_lev_OBS=[]

    D_matrizT2_lev_carregamento=[]
    D_matrizT2_lev_POTP=[]
    D_matrizT2_lev_POTQ=[]
    D_matrizT2_lev_TENSAO=[]
    D_matrizT2_lev_BqV=[]
    D_matrizT2_lev_ANGULO=[]
    D_matrizT2_lev_BPQ=[]   
    D_matrizT2_lev_CONT=[]
    D_matrizT2_lev_OBS=[]

    if Lista_de_Candidatos_T2!=[] or Lista_de_Candidatos_T2pv!=[]:  


        if Lista_de_Candidatos_T2!=[] and Lista_de_Candidatos_T2pv==[]:  
            
            #print('Lista_de_Candidatos_T2_index=',Lista_de_Candidatos_T2_index)
            #print('Lista_de_Candidatos_T2_siOrno=',Lista_de_Candidatos_T2_siOrno)

            _ , vetor_inicio, vetor_ponta = extrair_vetores_ObjetoAEstudado(Lista_de_Candidatos_T2_siOrno, Lista_de_Candidatos_T2_index)
            vetor_ponta_corrigido = corrigir_capturaPontos(Lista_de_Candidatos_T2_siOrno)

            if vetor_ponta_corrigido!=[]:
                Lista_de_Candidatos_T2_index=[[0]*len(Lista_de_Candidatos_T2_index[0])]+Lista_de_Candidatos_T2_index
                vetor_inicio=[0]+vetor_inicio
                vetor_ponta=vetor_ponta_corrigido+vetor_ponta
                ##Corrigindo Vetor_Inicio
                for AUXILIAR2 in range(len(vetor_inicio)):
                    if AUXILIAR2>0:
                        vetor_inicio[AUXILIAR2]= vetor_inicio[AUXILIAR2]+1                    

            matriz_de_pontos_testes_antes_lev, matriz_diferencas_lev = identifica_PQambos_valor_que_faz_cair(Lista_de_Candidatos_T2_index, vetor_inicio, vetor_ponta)
            Lista_intersecao, Lista_diferencas = encontrar_interseccao_e_diferencas(Lista_de_Candidatos_T2_siOrno, Lista_de_Candidatos_T2_index)
            if Lista_intersecao!=[] and Lista_diferencas!=[]:
                matriz_de_pontos_testes_antes_lev.append(Lista_intersecao)
                matriz_diferencas_lev.append(Lista_diferencas)
            
            #  timer
            time = datetime.now()
            #time_date = datetime.fromtimestamp(time)
            parametro_de_verificacao.append([time.strftime("%H:%M:%S"),'ANÁLISE DE FRONTREIRA: REGIME LEVE', len(matriz_de_pontos_testes_antes_lev),' -PONTOS DETECTADOS' ])  
            print([time.strftime("%H:%M:%S"),'ANÁLISE DE FRONTREIRA: REGIME LEVE', len(matriz_de_pontos_testes_antes_lev),' -PONTOS DETECTADOS' ])

            for cadidat in range(len(matriz_de_pontos_testes_antes_lev)):
                procura_fronteira_down='no'
                _ , ATIVA_down = gerar_vetores_com_variacao(matriz_de_pontos_testes_antes_lev[cadidat], ATIVA_ESPEC, limite_variacao)
                # for auxiliar in range(len(ATIVA_down)):
                #     ATIVA_down[auxiliar]=[float(x) for x in ATIVA_down[auxiliar]]                
                A_carga_lev=[0]*len(ATIVA_ESPEC)
                A_DeltaV_lev=[0]*len(ATIVA_ESPEC)
                A_PotP_lev=[0]*len(ATIVA_ESPEC)
                A_PotQ_lev=[0]*len(ATIVA_ESPEC)
                A_BqV_lev=[0]*len(ATIVA_ESPEC)
                A_Ang_lev=[0]*len(ATIVA_ESPEC)
                A_Bpq_lev=[0]*len(ATIVA_ESPEC)
                A_cont_lev=0
                stopa_por_nao_encontrar='no'                       
                while procura_fronteira_down=='no':
                    # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                    #     PVbarIndex, TENSAO_ESPEC, PIndex, ATIVA_down, GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                    # )
                    # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                    #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                    # )

                    for AUXILIAR in range(len(ATIVA_down)):
                        matriz_DadosBarra[1][AUXILIAR]=(float(ATIVA_down[AUXILIAR]))/S_base
                        matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                        matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                        matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                        matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                        infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                        matrizSystem[AUXILIAR][9]=(-1)*(float(ATIVA_down[AUXILIAR]))

                    # Execução do fluxo de potência
                    stopa_por_nao_encontrar=confirmar_se_nao_CAI(matriz_diferencas_lev, matriz_de_pontos_testes_antes_lev, ATIVA_down, ATIVA_ESPEC, cadidat, limite_variacao, stopa_por_nao_encontrar)
                    Fluxo_divergente='no'
                    try:                        
                        (DeltaV, Delta0, PotP, PotQ, _, _, cont, _, Barras_PQ , _, _, BarraQViola_estatica, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola, _, _, _) = CHAMA_FLNR_03_LTT(
                            matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                        )
                    except Exception as e:
                        Fluxo_divergente='yes'

                    if Fluxo_divergente=='no' and stopa_por_nao_encontrar=='no':
                        Observation='None'                                                
                        resultado_fronteira, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica, VerificaSeViola) 
                        if resultado_fronteira==False:
                            procura_fronteira_down='no'
                            for aux in range(len(ATIVA_ESPEC)):
                                A_carga_lev[aux]=ATIVA_down[aux]
                                A_DeltaV_lev[aux]=DeltaV[aux]
                                A_PotP_lev[aux]=PotP[aux]
                                A_PotQ_lev[aux]=PotQ[aux]
                                A_BqV_lev[aux]=BarraQViola_estatica[aux]
                                A_Ang_lev[aux]=Delta0[aux]
                                A_Bpq_lev[aux]=Barras_PQ[aux]
                                A_cont_lev=cont

                            elemento_x=matriz_diferencas_lev[cadidat]  # Acessa a matriz de índice cadidat
                            for valor in elemento_x:  # Itera sobre os elementos dessa matriz
                                if ATIVA_down[valor]<ATIVA_ESPEC[valor]*(1-limite_variacao/100):
                                    ATIVA_down[valor] = ATIVA_down[valor] + PassoEstudo_DasCombinacoes  
                                else:
                                    ATIVA_down[valor]=ATIVA_ESPEC[valor]*(1-limite_variacao/100)   
                        else:
                            procura_fronteira_down='yes'
                    else:
                        #ATIVA_down=[0]*len(ATIVA_ESPEC)
                        DeltaV=[0]*len(ATIVA_ESPEC)
                        PotP=[0]*len(ATIVA_ESPEC)
                        PotQ=[0]*len(ATIVA_ESPEC)
                        BarraQViola_estatica=[0]*len(ATIVA_ESPEC)
                        Delta0=[0]*len(ATIVA_ESPEC)
                        Barras_PQ=[0]*len(ATIVA_ESPEC)
                        if  stopa_por_nao_encontrar=='no':
                            Observation='Fluxo divergente.'
                        else:
                            Observation='Fluxo Indiferente'
                        cont=0
                        procura_fronteira_down='yes'

                D_matrizT2_lev_carregamento.append(ATIVA_down)
                D_matrizT2_lev_POTP.append(PotP)
                D_matrizT2_lev_POTQ.append(PotQ)
                D_matrizT2_lev_TENSAO.append(DeltaV)
                D_matrizT2_lev_BqV.append(BarraQViola_estatica)
                D_matrizT2_lev_ANGULO.append(Delta0)
                D_matrizT2_lev_BPQ.append(Barras_PQ)
                D_matrizT2_lev_CONT.append(cont)
                D_matrizT2_lev_OBS.append(Observation)

                A_matrizT2_lev_carregamento.append(A_carga_lev)
                A_matrizT2_lev_POTP.append(A_PotP_lev)
                A_matrizT2_lev_POTQ.append(A_PotQ_lev)
                A_matrizT2_lev_TENSAO.append(A_DeltaV_lev)
                A_matrizT2_lev_BqV.append(A_BqV_lev)
                A_matrizT2_lev_ANGULO.append(A_Ang_lev)
                A_matrizT2_lev_BPQ.append(A_Bpq_lev)
                A_matrizT2_lev_CONT.append(A_cont_lev)
                A_matrizT2_lev_OBS.append(Observation)

            # vetPswing_D_lev=[]
            # for i in range(len(D_matrizT2_lev_POTP)): 
            #     vetPswing_D_lev.append(D_matrizT2_lev_POTP[i][0])
            # print(vetPswing_D_lev)
            
            # D_Pswing_lev_max = max(vetPswing_D_lev)  # Encontra o valor máximo
            # D_Pswing_lev_min = min(vetPswing_D_lev)  # Encontra o valor mínim
            # indice_Pswing_lev_max = vetPswing_D_lev.index(D_Pswing_lev_max)  # Encontra o índice do valor máximo
            # indice_Pswing_lev_min = vetPswing_D_lev.index(D_Pswing_lev_min)  # Encontra o índice do valor mínimo              


        if Lista_de_Candidatos_T2==[] and Lista_de_Candidatos_T2pv!=[]:  
            
            #print('Lista_de_Candidatos_T2_index=',Lista_de_Candidatos_T2pv_index)
            #print('Lista_de_Candidatos_T2_siOrno=',Lista_de_Candidatos_T2pv_siOrno)

            _ , vetor_inicio, vetor_ponta = extrair_vetores_ObjetoAEstudado(Lista_de_Candidatos_T2pv_siOrno, Lista_de_Candidatos_T2pv_index)
            vetor_ponta_corrigido = corrigir_capturaPontos(Lista_de_Candidatos_T2pv_siOrno)

            if vetor_ponta_corrigido!=[]:
                Lista_de_Candidatos_T2pv_index=[[0]*len(Lista_de_Candidatos_T2pv_index[0])]+Lista_de_Candidatos_T2pv_index
                vetor_inicio=[0]+vetor_inicio
                vetor_ponta=vetor_ponta_corrigido+vetor_ponta
                ##Corrigindo Vetor_Inicio
                for AUXILIAR2 in range(len(vetor_inicio)):
                    if AUXILIAR2>0:
                        vetor_inicio[AUXILIAR2]= vetor_inicio[AUXILIAR2]+1

            matriz_de_pontos_testes_antes_lev, matriz_diferencas_lev = identifica_PQambos_valor_que_faz_cair(Lista_de_Candidatos_T2pv_index, vetor_inicio, vetor_ponta)
            Lista_intersecao, Lista_diferencas = encontrar_interseccao_e_diferencas(Lista_de_Candidatos_T2pv_siOrno, Lista_de_Candidatos_T2pv_index)
            if Lista_intersecao!=[] and Lista_diferencas!=[]:
                matriz_de_pontos_testes_antes_lev.append(Lista_intersecao)
                matriz_diferencas_lev.append(Lista_diferencas)

            for cadidat in range(len(matriz_de_pontos_testes_antes_lev)):
                procura_fronteira_down='no'
                _ , ATIVA_down = gerar_vetores_com_variacao(matriz_de_pontos_testes_antes_lev[cadidat], ATIVA_ESPEC, limite_variacao)
                # for auxiliar in range(len(ATIVA_down)):
                #     ATIVA_down[auxiliar]=[float(x) for x in ATIVA_down[auxiliar]]
                A_carga_lev=[0]*len(ATIVA_ESPEC)
                A_DeltaV_lev=[0]*len(ATIVA_ESPEC)
                A_PotP_lev=[0]*len(ATIVA_ESPEC)
                A_PotQ_lev=[0]*len(ATIVA_ESPEC)
                A_BqV_lev=[0]*len(ATIVA_ESPEC)
                A_Ang_lev=[0]*len(ATIVA_ESPEC)
                A_Bpq_lev=[0]*len(ATIVA_ESPEC)
                A_cont_lev=0
                stopa_por_nao_encontrar='no'
                while procura_fronteira_down=='no':
                    # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                    #     PVbarIndex, TENSAO_ESPEC, PIndex, ATIVA_down, GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                    # )
                    # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                    #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                    # )

                    for AUXILIAR in range(len(ATIVA_down)):
                        matriz_DadosBarra[1][AUXILIAR]=(float(ATIVA_down[AUXILIAR]))/S_base
                        matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                        matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                        matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                        matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                        infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                        matrizSystem[AUXILIAR][9]=(-1)*(float(ATIVA_down[AUXILIAR]))

                    # Execução do fluxo de potência
                    stopa_por_nao_encontrar=confirmar_se_nao_CAI(matriz_diferencas_lev, matriz_de_pontos_testes_antes_lev, ATIVA_down, ATIVA_ESPEC, cadidat, limite_variacao, stopa_por_nao_encontrar)
                    Fluxo_divergente='no'
                    try:                        
                        (DeltaV, Delta0, PotP, PotQ, _, _, cont, _, Barras_PQ , _, _, BarraQViola_estatica, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola, _, _, _) = CHAMA_FLNR_03_LTT(
                            matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                        )
                    except Exception as e:
                        Fluxo_divergente='yes'
                    
                    if Fluxo_divergente=='no' and stopa_por_nao_encontrar=='no':
                        Observation='None'                                                 
                        resultado_fronteira, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica, VerificaSeViola) 
                        if resultado_fronteira==False:
                            procura_fronteira_down='no'
                            for aux in range(len(ATIVA_ESPEC)):
                                A_carga_lev[aux]=ATIVA_down[aux]
                                A_DeltaV_lev[aux]=DeltaV[aux]
                                A_PotP_lev[aux]=PotP[aux]
                                A_PotQ_lev[aux]=PotQ[aux]
                                A_BqV_lev[aux]=BarraQViola_estatica[aux] 
                                A_Ang_lev[aux]=Delta0[aux]
                                A_Bpq_lev[aux]=Barras_PQ[aux]
                                A_cont_lev=cont

                            elemento_x=matriz_diferencas_lev[cadidat]  # Acessa a matriz de índice cadidat
                            for valor in elemento_x:  # Itera sobre os elementos dessa matriz
                                if ATIVA_down[valor]<ATIVA_ESPEC[valor]*(1-limite_variacao/100):
                                    ATIVA_down[valor] = ATIVA_down[valor] + PassoEstudo_DasCombinacoes 
                                else:
                                    ATIVA_down[valor]=ATIVA_ESPEC[valor]*(1-limite_variacao/100)   
                        else:
                            procura_fronteira_down='yes'
                    else:
                        #ATIVA_down=[0]*len(ATIVA_ESPEC)
                        DeltaV=[0]*len(ATIVA_ESPEC)
                        PotP=[0]*len(ATIVA_ESPEC)
                        PotQ=[0]*len(ATIVA_ESPEC)
                        BarraQViola_estatica=[0]*len(ATIVA_ESPEC)
                        Delta0=[0]*len(ATIVA_ESPEC)
                        Barras_PQ=[0]*len(ATIVA_ESPEC)
                        if  stopa_por_nao_encontrar=='no':
                            Observation='Fluxo divergente.'
                        else:
                            Observation='Fluxo Indiferente'
                        cont=0
                        procura_fronteira_down='yes'

                D_matrizT2_lev_carregamento.append(ATIVA_down)
                D_matrizT2_lev_POTP.append(PotP)
                D_matrizT2_lev_POTQ.append(PotQ)
                D_matrizT2_lev_TENSAO.append(DeltaV)
                D_matrizT2_lev_BqV.append(BarraQViola_estatica)
                D_matrizT2_lev_ANGULO.append(Delta0)
                D_matrizT2_lev_BPQ.append(Barras_PQ)
                D_matrizT2_lev_CONT.append(cont)
                D_matrizT2_lev_OBS.append(Observation)

                A_matrizT2_lev_carregamento.append(A_carga_lev)
                A_matrizT2_lev_POTP.append(A_PotP_lev)
                A_matrizT2_lev_POTQ.append(A_PotQ_lev)
                A_matrizT2_lev_TENSAO.append(A_DeltaV_lev)
                A_matrizT2_lev_BqV.append(A_BqV_lev)
                A_matrizT2_lev_ANGULO.append(A_Ang_lev)
                A_matrizT2_lev_BPQ.append(A_Bpq_lev)
                A_matrizT2_lev_CONT.append(A_cont_lev)
                A_matrizT2_lev_OBS.append(Observation)

            # vetPswing_D_lev=[]
            # for i in range(len(D_matrizT2_lev_POTP)): 
            #     vetPswing_D_lev.append(D_matrizT2_lev_POTP[i][0])
            # print(vetPswing_D_lev)
            
            # D_Pswing_lev_max = max(vetPswing_D_lev)  # Encontra o valor máximo
            # D_Pswing_lev_min = min(vetPswing_D_lev)  # Encontra o valor mínim
            # indice_Pswing_lev_max = vetPswing_D_lev.index(D_Pswing_lev_max)  # Encontra o índice do valor máximo
            # indice_Pswing_lev_min = vetPswing_D_lev.index(D_Pswing_lev_min)  # Encontra o índice do valor mínimo              


        if Lista_de_Candidatos_T2!=[] and Lista_de_Candidatos_T2pv!=[]:
            Lista_de_Candidatos_T2_index =Lista_de_Candidatos_T2pv_index+Lista_de_Candidatos_T2_index
            Lista_de_Candidatos_T2_siOrno=Lista_de_Candidatos_T2pv_siOrno+Lista_de_Candidatos_T2_siOrno  

            #print('Lista_de_Candidatos_T2_index=',Lista_de_Candidatos_T2_index)
            #print('Lista_de_Candidatos_T2_siOrno=',Lista_de_Candidatos_T2_siOrno)

            _ , vetor_inicio, vetor_ponta = extrair_vetores_ObjetoAEstudado(Lista_de_Candidatos_T2_siOrno, Lista_de_Candidatos_T2_index)
            vetor_ponta_corrigido = corrigir_capturaPontos(Lista_de_Candidatos_T2_siOrno)

            if vetor_ponta_corrigido!=[]:
                Lista_de_Candidatos_T2_index=[[0]*len(Lista_de_Candidatos_T2_index[0])]+Lista_de_Candidatos_T2_index
                vetor_inicio=[0]+vetor_inicio
                vetor_ponta=vetor_ponta_corrigido+vetor_ponta
                ##Corrigindo Vetor_Inicio
                for AUXILIAR2 in range(len(vetor_inicio)):
                    if AUXILIAR2>0:
                        vetor_inicio[AUXILIAR2]= vetor_inicio[AUXILIAR2]+1

            matriz_de_pontos_testes_antes_lev, matriz_diferencas_lev = identifica_PQambos_valor_que_faz_cair(Lista_de_Candidatos_T2_index, vetor_inicio, vetor_ponta)
            Lista_intersecao, Lista_diferencas = encontrar_interseccao_e_diferencas(Lista_de_Candidatos_T2_siOrno, Lista_de_Candidatos_T2_index)
            if Lista_intersecao!=[] and Lista_diferencas!=[]:
                matriz_de_pontos_testes_antes_lev.append(Lista_intersecao)
                matriz_diferencas_lev.append(Lista_diferencas)

            for cadidat in range(len(matriz_de_pontos_testes_antes_lev)):
                procura_fronteira_down='no'
                _ , ATIVA_down = gerar_vetores_com_variacao(matriz_de_pontos_testes_antes_lev[cadidat], ATIVA_ESPEC, limite_variacao)
                A_carga_lev=[0]*len(ATIVA_ESPEC)
                A_DeltaV_lev=[0]*len(ATIVA_ESPEC)
                A_PotP_lev=[0]*len(ATIVA_ESPEC)
                A_PotQ_lev=[0]*len(ATIVA_ESPEC)
                A_BqV_lev=[0]*len(ATIVA_ESPEC)
                A_Ang_lev=[0]*len(ATIVA_ESPEC)
                A_Bpq_lev=[0]*len(ATIVA_ESPEC)
                A_cont_lev=0
                stopa_por_nao_encontrar='no'
                while procura_fronteira_down=='no':
                    # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                    #     PVbarIndex, TENSAO_ESPEC, PIndex, ATIVA_down, GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                    # )
                    # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                    #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                    # )

                    for AUXILIAR in range(len(ATIVA_down)):
                        matriz_DadosBarra[1][AUXILIAR]=(float(ATIVA_down[AUXILIAR]))/S_base
                        matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                        matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                        matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                        matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                        infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                        matrizSystem[AUXILIAR][9]=(-1)*(float(ATIVA_down[AUXILIAR]))

                    # # Execução do fluxo de potência
                    # elemento_x=matriz_diferencas_lev[cadidat]  # Acessa a matriz de índice cadidat
                                       

                    # verificador=0
                    # verificador_auxiliar=len(elemento_x)
                    # vetorVigia=[]
                    # for auxiliar_verificador in range(len(matriz_de_pontos_testes_antes_lev[cadidat])):
                    #     if matriz_de_pontos_testes_antes_lev[cadidat][auxiliar_verificador]!=0:
                    #         verificador_auxiliar=verificador_auxiliar+1
                    #         vetorVigia.append(matriz_de_pontos_testes_antes_lev[cadidat][auxiliar_verificador])                    

                    # vetorVigia=vetorVigia+elemento_x
                    # for valor in vetorVigia:  # Itera sobre os elementos dessa matriz
                    #     if ATIVA_down[valor]==ATIVA_ESPEC[valor]*(1-limite_variacao/100):
                    #         verificador=verificador+1

                    # if verificador==verificador_auxiliar:
                    #     stopa_por_nao_encontrar='yes'                    
                    stopa_por_nao_encontrar=confirmar_se_nao_CAI(matriz_diferencas_lev, matriz_de_pontos_testes_antes_lev, ATIVA_down, ATIVA_ESPEC, cadidat, limite_variacao, stopa_por_nao_encontrar)        
                    Fluxo_divergente='no'
                    try:                        
                        (DeltaV, Delta0, PotP, PotQ, _, _, cont, _, Barras_PQ , _, _, BarraQViola_estatica, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola, _, _, _) = CHAMA_FLNR_03_LTT(
                            matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                        )
                    except Exception as e:
                        Fluxo_divergente='yes'
                    
                    if Fluxo_divergente=='no' and stopa_por_nao_encontrar=='no':
                        Observation='None'                                                
                        resultado_fronteira, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica, VerificaSeViola) 
                        if (resultado_fronteira==False):
                            procura_fronteira_down='no'
                            for aux in range(len(ATIVA_ESPEC)):
                                A_carga_lev[aux]=ATIVA_down[aux]
                                A_DeltaV_lev[aux]=DeltaV[aux]
                                A_PotP_lev[aux]=PotP[aux]
                                A_PotQ_lev[aux]=PotQ[aux]
                                A_BqV_lev[aux]=BarraQViola_estatica[aux]
                                A_Ang_lev[aux]=Delta0[aux]
                                A_Bpq_lev[aux]=Barras_PQ[aux]
                                A_cont_lev=cont

                            elemento_x=matriz_diferencas_lev[cadidat]  # Acessa a matriz de índice cadidat
                            for valor in elemento_x:  # Itera sobre os elementos dessa matriz
                                if ATIVA_down[valor]<ATIVA_ESPEC[valor]*(1-limite_variacao/100):
                                    ATIVA_down[valor] = ATIVA_down[valor] + PassoEstudo_DasCombinacoes  
                                else:
                                    ATIVA_down[valor]=ATIVA_ESPEC[valor]*(1-limite_variacao/100)   
                        else:
                            procura_fronteira_down='yes'
                    else:
                        #ATIVA_down=[0]*len(ATIVA_ESPEC)
                        DeltaV=[0]*len(ATIVA_ESPEC)
                        PotP=[0]*len(ATIVA_ESPEC)
                        PotQ=[0]*len(ATIVA_ESPEC)
                        BarraQViola_estatica=[0]*len(ATIVA_ESPEC)
                        Delta0=[0]*len(ATIVA_ESPEC)
                        Barras_PQ=[0]*len(ATIVA_ESPEC)
                        if  stopa_por_nao_encontrar=='no':
                            Observation='Fluxo divergente.'
                        else:
                            Observation='Fluxo Indiferente'
                        cont=0
                        procura_fronteira_down='yes'

                D_matrizT2_lev_carregamento.append(ATIVA_down)
                D_matrizT2_lev_POTP.append(PotP)
                D_matrizT2_lev_POTQ.append(PotQ)
                D_matrizT2_lev_TENSAO.append(DeltaV)
                D_matrizT2_lev_BqV.append(BarraQViola_estatica)
                D_matrizT2_lev_ANGULO.append(Delta0)
                D_matrizT2_lev_BPQ.append(Barras_PQ)
                D_matrizT2_lev_CONT.append(cont)
                D_matrizT2_lev_OBS.append(Observation)

                A_matrizT2_lev_carregamento.append(A_carga_lev)
                A_matrizT2_lev_POTP.append(A_PotP_lev)
                A_matrizT2_lev_POTQ.append(A_PotQ_lev)
                A_matrizT2_lev_TENSAO.append(A_DeltaV_lev)
                A_matrizT2_lev_BqV.append(A_BqV_lev)
                A_matrizT2_lev_ANGULO.append(A_Ang_lev)
                A_matrizT2_lev_BPQ.append(A_Bpq_lev)
                A_matrizT2_lev_CONT.append(A_cont_lev)
                A_matrizT2_lev_OBS.append(Observation)

            # vetPswing_D_lev=[]
            # for i in range(len(D_matrizT2_lev_POTP)): 
            #     vetPswing_D_lev.append(D_matrizT2_lev_POTP[i][0])
            # print(vetPswing_D_lev)
            
            # D_Pswing_lev_max = max(vetPswing_D_lev)  # Encontra o valor máximo
            # D_Pswing_lev_min = min(vetPswing_D_lev)  # Encontra o valor mínim
            # indice_Pswing_lev_max = vetPswing_D_lev.index(D_Pswing_lev_max)  # Encontra o índice do valor máximo
            # indice_Pswing_lev_min = vetPswing_D_lev.index(D_Pswing_lev_min)  # Encontra o índice do valor mínimo  



            #print('aqui')
        
    A_matrizT3_pes_carregamento=[]
    A_matrizT3_pes_POTP=[]
    A_matrizT3_pes_POTQ=[]
    A_matrizT3_pes_TENSAO=[]
    A_matrizT3_pes_BqV=[]
    A_matrizT3_pes_ANGULO=[]
    A_matrizT3_pes_BPQ=[]
    A_matrizT3_pes_CONT=[]
    A_matrizT3_pes_OBS=[]
    
    D_MatrizT3_pes_carregamento=[]
    D_MatrizT3_pes_POTP=[]
    D_MatrizT3_pes_POTQ=[]
    D_MatrizT3_pes_TENSAO=[]
    D_MatrizT3_pes_BqV=[]
    D_MatrizT3_pes_ANGULO=[]
    D_MatrizT3_pes_BPQ=[]
    D_MatrizT3_pes_CONT=[]
    D_MatrizT3_pes_OBS=[]        
    
    if Lista_de_Candidatos_T3!=[] and Lista_de_Candidatos_T4==[]: 


        if PQpes=='yes':
         #if PQpes=='yes' and PQlev=='no':
            elementos, _ , candidates_vetor = arrumadadosDados(candidateviola_block_anterior_pes,candidate_bloc_anterior_pes)
            #print('elementos=',elementos)
            #print('aqui')
            #print(indices_doBloco)
            # print('candidate_bloc_anterior=',candidate_bloc_anterior)
            # print(candidateviola_block_anterior)

            _ , vetor_inicio, vetor_ponta = extrair_vetores_ObjetoAEstudado(elementos, candidates_vetor)
            vetor_ponta_corrigido = corrigir_capturaPontos(elementos)

            if vetor_ponta_corrigido!=[]:
                candidates_vetor=[[0]*len(candidates_vetor[0])]+candidates_vetor
                vetor_inicio=[0]+vetor_inicio
                vetor_ponta=vetor_ponta_corrigido+vetor_ponta
                ##Corrigindo Vetor_Inicio
                for AUXILIAR2 in range(len(vetor_inicio)):
                    if AUXILIAR2>0:
                        vetor_inicio[AUXILIAR2]= vetor_inicio[AUXILIAR2]+1

            # print("Vet_objeto:", vet_objeto)
            # print("Vetor_inicio:", vetor_inicio)
            # print("Vetor_ponta:", vetor_ponta)
            # print('-------------------------------------------')
            # print('-------------------------------------------------------------------------------------------')
            # print('-------------------------------------------')
            # print('-------------------------------------------------------------------------------------------')
            # print('-------------------------------------------')
            # print('------------------------------------------------------INICIO-------------------------------')
            # print("candidates_vetor:", candidates_vetor)
            # print('-------------------------------------------')
            # print('-------------------------------------------------------------------------------------------')
            # print('-------------------------------------------')
            # print('-------------------------------------------------------------------------------------------')
            # print('-------------------------------------------')
            # print('------------------------------------------------------FIM----------------------------------')
            # print(primeiroAviolar)
            # print(ultimoAviolar)
            #print('aqui33')
            
            #indices_encontrados_pontosInteresse_lev = buscar_indices_matrizes(matrizes_substituidas_025, vet_objeto)
            # print(indices_encontrados_pontosInteresse_lev)          
            # print('aqui')

            # Chamando a função
            #matriz_de_pontos_testes, diferencas = criar_matriz_de_pontos_testes(candidates_vetor, vetor_inicio, vetor_ponta)
            matriz_de_pontos_testes_antes_pes, matriz_diferencas_pes = identifica_PQambos_valor_que_faz_cair(candidates_vetor, vetor_inicio, vetor_ponta)
            # Resultado
            # print("Matriz de diferenças:")
            # for linha in matriz_diferencas:
            #     print(linha)
                
            # # Resultados
            # print("matriz_de_pontos_testes_antes=")
            # for linha in matriz_de_pontos_testes_antes:
            #     print(linha)
            # print('aqui')

            #print('aqui1')
            #  timer
            time = datetime.now()
            #time_date = datetime.fromtimestamp(time)
            parametro_de_verificacao.append([time.strftime("%H:%M:%S"),'ANÁLISE DE FRONTREIRA: REGIME PESADO', len(matriz_de_pontos_testes_antes_pes),' -PONTOS DETECTADOS' ])  
            print([time.strftime("%H:%M:%S"),'ANÁLISE DE FRONTREIRA: REGIME PESADO', len(matriz_de_pontos_testes_antes_pes),' -PONTOS DETECTADOS' ]) 

            for cadidat in range(len(matriz_de_pontos_testes_antes_pes)):
                #print(cadidat)
                procura_fronteira_up='no'
                ATIVA_up , _ = gerar_vetores_com_variacao(matriz_de_pontos_testes_antes_pes[cadidat], ATIVA_ESPEC, limite_variacao)
                # for auxiliar in range(len(ATIVA_up)):
                #     ATIVA_up[auxiliar]=[float(x) for x in ATIVA_up[auxiliar]]                  
                A_carga_pes=[0]*len(ATIVA_ESPEC)
                A_DeltaV_pes=[0]*len(ATIVA_ESPEC)
                A_PotP_pes=[0]*len(ATIVA_ESPEC)
                A_PotQ_pes=[0]*len(ATIVA_ESPEC)
                A_BqV_pes=[0]*len(ATIVA_ESPEC)
                A_Ang_pes=[0]*len(ATIVA_ESPEC)
                A_Bpq_pes=[0]*len(ATIVA_ESPEC)
                A_cont_pes=0
                stopa_por_nao_encontrar='no'                
                while procura_fronteira_up=='no':
                    # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                    #     PVbarIndex, TENSAO_ESPEC, PIndex, ATIVA_up, GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                    # )
                    # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                    #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                    # )

                    for AUXILIAR in range(len(ATIVA_up)):
                        matriz_DadosBarra[1][AUXILIAR]=(float(ATIVA_up[AUXILIAR]))/S_base
                        matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                        matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                        matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                        matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                        infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                        matrizSystem[AUXILIAR][9]=(-1)*(float(ATIVA_up[AUXILIAR]))

                    # Execução do fluxo de potência
                    stopa_por_nao_encontrar=confirmar_se_nao_CAI(matriz_diferencas_pes, matriz_de_pontos_testes_antes_pes, ATIVA_up, ATIVA_ESPEC, cadidat, limite_variacao, stopa_por_nao_encontrar)
                    Fluxo_divergente='no'
                    try:
                        (DeltaV, Delta0, PotP, PotQ, _, _, cont, _, Barras_PQ , _, _, BarraQViola_estatica, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola, _, _, _) = CHAMA_FLNR_03_LTT(
                            matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                        )
                    except Exception as e:
                        Fluxo_divergente='yes'
                    
                    if Fluxo_divergente=='no' and stopa_por_nao_encontrar=='no':  
                        Observation='None'                                        
                        resultado_fronteira, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica, VerificaSeViola) 
                        if resultado_fronteira==False:
                            procura_fronteira_up='no'
                            for aux in range(len(ATIVA_ESPEC)):
                                A_carga_pes[aux]=ATIVA_up[aux]
                                A_DeltaV_pes[aux]=DeltaV[aux]
                                A_PotP_pes[aux]=PotP[aux]
                                A_PotQ_pes[aux]=PotQ[aux]
                                A_BqV_pes[aux]=BarraQViola_estatica[aux] 
                                A_Ang_pes[aux]=Delta0[aux]
                                A_Bpq_pes[aux]=Barras_PQ[aux]
                                A_cont_pes=cont

                            elemento_x=matriz_diferencas_pes[cadidat]  # Acessa a matriz de índice cadidat
                            for valor in elemento_x:  # Itera sobre os elementos dessa matriz
                                if ATIVA_up[valor]>ATIVA_ESPEC[valor]*(1+limite_variacao/100):
                                    ATIVA_up[valor] = ATIVA_up[valor] - PassoEstudo_DasCombinacoes
                                else:
                                    ATIVA_up[valor]=ATIVA_ESPEC[valor]*(1+limite_variacao/100)   
                        else:
                            procura_fronteira_up='yes'
                    else:
                        #ATIVA_up=[0]*len(ATIVA_ESPEC)
                        DeltaV=[0]*len(ATIVA_ESPEC)
                        PotP=[0]*len(ATIVA_ESPEC)
                        PotQ=[0]*len(ATIVA_ESPEC)
                        BarraQViola_estatica=[0]*len(ATIVA_ESPEC)
                        Delta0=[0]*len(ATIVA_ESPEC)
                        Barras_PQ=[0]*len(ATIVA_ESPEC)
                        if  stopa_por_nao_encontrar=='no':
                            Observation='Fluxo divergente.'
                        else:
                            Observation='Fluxo Indiferente'
                        cont=0
                        procura_fronteira_up='yes'

                D_MatrizT3_pes_carregamento.append(ATIVA_up)
                D_MatrizT3_pes_POTP.append(PotP)
                D_MatrizT3_pes_POTQ.append(PotQ)
                D_MatrizT3_pes_TENSAO.append(DeltaV)
                D_MatrizT3_pes_BqV.append(BarraQViola_estatica)
                D_MatrizT3_pes_ANGULO.append(Delta0)
                D_MatrizT3_pes_BPQ.append(Barras_PQ)
                D_MatrizT3_pes_CONT.append(cont)
                D_MatrizT3_pes_OBS.append(Observation)                

                A_matrizT3_pes_carregamento.append(A_carga_pes)
                A_matrizT3_pes_POTP.append(A_PotP_pes)
                A_matrizT3_pes_POTQ.append(A_PotQ_pes)
                A_matrizT3_pes_TENSAO.append(A_DeltaV_pes)
                A_matrizT3_pes_BqV.append(A_BqV_pes)
                A_matrizT3_pes_ANGULO.append(A_Ang_pes)
                A_matrizT3_pes_BPQ.append(A_Bpq_pes)
                A_matrizT3_pes_CONT.append(A_cont_pes)
                A_matrizT3_pes_OBS.append(Observation)                

            # vetPswing_D_pes=[]
            # for i in range(len(D_MatrizT3_pes_POTP)): 
            #     vetPswing_D_pes.append(D_MatrizT3_pes_POTP[i][0])
            # print(vetPswing_D_lev)
            
            # D_Pswing_pes_max = max(vetPswing_D_pes)  # Encontra o valor máximo
            # D_Pswing_pes_min = min(vetPswing_D_pes)  # Encontra o valor mínim
            # indice_Pswing_pes_max = vetPswing_D_lev.index(D_Pswing_pes_max)  # Encontra o índice do valor máximo
            # indice_Pswing_pes_min = vetPswing_D_lev.index(D_Pswing_pes_min)  # Encontra o índice do valor mínimo
        
    A_matrizT3_lev_carregamento=[]
    A_matrizT3_lev_POTP=[]
    A_matrizT3_lev_POTQ=[]
    A_matrizT3_lev_TENSAO=[]
    A_matrizT3_lev_BqV=[]
    A_matrizT3_lev_ANGULO=[]
    A_matrizT3_lev_BPQ=[]
    A_matrizT3_lev_CONT=[]
    A_matrizT3_lev_OBS=[]


    D_MatrizT3_lev_carregamento=[]
    D_MatrizT3_lev_POTP=[]
    D_MatrizT3_lev_POTQ=[]
    D_MatrizT3_lev_TENSAO=[]
    D_MatrizT3_lev_BqV=[]
    D_MatrizT3_lev_ANGULO=[]
    D_MatrizT3_lev_BPQ=[]
    D_MatrizT3_lev_CONT=[]
    D_MatrizT3_lev_OBS=[] 

    if Lista_de_Candidatos_T3==[] and Lista_de_Candidatos_T4!=[]:


        #if PQpes=='no' and PQlev=='yes':
        if PQlev=='yes':
            elementos, _ , candidates_vetor = arrumadadosDados(candidateviola_block_anterior_lev,candidate_bloc_anterior_lev)
            #print('elementos=',elementos)
            #print(indices_doBloco)
            # print('candidate_bloc_anterior=',candidate_bloc_anterior)
            # print(candidateviola_block_anterior)
            
            _ , vetor_inicio, vetor_ponta = extrair_vetores_ObjetoAEstudado(elementos, candidates_vetor)
            vetor_ponta_corrigido = corrigir_capturaPontos(elementos)

            if vetor_ponta_corrigido!=[]:
                candidates_vetor=[[0]*len(candidates_vetor[0])]+candidates_vetor
                vetor_inicio=[0]+vetor_inicio
                vetor_ponta=vetor_ponta_corrigido+vetor_ponta
                ##Corrigindo Vetor_Inicio
                for AUXILIAR2 in range(len(vetor_inicio)):
                    if AUXILIAR2>0:
                        vetor_inicio[AUXILIAR2]= vetor_inicio[AUXILIAR2]+1                            

            # print("Vet_objeto:", vet_objeto)
            # print("Vetor_inicio:", vetor_inicio)
            # print("Vetor_ponta:", vetor_ponta)
            # print('-------------------------------------------')
            # print('-------------------------------------------------------------------------------------------')
            # print('-------------------------------------------')
            # print('-------------------------------------------------------------------------------------------')
            # print('-------------------------------------------')
            # print('------------------------------------------------------INICIO-------------------------------')
            # print("candidates_vetor:", candidates_vetor)
            # print('-------------------------------------------')
            # print('-------------------------------------------------------------------------------------------')
            # print('-------------------------------------------')
            # print('-------------------------------------------------------------------------------------------')
            # print('-------------------------------------------')
            # print('------------------------------------------------------FIM----------------------------------')
            # print(primeiroAviolar)
            # print(ultimoAviolar)
            #print('aqui33')
            
            #indices_encontrados_pontosInteresse_lev = buscar_indices_matrizes(matrizes_substituidas_025, vet_objeto)
            # print(indices_encontrados_pontosInteresse_lev)               
            # print('aqui')

            # Chamando a função
            #matriz_de_pontos_testes, diferencas = criar_matriz_de_pontos_testes(candidates_vetor, vetor_inicio, vetor_ponta)
            matriz_de_pontos_testes_antes_lev, matriz_diferencas_lev = identifica_PQambos_valor_que_faz_cair(candidates_vetor, vetor_inicio, vetor_ponta)
            #indices_encontrados_pontosInteresse_lev2 = buscar_indices_matrizes(matrizes_substituidas_025, matriz_de_pontos_testes_antes)
            
            #print(indices_encontrados_pontosInteresse_lev)
            # Resultado
            # print("Matriz de diferenças=")
            # for linha in matriz_diferencas:
            #     print(linha)
                
            # # Resultados
            # print("matriz_de_pontos_testes_antes=")
            # for linha in matriz_de_pontos_testes_antes:
            #     print(linha)
            
            # print('ATIVA_ESPEC=',ATIVA_ESPEC0)
        
            #print('aqui2')
            #  timer
            time = datetime.now()
            #time_date = datetime.fromtimestamp(time)
            parametro_de_verificacao.append([time.strftime("%H:%M:%S"),'ANÁLISE DE FRONTREIRA: REGIME LEVE', len(matriz_de_pontos_testes_antes_lev),' -PONTOS DETECTADOS' ])  
            print([time.strftime("%H:%M:%S"),'ANÁLISE DE FRONTREIRA: REGIME LEVE', len(matriz_de_pontos_testes_antes_lev),' -PONTOS DETECTADOS' ]) 

            for cadidat in range(len(matriz_de_pontos_testes_antes_lev)):
                procura_fronteira_down='no'
                _ , ATIVA_down = gerar_vetores_com_variacao(matriz_de_pontos_testes_antes_lev[cadidat], ATIVA_ESPEC, limite_variacao)
                # for auxiliar in range(len(ATIVA_down)):
                #     ATIVA_down[auxiliar]=[float(x) for x in ATIVA_down[auxiliar]]                
                A_carga_lev=[0]*len(ATIVA_ESPEC)
                A_DeltaV_lev=[0]*len(ATIVA_ESPEC)
                A_PotP_lev=[0]*len(ATIVA_ESPEC)
                A_PotQ_lev=[0]*len(ATIVA_ESPEC)
                A_BqV_lev=[0]*len(ATIVA_ESPEC)
                A_Ang_lev=[0]*len(ATIVA_ESPEC)
                A_Bpq_lev=[0]*len(ATIVA_ESPEC)
                A_cont_lev=0
                stopa_por_nao_encontrar='no'
                while procura_fronteira_down=='no':
                    # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                    #     PVbarIndex, TENSAO_ESPEC, PIndex, ATIVA_down, GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                    # )
                    # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                    #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                    # )

                    for AUXILIAR in range(len(ATIVA_down)):
                        matriz_DadosBarra[1][AUXILIAR]=(float(ATIVA_down[AUXILIAR]))/S_base
                        matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                        matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                        matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                        matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                        infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                        matrizSystem[AUXILIAR][9]=(-1)*(float(ATIVA_down[AUXILIAR]))

                    # Execução do fluxo de potência
                    stopa_por_nao_encontrar=confirmar_se_nao_CAI(matriz_diferencas_lev, matriz_de_pontos_testes_antes_lev, ATIVA_down, ATIVA_ESPEC, cadidat, limite_variacao, stopa_por_nao_encontrar)
                    Fluxo_divergente='no'
                    try:                    
                        (DeltaV, Delta0, PotP, PotQ, _, _, cont, _, Barras_PQ , _, _, BarraQViola_estatica, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola, _, _, _) = CHAMA_FLNR_03_LTT(
                            matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                        )
                    except Exception as e:
                        Fluxo_divergente='yes'

                    if Fluxo_divergente=='no' and stopa_por_nao_encontrar=='no':
                        Observation='None'                                             
                        resultado_fronteira, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica, VerificaSeViola) 
                        if resultado_fronteira==False:
                            procura_fronteira_down='no'
                            for aux in range(len(ATIVA_ESPEC)):
                                A_carga_lev[aux]=ATIVA_down[aux]
                                A_DeltaV_lev[aux]=DeltaV[aux]
                                A_PotP_lev[aux]=PotP[aux]
                                A_PotQ_lev[aux]=PotQ[aux]
                                A_BqV_lev[aux]=BarraQViola_estatica[aux]
                                A_Ang_lev[aux]=Delta0[aux]
                                A_Bpq_lev[aux]=Barras_PQ[aux]
                                A_cont_lev=cont

                            elemento_x=matriz_diferencas_lev[cadidat]  # Acessa a matriz de índice cadidat
                            for valor in elemento_x:  # Itera sobre os elementos dessa matriz
                                if ATIVA_down[valor]<ATIVA_ESPEC[valor]*(1-limite_variacao/100):
                                    ATIVA_down[valor] = ATIVA_down[valor] + PassoEstudo_DasCombinacoes 
                                else:
                                    ATIVA_down[valor]=ATIVA_ESPEC[valor]*(1-limite_variacao/100)   
                        else:
                            procura_fronteira_down='yes'
                    else:
                        #ATIVA_up=[0]*len(ATIVA_ESPEC)
                        DeltaV=[0]*len(ATIVA_ESPEC)
                        PotP=[0]*len(ATIVA_ESPEC)
                        PotQ=[0]*len(ATIVA_ESPEC)
                        BarraQViola_estatica=[0]*len(ATIVA_ESPEC)
                        Delta0=[0]*len(ATIVA_ESPEC)
                        Barras_PQ=[0]*len(ATIVA_ESPEC)
                        if  stopa_por_nao_encontrar=='no':
                            Observation='Fluxo divergente.'
                        else:
                            Observation='Fluxo Indiferente'
                        cont=0
                        procura_fronteira_down='yes'

                D_MatrizT3_lev_carregamento.append(ATIVA_down)
                D_MatrizT3_lev_POTP.append(PotP)
                D_MatrizT3_lev_POTQ.append(PotQ)
                D_MatrizT3_lev_TENSAO.append(DeltaV)
                D_MatrizT3_lev_BqV.append(BarraQViola_estatica)
                D_MatrizT3_lev_ANGULO.append(Delta0)
                D_MatrizT3_lev_BPQ.append(Barras_PQ)
                D_MatrizT3_lev_CONT.append(cont)
                D_MatrizT3_lev_OBS.append(Observation)                

                A_matrizT3_lev_carregamento.append(A_carga_lev)
                A_matrizT3_lev_POTP.append(A_PotP_lev)
                A_matrizT3_lev_POTQ.append(A_PotQ_lev)
                A_matrizT3_lev_TENSAO.append(A_DeltaV_lev)
                A_matrizT3_lev_BqV.append(A_BqV_lev)
                A_matrizT3_lev_ANGULO.append(A_Ang_lev)
                A_matrizT3_lev_BPQ.append(A_Bpq_lev)
                A_matrizT3_lev_CONT.append(A_cont_lev)
                A_matrizT3_lev_OBS.append(Observation)
            # vetPswing_D_lev=[]
            # for i in range(len(D_MatrizT3_lev_POTP)): 
            #     vetPswing_D_lev.append(D_MatrizT3_lev_POTP[i][0])
            # print(vetPswing_D_lev)
            
            # D_Pswing_lev_max = max(vetPswing_D_lev)  # Encontra o valor máximo
            # D_Pswing_lev_min = min(vetPswing_D_lev)  # Encontra o valor mínim
            # indice_Pswing_lev_max = vetPswing_D_lev.index(D_Pswing_lev_max)  # Encontra o índice do valor máximo
            # indice_Pswing_lev_min = vetPswing_D_lev.index(D_Pswing_lev_min)  # Encontra o índice do valor mínimo    

    if Lista_de_Candidatos_T3!=[] and Lista_de_Candidatos_T4!=[]:
        if PQpes=='yes' and PQlev=='yes':
            #  timer
                               
            
            elementos, _ , candidates_vetor = arrumadadosDados(candidateviola_block_anterior_pes,candidate_bloc_anterior_pes)
            #print('elementos=',elementos)
            #print(indices_doBloco)
            # print('candidate_bloc_anterior=',candidate_bloc_anterior)
            # print(candidateviola_block_anterior)

            _ , vetor_inicio, vetor_ponta = extrair_vetores_ObjetoAEstudado(elementos, candidates_vetor)
            vetor_ponta_corrigido = corrigir_capturaPontos(elementos)

            if vetor_ponta_corrigido!=[]:
                candidates_vetor=[[0]*len(candidates_vetor[0])]+candidates_vetor
                vetor_inicio=[0]+vetor_inicio
                vetor_ponta=vetor_ponta_corrigido+vetor_ponta   
                ##Corrigindo Vetor_Inicio
                for AUXILIAR2 in range(len(vetor_inicio)):
                    if AUXILIAR2>0:
                        vetor_inicio[AUXILIAR2]= vetor_inicio[AUXILIAR2]+1

            # print("Vet_objeto:", vet_objeto)
            # print("Vetor_inicio:", vetor_inicio)
            # print("Vetor_ponta:", vetor_ponta)
            # print('-------------------------------------------')
            # print('-------------------------------------------------------------------------------------------')
            # print('-------------------------------------------')
            # print('-------------------------------------------------------------------------------------------')
            # print('-------------------------------------------')
            # print('------------------------------------------------------INICIO-------------------------------')
            # print("candidates_vetor:", candidates_vetor)
            # print('-------------------------------------------')
            # print('-------------------------------------------------------------------------------------------')
            # print('-------------------------------------------')
            # print('-------------------------------------------------------------------------------------------')
            # print('-------------------------------------------')
            # print('------------------------------------------------------FIM----------------------------------')
            # print(primeiroAviolar)
            # print(ultimoAviolar)
            #print('aqui33')
            
            #indices_encontrados_pontosInteresse_lev = buscar_indices_matrizes(matrizes_substituidas_025, vet_objeto)
            # print(indices_encontrados_pontosInteresse_lev)          
            # print('aqui')

            # Chamando a função
            #matriz_de_pontos_testes, diferencas = criar_matriz_de_pontos_testes(candidates_vetor, vetor_inicio, vetor_ponta)
            matriz_de_pontos_testes_antes_pes, matriz_diferencas_pes = identifica_PQambos_valor_que_faz_cair(candidates_vetor, vetor_inicio, vetor_ponta)
            # Resultado
            # print("Matriz de diferenças:")
            # for linha in matriz_diferencas:
            #     print(linha)
                
            # # Resultados
            # print("matriz_de_pontos_testes_antes=")
            # for linha in matriz_de_pontos_testes_antes:
            #     print(linha)
            # print('aqui')

            #print('aqui1')
            time = datetime.now()
            #time_date = datetime.fromtimestamp(time)
            parametro_de_verificacao.append([time.strftime("%H:%M:%S"),'ANÁLISE DE FRONTREIRA: REGIME PESADO', len(matriz_de_pontos_testes_antes_pes),' -PONTOS DETECTADOS' ])  
            print([time.strftime("%H:%M:%S"),'ANÁLISE DE FRONTREIRA: REGIME PESADO', len(matriz_de_pontos_testes_antes_pes),' -PONTOS DETECTADOS' ])  
            
            for cadidat in range(len(matriz_de_pontos_testes_antes_pes)):
                procura_fronteira_up='no'
                ATIVA_up , _ = gerar_vetores_com_variacao(matriz_de_pontos_testes_antes_pes[cadidat], ATIVA_ESPEC, limite_variacao)
                # for auxiliar in range(len(ATIVA_up)):
                #     ATIVA_up[auxiliar]=[float(x) for x in ATIVA_up[auxiliar]]                  
                A_carga_pes=[0]*len(ATIVA_ESPEC)
                A_DeltaV_pes=[0]*len(ATIVA_ESPEC)
                A_PotP_pes=[0]*len(ATIVA_ESPEC)
                A_PotQ_pes=[0]*len(ATIVA_ESPEC)
                A_BqV_pes=[0]*len(ATIVA_ESPEC)
                A_Ang_pes=[0]*len(ATIVA_ESPEC)
                A_Bpq_pes=[0]*len(ATIVA_ESPEC)
                A_cont_pes=0
                stopa_por_nao_encontrar='no'
                while procura_fronteira_up=='no':
                    # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                    #     PVbarIndex, TENSAO_ESPEC, PIndex, ATIVA_up, GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                    # )
                    # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                    #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                    # )

                    for AUXILIAR in range(len(ATIVA_up)):
                        matriz_DadosBarra[1][AUXILIAR]=(float(ATIVA_up[AUXILIAR]))/S_base
                        matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                        matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                        matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                        matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                        infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                        matrizSystem[AUXILIAR][9]=(-1)*(float(ATIVA_up[AUXILIAR]))

                    # Execução do fluxo de potência
                    stopa_por_nao_encontrar=confirmar_se_nao_CAI(matriz_diferencas_pes, matriz_de_pontos_testes_antes_pes, ATIVA_up, ATIVA_ESPEC, cadidat, limite_variacao, stopa_por_nao_encontrar)
                    Fluxo_divergente='no'
                    try:                    
                        (DeltaV, Delta0, PotP, PotQ, _, _, cont, _, Barras_PQ , _, _, BarraQViola_estatica, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola, _, _, _) = CHAMA_FLNR_03_LTT(
                            matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                        )
                    except Exception as e:
                        Fluxo_divergente='yes'

                    if Fluxo_divergente=='no' and stopa_por_nao_encontrar=='no':
                        Observation='None'                                        
                        resultado_fronteira, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica, VerificaSeViola) 
                        if resultado_fronteira==False:
                            procura_fronteira_up='no'
                            for aux in range(len(ATIVA_ESPEC)):
                                A_carga_pes[aux]=ATIVA_up[aux]
                                A_DeltaV_pes[aux]=DeltaV[aux]
                                A_PotP_pes[aux]=PotP[aux]
                                A_PotQ_pes[aux]=PotQ[aux]
                                A_BqV_pes[aux]=BarraQViola_estatica[aux]
                                A_Ang_pes[aux]=Delta0[aux]
                                A_Bpq_pes[aux]=Barras_PQ[aux]
                                A_cont_pes=cont

                            elemento_x=matriz_diferencas_pes[cadidat]  # Acessa a matriz de índice cadidat
                            for valor in elemento_x:  # Itera sobre os elementos dessa matriz
                                if ATIVA_up[valor]>ATIVA_ESPEC[valor]*(1+limite_variacao/100):
                                    ATIVA_up[valor] = ATIVA_up[valor] - PassoEstudo_DasCombinacoes 
                                else:
                                    ATIVA_up[valor]=ATIVA_ESPEC[valor]*(1+limite_variacao/100)   
                        else:
                            procura_fronteira_up='yes'
                    else:
                        #ATIVA_up=[0]*len(ATIVA_ESPEC)
                        DeltaV=[0]*len(ATIVA_ESPEC)
                        PotP=[0]*len(ATIVA_ESPEC)
                        PotQ=[0]*len(ATIVA_ESPEC)
                        BarraQViola_estatica=[0]*len(ATIVA_ESPEC)
                        Delta0=[0]*len(ATIVA_ESPEC)
                        Barras_PQ=[0]*len(ATIVA_ESPEC)
                        if  stopa_por_nao_encontrar=='no':
                            Observation='Fluxo divergente.'
                        else:
                            Observation='Fluxo Indiferente'
                        cont=0
                        procura_fronteira_up='yes'

                D_MatrizT3_pes_carregamento.append(ATIVA_up)
                D_MatrizT3_pes_POTP.append(PotP)
                D_MatrizT3_pes_POTQ.append(PotQ)
                D_MatrizT3_pes_TENSAO.append(DeltaV)
                D_MatrizT3_pes_BqV.append(BarraQViola_estatica)
                D_MatrizT3_pes_ANGULO.append(Delta0)
                D_MatrizT3_pes_BPQ.append(Barras_PQ)
                D_MatrizT3_pes_CONT.append(cont)
                D_MatrizT3_pes_OBS.append(Observation) 

                A_matrizT3_pes_carregamento.append(A_carga_pes)
                A_matrizT3_pes_POTP.append(A_PotP_pes)
                A_matrizT3_pes_POTQ.append(A_PotQ_pes)
                A_matrizT3_pes_TENSAO.append(A_DeltaV_pes)
                A_matrizT3_pes_BqV.append(A_BqV_pes)
                A_matrizT3_pes_ANGULO.append(A_Ang_pes)
                A_matrizT3_pes_BPQ.append(A_Bpq_pes)
                A_matrizT3_pes_CONT.append(A_cont_pes)
                A_matrizT3_pes_OBS.append(Observation)                 
                
            # vetPswing_D_pes=[]
            # for i in range(len(D_MatrizT3_pes_POTP)): 
            #     vetPswing_D_pes.append(D_MatrizT3_pes_POTP[i][0])
            # print('vetPswing_D_pes=',vetPswing_D_pes)
            
            # D_Pswing_pes_max = max(vetPswing_D_pes)  # Encontra o valor máximo
            # D_Pswing_pes_min = min(vetPswing_D_pes)  # Encontra o valor mínim
            # indice_Pswing_pes_max = vetPswing_D_pes.index(D_Pswing_pes_max)  # Encontra o índice do valor máximo
            # indice_Pswing_pes_min = vetPswing_D_pes.index(D_Pswing_pes_min)  # Encontra o índice do valor mínimo
            
            #  timer         
            
            elementos, _ , candidates_vetor = arrumadadosDados(candidateviola_block_anterior_lev,candidate_bloc_anterior_lev)
            #print('elementos=',elementos)
            #print(indices_doBloco)
            # print('candidate_bloc_anterior=',candidate_bloc_anterior)
            # print(candidateviola_block_anterior)
            
            _ , vetor_inicio, vetor_ponta = extrair_vetores_ObjetoAEstudado(elementos, candidates_vetor)
            vetor_ponta_corrigido = corrigir_capturaPontos(elementos)

            if vetor_ponta_corrigido!=[]:
                candidates_vetor=[[0]*len(candidates_vetor[0])]+candidates_vetor
                vetor_inicio=[0]+vetor_inicio
                vetor_ponta=vetor_ponta_corrigido+vetor_ponta
                ##Corrigindo Vetor_Inicio
                for AUXILIAR2 in range(len(vetor_inicio)):
                    if AUXILIAR2>0:
                        vetor_inicio[AUXILIAR2]= vetor_inicio[AUXILIAR2]+1                

            # print("Vet_objeto:", vet_objeto)
            # print("Vetor_inicio:", vetor_inicio)
            # print("Vetor_ponta:", vetor_ponta)
            # print('-------------------------------------------')
            # print('-------------------------------------------------------------------------------------------')
            # print('-------------------------------------------')
            # print('-------------------------------------------------------------------------------------------')
            # print('-------------------------------------------')
            # print('------------------------------------------------------INICIO-------------------------------')
            # print("candidates_vetor:", candidates_vetor)
            # print('-------------------------------------------')
            # print('-------------------------------------------------------------------------------------------')
            # print('-------------------------------------------')
            # print('-------------------------------------------------------------------------------------------')
            # print('-------------------------------------------')
            # print('------------------------------------------------------FIM----------------------------------')
            # print(primeiroAviolar)
            # print(ultimoAviolar)
            #print('aqui33')
            
            #indices_encontrados_pontosInteresse_lev = buscar_indices_matrizes(matrizes_substituidas_025, vet_objeto)
            # print(indices_encontrados_pontosInteresse_lev)               
            # print('aqui')

            # Chamando a função
            #matriz_de_pontos_testes, diferencas = criar_matriz_de_pontos_testes(candidates_vetor, vetor_inicio, vetor_ponta)
            matriz_de_pontos_testes_antes_lev, matriz_diferencas_lev = identifica_PQambos_valor_que_faz_cair(candidates_vetor, vetor_inicio, vetor_ponta)
            #indices_encontrados_pontosInteresse_lev2 = buscar_indices_matrizes(matrizes_substituidas_025, matriz_de_pontos_testes_antes)
            
            #print(indices_encontrados_pontosInteresse_lev)
            # Resultado
            # print("Matriz de diferenças=")
            # for linha in matriz_diferencas:
            #     print(linha)
                
            # # Resultados
            # print("matriz_de_pontos_testes_antes=")
            # for linha in matriz_de_pontos_testes_antes:
            #     print(linha)
            
            # print('ATIVA_ESPEC=',ATIVA_ESPEC0)
        
            #print('aqui2')
            time = datetime.now()
            #time_date = datetime.fromtimestamp(time)
            parametro_de_verificacao.append([time.strftime("%H:%M:%S"),' ANÁLISE DE FRONTREIRA: REGIME LEVE ', len(matriz_de_pontos_testes_antes_lev),' -PONTOS DETECTADOS' ])  
            print([time.strftime("%H:%M:%S"),' ANÁLISE DE FRONTREIRA: REGIME LEVE ', len(matriz_de_pontos_testes_antes_lev),' -PONTOS DETECTADOS' ])     

            for cadidat in range(len(matriz_de_pontos_testes_antes_lev)):
                procura_fronteira_down='no'
                _ , ATIVA_down = gerar_vetores_com_variacao(matriz_de_pontos_testes_antes_lev[cadidat], ATIVA_ESPEC, limite_variacao)
                # for auxiliar in range(len(ATIVA_down)):
                #     ATIVA_down[auxiliar]=[float(x) for x in ATIVA_down[auxiliar]]                
                A_carga_lev=[0]*len(ATIVA_ESPEC)
                A_DeltaV_lev=[0]*len(ATIVA_ESPEC)
                A_PotP_lev=[0]*len(ATIVA_ESPEC)
                A_PotQ_lev=[0]*len(ATIVA_ESPEC)
                A_BqV_lev=[0]*len(ATIVA_ESPEC)
                A_Ang_lev=[0]*len(ATIVA_ESPEC)
                A_Bpq_lev=[0]*len(ATIVA_ESPEC)
                A_cont_lev=0
                stopa_por_nao_encontrar='no'
                while procura_fronteira_down=='no':
                    # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                    #     PVbarIndex, TENSAO_ESPEC, PIndex, ATIVA_down, GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                    # )
                    # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                    #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                    # )

                    for AUXILIAR in range(len(ATIVA_down)):
                        matriz_DadosBarra[1][AUXILIAR]=(float(ATIVA_down[AUXILIAR]))/S_base
                        matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                        matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                        matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                        matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                        infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                        matrizSystem[AUXILIAR][9]=(-1)*(float(ATIVA_down[AUXILIAR]))

                    # Execução do fluxo de potência
                    stopa_por_nao_encontrar=confirmar_se_nao_CAI(matriz_diferencas_lev, matriz_de_pontos_testes_antes_lev, ATIVA_down, ATIVA_ESPEC, cadidat, limite_variacao, stopa_por_nao_encontrar)
                    Fluxo_divergente='no'
                    try:                    
                        (DeltaV, Delta0, PotP, PotQ, _, _, cont, _, Barras_PQ , _, _, BarraQViola_estatica, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola, _, _, _) = CHAMA_FLNR_03_LTT(
                            matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                        )
                    except Exception as e:
                        Fluxo_divergente='yes'

                    if Fluxo_divergente=='no' and stopa_por_nao_encontrar=='no': 
                        Observation='None'                                       
                        resultado_fronteira, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica, VerificaSeViola) 
                        if resultado_fronteira==False:
                            procura_fronteira_down='no'
                            for aux in range(len(ATIVA_ESPEC)):
                                A_carga_lev[aux]=ATIVA_down[aux]
                                A_DeltaV_lev[aux]=DeltaV[aux]
                                A_PotP_lev[aux]=PotP[aux]
                                A_PotQ_lev[aux]=PotQ[aux]
                                A_BqV_lev[aux]=BarraQViola_estatica[aux]
                                A_Ang_lev[aux]=Delta0[aux]
                                A_Bpq_lev[aux]=Barras_PQ[aux]
                                A_cont_lev=cont

                            elemento_x=matriz_diferencas_lev[cadidat]  # Acessa a matriz de índice cadidat
                            for valor in elemento_x:  # Itera sobre os elementos dessa matriz
                                if ATIVA_down[valor]<ATIVA_ESPEC[valor]*(1-limite_variacao/100):
                                    ATIVA_down[valor] = ATIVA_down[valor] + PassoEstudo_DasCombinacoes 
                                else:
                                    ATIVA_down[valor]=ATIVA_ESPEC[valor]*(1-limite_variacao/100) 
                        else:
                            procura_fronteira_down='yes'
                    else:
                        #ATIVA_up=[0]*len(ATIVA_ESPEC)
                        DeltaV=[0]*len(ATIVA_ESPEC)
                        PotP=[0]*len(ATIVA_ESPEC)
                        PotQ=[0]*len(ATIVA_ESPEC)
                        BarraQViola_estatica=[0]*len(ATIVA_ESPEC)
                        Delta0=[0]*len(ATIVA_ESPEC)
                        Barras_PQ=[0]*len(ATIVA_ESPEC)
                        if  stopa_por_nao_encontrar=='no':
                            Observation='Fluxo divergente.'
                        else:
                            Observation='Fluxo Indiferente'
                        cont=0
                        procura_fronteira_down='yes'

                D_MatrizT3_lev_carregamento.append(ATIVA_down)
                D_MatrizT3_lev_POTP.append(PotP)
                D_MatrizT3_lev_POTQ.append(PotQ)
                D_MatrizT3_lev_TENSAO.append(DeltaV)
                D_MatrizT3_lev_BqV.append(BarraQViola_estatica)
                D_MatrizT3_lev_ANGULO.append(Delta0)
                D_MatrizT3_lev_BPQ.append(Barras_PQ)
                D_MatrizT3_lev_CONT.append(cont)
                D_MatrizT3_lev_OBS.append(Observation) 

                A_matrizT3_lev_carregamento.append(A_carga_lev)
                A_matrizT3_lev_POTP.append(A_PotP_lev)
                A_matrizT3_lev_POTQ.append(A_PotQ_lev)
                A_matrizT3_lev_TENSAO.append(A_DeltaV_lev)
                A_matrizT3_lev_BqV.append(A_BqV_lev)
                A_matrizT3_lev_ANGULO.append(A_Ang_lev)
                A_matrizT3_lev_BPQ.append(A_Bpq_lev)
                A_matrizT3_lev_CONT.append(A_cont_lev)
                A_matrizT3_lev_OBS.append(Observation)

            # vetPswing_D_lev=[]
            # for i in range(len(D_MatrizT3_lev_POTP)): 
            #     vetPswing_D_lev.append(D_MatrizT3_lev_POTP[i][0])
            # print('vetPswing_D_lev=',vetPswing_D_lev)
            
            # D_Pswing_lev_max = max(vetPswing_D_lev)  # Encontra o valor máximo
            # D_Pswing_lev_min = min(vetPswing_D_lev)  # Encontra o valor mínim
            # indice_Pswing_lev_max = vetPswing_D_lev.index(D_Pswing_lev_max)  # Encontra o índice do valor máximo
            # indice_Pswing_lev_min = vetPswing_D_lev.index(D_Pswing_lev_min)  # Encontra o índice do valor mínimo
    
    
    
    ''' ------------------------------------------------------------------------------------------------ '''
    ''' ------------------------------------ ANÁLISE DE CANDIDATOS ------------------------------------- '''
    ''' ------------------------------------------------------------------------------------------------ '''
    if tipo_de_ESTUDO=='Todo Espaco Amostral':        
        Lista_de_Candidatos_T5=[] 
        Lista_de_Candidatos_T5_index=[]
        Lista_de_Candidatos_T6=[] 
        Lista_de_Candidatos_T6_index=[]    

        candidate_bloc=[]
        candidateviola=[]

        quantidade_anterior_pes=-1
        candidate_bloc_anterior_pes=[]
        candidateviola_block_anterior_pes=[]
        primeiroAviolar_pes=0
        ultimoAviolar_pes=0
        quantidade_anterior_lev=-1
        candidate_bloc_anterior_lev=[]
        candidateviola_block_anterior_lev=[]
        primeiroAviolar_lev=0
        ultimoAviolar_lev=0

        if tipo_de_REGIME=='pesado' or tipo_de_REGIME=='ambos':
            if PQPVpes=='yes':
                #  timer
                time = datetime.now()
                #time_date = datetime.fromtimestamp(time)
                parametro_de_verificacao.append([time.strftime("%H:%M:%S"),' ANÁLISE DE PONTOS CANDITADOS: REGIME PESADO '])
                print([time.strftime("%H:%M:%S"),' ANÁLISE DE PONTOS CANDITADOS: REGIME PESADO '])             
                
                for k in range(len(matrizes_substituidas_125)):
                    if ultimoAviolar_pes==0:   
                        if CONTAR_POTP<=limita_EspacoAmostral and ReduzirEspacoAmostral=='no':
                            resultado =  (resultado[0],resultados_com_delta_025[k], resultados_com_delta_125[k])
                        else:
                            resultado = (indices_modificados, resultados_com_delta_025[k], resultados_com_delta_125[k])
                                                
                        #resultado = (resultado[0],resultados_com_delta_025[k], resultados_com_delta_125[k])
                        resultado_corrigido_melhorado = corrigir_resultado_melhorado(resultado, ATIVA_ESPEC00A, REGIME_de_CARGA, 'PQPV')
                        #print("Resultado_corrigido:", resultado_corrigido_melhorado)

                        # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                        #     PVbarIndex, TENSAO_ESPEC, PIndex, resultado_corrigido_melhorado[2], GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                        # )
                        # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                        #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                        # )

                        for AUXILIAR in range(len(resultado_corrigido_melhorado[2])):
                            matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[2][AUXILIAR]))/S_base
                            matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                            matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                            matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                            matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                            infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                            matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[2][AUXILIAR]))

                        try:
                            # Execução do fluxo de potência
                            (DeltaV_T5, Delta0_T5, PotP_T5, PotQ_T5, _, _, cont_T5, _, Barras_PQ_T5 , _, _, BarraQViola_estatica_T5, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola_T5, _, _, _) = CHAMA_FLNR_03_LTT(
                                matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                            )
                        except Exception as e:
                            Fluxo_divergente_T5='yes'
                            BarraQViola_estatica_T5=[1]*len(ATIVA_ESPEC)
                            VerificaSeViola_T5=['ViolaPB']*len(ATIVA_ESPEC)

                        resultado_T5, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_T5, VerificaSeViola_T5)           
                        if resultado_T5==True:
                            candidateviola_value='yes'
                            Lista_de_Candidatos_T5.append(resultado_corrigido_melhorado[2])
                            Lista_de_Candidatos_T5_index.append(matrizes_substituidas_125[k])

                            # ##PLOTAGEM
                            # print('\n')
                            # print('------------------------------------------------------') 
                            # print('-------------------------(T5)  -----------------------') 
                            # print('---------------------- Todas pesada ------------------')  
                            # plot(DeltaV_T5, Delta0_T5, PotP_T5, PotQ_T5,infoVctrl,cont_T5)
                            # plot_PotGer(PotP_T5, PotQ_T5, infoVctrl, Barras_PQ_T5 , matriz_DadosBarra)

                        else:
                            candidateviola_value='no'

                        #if k>0: 
                        # Conta os valores diferentes de zero
                        quantidade_atual = sum(1 for valor in matrizes_substituidas_125[k] if valor != 0)    
                        # Verifica e emite alerta se houve mudança
                        candidate_bloc.append(matrizes_substituidas_125[k])
                        candidateviola.append(candidateviola_value)

                        if quantidade_atual != quantidade_anterior_pes:
                            candidate_bloc_anterior_pes.append(candidate_bloc)
                            candidateviola_block_anterior_pes.append(candidateviola)
                            # print(candidateviola)
                            # Verificando se todos os elementos são 'no'
                            # voltar aqui para replicar                
                            if all(element == 'no' for element in candidateviola[:-1]) or all(element == 'yes' for element in candidateviola[:-1]):
                                #print("bloco não viola")
                                if primeiroAviolar_pes!=0:
                                    if ultimoAviolar_pes==0:
                                        ultimoAviolar_pes=quantidade_anterior_pes         
                            else:
                                #print("bloco viola")
                                if primeiroAviolar_pes==0:
                                    primeiroAviolar_pes=quantidade_anterior_pes


                            #print(f"Alerta: Mudança detectada! Quantidade atual de valores diferentes de zero: {quantidade_atual}")
                            quantidade_anterior_pes = quantidade_atual
                            candidate_bloc=[]    
                            candidateviola=[]        
                        
                        # print('candidate_bloc_anterior_pes=',candidate_bloc_anterior_pes)
                        # print('*********************** OUTRAS INFOS RELEVANTES *********************** ')
                        # print("Resultado_corrigido:", resultado_corrigido_melhorado)
                        # print(resultados_com_delta_125[k])
                        # print(matrizes_substituidas_125[k])
                        
                        #print('aqui')
        # elementos, indices_doBloco, candidates_vetor = arrumadadosDados(candidateviola_block_anterior_pes,candidate_bloc_anterior_pes)
        # #print('elementos=',elementos)
        # #print(indices_doBloco)
        # #print('candidates_vetor=',candidates_vetor)
        # #print(candidateviola_block_anterior_pes)
        # vet_objeto, vetor_inicio, vetor_ponta = extrair_vetores_ObjetoAEstudado(elementos, candidates_vetor)

        if tipo_de_REGIME=='leve' or tipo_de_REGIME=='ambos':
            if PQPVlev=='yes':
                #  timer
                time = datetime.now()
                #time_date = datetime.fromtimestamp(time)
                parametro_de_verificacao.append([time.strftime("%H:%M:%S"),' ANÁLISE DE PONTOS CANDITADOS: REGIME LEVE ']) 
                print([time.strftime("%H:%M:%S"),' ANÁLISE DE PONTOS CANDITADOS: REGIME LEVE '])  

                for k in range(len(matrizes_substituidas_025)):
                    if ultimoAviolar_lev==0:
                        if CONTAR_POTP<=limita_EspacoAmostral and ReduzirEspacoAmostral=='no':
                            resultado =  (resultado[0],resultados_com_delta_025[k], resultados_com_delta_125[k])
                        else:
                            resultado = (indices_modificados, resultados_com_delta_025[k], resultados_com_delta_125[k])
                            
                        #resultado = (resultado[0],resultados_com_delta_025[k], resultados_com_delta_125[k])
                        resultado_corrigido_melhorado = corrigir_resultado_melhorado(resultado, ATIVA_ESPEC00A, REGIME_de_CARGA, 'PQPV')
                        #print("Resultado_corrigido:", resultado_corrigido_melhorado)

                        # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                        #     PVbarIndex, TENSAO_ESPEC, PIndex, resultado_corrigido_melhorado[1], GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                        # )
                        # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                        #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                        # )

                        for AUXILIAR in range(len(resultado_corrigido_melhorado[1])):
                            matriz_DadosBarra[1][AUXILIAR]=(float(resultado_corrigido_melhorado[1][AUXILIAR]))/S_base
                            matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                            matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                            matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                            matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                            infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                            matrizSystem[AUXILIAR][9]=(-1)*(float(resultado_corrigido_melhorado[1][AUXILIAR]))

                        try:
                            # Execução do fluxo de potência
                            (DeltaV_T6, Delta0_T6, PotP_T6, PotQ_T6, _, _, cont_T6, _, Barras_PQ_T6 , _, _, BarraQViola_estatica_T6, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola_T6, _, _, _) = CHAMA_FLNR_03_LTT(
                                matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                            )
                        except Exception as e:
                            Fluxo_divergente_T6='yes'
                            BarraQViola_estatica_T6=[1]*len(ATIVA_ESPEC)
                            VerificaSeViola_T6=['ViolaPB']*len(ATIVA_ESPEC)
                        
                        resultado_T6, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica_T6, VerificaSeViola_T6)             
                        if resultado_T6==True:
                            candidateviola_value='yes'
                            Lista_de_Candidatos_T6.append(resultado_corrigido_melhorado[1])
                            Lista_de_Candidatos_T6_index.append(matrizes_substituidas_025[k])

                            # #PLOTAGEM
                            # print('\n')
                            # print('------------------------------------------------------') 
                            # print('--------------------------(T6)------------------------') 
                            # print('------------------------- Todas leve -----------------')  
                            # plot(DeltaV_T6, Delta0_T6, PotP_T6, PotQ_T6,infoVctrl,cont_T6)
                            # plot_PotGer(PotP_T6, PotQ_T6, infoVctrl, Barras_PQ_T6 , matriz_DadosBarra)
                        else:
                            candidateviola_value='no'

                        #if k>0: 
                        # Conta os valores diferentes de zero
                        quantidade_atual = sum(1 for valor in matrizes_substituidas_025[k] if valor != 0)    
                        # Verifica e emite alerta se houve mudança
                        candidate_bloc.append(matrizes_substituidas_025[k])
                        candidateviola.append(candidateviola_value)

                        if quantidade_atual != quantidade_anterior_lev:
                            candidate_bloc_anterior_lev.append(candidate_bloc)
                            candidateviola_block_anterior_lev.append(candidateviola)
                            # print(candidateviola)
                            # Verificando se todos os elementos são 'no'
                            # voltar aqui para replicar                
                            if all(element == 'no' for element in candidateviola[:-1]) or all(element == 'yes' for element in candidateviola[:-1]):
                                #print("bloco não viola")
                                if primeiroAviolar_lev!=0:
                                    if ultimoAviolar_lev==0:
                                        ultimoAviolar_lev=quantidade_anterior_lev         
                            else:
                                #print("bloco viola")
                                if primeiroAviolar_lev==0:
                                    primeiroAviolar_lev=quantidade_anterior_lev


                            #print(f"Alerta: Mudança detectada! Quantidade atual de valores diferentes de zero: {quantidade_atual}")
                            quantidade_anterior_lev = quantidade_atual
                            candidate_bloc=[]    
                            candidateviola=[]        
                        
                        # print('candidate_bloc_anterior_lev=',candidate_bloc_anterior_lev)
                        # print('*********************** OUTRAS INFOS RELEVANTES *********************** ')
                        # print("Resultado_corrigido:", resultado_corrigido_melhorado)
                        # print(resultados_com_delta_025[k])
                        # print(matrizes_substituidas_025[k])
                        # #print(indices_encontradosPQsomente[k])
                        # print('aqui')

        A_matrizT5_pes_carregamento=[]
        A_matrizT5_pes_POTP=[]
        A_matrizT5_pes_POTQ=[]
        A_matrizT5_pes_TENSAO=[]
        A_matrizT5_pes_BqV=[]
        A_matrizT5_pes_ANGULO=[]
        A_matrizT5_pes_BPQ=[]
        A_matrizT5_pes_CONT=[]
        A_matrizT5_pes_OBS=[]

        D_MatrizT5_pes_carregamento=[]
        D_MatrizT5_pes_POTP=[]
        D_MatrizT5_pes_POTQ=[]
        D_MatrizT5_pes_TENSAO=[]
        D_MatrizT5_pes_BqV=[]      
        D_MatrizT5_pes_ANGULO=[]
        D_MatrizT5_pes_BPQ=[]
        D_MatrizT5_pes_CONT=[]
        D_MatrizT5_pes_OBS=[]  
        
        
        
        ''' ------------------------------------------------------------------------------------------------ '''
        ''' ------------------------------------ ANÁLISE DE FRONTEIRA -------------------------------------- '''
        ''' ------------------------------------------------------------------------------------------------ '''
        if tipo_de_REGIME=='pesado' or tipo_de_REGIME=='ambos':
            if PQPVpes=='yes':
                #  timer

                elementos, _ , candidates_vetor = arrumadadosDados(candidateviola_block_anterior_pes,candidate_bloc_anterior_pes)
                
                #print('elementos=',elementos)
                #print(indices_doBloco)
                # print('candidate_bloc_anterior=',candidate_bloc_anterior)
                # print(candidateviola_block_anterior)

                _ , vetor_inicio, vetor_ponta = extrair_vetores_ObjetoAEstudado(elementos, candidates_vetor)
                vetor_ponta_corrigido = corrigir_capturaPontos(elementos)

                if vetor_ponta_corrigido!=[]:
                    candidates_vetor=[[0]*len(candidates_vetor[0])]+candidates_vetor
                    vetor_inicio=[0]+vetor_inicio
                    vetor_ponta=vetor_ponta_corrigido+vetor_ponta
                    ##Corrigindo Vetor_Inicio
                    for AUXILIAR2 in range(len(vetor_inicio)):
                        if AUXILIAR2>0:
                            vetor_inicio[AUXILIAR2]= vetor_inicio[AUXILIAR2]+1
                # print("Vet_objeto:", vet_objeto)
                # print("Vetor_inicio:", vetor_inicio)
                # print("Vetor_ponta:", vetor_ponta)
                # print('-------------------------------------------')
                # print('-------------------------------------------------------------------------------------------')
                # print('-------------------------------------------')
                # print('-------------------------------------------------------------------------------------------')
                # print('-------------------------------------------')
                # print('------------------------------------------------------INICIO-------------------------------')
                # print("candidates_vetor:", candidates_vetor)
                # print('-------------------------------------------')
                # print('-------------------------------------------------------------------------------------------')
                # print('-------------------------------------------')
                # print('-------------------------------------------------------------------------------------------')
                # print('-------------------------------------------')
                # print('------------------------------------------------------FIM----------------------------------')
                # print(primeiroAviolar)
                # print(ultimoAviolar)
                #print('aqui33')
                
                #indices_encontrados_pontosInteresse_lev = buscar_indices_matrizes(matrizes_substituidas_025, vet_objeto)
                # print(indices_encontrados_pontosInteresse_lev)          
                # print('aqui')

                # Chamando a função
                #matriz_de_pontos_testes, diferencas = criar_matriz_de_pontos_testes(candidates_vetor, vetor_inicio, vetor_ponta)
                matriz_de_pontos_testes_antes_pes, matriz_diferencas_pes = identifica_PQambos_valor_que_faz_cair(candidates_vetor, vetor_inicio, vetor_ponta)
                # Resultado
                # print("Matriz de diferenças:")
                # for linha in matriz_diferencas:
                #     print(linha)
                
                time = datetime.now()
                #time_date = datetime.fromtimestamp(time)
                parametro_de_verificacao.append([time.strftime("%H:%M:%S"),'ANÁLISE DE FRONTREIRA: REGIME PESADO', len(matriz_de_pontos_testes_antes_pes),' -PONTOS DETECTADOS' ])  
                print([time.strftime("%H:%M:%S"),'ANÁLISE DE FRONTREIRA: REGIME PESADO', len(matriz_de_pontos_testes_antes_pes),' -PONTOS DETECTADOS' ])   

                # # Resultados
                # print("matriz_de_pontos_testes_antes=")
                # for linha in matriz_de_pontos_testes_antes:
                #     print(linha)
                # print('aqui')
                #print('aqui1')    

                for cadidat in range(len(matriz_de_pontos_testes_antes_pes)):
                    procura_fronteira_up='no'
                    ATIVA_up , _ = gerar_vetores_com_variacao(matriz_de_pontos_testes_antes_pes[cadidat], ATIVA_ESPEC, limite_variacao)
                    # for auxiliar in range(len(ATIVA_up)):
                    #     ATIVA_up[auxiliar]=[float(x) for x in ATIVA_up[auxiliar]]                    
                    A_carga_pes=[0]*len(ATIVA_ESPEC)
                    A_DeltaV_pes=[0]*len(ATIVA_ESPEC)
                    A_PotP_pes=[0]*len(ATIVA_ESPEC)
                    A_PotQ_pes=[0]*len(ATIVA_ESPEC)
                    A_BqV_pes=[0]*len(ATIVA_ESPEC)
                    A_Ang_pes=[0]*len(ATIVA_ESPEC)
                    A_Bpq_pes=[0]*len(ATIVA_ESPEC)
                    A_cont_pes=0
                    stopa_por_nao_encontrar='no'
                    while procura_fronteira_up=='no':
                        # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                        #     PVbarIndex, TENSAO_ESPEC, PIndex, ATIVA_up, GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                        # )
                        # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                        #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                        # )

                        for AUXILIAR in range(len(ATIVA_up)):
                            matriz_DadosBarra[1][AUXILIAR]=(float(ATIVA_up[AUXILIAR]))/S_base
                            matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                            matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                            matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                            matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                            infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                            matrizSystem[AUXILIAR][9]=(-1)*(ATIVA_up[AUXILIAR])
                        try:
                            stopa_por_nao_encontrar=confirmar_se_nao_CAI(matriz_diferencas_pes, matriz_de_pontos_testes_antes_pes, ATIVA_up, ATIVA_ESPEC, cadidat, limite_variacao, stopa_por_nao_encontrar)
                        except Exception as e:
                            stopa_por_nao_encontrar='yes'

                        Fluxo_divergente='no'
                        try:  
                            (DeltaV, Delta0, PotP, PotQ, _, _, cont, _, Barras_PQ , _, _, BarraQViola_estatica, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola, _, _, _) = CHAMA_FLNR_03_LTT(
                                matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                            )
                        except Exception as e:
                            Fluxo_divergente='yes'
                                    
                        if Fluxo_divergente=='no' and stopa_por_nao_encontrar=='no':
                            Observation='None'
                            resultado_fronteira, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica, VerificaSeViola) 
                            if resultado_fronteira==False:
                                procura_fronteira_up='no'
                                for aux in range(len(ATIVA_ESPEC)):
                                    A_carga_pes[aux]=ATIVA_up[aux]
                                    A_DeltaV_pes[aux]=DeltaV[aux]
                                    A_PotP_pes[aux]=PotP[aux]
                                    A_PotQ_pes[aux]=PotQ[aux]
                                    A_BqV_pes[aux]=BarraQViola_estatica[aux]   
                                    A_Ang_pes[aux]=Delta0[aux]
                                    A_Bpq_pes[aux]=Barras_PQ[aux]
                                    A_cont_pes=cont

                                elemento_x=matriz_diferencas_pes[cadidat]  # Acessa a matriz de índice cadidat
                                for valor in elemento_x:  # Itera sobre os elementos dessa matriz
                                    if ATIVA_up[valor]>ATIVA_ESPEC[valor]*(1+limite_variacao/100):
                                        ATIVA_up[valor] = ATIVA_up[valor] - PassoEstudo_DasCombinacoes
                                    else:
                                        ATIVA_up[valor]=ATIVA_ESPEC[valor]*(1+limite_variacao/100) 
                            else:
                                procura_fronteira_up='yes'
                        else:
                            DeltaV=[0]*len(ATIVA_ESPEC)
                            PotP=[0]*len(ATIVA_ESPEC)
                            PotQ=[0]*len(ATIVA_ESPEC)
                            BarraQViola_estatica=[0]*len(ATIVA_ESPEC)
                            Delta0=[0]*len(ATIVA_ESPEC)
                            Barras_PQ=[0]*len(ATIVA_ESPEC)
                            if  stopa_por_nao_encontrar=='no':
                                Observation='Fluxo divergente.'
                            else:
                                Observation='Fluxo Indiferente'
                            cont=0
                            procura_fronteira_up='yes'

                    D_MatrizT5_pes_carregamento.append(ATIVA_up)
                    D_MatrizT5_pes_POTP.append(PotP)
                    D_MatrizT5_pes_POTQ.append(PotQ)
                    D_MatrizT5_pes_TENSAO.append(DeltaV)
                    D_MatrizT5_pes_BqV.append(BarraQViola_estatica)
                    D_MatrizT5_pes_ANGULO.append(Delta0)
                    D_MatrizT5_pes_BPQ.append(Barras_PQ)
                    D_MatrizT5_pes_CONT.append(cont)
                    D_MatrizT5_pes_OBS.append(Observation)

                    A_matrizT5_pes_carregamento.append(A_carga_pes)
                    A_matrizT5_pes_POTP.append(A_PotP_pes)
                    A_matrizT5_pes_POTQ.append(A_PotQ_pes)
                    A_matrizT5_pes_TENSAO.append(A_DeltaV_pes)
                    A_matrizT5_pes_BqV.append(A_BqV_pes)
                    A_matrizT5_pes_ANGULO.append(A_Ang_pes)
                    A_matrizT5_pes_BPQ.append(A_Bpq_pes)
                    A_matrizT5_pes_CONT.append(A_cont_pes)
                    A_matrizT5_pes_OBS.append(A_Bpq_pes)

        # vetPswing_D_pes=[]
        # for i in range(len(D_MatrizT5_pes_POTP)): 
        #     vetPswing_D_pes.append(D_MatrizT5_pes_POTP[i][0])
        # print('vetPswing_D_pes=',vetPswing_D_pes)
        
        # D_Pswing_pes_max = max(vetPswing_D_pes)  # Encontra o valor máximo
        # D_Pswing_pes_min = min(vetPswing_D_pes)  # Encontra o valor mínim
        # indice_Pswing_pes_max = vetPswing_D_pes.index(D_Pswing_pes_max)  # Encontra o índice do valor máximo
        # indice_Pswing_pes_min = vetPswing_D_pes.index(D_Pswing_pes_min)  # Encontra o índice do valor mínimo
        A_matrizT6_lev_carregamento=[]
        A_matrizT6_lev_POTP=[]
        A_matrizT6_lev_POTQ=[]
        A_matrizT6_lev_TENSAO=[]
        A_matrizT6_lev_BqV=[]
        A_matrizT6_lev_ANGULO=[]
        A_matrizT6_lev_BPQ=[]
        A_matrizT6_lev_CONT=[]
        A_matrizT6_lev_OBS=[]

        D_MatrizT6_lev_carregamento=[]
        D_MatrizT6_lev_POTP=[]
        D_MatrizT6_lev_POTQ=[]
        D_MatrizT6_lev_TENSAO=[]
        D_MatrizT6_lev_BqV=[]
        D_MatrizT6_lev_ANGULO=[]
        D_MatrizT6_lev_BPQ=[]
        D_MatrizT6_lev_CONT=[]
        D_MatrizT6_lev_OBS=[]         
        
        
        
        if tipo_de_REGIME=='leve' or tipo_de_REGIME=='ambos':
            if PQPVlev=='yes':


                elementos, _ , candidates_vetor = arrumadadosDados(candidateviola_block_anterior_lev,candidate_bloc_anterior_lev)
                
                #print('elementos=',elementos)
                #print(indices_doBloco)
                # print('candidate_bloc_anterior=',candidate_bloc_anterior)
                # print(candidateviola_block_anterior)
                
                _ , vetor_inicio, vetor_ponta = extrair_vetores_ObjetoAEstudado(elementos, candidates_vetor)
                vetor_ponta_corrigido = corrigir_capturaPontos(elementos)

                if vetor_ponta_corrigido!=[]:
                    candidates_vetor=[[0]*len(candidates_vetor[0])]+candidates_vetor
                    vetor_inicio=[0]+vetor_inicio
                    vetor_ponta=vetor_ponta_corrigido+vetor_ponta
                    for AUXILIAR2 in range(len(vetor_inicio)):
                        if AUXILIAR2>0:
                            vetor_inicio[AUXILIAR2]= vetor_inicio[AUXILIAR2]+1

                # print("Vet_objeto:", vet_objeto)
                # print("Vetor_inicio:", vetor_inicio)
                # print("Vetor_ponta:", vetor_ponta)
                # print('-------------------------------------------')
                # print('-------------------------------------------------------------------------------------------')
                # print('-------------------------------------------')
                # print('-------------------------------------------------------------------------------------------')
                # print('-------------------------------------------')
                # print('------------------------------------------------------INICIO-------------------------------')
                # print("candidates_vetor:", candidates_vetor)
                # print('-------------------------------------------')
                # print('-------------------------------------------------------------------------------------------')
                # print('-------------------------------------------')
                # print('-------------------------------------------------------------------------------------------')
                # print('-------------------------------------------')
                # print('------------------------------------------------------FIM----------------------------------')
                # print(primeiroAviolar)
                # print(ultimoAviolar)
                #print('aqui33')
                
                #indices_encontrados_pontosInteresse_lev = buscar_indices_matrizes(matrizes_substituidas_025, vet_objeto)
                # print(indices_encontrados_pontosInteresse_lev)               
                # print('aqui')

                # Chamando a função
                #matriz_de_pontos_testes, diferencas = criar_matriz_de_pontos_testes(candidates_vetor, vetor_inicio, vetor_ponta)
                matriz_de_pontos_testes_antes_lev, matriz_diferencas_lev = identifica_PQambos_valor_que_faz_cair(candidates_vetor, vetor_inicio, vetor_ponta)
                #indices_encontrados_pontosInteresse_lev2 = buscar_indices_matrizes(matrizes_substituidas_025, matriz_de_pontos_testes_antes)
                
                #print(indices_encontrados_pontosInteresse_lev)
                # Resultado
                # print("Matriz de diferenças=")
                # for linha in matriz_diferencas:
                #     print(linha)
                    
                # # Resultados
                # print("matriz_de_pontos_testes_antes=")
                # for linha in matriz_de_pontos_testes_antes:
                #     print(linha)
                
                # print('ATIVA_ESPEC=',ATIVA_ESPEC0)
                #print('aqui2')
                #  timer
                time = datetime.now()
                #time_date = datetime.fromtimestamp(time)
                parametro_de_verificacao.append([time.strftime("%H:%M:%S"),'ANÁLISE DE FRONTREIRA: REGIME LEVE', len(matriz_de_pontos_testes_antes_lev),' -PONTOS DETECTADOS' ])  
                print([time.strftime("%H:%M:%S"),'ANÁLISE DE FRONTREIRA: REGIME LEVE', len(matriz_de_pontos_testes_antes_lev),' -PONTOS DETECTADOS' ])         

                for cadidat in range(len(matriz_de_pontos_testes_antes_lev)):
                    procura_fronteira_down='no'
                    _ , ATIVA_down = gerar_vetores_com_variacao(matriz_de_pontos_testes_antes_lev[cadidat], ATIVA_ESPEC, limite_variacao)
                    # for auxiliar in range(len(ATIVA_down)):
                    #     ATIVA_down[auxiliar]=[float(x) for x in ATIVA_down[auxiliar]]                    
                    A_carga_lev=[0]*len(ATIVA_ESPEC)
                    A_DeltaV_lev=[0]*len(ATIVA_ESPEC)
                    A_PotP_lev=[0]*len(ATIVA_ESPEC)
                    A_PotQ_lev=[0]*len(ATIVA_ESPEC)
                    A_BqV_lev=[0]*len(ATIVA_ESPEC)
                    A_Ang_lev=[0]*len(ATIVA_ESPEC)
                    A_Bpq_lev=[0]*len(ATIVA_ESPEC)
                    A_cont_lev=0
                    stopa_por_nao_encontrar='no'
                    while procura_fronteira_down=='no':
                        # MatrizCarregamento = criar_matriz_esparsa_com_indices(
                        #     PVbarIndex, TENSAO_ESPEC, PIndex, ATIVA_down, GIndex, GERADOR, QIndex, REATIVA_ESPEC, MinMaxIndex, Qmin, Qmax, num_barras + 1, status_program
                        # )
                        # ([matriz_DadosBarra], [infoVctrl]) = DefineMatrizDadosBarra(
                        #     matrizSystem, 100, HabiltAval_Lim_Reativo, status_program, MODELin, MatrizCarregamento, alterar_tensao_decontrole_doCDF
                        # )

                        for AUXILIAR in range(len(ATIVA_down)):
                            matriz_DadosBarra[1][AUXILIAR]=(float(ATIVA_down[AUXILIAR]))/S_base
                            matriz_DadosBarra[2][AUXILIAR]=float(matriz_DadosBarra[2][AUXILIAR])
                            matriz_DadosBarra[4][AUXILIAR]=float(matriz_DadosBarra[4][AUXILIAR])
                            matriz_DadosBarra[5][AUXILIAR]=float(matriz_DadosBarra[5][AUXILIAR])
                            matriz_DadosBarra[7][AUXILIAR]=float(matriz_DadosBarra[7][AUXILIAR])
                            infoVctrl[1][AUXILIAR]=float( infoVctrl[1][AUXILIAR])
                            matrizSystem[AUXILIAR][9]=(-1)*(ATIVA_down[AUXILIAR])

                        # Execução do fluxo de potência
                        stopa_por_nao_encontrar=confirmar_se_nao_CAI(matriz_diferencas_lev, matriz_de_pontos_testes_antes_lev, ATIVA_down, ATIVA_ESPEC, cadidat, limite_variacao, stopa_por_nao_encontrar)
                        Fluxo_divergente='no'
                        try: 
                            (DeltaV, Delta0, PotP, PotQ, _, _, cont, _, Barras_PQ , _, _, BarraQViola_estatica, _ , _ , _ , _ , _ , _ , _ , _ , _ , _ , VerificaSeViola, _, _, _) = CHAMA_FLNR_03_LTT(
                                matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, MODELin, Tolerancia, momentoTirarfoto, PotP_Lim_Func, PotQ_Lim_Func, infoVctrl_Lim_Func, Barras_PQ_Lim_Func, matriz_DadosBarra_Lim_Func, cont_Lim_Func, DeltaV_Lim_Func, Delta0_Lim_Func, jatirouafoto, sinal, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY
                            )
                        except Exception as e:
                            Fluxo_divergente='yes'  

                        if Fluxo_divergente=='no' and stopa_por_nao_encontrar=='no':
                            Observation='None'
                            resultado_fronteira, _= detectar_mudanca_de_status_0(BarraQViola_estatica_0, VerificaSeViola_0, BarraQViola_estatica, VerificaSeViola) 
                            if resultado_fronteira==False:
                                procura_fronteira_down='no'
                                for aux in range(len(ATIVA_ESPEC)):
                                    A_carga_lev[aux]=ATIVA_down[aux]
                                    A_DeltaV_lev[aux]=DeltaV[aux]
                                    A_PotP_lev[aux]=PotP[aux]
                                    A_PotQ_lev[aux]=PotQ[aux]
                                    A_BqV_lev[aux]=BarraQViola_estatica[aux] 
                                    A_Ang_lev[aux]=Delta0[aux]
                                    A_Bpq_lev[aux]=Barras_PQ[aux]
                                    A_cont_lev=cont

                                elemento_x=matriz_diferencas_lev[cadidat]  # Acessa a matriz de índice cadidat
                                for valor in elemento_x:  # Itera sobre os elementos dessa matriz
                                    if ATIVA_down[valor]<ATIVA_ESPEC[valor]*(1-limite_variacao/100):
                                        ATIVA_down[valor] = ATIVA_down[valor] + PassoEstudo_DasCombinacoes 
                                    else:
                                        ATIVA_down[valor]=ATIVA_ESPEC[valor]*(1-limite_variacao/100)  
                            else:
                                procura_fronteira_down='yes'
                        else:
                            DeltaV=[0]*len(ATIVA_ESPEC)
                            PotP=[0]*len(ATIVA_ESPEC)
                            PotQ=[0]*len(ATIVA_ESPEC)
                            BarraQViola_estatica=[0]*len(ATIVA_ESPEC)
                            Delta0=[0]*len(ATIVA_ESPEC)
                            Barras_PQ=[0]*len(ATIVA_ESPEC)
                            if  stopa_por_nao_encontrar=='no':
                                Observation='Fluxo divergente.'
                            else:
                                Observation='Fluxo Indiferente'
                            cont=0    
                            procura_fronteira_down='yes'

                    D_MatrizT6_lev_carregamento.append(ATIVA_down)
                    D_MatrizT6_lev_POTP.append(PotP)
                    D_MatrizT6_lev_POTQ.append(PotQ)
                    D_MatrizT6_lev_TENSAO.append(DeltaV)
                    D_MatrizT6_lev_BqV.append(BarraQViola_estatica)
                    D_MatrizT6_lev_ANGULO.append(Delta0)
                    D_MatrizT6_lev_BPQ.append(Barras_PQ)
                    D_MatrizT6_lev_CONT.append(cont)
                    D_MatrizT6_lev_OBS.append(Observation)            

                    A_matrizT6_lev_carregamento.append(A_carga_lev)
                    A_matrizT6_lev_POTP.append(A_PotP_lev)
                    A_matrizT6_lev_POTQ.append(A_PotQ_lev)
                    A_matrizT6_lev_TENSAO.append(A_DeltaV_lev)
                    A_matrizT6_lev_BqV.append(A_BqV_lev)
                    A_matrizT6_lev_ANGULO.append(A_Ang_lev)
                    A_matrizT6_lev_BPQ.append(A_Bpq_lev)
                    A_matrizT6_lev_CONT.append(A_cont_lev)
                    A_matrizT6_lev_OBS.append(Observation)            

            # vetPswing_D_lev=[]
            # for i in range(len(D_MatrizT6_lev_POTP)): 
            #     vetPswing_D_lev.append(D_MatrizT6_lev_POTP[i][0])
            # #print('vetPswing_D_lev=',vetPswing_D_lev)
            
            # D_Pswing_lev_max = max(vetPswing_D_lev)  # Encontra o valor máximo
            # D_Pswing_lev_min = min(vetPswing_D_lev)  # Encontra o valor mínim
            # indice_Pswing_lev_max = vetPswing_D_lev.index(D_Pswing_lev_max)  # Encontra o índice do valor máximo
            # indice_Pswing_lev_min = vetPswing_D_lev.index(D_Pswing_lev_min)  # Encontra o índice do valor mínimo



    ''' ------------------------------------------------------------------------------------------------ '''
    ''' ----------------------------------------- APRESENTAÇÃO ----------------------------------------- '''
    ''' ------------------------------------------------------------------------------------------------ '''
    #  timer
    time = datetime.now()
    #time_date = datetime.fromtimestamp(time)
    parametro_de_verificacao.append([time.strftime("%H:%M:%S"),' FINALIZANDO CÁLCULO '])
    print([time.strftime("%H:%M:%S"),' FINALIZANDO CÁLCULO ']) 
    
    if (tipo_de_ESTUDO=='Segregar (PQ)_(PV)' or tipo_de_ESTUDO=='Segregar (PQ)' or tipo_de_ESTUDO=='Segregar (PV)'):

        D_CARREGAMENTO_PES=[]
        A_CARREGAMENTO_PES=[]
        D_TENSAO_PES=[]
        A_TENSAO_PES=[]
        D_POTP_PES=[]
        A_POTP_PES=[]        
        D_POTQ_PES=[]
        A_POTQ_PES=[]
        D_BqV_PES=[]
        A_BqV_PES=[]
        D_ANGULO_PES=[]
        A_ANGULO_PES=[]        
        D_BPQ_PES=[]
        A_BPQ_PES=[]  
        D_CONT_PES=[]
        A_CONT_PES=[]
        D_OBS_PES=[]
        A_OBS_PES=[]                

        if D_matrizT1_pes_carregamento!=[] and D_MatrizT3_pes_carregamento!=[]:
            D_CARREGAMENTO_PES=D_matrizT1_pes_carregamento+D_MatrizT3_pes_carregamento
            A_CARREGAMENTO_PES=A_matrizT1_pes_carregamento+A_matrizT3_pes_carregamento
            D_TENSAO_PES=D_matrizT1_pes_TENSAO+D_MatrizT3_pes_TENSAO
            A_TENSAO_PES=A_matrizT1_pes_TENSAO+A_matrizT3_pes_TENSAO
            D_POTP_PES=D_matrizT1_pes_POTP+D_MatrizT3_pes_POTP
            A_POTP_PES=A_matrizT1_pes_POTP+A_matrizT3_pes_POTP
            D_POTQ_PES=D_matrizT1_pes_POTQ+D_MatrizT3_pes_POTQ
            A_POTQ_PES=A_matrizT1_pes_POTQ+A_matrizT3_pes_POTQ
            D_BqV_PES=D_matrizT1_pes_BqV+D_MatrizT3_pes_BqV
            A_BqV_PES=A_matrizT1_pes_BqV+A_matrizT3_pes_BqV
            D_ANGULO_PES=D_matrizT1_pes_ANGULO+D_MatrizT3_pes_ANGULO
            A_ANGULO_PES=A_matrizT1_pes_ANGULO+A_matrizT3_pes_ANGULO
            D_BPQ_PES=D_matrizT1_pes_BPQ+D_MatrizT3_pes_BPQ
            A_BPQ_PES=A_matrizT1_pes_BPQ+A_matrizT3_pes_BPQ 
            D_CONT_PES=D_matrizT1_pes_CONT+D_MatrizT3_pes_CONT
            A_CONT_PES=A_matrizT1_pes_CONT+A_matrizT3_pes_CONT 
            D_OBS_PES=D_matrizT1_pes_OBS+D_MatrizT3_pes_OBS
            A_OBS_PES=A_matrizT1_pes_OBS+A_matrizT3_pes_OBS                                    

        if D_matrizT1_pes_carregamento!=[] and D_MatrizT3_pes_carregamento==[]:    
            D_CARREGAMENTO_PES=D_matrizT1_pes_carregamento
            A_CARREGAMENTO_PES=A_matrizT1_pes_carregamento
            D_TENSAO_PES=D_matrizT1_pes_TENSAO
            A_TENSAO_PES=A_matrizT1_pes_TENSAO
            D_POTP_PES=D_matrizT1_pes_POTP
            A_POTP_PES=A_matrizT1_pes_POTP
            D_POTQ_PES=D_matrizT1_pes_POTQ
            A_POTQ_PES=A_matrizT1_pes_POTQ
            D_BqV_PES=D_matrizT1_pes_BqV
            A_BqV_PES=A_matrizT1_pes_BqV
            D_ANGULO_PES=D_matrizT1_pes_ANGULO
            A_ANGULO_PES=A_matrizT1_pes_ANGULO
            D_BPQ_PES=D_matrizT1_pes_BPQ
            A_BPQ_PES=A_matrizT1_pes_BPQ  
            D_CONT_PES=D_matrizT1_pes_CONT
            A_CONT_PES=A_matrizT1_pes_CONT 
            D_OBS_PES=D_matrizT1_pes_OBS
            A_OBS_PES=A_matrizT1_pes_OBS  

        if D_matrizT1_pes_carregamento==[] and D_MatrizT3_pes_carregamento!=[]:    
            D_CARREGAMENTO_PES=D_MatrizT3_pes_carregamento
            A_CARREGAMENTO_PES=A_matrizT3_pes_carregamento       
            D_TENSAO_PES=D_MatrizT3_pes_TENSAO
            A_TENSAO_PES=A_matrizT3_pes_TENSAO
            D_POTP_PES=D_MatrizT3_pes_POTP
            A_POTP_PES=A_matrizT3_pes_POTP
            D_POTQ_PES=D_MatrizT3_pes_POTQ
            A_POTQ_PES=A_matrizT3_pes_POTQ
            D_BqV_PES=D_MatrizT3_pes_BqV
            A_BqV_PES=A_matrizT3_pes_BqV
            D_ANGULO_PES=D_MatrizT3_pes_ANGULO
            A_ANGULO_PES=A_matrizT3_pes_ANGULO
            D_BPQ_PES=D_MatrizT3_pes_BPQ
            A_BPQ_PES=A_matrizT3_pes_BPQ   
            D_CONT_PES=D_MatrizT3_pes_CONT
            A_CONT_PES=A_matrizT3_pes_CONT 
            D_OBS_PES=D_MatrizT3_pes_OBS
            A_OBS_PES=A_matrizT3_pes_OBS  


        D_CARREGAMENTO_LEV=[]
        A_CARREGAMENTO_LEV=[]
        D_TENSAO_LEV=[]
        A_TENSAO_LEV=[]
        D_POTP_LEV=[]
        A_POTP_LEV=[]        
        D_POTQ_LEV=[]
        A_POTQ_LEV=[]
        D_BqV_LEV=[]
        A_BqV_LEV=[]
        D_ANGULO_LEV=[]
        A_ANGULO_LEV=[]        
        D_BPQ_LEV=[]
        A_BPQ_LEV=[]  
        D_CONT_LEV=[]
        A_CONT_LEV=[]
        D_OBS_LEV=[]
        A_OBS_LEV=[] 

        if D_matrizT2_lev_carregamento!=[] and D_MatrizT3_lev_carregamento!=[]:
            D_CARREGAMENTO_LEV=D_matrizT2_lev_carregamento+D_MatrizT3_lev_carregamento
            A_CARREGAMENTO_LEV=A_matrizT2_lev_carregamento+A_matrizT3_lev_carregamento
            D_TENSAO_LEV=D_matrizT2_lev_TENSAO+D_MatrizT3_lev_TENSAO
            A_TENSAO_LEV=A_matrizT2_lev_TENSAO+A_matrizT3_lev_TENSAO
            D_POTP_LEV=D_matrizT2_lev_POTP+D_MatrizT3_lev_POTP
            A_POTP_LEV=A_matrizT2_lev_POTP+A_matrizT3_lev_POTP
            D_POTQ_LEV=D_matrizT2_lev_POTQ+D_MatrizT3_lev_POTQ
            A_POTQ_LEV=A_matrizT2_lev_POTQ+A_matrizT3_lev_POTQ
            D_BqV_LEV=D_matrizT2_lev_BqV+D_MatrizT3_lev_BqV
            A_BqV_LEV=A_matrizT2_lev_BqV+A_matrizT3_lev_BqV
            D_ANGULO_LEV=D_matrizT2_lev_ANGULO+D_MatrizT3_lev_ANGULO
            A_ANGULO_LEV=A_matrizT2_lev_ANGULO+A_matrizT3_lev_ANGULO
            D_BPQ_LEV=D_matrizT2_lev_BPQ+D_MatrizT3_lev_BPQ
            A_BPQ_LEV=A_matrizT2_lev_BPQ+A_matrizT3_lev_BPQ
            D_CONT_LEV=D_matrizT2_lev_CONT+D_MatrizT3_lev_CONT
            A_CONT_LEV=A_matrizT2_lev_CONT+A_matrizT3_lev_CONT
            D_OBS_LEV=D_matrizT2_lev_OBS+D_MatrizT3_lev_OBS
            A_OBS_LEV=A_matrizT2_lev_OBS+A_matrizT3_lev_OBS                        

        if D_matrizT2_lev_carregamento!=[] and D_MatrizT3_lev_carregamento==[]:  
            D_CARREGAMENTO_LEV=D_matrizT2_lev_carregamento
            A_CARREGAMENTO_LEV=A_matrizT2_lev_carregamento
            D_TENSAO_LEV=D_matrizT2_lev_TENSAO
            A_TENSAO_LEV=A_matrizT2_lev_TENSAO
            D_POTP_LEV=D_matrizT2_lev_POTP
            A_POTP_LEV=A_matrizT2_lev_POTP
            D_POTQ_LEV=D_matrizT2_lev_POTQ
            A_POTQ_LEV=A_matrizT2_lev_POTQ
            D_BqV_LEV=D_matrizT2_lev_BqV
            A_BqV_LEV=A_matrizT2_lev_BqV
            D_ANGULO_LEV=D_matrizT2_lev_ANGULO
            A_ANGULO_LEV=A_matrizT2_lev_ANGULO
            D_BPQ_LEV=D_matrizT2_lev_BPQ
            A_BPQ_LEV=A_matrizT2_lev_BPQ
            D_CONT_LEV=D_matrizT2_lev_CONT
            A_CONT_LEV=A_matrizT2_lev_CONT
            D_OBS_LEV=D_matrizT2_lev_OBS
            A_OBS_LEV=A_matrizT2_lev_OBS  

        if D_matrizT2_lev_carregamento==[] and D_MatrizT3_lev_carregamento!=[]:    
            D_CARREGAMENTO_LEV=D_MatrizT3_lev_carregamento
            A_CARREGAMENTO_LEV=A_matrizT3_lev_carregamento
            D_TENSAO_LEV=D_MatrizT3_lev_TENSAO
            A_TENSAO_LEV=A_matrizT3_lev_TENSAO
            D_POTP_LEV=D_MatrizT3_lev_POTP
            A_POTP_LEV=A_matrizT3_lev_POTP
            D_POTQ_LEV=D_MatrizT3_lev_POTQ
            A_POTQ_LEV=A_matrizT3_lev_POTQ
            D_BqV_LEV=D_MatrizT3_lev_BqV
            A_BqV_LEV=A_matrizT3_lev_BqV
            D_ANGULO_LEV=D_MatrizT3_lev_ANGULO
            A_ANGULO_LEV=A_matrizT3_lev_ANGULO
            D_BPQ_LEV=D_MatrizT3_lev_BPQ
            A_BPQ_LEV=A_matrizT3_lev_BPQ
            D_CONT_LEV=D_MatrizT3_lev_CONT
            A_CONT_LEV=A_matrizT3_lev_CONT
            D_OBS_LEV=D_MatrizT3_lev_OBS
            A_OBS_LEV=A_matrizT3_lev_OBS  

        # Converter os arrays em listas
        D_CARREGAMENTO_PES = [list(arr) for arr in D_CARREGAMENTO_PES]
        A_CARREGAMENTO_PES = [list(arr) for arr in A_CARREGAMENTO_PES]
        for auxiliar in range(len(D_CARREGAMENTO_PES)):
            D_CARREGAMENTO_PES[auxiliar]=[float(x) for x in D_CARREGAMENTO_PES[auxiliar]]
        for auxiliar in range(len(A_CARREGAMENTO_PES)):
            A_CARREGAMENTO_PES[auxiliar]=[float(x) for x in A_CARREGAMENTO_PES[auxiliar]]

        D_CARREGAMENTO_LEV = [list(arr) for arr in D_CARREGAMENTO_LEV]
        A_CARREGAMENTO_LEV = [list(arr) for arr in A_CARREGAMENTO_LEV]
        for auxiliar in range(len(D_CARREGAMENTO_LEV)):
            D_CARREGAMENTO_LEV[auxiliar]=[float(x) for x in D_CARREGAMENTO_LEV[auxiliar]] 
        for auxiliar in range(len(A_CARREGAMENTO_LEV)):
            A_CARREGAMENTO_LEV[auxiliar]=[float(x) for x in A_CARREGAMENTO_LEV[auxiliar]] 


        for auxiliar in range(len(D_TENSAO_PES)):
            D_TENSAO_PES[auxiliar]=[float(x) for x in D_TENSAO_PES[auxiliar]]
        for auxiliar in range(len(D_ANGULO_PES)):
            D_ANGULO_PES[auxiliar]=[float(x) for x in D_ANGULO_PES[auxiliar]]
        for auxiliar in range(len(D_POTP_PES)):
            D_POTP_PES[auxiliar]=[float(x) for x in D_POTP_PES[auxiliar]]
        for auxiliar in range(len(D_POTQ_PES)):
            D_POTQ_PES[auxiliar]=[float(x) for x in D_POTQ_PES[auxiliar]]

        for auxiliar in range(len(A_TENSAO_PES)):
            A_TENSAO_PES[auxiliar]=[float(x) for x in A_TENSAO_PES[auxiliar]]
        for auxiliar in range(len(A_ANGULO_PES)):
            A_ANGULO_PES[auxiliar]=[float(x) for x in A_ANGULO_PES[auxiliar]]
        for auxiliar in range(len(A_POTP_PES)):
            A_POTP_PES[auxiliar]=[float(x) for x in A_POTP_PES[auxiliar]]
        for auxiliar in range(len(A_POTQ_PES)):
            A_POTQ_PES[auxiliar]=[float(x) for x in A_POTQ_PES[auxiliar]]

        for auxiliar in range(len(D_TENSAO_LEV)):
            D_TENSAO_LEV[auxiliar]=[float(x) for x in D_TENSAO_LEV[auxiliar]]
        for auxiliar in range(len(D_ANGULO_LEV)):
            D_ANGULO_LEV[auxiliar]=[float(x) for x in D_ANGULO_LEV[auxiliar]]
        for auxiliar in range(len(D_POTP_LEV)):
            D_POTP_LEV[auxiliar]=[float(x) for x in D_POTP_LEV[auxiliar]]
        for auxiliar in range(len(D_POTQ_LEV)):
            D_POTQ_LEV[auxiliar]=[float(x) for x in D_POTQ_LEV[auxiliar]]

        for auxiliar in range(len(A_TENSAO_LEV)):
            A_TENSAO_LEV[auxiliar]=[float(x) for x in A_TENSAO_LEV[auxiliar]]
        for auxiliar in range(len(A_ANGULO_LEV)):
            A_ANGULO_LEV[auxiliar]=[float(x) for x in A_ANGULO_LEV[auxiliar]]
        for auxiliar in range(len(A_POTP_LEV)):
            A_POTP_LEV[auxiliar]=[float(x) for x in A_POTP_LEV[auxiliar]]
        for auxiliar in range(len(A_POTQ_LEV)):
            A_POTQ_LEV[auxiliar]=[float(x) for x in A_POTQ_LEV[auxiliar]]
        # Converter os elementos para float
        # vetPswing_D_lev = [float(x) for x in vetPswing_D_lev]

        #print(A_TENSAO_LEV)
        # if A_TENSAO_LEV!=[]:
        #     plot(A_TENSAO_LEV[0], A_ANGULO_LEV[0], A_POTP_LEV[0], A_POTQ_LEV[0],infoVctrl,cont)
        #     plot_PotGer(A_POTP_LEV[0], A_POTQ_LEV[0], infoVctrl, A_BPQ_LEV[0], matriz_DadosBarra)
        
        # if A_TENSAO_PES!=[]:
        #     plot(A_TENSAO_PES[0], A_ANGULO_PES[0], A_POTP_PES[0], A_POTQ_PES[0],infoVctrl,cont)
        #     plot_PotGer(A_POTP_PES[0], A_POTQ_PES[0], infoVctrl, A_BPQ_PES[0], matriz_DadosBarra)
       
       # print('D_BqV_PES=', D_BqV_PES)
        # # print('ATIVA_ESPEC=', ATIVA_ESPEC)
        # print('aqui') 

        # print('D_CARREGAMENTO_LEV', D_CARREGAMENTO_LEV)
        # print('ATIVA_ESPEC=', ATIVA_ESPEC)
        # print('aqui') 
        if TENSAO_ESPEC[0]==DeltaV_0[0]:
            BarraQViola_estatica_00=0
        else:
            BarraQViola_estatica_00=1

        #D_CARREGAMENTO_PES_val, D_CARREGAMENTO_PES_pos, vetor_BarrasAdicionadas = comparar_carregamento(D_CARREGAMENTO_PES, ATIVA_ESPEC)
        #print()
        result_PES = comparar_carregamento(D_CARREGAMENTO_PES, ATIVA_ESPEC)
        # Exibindo os resultados
        (
            D_CARREGAMENTO_PES_val,
            D_CARREGAMENTO_PES_pos,
            vetor_BarrasAdicionadas_PES,
            PotP_Adicionada_PES,
            MatrizPorcentagem_PES,
            VetorPorcentagem_PES,
        ) = result_PES
        
        vetor_BqV_PES = analisa_BqV(D_BqV_PES)
        vetorTAG_PES = geraTAG(D_CARREGAMENTO_PES_pos, PVbarIndex)
        # quantidadeViolada_0, _ , vetor_de_diferencas_PES, Indicador_de_QUALIDADE_PES, Quantidade_Violada_PES = analisadora_DeResultados(
        #     BarraQViola_estatica_0, PVbarIndex, D_BqV_PES, D_TENSAO_PES, A_TENSAO_LEV, BarraQViola_estatica_00
        # )      
        # 
        quantidadeViolada_0 , _ , vetor_de_diferencas_PES, Indicador_de_QUALIDADE_PES, Quantidade_Violada_PES=analisadora_DeResultados_POSTUMAS02(D_TENSAO_PES, A_TENSAO_PES, DeltaV_0, infoVctrl[1])  


        # print('BarraQViola_estatica_0=',BarraQViola_estatica_0)
        # print('PVbarIndex=',PVbarIndex)        
        # print('D_BqV_PES=',D_BqV_PES)

        result_LEV = comparar_carregamento(D_CARREGAMENTO_LEV, ATIVA_ESPEC)
        # Exibindo os resultados
        (
            _ ,
            D_CARREGAMENTO_LEV_pos,
            vetor_BarrasAdicionadas_LEV,
            PotP_Adicionada_LEV,
            _ ,
            VetorPorcentagem_LEV,
        ) = result_LEV
        
        vetor_BqV_LEV = analisa_BqV(D_BqV_LEV)
        vetorTAG_LEV = geraTAG(D_CARREGAMENTO_LEV_pos, PVbarIndex)       
        # _ , _ , vetor_de_diferencas_LEV, Indicador_de_QUALIDADE_LEV, Quantidade_Violada_LEV = analisadora_DeResultados(
        #     BarraQViola_estatica_0, PVbarIndex, D_BqV_LEV, D_TENSAO_LEV, A_TENSAO_LEV, BarraQViola_estatica_00
        # )
        quantidadeViolada_0 , _ , vetor_de_diferencas_LEV, Indicador_de_QUALIDADE_LEV, Quantidade_Violada_LEV=analisadora_DeResultados_POSTUMAS02(D_TENSAO_LEV, A_TENSAO_LEV, DeltaV_0, infoVctrl[1])

        BarraQViola_estatica_0_STRG = incrementar_BarraQViola(BarraQViola_estatica_0)
        
        BarrasQjaViolavam_indicacaoDeQualidade_LEV=[]
        BarrasQjaViolavam_indicacaoDeQualidade_PES=[]

        for aux in range(len(D_TENSAO_LEV)):
            _, _, _, _, _, stringvetTAGBqVrestante  = analisadora_DeResultados_POSTUMAS_01(BarraQViola_estatica_0, D_TENSAO_LEV[aux], DeltaV_0, infoVctrl[1], tolApresent)
            #vetor_Acomparar, vetor_ref, vetor_SAF, vetor_SAP, vetTAGBqVrestante, stringvetTAGBqVrestante  = analisadora_DeResultados_POSTUMAS_01(BarraQViola_estatica_0, D_TENSAO_LEV_aux, DeltaV_0, infoVcontrol, tolApresent)
            BarrasQjaViolavam_indicacaoDeQualidade_LEV.append(stringvetTAGBqVrestante)
        for aux in range(len(D_TENSAO_PES)):
            _, _, _, _, _, stringvetTAGBqVrestante  = analisadora_DeResultados_POSTUMAS_01(BarraQViola_estatica_0, D_TENSAO_PES[aux], DeltaV_0, infoVctrl[1], tolApresent)
            #vetor_Acomparar, vetor_ref, vetor_SAF, vetor_SAP, vetTAGBqVrestante, stringvetTAGBqVrestante  = analisadora_DeResultados_POSTUMAS_01(BarraQViola_estatica_0, D_TENSAO_LEV_aux, DeltaV_0, infoVcontrol, tolApresent)
            BarrasQjaViolavam_indicacaoDeQualidade_PES.append(stringvetTAGBqVrestante) 
        
        
        # print('\n\n')
        # print('---------------------------------------------------------------')
        # print("Quantidade Violada_0:", quantidadeViolada_0)
        # print("Barra Violada_0:", BarraQViola_estatica_0_STRG)
        # print('---------------------------------------------------------------')
        # print('\n')
        # print('RESULTADO REGIME CARGA PESADA:')
        # print('vetorTAG_PES=', vetorTAG_PES[:30])
        # print("PotP_Adicionada_PES=", PotP_Adicionada_PES[:30])
        # print("vetor_BqV_PES=", vetor_BqV_PES[:30])
        # print("vetor_BarrasAdicionadas_PES=", vetor_BarrasAdicionadas_PES[:30])
        # print("VetorPorcentagem_PES=", VetorPorcentagem_PES[:30])
        
        # #print("Matriz de Diferenças:", matriz_de_diferencas)
        # print("Vetor de Diferenças_PES:", vetor_de_diferencas_PES)
        # print("Indicador_de_QUALIDADE_PES:", Indicador_de_QUALIDADE_PES)
        # print('Quantidade_Violada_PES:',Quantidade_Violada_PES)
        
        # print('\n')
        # print('RESULTADO REGIME CARGA LEVE:')
        # print('vetorTAG_LEV=', vetorTAG_LEV[:30])
        # print("PotP_Adicionada_LEV=", PotP_Adicionada_LEV[:30])
        # print("vetor_BqV_LEV=", vetor_BqV_LEV[:30])
        # print("vetor_BarrasAdicionadas_LEV=", vetor_BarrasAdicionadas_LEV[:30])
        # print("VetorPorcentagem_LEV=", VetorPorcentagem_LEV[:30])
        # #print('aqui')

        # #print("Matriz de Diferenças:", matriz_de_diferencas)
        # print("Vetor de Diferenças_LEV:", vetor_de_diferencas_LEV)
        # print("Indicador_de_QUALIDADE_LEV:", Indicador_de_QUALIDADE_LEV)
        # print('Quantidade_Violada_LEV:',Quantidade_Violada_LEV)
        # print('\n\n')
        
        
        MATRIZ_TOTAL_PES=[]
        for aux in range(len(vetor_de_diferencas_PES)):
            MATRIZ_TOTAL_PES_lin=[]
            MATRIZ_TOTAL_PES_lin.append(vetorTAG_PES[aux]) #0
            MATRIZ_TOTAL_PES_lin.append(PotP_Adicionada_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(vetor_BarrasAdicionadas_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(VetorPorcentagem_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(vetor_de_diferencas_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(Indicador_de_QUALIDADE_PES[aux])  #5
            MATRIZ_TOTAL_PES_lin.append(Quantidade_Violada_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(D_OBS_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(BarrasQjaViolavam_indicacaoDeQualidade_PES[aux])             
            MATRIZ_TOTAL_PES_lin.append('-------')
            MATRIZ_TOTAL_PES_lin.append(vetor_BqV_PES[aux])  #10
            MATRIZ_TOTAL_PES_lin.append(D_CARREGAMENTO_PES[aux])
            #MATRIZ_TOTAL_PES_lin.append(infoVctrl)  
            #MATRIZ_TOTAL_PES_lin.append(matriz_DadosBarra)
            MATRIZ_TOTAL_PES_lin.append('INICIO TABELAS')            
            MATRIZ_TOTAL_PES_lin.append('TABELA 1A - Plot - PESADO DEPOIS')             
            MATRIZ_TOTAL_PES_lin.append(D_TENSAO_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(D_ANGULO_PES[aux])  #15
            MATRIZ_TOTAL_PES_lin.append(D_POTP_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(D_POTQ_PES[aux])
            #MATRIZ_TOTAL_PES_lin.append(D_BqV_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(infoVctrl) 
            MATRIZ_TOTAL_PES_lin.append(D_CONT_PES[aux])  #19
            MATRIZ_TOTAL_PES_lin.append(matriz_DadosBarra)
            #MATRIZ_TOTAL_PES_lin.append(D_BPQ_PES[aux])
            MATRIZ_TOTAL_PES_lin.append('TABELA 1B - PotGer - PESADO DEPOIS') 
            MATRIZ_TOTAL_PES_lin.append(D_POTP_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(D_POTQ_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(infoVctrl) 
            MATRIZ_TOTAL_PES_lin.append(D_BqV_PES[aux]) #25
            MATRIZ_TOTAL_PES_lin.append(matriz_DadosBarra)                       
            MATRIZ_TOTAL_PES_lin.append('TABELA 2A - Plot - PESADO ANTES')             
            MATRIZ_TOTAL_PES_lin.append(A_TENSAO_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(A_ANGULO_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(A_POTP_PES[aux]) #30
            MATRIZ_TOTAL_PES_lin.append(A_POTQ_PES[aux])
            #MATRIZ_TOTAL_PES_lin.append(A_BqV_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(infoVctrl) 
            MATRIZ_TOTAL_PES_lin.append(A_CONT_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(matriz_DadosBarra)
            #MATRIZ_TOTAL_PES_lin.append(A_BPQ_PES[aux]) 
            MATRIZ_TOTAL_PES_lin.append('TABELA 2B - PotGer - PESADO ANTES') #35
            MATRIZ_TOTAL_PES_lin.append(A_POTP_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(A_POTQ_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(infoVctrl) 
            MATRIZ_TOTAL_PES_lin.append(A_BqV_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(matriz_DadosBarra) #40 
            MATRIZ_TOTAL_PES_lin.append('FIM TABELAS')  
            MATRIZ_TOTAL_PES_lin.append(A_OBS_PES[aux]) 
            MATRIZ_TOTAL_PES_lin.append(A_CARREGAMENTO_PES)           
            MATRIZ_TOTAL_PES.append(MATRIZ_TOTAL_PES_lin) #44
            #MATRIZ_TOTAL_PES_lin=[]
        #MATRIZ_TOTAL
        #print('AQUI')
        
        MATRIZ_TOTAL_LEV=[]
        for aux in range(len(vetor_de_diferencas_LEV)):
            MATRIZ_TOTAL_LEV_lin=[]
            MATRIZ_TOTAL_LEV_lin.append(vetorTAG_LEV[aux])  #0
            MATRIZ_TOTAL_LEV_lin.append(PotP_Adicionada_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(vetor_BarrasAdicionadas_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(VetorPorcentagem_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(vetor_de_diferencas_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(Indicador_de_QUALIDADE_LEV[aux])  #5
            MATRIZ_TOTAL_LEV_lin.append(Quantidade_Violada_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(D_OBS_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(BarrasQjaViolavam_indicacaoDeQualidade_LEV[aux])            
            MATRIZ_TOTAL_LEV_lin.append('-------')
            MATRIZ_TOTAL_LEV_lin.append(vetor_BqV_LEV[aux])  #10
            MATRIZ_TOTAL_LEV_lin.append(D_CARREGAMENTO_LEV[aux])            
            #MATRIZ_TOTAL_LEV_lin.append(infoVctrl)  
            #MATRIZ_TOTAL_LEV_lin.append(matriz_DadosBarra)
            MATRIZ_TOTAL_LEV_lin.append('INICIO TABELAS') 
            MATRIZ_TOTAL_LEV_lin.append('TABELA 1A - Plot - LEVE DEPOIS')            
            MATRIZ_TOTAL_LEV_lin.append(D_TENSAO_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(D_ANGULO_LEV[aux])  #15
            MATRIZ_TOTAL_LEV_lin.append(D_POTP_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(D_POTQ_LEV[aux])
            #MATRIZ_TOTAL_LEV_lin.append(D_BqV_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(infoVctrl) 
            MATRIZ_TOTAL_LEV_lin.append(D_CONT_LEV[aux])   #19
            MATRIZ_TOTAL_LEV_lin.append(matriz_DadosBarra)
            #MATRIZ_TOTAL_LEV_lin.append(D_BPQ_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append('TABELA 1B - PotGER - LEVE DEPOIS')  
            MATRIZ_TOTAL_LEV_lin.append(D_POTP_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(D_POTQ_LEV[aux]) 
            MATRIZ_TOTAL_LEV_lin.append(infoVctrl)
            MATRIZ_TOTAL_LEV_lin.append(D_BPQ_LEV[aux]) #25
            MATRIZ_TOTAL_LEV_lin.append(matriz_DadosBarra)          
            MATRIZ_TOTAL_LEV_lin.append('TABELA 2A - Plot - LEVE ANTES')              
            MATRIZ_TOTAL_LEV_lin.append(A_TENSAO_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(A_ANGULO_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(A_POTP_LEV[aux]) #30
            MATRIZ_TOTAL_LEV_lin.append(A_POTQ_LEV[aux])
            #MATRIZ_TOTAL_LEV_lin.append(A_BqV_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(infoVctrl)
            MATRIZ_TOTAL_LEV_lin.append(A_CONT_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(matriz_DadosBarra)
            #MATRIZ_TOTAL_LEV_lin.append(A_BPQ_LEV[aux]) 
            MATRIZ_TOTAL_LEV_lin.append('TABELA 1B - PotGER - LEVE ANTES') #35  
            MATRIZ_TOTAL_LEV_lin.append(A_POTP_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(A_POTQ_LEV[aux]) 
            MATRIZ_TOTAL_LEV_lin.append(infoVctrl)
            MATRIZ_TOTAL_LEV_lin.append(A_BPQ_LEV[aux]) 
            MATRIZ_TOTAL_LEV_lin.append(matriz_DadosBarra) #40
            MATRIZ_TOTAL_LEV_lin.append('FIM TABELAS')  
            MATRIZ_TOTAL_LEV_lin.append(A_OBS_LEV[aux]) 
            MATRIZ_TOTAL_LEV_lin.append(A_CARREGAMENTO_LEV)              
            MATRIZ_TOTAL_LEV.append(MATRIZ_TOTAL_LEV_lin) #44
        
        conctVerificaSeViola0=''
        for aux_aux_aux in range(len(VerificaSeViola_0)):
            if VerificaSeViola_0[aux_aux_aux]=='ViolaPC' or VerificaSeViola_0[aux_aux_aux]=='ViolaPB':
                if conctVerificaSeViola0=='':
                    conctVerificaSeViola0=VerificaSeViola_0[aux_aux_aux]
                else:
                    conctVerificaSeViola0=conctVerificaSeViola0+'_'+VerificaSeViola_0[aux_aux_aux]

        MATRIZ_TOTAL_INICIAL=[]
        MATRIZ_TOTAL_INICIAL.append(DeltaV_0)
        MATRIZ_TOTAL_INICIAL.append(Delta0_0)
        MATRIZ_TOTAL_INICIAL.append(PotP_0)
        MATRIZ_TOTAL_INICIAL.append(PotQ_0)        
        MATRIZ_TOTAL_INICIAL.append(BarraQViola_estatica_0)
        MATRIZ_TOTAL_INICIAL.append(cont_0)
        MATRIZ_TOTAL_INICIAL.append(Barras_PQ_0)
        MATRIZ_TOTAL_INICIAL.append(infoVctrl)
        MATRIZ_TOTAL_INICIAL.append(matriz_DadosBarra)
        MATRIZ_TOTAL_INICIAL.append(ATIVA_ESPEC0)
        MATRIZ_TOTAL_INICIAL.append(conctVerificaSeViola0)

    
        #print('aqui')

    elif tipo_de_ESTUDO=='Todo Espaco Amostral':
        D_CARREGAMENTO_PES=[list(arr) for arr in D_MatrizT5_pes_carregamento]
        A_CARREGAMENTO_PES=[list(arr) for arr in A_matrizT5_pes_carregamento]
        for auxiliar in range(len(D_CARREGAMENTO_PES)):
            D_CARREGAMENTO_PES[auxiliar]=[float(x) for x in D_CARREGAMENTO_PES[auxiliar]]
        for auxiliar in range(len(A_CARREGAMENTO_PES)):
            A_CARREGAMENTO_PES[auxiliar]=[float(x) for x in A_CARREGAMENTO_PES[auxiliar]]

        D_CARREGAMENTO_LEV=[list(arr) for arr in D_MatrizT6_lev_carregamento]
        A_CARREGAMENTO_LEV=[list(arr) for arr in A_matrizT6_lev_carregamento]
        for auxiliar in range(len(D_CARREGAMENTO_LEV)):
            D_CARREGAMENTO_LEV[auxiliar]=[float(x) for x in D_CARREGAMENTO_LEV[auxiliar]] 
        for auxiliar in range(len(A_CARREGAMENTO_LEV)):
            A_CARREGAMENTO_LEV[auxiliar]=[float(x) for x in A_CARREGAMENTO_LEV[auxiliar]]  

        
        D_TENSAO_PES=D_MatrizT5_pes_TENSAO
        A_TENSAO_PES=A_matrizT5_pes_TENSAO
        D_POTP_PES=D_MatrizT5_pes_POTP
        A_POTP_PES=A_matrizT5_pes_POTP      
        D_POTQ_PES=D_MatrizT5_pes_POTQ
        A_POTQ_PES=A_matrizT5_pes_POTQ
        D_BqV_PES=D_MatrizT5_pes_BqV
        A_BqV_PES=A_matrizT5_pes_BqV
        D_ANGULO_PES=D_MatrizT5_pes_ANGULO
        A_ANGULO_PES=A_matrizT5_pes_ANGULO      
        D_BPQ_PES=D_MatrizT5_pes_BPQ
        A_BPQ_PES=A_matrizT5_pes_BPQ 
        D_CONT_PES=D_MatrizT5_pes_CONT
        A_CONT_PES=A_matrizT5_pes_CONT 
        D_OBS_PES=D_MatrizT5_pes_OBS
        A_OBS_PES=A_matrizT5_pes_OBS                  
        
        D_TENSAO_LEV=D_MatrizT6_lev_TENSAO
        A_TENSAO_LEV=A_matrizT6_lev_TENSAO
        D_POTP_LEV=D_MatrizT6_lev_POTP
        A_POTP_LEV=A_matrizT6_lev_POTP       
        D_POTQ_LEV=D_MatrizT6_lev_POTQ
        A_POTQ_LEV=A_matrizT6_lev_POTQ
        D_BqV_LEV=D_MatrizT6_lev_BqV
        A_BqV_LEV=A_matrizT6_lev_BqV
        D_ANGULO_LEV=D_MatrizT6_lev_ANGULO
        A_ANGULO_LEV=A_matrizT6_lev_ANGULO       
        D_BPQ_LEV=D_MatrizT6_lev_BPQ
        A_BPQ_LEV=A_matrizT6_lev_BPQ
        D_CONT_LEV=D_MatrizT6_lev_CONT
        A_CONT_LEV=A_matrizT6_lev_CONT
        D_OBS_LEV=D_MatrizT6_lev_OBS
        A_OBS_LEV=A_matrizT6_lev_OBS        
       
        
        for auxiliar in range(len(D_MatrizT5_pes_TENSAO)):
            D_TENSAO_PES[auxiliar]=[float(x) for x in D_MatrizT5_pes_TENSAO[auxiliar]]
        for auxiliar in range(len(D_MatrizT5_pes_ANGULO)):
            D_ANGULO_PES[auxiliar]=[float(x) for x in D_MatrizT5_pes_ANGULO[auxiliar]]
        for auxiliar in range(len(D_MatrizT5_pes_POTP)):
            D_POTP_PES[auxiliar]=[float(x) for x in D_MatrizT5_pes_POTP[auxiliar]]
        for auxiliar in range(len(D_MatrizT5_pes_POTQ)):
            D_POTQ_PES[auxiliar]=[float(x) for x in D_MatrizT5_pes_POTQ[auxiliar]]

        for auxiliar in range(len(A_matrizT5_pes_TENSAO)):
            A_TENSAO_PES[auxiliar]=[float(x) for x in A_matrizT5_pes_TENSAO[auxiliar]]
        for auxiliar in range(len(A_matrizT5_pes_ANGULO)):
            A_ANGULO_PES[auxiliar]=[float(x) for x in A_matrizT5_pes_ANGULO[auxiliar]]
        for auxiliar in range(len(A_matrizT5_pes_POTP)):
            A_POTP_PES[auxiliar]=[float(x) for x in A_matrizT5_pes_POTP[auxiliar]]
        for auxiliar in range(len(A_matrizT5_pes_POTQ)):
            A_POTQ_PES[auxiliar]=[float(x) for x in A_matrizT5_pes_POTQ[auxiliar]]


        for auxiliar in range(len(D_MatrizT6_lev_TENSAO)):
            D_TENSAO_LEV[auxiliar]=[float(x) for x in D_MatrizT6_lev_TENSAO[auxiliar]]
        for auxiliar in range(len(D_MatrizT6_lev_ANGULO)):
            D_ANGULO_LEV[auxiliar]=[float(x) for x in D_MatrizT6_lev_ANGULO[auxiliar]]
        for auxiliar in range(len(D_MatrizT6_lev_POTP)):
            D_POTP_LEV[auxiliar]=[float(x) for x in D_MatrizT6_lev_POTP[auxiliar]]
        for auxiliar in range(len(D_MatrizT6_lev_POTQ)):
            D_POTQ_LEV[auxiliar]=[float(x) for x in D_MatrizT6_lev_POTQ[auxiliar]]

        for auxiliar in range(len(A_matrizT6_lev_TENSAO)):
            A_TENSAO_LEV[auxiliar]=[float(x) for x in A_matrizT6_lev_TENSAO[auxiliar]]
        for auxiliar in range(len(A_matrizT6_lev_ANGULO)):
            A_ANGULO_LEV[auxiliar]=[float(x) for x in A_matrizT6_lev_ANGULO[auxiliar]]
        for auxiliar in range(len(A_matrizT6_lev_POTP)):
            A_POTP_LEV[auxiliar]=[float(x) for x in A_matrizT6_lev_POTP[auxiliar]]
        for auxiliar in range(len(A_matrizT6_lev_POTQ)):
            A_POTQ_LEV[auxiliar]=[float(x) for x in A_matrizT6_lev_POTQ[auxiliar]]



        result_PES = comparar_carregamento(D_CARREGAMENTO_PES, ATIVA_ESPEC)
        # Exibindo os resultados
        (
            D_CARREGAMENTO_PES_val,
            D_CARREGAMENTO_PES_pos,
            vetor_BarrasAdicionadas_PES,
            PotP_Adicionada_PES,
            MatrizPorcentagem_PES,
            VetorPorcentagem_PES,
        ) = result_PES
        vetor_BqV_PES = analisa_BqV(D_BqV_PES)
        vetorTAG_PES = geraTAG(D_CARREGAMENTO_PES_pos, PVbarIndex)
        # quantidadeViolada_0, _ , vetor_de_diferencas_PES, Indicador_de_QUALIDADE_PES, Quantidade_Violada_PES = analisadora_DeResultados(
        #     BarraQViola_estatica_0, PVbarIndex, D_BqV_PES, D_TENSAO_PES, A_TENSAO_PES, BarraQViola_estatica_00
        # )  
        quantidadeViolada_0 , _ , vetor_de_diferencas_PES, Indicador_de_QUALIDADE_PES, Quantidade_Violada_PES=analisadora_DeResultados_POSTUMAS02(D_TENSAO_PES, A_TENSAO_PES, DeltaV_0, infoVctrl[1])

        result_LEV = comparar_carregamento(D_CARREGAMENTO_LEV, ATIVA_ESPEC)
        # Exibindo os resultados
        (
            _ ,
            D_CARREGAMENTO_LEV_pos,
            vetor_BarrasAdicionadas_LEV,
            PotP_Adicionada_LEV,
            _ ,
            VetorPorcentagem_LEV,
        ) = result_LEV
        vetor_BqV_LEV = analisa_BqV(D_BqV_LEV)
        vetorTAG_LEV = geraTAG(D_CARREGAMENTO_LEV_pos, PVbarIndex)
        # _ , _ , vetor_de_diferencas_LEV, Indicador_de_QUALIDADE_LEV, Quantidade_Violada_LEV = analisadora_DeResultados(
        #     BarraQViola_estatica_0, PVbarIndex, D_BqV_LEV, D_TENSAO_LEV, A_TENSAO_LEV, BarraQViola_estatica_00
        # )
        quantidadeViolada_0 , _ , vetor_de_diferencas_LEV, Indicador_de_QUALIDADE_LEV, Quantidade_Violada_LEV=analisadora_DeResultados_POSTUMAS02(D_TENSAO_LEV, A_TENSAO_LEV, DeltaV_0, infoVctrl[1])

        BarraQViola_estatica_0_STRG = incrementar_BarraQViola(BarraQViola_estatica_0)

        
        BarrasQjaViolavam_indicacaoDeQualidade_LEV=[]
        BarrasQjaViolavam_indicacaoDeQualidade_PES=[]

        for aux in range(len(D_TENSAO_LEV)):
            _, _, _, _, _, stringvetTAGBqVrestante  = analisadora_DeResultados_POSTUMAS_01(BarraQViola_estatica_0, D_TENSAO_LEV[aux], DeltaV_0, infoVctrl[1], tolApresent)
            #vetor_Acomparar, vetor_ref, vetor_SAF, vetor_SAP, vetTAGBqVrestante, stringvetTAGBqVrestante  = analisadora_DeResultados_POSTUMAS_01(BarraQViola_estatica_0, D_TENSAO_LEV_aux, DeltaV_0, infoVcontrol, tolApresent)
            BarrasQjaViolavam_indicacaoDeQualidade_LEV.append(stringvetTAGBqVrestante)
        for aux in range(len(D_TENSAO_PES)):
            _, _, _, _, _, stringvetTAGBqVrestante  = analisadora_DeResultados_POSTUMAS_01(BarraQViola_estatica_0, D_TENSAO_PES[aux], DeltaV_0, infoVctrl[1], tolApresent)
            #vetor_Acomparar, vetor_ref, vetor_SAF, vetor_SAP, vetTAGBqVrestante, stringvetTAGBqVrestante  = analisadora_DeResultados_POSTUMAS_01(BarraQViola_estatica_0, D_TENSAO_LEV_aux, DeltaV_0, infoVcontrol, tolApresent)
            BarrasQjaViolavam_indicacaoDeQualidade_PES.append(stringvetTAGBqVrestante) 


        # print('\n\n')
        # print('---------------------------------------------------------------')
        # print("Quantidade Violada_0:", quantidadeViolada_0)
        # print("Barra Violada_0:", BarraQViola_estatica_0_STRG)
        # print('---------------------------------------------------------------')
        # print('\n')
       
        # print('RESULTADO REGIME CARGA PESADA:')        
        # print('vetorTAG_PES=', vetorTAG_PES[:20])
        # print("PotP_Adicionada_PES=", PotP_Adicionada_PES[:20])
        # print("vetor_BqV_PES=", vetor_BqV_PES[:20])
        # print("vetor_BarrasAdicionadas_PES=", vetor_BarrasAdicionadas_PES[:20])
        # print("VetorPorcentagem_PES=", VetorPorcentagem_PES[:20])

        # #print("Matriz de Diferenças:", matriz_de_diferencas)
        # print("Vetor de Diferenças_PES:", vetor_de_diferencas_PES)
        # print("Indicador_de_QUALIDADE_PES:", Indicador_de_QUALIDADE_PES)
        # print('Quantidade_Violada_PES:',Quantidade_Violada_PES)

        # print('\n')
        # print('RESULTADO REGIME CARGA LEVE:')
        # print('vetorTAG_LEV=', vetorTAG_LEV[:20])
        # print("PotP_Adicionada_LEV=", PotP_Adicionada_LEV[:20])
        # print("vetor_BqV_LEV=", vetor_BqV_LEV[:20])
        # print("vetor_BarrasAdicionadas_LEV=", vetor_BarrasAdicionadas_LEV[:20])
        # print("VetorPorcentagem_LEV=", VetorPorcentagem_LEV[:20])
        # #print('aqui')

        # #print("Matriz de Diferenças:", matriz_de_diferencas)
        # print("Vetor de Diferenças_LEV:", vetor_de_diferencas_LEV)
        # print("Indicador_de_QUALIDADE_LEV:", Indicador_de_QUALIDADE_LEV)
        # print('Quantidade_Violada_LEV:',Quantidade_Violada_LEV)
        # print('\n\n')


        # print("D_CARREGAMENTO_PES_val:", D_CARREGAMENTO_PES_val)
        # print("D_CARREGAMENTO_PES_pos:", D_CARREGAMENTO_PES_pos)
        # print("vetor_BarrasAdicionadas_PES:", vetor_BarrasAdicionadas_PES)
        # print("PotP_Adicionada_PES:", PotP_Adicionada_PES)
        # print("MatrizPorcentagem_PES:", MatrizPorcentagem_PES)
        # print("VetorPorcentagem_PES:", VetorPorcentagem_PES)
        MATRIZ_TOTAL_PES=[]
        for aux in range(len(vetor_de_diferencas_PES)):
            MATRIZ_TOTAL_PES_lin=[]
            MATRIZ_TOTAL_PES_lin.append(vetorTAG_PES[aux]) #0
            MATRIZ_TOTAL_PES_lin.append(PotP_Adicionada_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(vetor_BarrasAdicionadas_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(VetorPorcentagem_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(vetor_de_diferencas_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(Indicador_de_QUALIDADE_PES[aux]) #5
            MATRIZ_TOTAL_PES_lin.append(Quantidade_Violada_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(D_OBS_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(BarrasQjaViolavam_indicacaoDeQualidade_PES[aux])
            MATRIZ_TOTAL_PES_lin.append('-------')
            MATRIZ_TOTAL_PES_lin.append(vetor_BqV_PES[aux]) #10
            MATRIZ_TOTAL_PES_lin.append(D_CARREGAMENTO_PES[aux])
            #MATRIZ_TOTAL_PES_lin.append(infoVctrl)  
            #MATRIZ_TOTAL_PES_lin.append(matriz_DadosBarra)
            MATRIZ_TOTAL_PES_lin.append('INICIO TABELAS')            
            MATRIZ_TOTAL_PES_lin.append('TABELA 1A - Plot - PESADO DEPOIS')             
            MATRIZ_TOTAL_PES_lin.append(D_TENSAO_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(D_ANGULO_PES[aux]) #15
            MATRIZ_TOTAL_PES_lin.append(D_POTP_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(D_POTQ_PES[aux])
            #MATRIZ_TOTAL_PES_lin.append(D_BqV_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(infoVctrl) 
            MATRIZ_TOTAL_PES_lin.append(D_CONT_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(matriz_DadosBarra) #20
            #MATRIZ_TOTAL_PES_lin.append(D_BPQ_PES[aux])
            MATRIZ_TOTAL_PES_lin.append('TABELA 1B - PotGer - PESADO DEPOIS') 
            MATRIZ_TOTAL_PES_lin.append(D_POTP_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(D_POTQ_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(infoVctrl) 
            MATRIZ_TOTAL_PES_lin.append(D_BqV_PES[aux]) #25
            MATRIZ_TOTAL_PES_lin.append(matriz_DadosBarra)                       
            MATRIZ_TOTAL_PES_lin.append('TABELA 2A - Plot - PESADO ANTES')             
            MATRIZ_TOTAL_PES_lin.append(A_TENSAO_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(A_ANGULO_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(A_POTP_PES[aux]) #30
            MATRIZ_TOTAL_PES_lin.append(A_POTQ_PES[aux])
            #MATRIZ_TOTAL_PES_lin.append(A_BqV_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(infoVctrl) 
            MATRIZ_TOTAL_PES_lin.append(A_CONT_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(matriz_DadosBarra)
            #MATRIZ_TOTAL_PES_lin.append(A_BPQ_PES[aux]) 
            MATRIZ_TOTAL_PES_lin.append('TABELA 2B - PotGer - PESADO ANTES') #35
            MATRIZ_TOTAL_PES_lin.append(A_POTP_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(A_POTQ_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(infoVctrl) 
            MATRIZ_TOTAL_PES_lin.append(A_BqV_PES[aux])
            MATRIZ_TOTAL_PES_lin.append(matriz_DadosBarra) #40
            MATRIZ_TOTAL_PES_lin.append('FIM TABELAS') 
            MATRIZ_TOTAL_PES_lin.append(A_OBS_PES[aux]) 
            MATRIZ_TOTAL_PES_lin.append(A_CARREGAMENTO_PES)                         
            MATRIZ_TOTAL_PES.append(MATRIZ_TOTAL_PES_lin) #44
            #MATRIZ_TOTAL_PES_lin=[]
        #MATRIZ_TOTAL
        #print('AQUI')
        
        MATRIZ_TOTAL_LEV=[]
        for aux in range(len(vetor_de_diferencas_LEV)):
            MATRIZ_TOTAL_LEV_lin=[]
            MATRIZ_TOTAL_LEV_lin.append(vetorTAG_LEV[aux])    #0
            MATRIZ_TOTAL_LEV_lin.append(PotP_Adicionada_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(vetor_BarrasAdicionadas_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(VetorPorcentagem_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(vetor_de_diferencas_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(Indicador_de_QUALIDADE_LEV[aux]) #5
            MATRIZ_TOTAL_LEV_lin.append(Quantidade_Violada_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(D_OBS_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(BarrasQjaViolavam_indicacaoDeQualidade_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append('-------')            
            MATRIZ_TOTAL_LEV_lin.append(vetor_BqV_LEV[aux]) #10
            MATRIZ_TOTAL_LEV_lin.append(D_CARREGAMENTO_LEV[aux])            
            #MATRIZ_TOTAL_LEV_lin.append(infoVctrl)  
            #MATRIZ_TOTAL_LEV_lin.append(matriz_DadosBarra)
            MATRIZ_TOTAL_LEV_lin.append('INICIO TABELAS') 
            MATRIZ_TOTAL_LEV_lin.append('TABELA 1A - Plot - LEVE DEPOIS')            
            MATRIZ_TOTAL_LEV_lin.append(D_TENSAO_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(D_ANGULO_LEV[aux]) #15
            MATRIZ_TOTAL_LEV_lin.append(D_POTP_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(D_POTQ_LEV[aux])
            #MATRIZ_TOTAL_LEV_lin.append(D_BqV_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(infoVctrl) 
            MATRIZ_TOTAL_LEV_lin.append(D_CONT_LEV[aux]) #19
            MATRIZ_TOTAL_LEV_lin.append(matriz_DadosBarra)
            #MATRIZ_TOTAL_LEV_lin.append(D_BPQ_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append('TABELA 1B - PotGER - LEVE DEPOIS')  
            MATRIZ_TOTAL_LEV_lin.append(D_POTP_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(D_POTQ_LEV[aux]) 
            MATRIZ_TOTAL_LEV_lin.append(infoVctrl)
            MATRIZ_TOTAL_LEV_lin.append(D_BPQ_LEV[aux]) #25 
            MATRIZ_TOTAL_LEV_lin.append(matriz_DadosBarra)         
            MATRIZ_TOTAL_LEV_lin.append('TABELA 2A - Plot - LEVE ANTES')              
            MATRIZ_TOTAL_LEV_lin.append(A_TENSAO_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(A_ANGULO_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(A_POTP_LEV[aux]) #30
            MATRIZ_TOTAL_LEV_lin.append(A_POTQ_LEV[aux])
            #MATRIZ_TOTAL_LEV_lin.append(A_BqV_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(infoVctrl)
            MATRIZ_TOTAL_LEV_lin.append(A_CONT_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(matriz_DadosBarra)
            #MATRIZ_TOTAL_LEV_lin.append(A_BPQ_LEV[aux]) 
            MATRIZ_TOTAL_LEV_lin.append('TABELA 1B - PotGER - LEVE ANTES')  #35
            MATRIZ_TOTAL_LEV_lin.append(A_POTP_LEV[aux])
            MATRIZ_TOTAL_LEV_lin.append(A_POTQ_LEV[aux]) 
            MATRIZ_TOTAL_LEV_lin.append(infoVctrl)
            MATRIZ_TOTAL_LEV_lin.append(A_BPQ_LEV[aux]) 
            MATRIZ_TOTAL_LEV_lin.append(matriz_DadosBarra) #40
            MATRIZ_TOTAL_LEV_lin.append('FIM TABELAS')
            MATRIZ_TOTAL_LEV_lin.append(A_OBS_LEV[aux]) 
            MATRIZ_TOTAL_LEV_lin.append(A_CARREGAMENTO_LEV)        
            MATRIZ_TOTAL_LEV.append(MATRIZ_TOTAL_LEV_lin) #44
        
        conctVerificaSeViola0=''
        for aux_aux_aux in range(len(VerificaSeViola_0)):
            if VerificaSeViola_0[aux_aux_aux]=='ViolaPC' or VerificaSeViola_0[aux_aux_aux]=='ViolaPB':
                if conctVerificaSeViola0=='':
                    conctVerificaSeViola0=VerificaSeViola_0[aux_aux_aux]
                else:
                    conctVerificaSeViola0=conctVerificaSeViola0+'_'+VerificaSeViola_0[aux_aux_aux]


        MATRIZ_TOTAL_INICIAL=[]
        MATRIZ_TOTAL_INICIAL.append(DeltaV_0)
        MATRIZ_TOTAL_INICIAL.append(Delta0_0)
        MATRIZ_TOTAL_INICIAL.append(PotP_0)
        MATRIZ_TOTAL_INICIAL.append(PotQ_0)        
        MATRIZ_TOTAL_INICIAL.append(BarraQViola_estatica_0)
        MATRIZ_TOTAL_INICIAL.append(cont_0)
        MATRIZ_TOTAL_INICIAL.append(Barras_PQ_0)
        MATRIZ_TOTAL_INICIAL.append(infoVctrl)
        MATRIZ_TOTAL_INICIAL.append(matriz_DadosBarra)
        MATRIZ_TOTAL_INICIAL.append(ATIVA_ESPEC0)
        MATRIZ_TOTAL_INICIAL.append(conctVerificaSeViola0)


    time = datetime.now()
    #time_date = datetime.fromtimestamp(time)
    parametro_de_verificacao.append([time.strftime("%H:%M:%S"),' PREPARANDO PARA PLOTAGEM GRÁFICA '])
    print([time.strftime("%H:%M:%S"),' PLOTAGEM ']) 

    FILTRO_out_LEV=[]
    FILTRO_out_PES=[]
    if MATRIZ_TOTAL_LEV!=[]:
        FILTRO_out_LEV=FiltroParaFIGType2(MATRIZ_TOTAL_LEV, S_base, filtrarDivergente)

    if MATRIZ_TOTAL_PES!=[]:
        FILTRO_out_PES=FiltroParaFIGType2(MATRIZ_TOTAL_PES, S_base, filtrarDivergente)

    ##POEMtodomundoJUNTO
    #if MATRIZ_TOTAL_LEV!=[] and MATRIZ_TOTAL_PES!=[]:
    FILTRO_out=POEMtodomundoJUNTO(FILTRO_out_LEV, FILTRO_out_PES)


    A_TENSAO_PES_de_diferencas=FILTRO_out[0]
    D_TENSAO_PES_de_diferencas=FILTRO_out[1]
    A_CARGA_PES_de_diferencas= FILTRO_out[2]
    D_CARGA_PES_de_diferencas=FILTRO_out[3]
    CENARIO_PES=FILTRO_out[4]
    CENARIO_PESantes=FILTRO_out[5]
    forfutureFilter_PES=FILTRO_out[6]
    vet_grupo_PES=FILTRO_out[7]
    pontos_fatorDePotencia_PES=FILTRO_out[8] 
    pontos_fatorDePotencia_PES_dep=FILTRO_out[9] 

    #print('pontos_fatorDePotencia_PES_dep=',pontos_fatorDePotencia_PES_dep)

    # Nome do arquivo (gerado por sua função, aqui exemplo)
    save_dir= os.path.join(os.getcwd(), "plot", "GenOfCases", "pfCurve", Diret_forPfCrv)
    tag = create_unique_tag2(save_dir, len(MATRIZ_TOTAL_INICIAL[0])) 
    #save_pontos_fatorDePotencia(pontos_fatorDePotencia_PES, tag, save_dir)
    #save_pontos_fatorDePotencia_total(pontos_fatorDePotencia_PES, pontos_fatorDePotencia_PES_dep, tag, save_dir)
    LEG_P_FIG_FP=[pontos_fatorDePotencia_PES, pontos_fatorDePotencia_PES_dep, tag, save_dir, forfutureFilter_PES]


    (CARG_0vet, TENSAO_0, CENARIO_BASE)=definirLegendFIGType2(vet_grupo_PES, MATRIZ_TOTAL_INICIAL, S_base)
    analysis_results = analizerResults03(CENARIO_PESantes, CENARIO_BASE)


    # =============================================================================
    # CONSTRUÇÃO DO GRÁFICO (DESCOMENTE O BLOCO INTEIRO)
    # =============================================================================
    # =============================================================================
    """# =============================================================================
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.set_xlabel('Potência das Cargas (p.u.)')
    ax.set_ylabel('Tensão (p.u.)')
    ax.set_title('Pontos "Antes" e "Depois" com Linha Degradê por Grupo (sem normalização)')
    ax.grid(True)

    # Dicionário de cores (conforme fornecido)
    color_pairs = [
        ('green', 'red'),
        ('blue', 'orange'),
        ('purple', 'yellow'),
        ('cyan', 'magenta'),
        ('yellow', 'green'),
        ('purple', 'red'),
    ]
    unique_groups = np.unique(vet_grupo)

    # Cria o dicionário que associa cada grupo a um par de cores
    group_color_map = {}
    for i, grupo in enumerate(unique_groups):
        group_color_map[grupo] = color_pairs[i % len(color_pairs)]

    num_interp = 100  # Número de pontos para interpolação (linha suave)

    # =============================================================================
    # Plotagem dos pontos e das linhas de degradê
    # =============================================================================
    # Aqui, os pontos "Antes" são plotados com os dados originais A_CARGA_PES_de_diferencas e A_TENSAO_PES_de_diferencas,
    # e os pontos "Depois" com D_CARGA_PES_de_diferencas e D_TENSAO_PES_de_diferencas.
    # (Você está utilizando estas variáveis conforme seu código original.)
    scatter_objs_antes = []  # Vamos armazenar apenas os scatter dos pontos "Antes" para os tooltips
    tooltip_texts_all = []   # Textos dos tooltips para os pontos "Antes"

    for grupo in unique_groups:
        before_color, after_color = group_color_map[grupo]
        group_cmap = LinearSegmentedColormap.from_list(f'grupo_{grupo}_cmap', [before_color, after_color])
        
        # Índices dos pontos do grupo
        indices_group = np.where(np.array(vet_grupo) == grupo)[0]
        
        # Seleciona os dados dos pontos "Antes" e "Depois"
        A_carga_group = np.array(A_CARGA_PES_de_diferencas)[indices_group]
        A_tensao_group = np.array(A_TENSAO_PES_de_diferencas)[indices_group]
        D_carga_group = np.array(D_CARGA_PES_de_diferencas)[indices_group]
        D_tensao_group = np.array(D_TENSAO_PES_de_diferencas)[indices_group]
        
        # Plota os pontos "Antes" (com tooltips) e os pontos "Depois" (sem tooltips)
        sc_antes = ax.scatter(A_carga_group, A_tensao_group, color=before_color, s=100, label=f'Grupo {grupo} - Antes')
        ax.scatter(D_carga_group, D_tensao_group, color=after_color, s=100, label=f'Grupo {grupo} - Depois')
        
        scatter_objs_antes.append(sc_antes)
        
        # Prepara os textos dos tooltips para os pontos "Antes" utilizando analysis_results
        texts = []
        for idx in indices_group:
            changed_idxs, percents = analysis_results[idx]
            if changed_idxs:
                t = f"Índices alterados: {changed_idxs}\nVariação (%): " + ", ".join(f"{p:.2f}%" for p in percents)
            else:
                t = "Sem alteração"
            texts.append(t)
        tooltip_texts_all.append(texts)
        
        # Desenha a linha de degradê conectando cada par de pontos "Antes" e "Depois"
        for i in indices_group:
            x0, y0 = A_CARGA_PES_de_diferencas[i], A_TENSAO_PES_de_diferencas[i]
            x1, y1 = D_CARGA_PES_de_diferencas[i], D_TENSAO_PES_de_diferencas[i]
            x_vals = np.linspace(x0, x1, num=num_interp)
            y_vals = np.linspace(y0, y1, num=num_interp)
            points = np.array([x_vals, y_vals]).T.reshape(-1, 1, 2)
            segments = np.concatenate([points[:-1], points[1:]], axis=1)
            colors_segment = [group_cmap(t) for t in np.linspace(0, 1, len(segments))]
            lc = LineCollection(segments, colors=colors_segment, linewidth=2)
            ax.add_collection(lc)

    # =============================================================================
    # Configura os tooltips apenas para os pontos "Antes"
    # =============================================================================
    for sc, texts in zip(scatter_objs_antes, tooltip_texts_all):
        cursor = mplcursors.cursor(sc, hover=True)
        @cursor.connect("add")
        def on_add(sel, texts=texts):
            ind = sel.index
            sel.annotation.set_text(texts[ind])
            sel.annotation.get_bbox_patch().set(alpha=0.8, fc="white")

    # Ponto inicial (estrelinha preta)
    ax.scatter(CARG_0vet, TENSAO_0, color='black', marker='*', s=150, label='(INICIAL)')

    ax.legend()
    plt.show() """
    
    PACOTE_OUT_FIGtype2=[]
    PACOTE_OUT_FIGtype2.append(A_CARGA_PES_de_diferencas)
    PACOTE_OUT_FIGtype2.append(A_TENSAO_PES_de_diferencas)
    PACOTE_OUT_FIGtype2.append(D_CARGA_PES_de_diferencas)
    PACOTE_OUT_FIGtype2.append(D_TENSAO_PES_de_diferencas)
    PACOTE_OUT_FIGtype2.append(analysis_results)
    PACOTE_OUT_FIGtype2.append(vet_grupo_PES)
    PACOTE_OUT_FIGtype2.append(CARG_0vet)
    PACOTE_OUT_FIGtype2.append(TENSAO_0)
    PACOTE_OUT_FIGtype2.append(CENARIO_BASE)
    PACOTE_OUT_FIGtype2.append(FILTRO_out)
    PACOTE_OUT_FIGtype2.append(FILTRO_out_LEV)
    PACOTE_OUT_FIGtype2.append(FILTRO_out_PES)

    return(MATRIZ_TOTAL_PES, MATRIZ_TOTAL_LEV, BarraQViola_estatica_0_STRG, quantidadeViolada_0, MATRIZ_TOTAL_INICIAL, PACOTE_OUT_FIGtype2, LEG_P_FIG_FP)
