import os
import sys
import tkinter as tk
from tkinter import messagebox

BIBLIOTECAS_REQUERIDAS = [
    "tkinter", "threading", "os", "numpy", "matplotlib", "sys", "datetime"
]

# Bibliotecas realmente externas ao Python puro
BIBLIOTECAS_EXTERNAS = [
    "numpy", "matplotlib", "mplcursors", "statsmodels", "chardet"
]

def verificar_bibliotecas():
    faltando = []
    for lib in BIBLIOTECAS_EXTERNAS:
        try:
            __import__(lib)
        except ImportError:
            faltando.append(lib)

    if faltando:
        root = tk.Tk()
        root.withdraw()  # Esconde a janela principal
        msg = "As seguintes bibliotecas estão faltando:\n\n" + "\n".join(faltando)
        msg += "\n\nInstale-as usando o comando:\n\npip install " + " ".join(faltando)
        messagebox.showerror("Erro - Bibliotecas ausentes", msg)
        sys.exit(1)


def verificar_e_criar_pastas():
    pastas_necessarias = [
        os.path.join("plot", "GenOfCases"),
        os.path.join("plot", "cdfsGerados", "G_TELA2")
    ]
    for pasta in pastas_necessarias:
        os.makedirs(pasta, exist_ok=True)
