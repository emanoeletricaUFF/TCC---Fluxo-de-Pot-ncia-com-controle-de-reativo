import numpy as np
import matplotlib.pyplot as plt
import numpy as np
import os
import mplcursors
import glob
import csv
import ast
import sys
from matplotlib.widgets import TextBox, Button
import matplotlib.gridspec as gridspec
import time
from scipy.interpolate import interp1d
import unicodedata

from G_FUNCAO_A import Ler_Arquivo, CHAMA_FLNR_03_LTT, DefineMatrizDadosBarra
from G_FUNCAO_A import corrige_duplicidadeDeLinha
from G_FUNCAO_A import extrair_potencias_negativas
from G_FUNCAO_A import extrair_vetores_da_matrizSystem
from G_FUNCAO_A import liga_desliga_CS, processar_matrizes
from G_FUNCAO_A import alterar_matrizes, calcularMATRIZ_Y
from G_FUNCAO_A import saveAbnormalPoints, saveDivergencies
from G_FUNCAO_A import create_unique_tag2, ceifar_matriz_vetor, interpret_choose_bar
from G_TERMINAL import terminal_buffer



def ler_diretorio_plot3(selecionarE3):
    """
    Varre o diretório 'plot/GoPVcurve' para identificar os arquivos CSV,
    extrai os parâmetros do cabeçalho de cada arquivo e os armazena na lista
    estudosE3_param. Em seguida, imprime os nomes dos arquivos e um resumo dos
    seus parâmetros.
    
    Parâmetro:
      selecionarE3 (int): Índice (base 1) do arquivo a ser selecionado.
      
    Retorna:
      total_arquivos (int): Quantidade de arquivos CSV encontrados.
      nameChoosed (str ou None): Nome do arquivo selecionado, se válido; caso
                                 contrário, None.
      estudosE3_param (list): Lista de dicionários com os parâmetros de cada arquivo.
    """
    # Define o diretório onde estão os arquivos CSV
    base_dir = os.path.join(os.getcwd(), "plot", "GenOfCurvs")
    pattern = os.path.join(base_dir, "*.csv")
    file_list = sorted(glob.glob(pattern))
    
    estudosE3_param = []  # Lista para armazenar os parâmetros de cada estudo
    arquivos_info = []    # Lista de tuplas (arquivo, parâmetros) para exibição

    # Função auxiliar para extrair os parâmetros do cabeçalho do arquivo
    def extrair_parametros(filepath):
        parametros = {}
        with open(filepath, mode='r', encoding='latin-1') as file:
            lines = file.readlines()
        
        # Procura a linha que contém "''' ESPECIFICAÇÃO '''" e, a partir dela,
        # lê as linhas seguintes até encontrar uma linha vazia ou uma que inicie com "EvolutionMatrixMatriz2[0]"
        inicio = False
        for line in lines:
            stripped = line.strip()
            if stripped == "''' ESPECIFICAÇÃO '''":
                inicio = True
                continue
            if inicio:
                # Se a linha estiver vazia ou indicar o início dos dados, encerra a leitura dos parâmetros
                if stripped == "" or stripped.startswith("EvolutionMatrixMatriz2[0]"):
                    break
                # Se houver o sinal de igualdade, processa como parâmetro
                if "=" in stripped:
                    try:
                        key, val = stripped.split("=", 1)
                        key = key.strip()
                        val = val.strip()
                        # Tenta interpretar o valor com ast.literal_eval para definir o tipo
                        try:
                            parametros[key] = ast.literal_eval(val)
                        except Exception:
                            parametros[key] = val
                    except Exception as e:
                        print(f"Erro processando a linha '{stripped}': {e}")
        return parametros

    # Varre os arquivos encontrados e extrai os parâmetros
    for arquivo in file_list:
        params = extrair_parametros(arquivo)
        estudosE3_param.append(params)
        arquivos_info.append((os.path.basename(arquivo), params))
    
    total_arquivos = len(file_list)
    
    # Exibe os arquivos encontrados e seus parâmetros (resumindo em poucas linhas)
    #print("Arquivos encontrados:")
    if total_arquivos == 0:
        print("\nNenhum arquivo CSV encontrado em 'plot/GenOfCurvs'.")
    else:
        print("CURVAS PxV ENCONTRADOS NO DIRETÓRIO (Plt3 - 'plot/GenOfCurvs'):")
        for idx, (nome, params) in enumerate(arquivos_info, start=1):
            # Cria uma string resumo com os parâmetros principais (pode ser adaptado conforme necessário)
            # Aqui, mostramos por exemplo SYSname, MODELin e Tolerancia
            resumo = f"{params.get('Estrategia', 'N/A')}; ESC: {params.get('ESCOLHER', 'N/A')}; REG: {params.get('RegimeE3', 'N/A')}; |{params.get('limite_variacao', 'N/A')}| LEV {params.get('limite_variacao_lev', 'N/A')}/ PES {params.get('limite_variacao_pes', 'N/A')}%; STP: {params.get('passoE3', 'N/A')}"
            print(f"{idx:3d}. {nome}  ->  {resumo}")
    
    # Verifica se a seleção é válida
    nameChoosed = None
    if total_arquivos == 0:
        print("\nNenhum arquivo para selecionar.")
    elif selecionarE3 < 1 or selecionarE3 > total_arquivos:
        print(f"\nForam encontrados {total_arquivos} estudos. Selecione um número entre 1 e {total_arquivos}.")
    else:
        # Lembrando que o índice para o usuário é baseado em 1, portanto subtraímos 1
        nameChoosed = os.path.basename(file_list[selecionarE3 - 1])
        print(f"Arquivo selecionado (opção {selecionarE3}): {nameChoosed}\n")
    
    return total_arquivos, nameChoosed, estudosE3_param, arquivos_info


def ler_diretorio_plot3_pfCrvs(selecionarE3):
    """
    Varre o diretório 'plot/GenOfCases/pfCurve' para identificar as pastas presentes,
    listando-as com um número de identificação.
    
    Parâmetro:
      selecionarE3 (int): Índice (base 1) da pasta a ser selecionada.
      
    Retorna:
      total_pastas (int): Quantidade de pastas encontradas.
      nameChoosed (str ou None): Nome da pasta selecionada, se válido; caso contrário, None.
      lista_pastas (list): Lista dos nomes das pastas encontradas.
    """
    base_dir = os.path.join(os.getcwd(), "plot", "GenOfCurvs", "pfCurve")
    
    if not os.path.isdir(base_dir):
        print(f"O diretório base não existe: {base_dir}")
        return 0, None, []
    
    # Lista apenas os itens que são diretórios (pastas)
    lista_pastas = [item for item in sorted(os.listdir(base_dir))
                    if os.path.isdir(os.path.join(base_dir, item))]
    
    total_pastas = len(lista_pastas)
    
    print("PASTAS ENCONTRADAS NO DIRETÓRIO (Plt3 - 'plot/GenOfCurvs/pfCurve'):")
    if total_pastas == 0:
        print("  Nenhuma pasta encontrada em 'plot/GenOfCurvs/pfCurve'.")
    else:
        for idx, pasta in enumerate(lista_pastas, start=1):
            print(f"{idx:3d}. {pasta}")
    
    nameChoosed = None
    if total_pastas == 0:
        print("Nenhuma pasta para selecionar. Realize antes o estudo 3 (TELA3_GoCurvs)\n")
        exit()
    elif selecionarE3 < 1 or selecionarE3 > total_pastas:
        print("\nPasta Selecionada (selecionarPlt3):", selecionarE3)
        print(f"Opção inválida!")
        print(f"Foram encontradas {total_pastas} pastas. Selecione um número entre 1 e {total_pastas}.\n")
        exit()
    else:
        nameChoosed = lista_pastas[selecionarE3 - 1]
        print(f"Pasta selecionada (opção {selecionarE3}): {nameChoosed}\n")
    
    return total_pastas, nameChoosed, lista_pastas



def pega_nome_maiusculo(nome_arquivo):
    # Separa o nome do arquivo da sua extensão
    nome, ext = os.path.splitext(nome_arquivo)
    # Retorna o nome em letras maiúsculas
    return nome.upper()


def FILTERForPresentationOfSelectedBarr(FILTER_IN00, FILTER_IN01):
    selection_curve=FILTER_IN00[0]
    CHOOSE_BAR=FILTER_IN00[1]
    mat0=FILTER_IN01[0]
    infoVctrl=FILTER_IN01[1]

    if selection_curve=='PV':

        BarrasPV=[]
        for auxiliar_col in range(len(infoVctrl[0])):
            if infoVctrl[0][auxiliar_col]=='-':
                for auxliar_lin in range(len(mat0)):
                    mat0[auxliar_lin][auxiliar_col]=0
            else:
                BarrasPV.append(auxiliar_col)
                    #print('wait')
        mat0, _ = ceifar_matriz_vetor(mat0, None, remover_linhas_correspondentes=False)
        return(mat0, BarrasPV)
    
    elif selection_curve=='PQ':
        
        BarrasPQ=[]
        for auxiliar_col in range(len(infoVctrl[0])):
            if infoVctrl[0][auxiliar_col]!='-':
                for auxliar_lin in range(len(mat0)):
                    mat0[auxliar_lin][auxiliar_col]=0
            else:
                BarrasPQ.append(auxiliar_col)
                    #print('wait')
        mat0, _ = ceifar_matriz_vetor(mat0, None, remover_linhas_correspondentes=False)
        return(mat0, BarrasPQ)
    
    elif selection_curve=='CHOOSE_BAR':
        #BarrasCHOSED=[]
        vetCHOOSE_BAR=interpret_choose_bar(CHOOSE_BAR)
        for aux in range(len(vetCHOOSE_BAR)):
            vetCHOOSE_BAR[aux]=vetCHOOSE_BAR[aux]-1

        #print(vetCHOOSE_BAR)
        for auxiliar_col in range(len(infoVctrl[0])):
            if auxiliar_col not in vetCHOOSE_BAR:
                for auxliar_lin in range(len(mat0)):
                    mat0[auxliar_lin][auxiliar_col]=0
                    #print('wait')
        mat0, _ = ceifar_matriz_vetor(mat0, None, remover_linhas_correspondentes=False)
        return(mat0, vetCHOOSE_BAR)

#CRITICAS

def determina_LimitesDeControlPotQsobrePVcurv(EvolutionMatrixMatriz2, infoVctrl):
    resultados = monitor_voltage_boundaries(EvolutionMatrixMatriz2, infoVctrl, tol=1e-12)
    PONTOS_LIMITES=[]
    for col, dados in resultados.items():
        limits = dados['limits']
        #print(f"Coluna {col} - Limites: {limits}")
        if limits!=[]:
            for aux in limits:
                PONTOS_LIMITES_forEachBar=[]
                PONTOS_LIMITES_forEachBar.append(EvolutionMatrixMatriz2[0][aux][col])
                PONTOS_LIMITES_forEachBar.append(EvolutionMatrixMatriz2[1][aux])
                PONTOS_LIMITES_forEachBar.append(col+1)
                PONTOS_LIMITES.append(PONTOS_LIMITES_forEachBar)
    #print('PONTOS_LIMITES=',PONTOS_LIMITES)
    return PONTOS_LIMITES


def find_continuous_segments(indices):
    """
    Recebe uma lista ordenada de índices inteiros e retorna uma lista de tuplas (início, fim)
    representando os trechos contínuos.
    """
    if not indices:
        return []
    segments = []
    start = indices[0]
    prev = indices[0]
    for idx in indices[1:]:
        if idx == prev + 1:
            prev = idx
        else:
            segments.append((start, prev))
            start = idx
            prev = idx
    segments.append((start, prev))
    return segments

def monitor_voltage_boundaries(EvolutionMatrixMatriz2, infoVctrl, tol=1e-6):
    """
    Para cada coluna em que o marcador (infoVctrl[0]) é 'swing', 'G' ou 'CS',
    verifica se os valores na evolução das tensões (EvolutionMatrixMatriz2[0])
    diferem do valor esperado (infoVctrl[1]) acima de uma tolerância.
    
    Retorna um dicionário com, para cada coluna de controle, os seguintes dados:
      - 'diff_indices': vetor com os índices (linhas) onde há diferença
      - 'segments': vetor de tuplas (início, fim) representando trechos contínuos
      - 'limits': vetor com os valores limítrofes (lista de [início, fim] para cada segmento)
    
    Também imprime os resultados.
    """
    # Converte a matriz de evolução para array NumPy (caso não seja)
    matrix = np.array(EvolutionMatrixMatriz2[0])
    expected = np.array(infoVctrl[1])
    
    # Índices das colunas onde há controle
    control_columns = [j for j, marker in enumerate(infoVctrl[0]) if marker in ['swing', 'G', 'CS']]
    
    resultados = {}  # Dicionário para armazenar os resultados para cada coluna de controle
    
    #control_columns_print = [x + 1 for x in control_columns]
    #print("Monitorando limites de controle nas barras:", control_columns_print)

    for j in control_columns:
        exp_val = expected[j]
        # Encontra os índices das linhas onde a diferença excede a tolerância
        diff_rows = np.where(np.abs(matrix[:, j] - exp_val) > tol)[0]
        diff_list = diff_rows.tolist()
        #print(f"\nColuna {j} ({infoVctrl[0][j]}): Valor esperado = {exp_val}.")
        #print("Diferenças detectadas nas linhas:", diff_list)
        
        # Identifica os trechos contínuos
        segments = find_continuous_segments(diff_list)
        #print("Trechos contínuos (segmentos):", segments)
        
        # Cria um vetor com os limites de cada segmento (ex: [inicio1, fim1, inicio2, fim2, ...])
        limits = [lim for seg in segments for lim in seg]
        #print("Valores limítrofes dos segmentos:", limits)
        
        resultados[j] = {
            'diff_indices': diff_list,
            'segments': segments,
            'limits': limits
        }
    
    return resultados


def kth_maior(vetor, k):
    """
    Retorna o k-ésimo maior valor de um vetor, considerando apenas valores distintos.
    
    Parâmetros:
      vetor (list): Lista de números.
      k (int): Posição do ranking desejado (1 para o maior, 2 para o segundo maior, etc.)
      
    Retorna:
      O k-ésimo maior valor (desconsiderando repetições) se existir; caso contrário, retorna None.
    """
    # Obtém os valores distintos
    valores_distintos = list(set(vetor))
    
    # Ordena os valores em ordem decrescente
    valores_distintos.sort(reverse=True)
    
    # Verifica se k é válido
    if 1 <= k <= len(valores_distintos):
        return valores_distintos[k - 1]
    else:
        return None



def encontrar_valor(matriz, valor_procurado):
    for i, linha in enumerate(matriz):
        for j, elemento in enumerate(linha):
            if elemento == valor_procurado:
                return (i, j)  # Retorna a primeira ocorrência
    return None  # Retorna None se o valor não for encontrado



def remover_elemento_sincronizado(vetor1, vetor2, elemento):
    """
    Cria novos vetores a partir de dois vetores de mesmo tamanho, removendo
    todas as ocorrências de um elemento escolhido em 'vetor1' e também removendo,
    de forma sincronizada, os elementos correspondentes em 'vetor2'.
    
    Parâmetros:
      vetor1 (list): Vetor de onde se deseja remover o elemento.
      vetor2 (list): Vetor associado (mesmo tamanho de vetor1) de onde o elemento
                     na mesma posição será removido.
      elemento (qualquer tipo): O elemento que se deseja remover de vetor1.
    
    Retorna:
      tuple: Dois novos vetores (novovetor1, novovetor2) sem as posições onde
             o elemento foi encontrado em vetor1.
    
    Exemplo:
      vetor1 = [1, 2, 3, 2, 4]
      vetor2 = ['a', 'b', 'c', 'd', 'e']
      elemento = 2
      -> Retorna: ([1, 3, 4], ['a', 'c', 'e'])
    """
    if len(vetor1) != len(vetor2):
        raise ValueError("Os vetores devem ter o mesmo tamanho.")
    
    novovetor1 = []
    novovetor2 = []
    
    for i, val in enumerate(vetor1):
        if val != elemento:
            novovetor1.append(val)
            novovetor2.append(vetor2[i])
    
    return novovetor1, novovetor2



def Volta_textoAPATE(pegar_quemParouUltimo_PotRef, pegar_quemParouUltimo_PotVar, regime, 
                     callback_barras, aux, DB_P_REF, novo_elemento, pegar_quemParouUltimo):
    
    vetornewRef = np.array(pegar_quemParouUltimo_PotRef)
    vetornewRef = np.append(vetornewRef, DB_P_REF[aux])
    vetornewVar = np.array(pegar_quemParouUltimo_PotVar)
    vetornewVar = np.append(vetornewVar, novo_elemento)
    vetor=np.append(pegar_quemParouUltimo, aux)
    vetor_novo = vetor + 1

    porcentagens=comparar_percentual_reducao(vetornewRef, vetornewVar, regime)
    if callback_barras:
        vetor_arredondado = np.round(porcentagens, 2)
        callback_barras(vetor_novo,vetor_arredondado)
    else:
        print("Barras alteradas:", aux+1)
    return()



def imprimir_barras_e_quedas_numerado(barras, quedas, colunas=2):
    assert len(barras) == len(quedas), "Listas devem ter o mesmo tamanho"
    
    print("\n                     |ORDEM - BARRAS - QUEDAS DE TENSÃO|  ")
    # Gerar blocos de 2 colunas por linha
    linhas_formatadas = []
    for i in range(0, len(barras), colunas):
        bloco = ""
        for j in range(2):
            if i + j < len(barras):
                n = i + j + 1
                b = barras[i + j]
                v = quedas[i + j]
                bloco += f"|{n:<3}º - Barra {b:<3} - ΔV {v:.5f}| "
        linhas_formatadas.append(bloco.strip())

    # Agora centraliza
    for linha in linhas_formatadas:
        print(linha.center(78))  # ou largura que desejar
    return()


def GoPC_generator_PVcurve_MAIORES(PORTAS_s_v, PORTAS_E3_IN, limite_variacao, RegimeE3, stop_checker, callback_barras):

    SYSname=PORTAS_E3_IN[0]
    MODELin=PORTAS_E3_IN[1]
    Tolerancia=PORTAS_E3_IN[2]
    HabiltAval_Lim_Reativo=PORTAS_E3_IN[3]
    S_base=PORTAS_E3_IN[4]
    Desabilitar_CS=PORTAS_E3_IN[5]
    Tipo_de_logicaSuplementar=PORTAS_E3_IN[6]
    ComutacaoMaxima=PORTAS_E3_IN[7]
    Ativar_inverter=PORTAS_E3_IN[8]
    passoE3=PORTAS_E3_IN[9]
    GirarTrafo=PORTAS_E3_IN[16]
    #limite_variacao=PORTAS_E3_IN[10]
    #RegimeE3=PORTAS_E3_IN[11]
       
    
    ''' INICIALIZAÇÃO '''
    status_program='CDF' #---MANUAL or CDF (DADOS DE BARRA)
    alterar_tensao_decontrole_doCDF='X' #---X, A or B 
    ([matrizSystem],[matrizSystem2])=Ler_Arquivo(SYSname)
    # for auxiliar_corrigeMS in range(len(matrizSystem)):
    #     matrizSystem[auxiliar_corrigeMS][18]=(-1)*matrizSystem[auxiliar_corrigeMS][18] ## IEEE30 or IEEE118 (linha em T)
    matrizSystem2 = corrige_duplicidadeDeLinha(matrizSystem2)
    ([matriz_DadosBarra],[infoVctrl])=DefineMatrizDadosBarra(matrizSystem, S_base, HabiltAval_Lim_Reativo, status_program, MODELin, None, alterar_tensao_decontrole_doCDF)
    (infoVctrl, matriz_DadosBarra)=liga_desliga_CS(matrizSystem, status_program, MODELin, None , alterar_tensao_decontrole_doCDF, S_base, HabiltAval_Lim_Reativo, Desabilitar_CS, matriz_DadosBarra, infoVctrl)
    ATIVA_ESPEC=extrair_potencias_negativas(matrizSystem)
    ATIVA_ESPECcomp=extrair_potencias_negativas(matrizSystem)
    PVbarIndex, _, _, _, _, _, _, _, _ = extrair_vetores_da_matrizSystem(matrizSystem)
    #print('infoVctrl=',infoVctrl)
    modelagem_linha = MODELin # Tipo de modelo da linha (PI ou T)
    matrizSystem, matrizSystem2, modelagem_resultante = alterar_matrizes(matrizSystem, matrizSystem2, modelagem_linha)
    MatrizY=calcularMATRIZ_Y(matrizSystem, matrizSystem2, Ativar_inverter, GirarTrafo)


    ''' NEWTON COMPLETO '''
    Fluxo_divergente_0='no'
    try:
        (DeltaV_0, Delta0_0, PotP_0, PotQ_0, _, _, cont_0, MATRIZ_Y, Barras_PQ_0, JACOBIANA_INICIAL_0, JACOBIANA_FINAL_0, BarraQViola_estatica_0,_, _, _, _, _, _, _, _, _, _, VerificaSeViola_0, _ , _ , _ )=CHAMA_FLNR_03_LTT (matrizSystem,matrizSystem2,matriz_DadosBarra,infoVctrl,MODELin,Tolerancia,'no', None, None, None, None, None, None, None, None, 'no', None, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY)
        #print(PotP_0[3])
        DeltaV=[float(x) for x in DeltaV_0]
        Delta0=[float(x) for x in Delta0_0]
        PotP=[float(x) for x in PotP_0]
        PotQ=[float(x) for x in PotQ_0]

        matriz_DadosBarra_universal=matriz_DadosBarra 
       
    except Exception as e:
        Fluxo_divergente_0='yes' 
        Observation_0='FLUXO INICIAL DIVERGENTE. CONFERIR ARQUIVO CDF.'
        DeltaV_0=[0]*len(ATIVA_ESPEC)  
        Delta0_0=[0]*len(ATIVA_ESPEC) 
        PotP_0=[0]*len(ATIVA_ESPEC)
        PotQ_0=[0]*len(ATIVA_ESPEC)
        Barras_PQ_0= ['FLUXO DIVERGENTE']*len(ATIVA_ESPEC)
        cont_0=0  
        JACOBIANA_FINAL_0=[] 
        JACOBIANA_INICIAL_0=[]
        MATRIZ_Y=[]
        stringQauntidadeQViolaInical_0='FLUXO DIVERGENTE!'
        stingBarraQViola_estatica_0='FLUXO DIVERGENTE!'
        #print('FLUXO DIVERGENTE EM REGIME DE CARGA INICIAL')
    
    matriz_TravaPSempre3=[0]*len(matriz_DadosBarra[1])
    for aux in range(len(matriz_DadosBarra[1])):
        matriz_TravaPSempre3[aux]=matriz_DadosBarra[1][aux]      
    #matriz_DadosBarra[1]
    ZERO_PACOTE=[matrizSystem, matrizSystem2, matriz_DadosBarra, infoVctrl, Fluxo_divergente_0, ATIVA_ESPEC, matriz_TravaPSempre3, MatrizY]
    
    DB_P_REF=[0]*len(matriz_DadosBarra[1])
    DB_listBar=[0]*len(matriz_DadosBarra[1])
    matriz_TravaPSempre=[0]*len(matriz_DadosBarra[1])
    for aux in range(len(matriz_DadosBarra[1])):
        matriz_TravaPSempre[aux]=matriz_DadosBarra[1][aux]
        DB_P_REF[aux]=(-1)*matriz_DadosBarra[1][aux] 
        DB_listBar[aux]=aux
    
    status=['avante']*len(matriz_DadosBarra[1])
    maior_valor_trajetory_pot=[]
    maior_valor_trajetory_dV=[]
    DeltaV_trajetory=[]
    PotGer_trajetory=[]
    PotGer_fatorDePotGlobal=[]
    LIMITOU_AS_GRANDES_LES='no'
    LIMITOU_AS_GRANDES_PES='no' 
    LIMITOU_AS_GRANDES_LES_val=None
    LIMITOU_AS_GRANDES_PES_val=None 
    var_limitarCalculo='yes'
    #pegar_quemParouUltimoGERAL=[]
    salva_ultimo_adict=0
    SALVAR_BARRAS_MIN=[]
    SALVAR_BARRAS_ADICT=[]
    if RegimeE3=='PESADO':
        print('\n______________________________________________________________________________')
        print("🗿 Avaliação de regime PESADO: Barras de MAIORES impactos identificadas.")
        print('     - Religamento de cargas (potência ativa). ')
        print('     - Aleteração COMPLETA nas potências das Barras avaliadas na listagem')
        print('       de maiores impactos sobre a queda de tensão.\n')
        ORDEM_GERAL='AVANTE'
        if Fluxo_divergente_0=='no':
            Fluxo_divergente='no'
            LISTAPrioritys=['-']*len(matriz_DadosBarra[1])
            cont_confirma_primeiraVez=0
            LISTAindex_maior_valor_estatica=[]
            LISTA_maior_valor_estatica=[]
            #limitou='no'
            pegar_quemParouUltimo=[]
            pegar_quemParouUltimo_PotRef=[]
            pegar_quemParouUltimo_PotVar=[]
            pegar_quemParouUltimo_PotVar2=[]
            MaxMaxindex=0
            res1=None

            trava_imprimir=0

            while (Fluxo_divergente=='no' and ORDEM_GERAL=='AVANTE'):
                # ──────────────────────────────────────────────────────────────────────────────
                # Bloco de parada segura – coloque-o logo após abrir o while
                # ──────────────────────────────────────────────────────────────────────────────
                if stop_checker and stop_checker():          # função vinda de G_TERMINAL
                    print(">>> Execução interrompida pelo usuário via interface.")
                    #vetor = [x + 1 for x in pegar_quemParouUltimo]
                    #print('    * Barras prenchidas completamente: ', vetor)
                    vetor = [x + 1 for x in pegar_quemParouUltimo]
                   # print('    * Barras prenchidas completamente: ', vetor)
                    print("      - Barras:")
                    for i in range(0, len(vetor), 17):
                        linha = vetor[i:i+17]
                        texto_barras = ", ".join(str(b) for b in linha)
                        print(f"        {texto_barras}")

                    # 1) monta o que já foi calculado até aqui
                    EvolutionMatrixMatriz2 = [
                        DeltaV_trajetory.copy(),             # curva ΔV
                        PotGer_trajetory.copy()              # curva −ΣPger
                    ]

                    # 2) monta   PORTAS_s_v   com os flags e vetores parciais
                    PORTAS_s_v = [
                        LIMITOU_AS_GRANDES_LES,
                        LIMITOU_AS_GRANDES_PES,
                        LIMITOU_AS_GRANDES_LES_val,
                        LIMITOU_AS_GRANDES_PES_val,
                        maior_valor_trajetory_pot,
                        PotGer_fatorDePotGlobal
                    ]

                    # 3) devolve exatamente o que a função promete retornar
                    return (EvolutionMatrixMatriz2, PORTAS_s_v, ZERO_PACOTE)
                # ──────────────────────────────────────────────────────────────────────────────



                if var_limitarCalculo=='yes' and res1==None:
                    deveRodarProcuraMaior='yes'
                elif var_limitarCalculo=='yes' and res1!=None: 
                    deveRodarProcuraMaior='no' 
                elif var_limitarCalculo=='no':
                    deveRodarProcuraMaior='yes'

                if deveRodarProcuraMaior=='yes':
                    vet_erroDaRodada=[0]*len(matriz_DadosBarra[1])
                    matriz_TravaPRoda=[0]*len(matriz_DadosBarra[1])
                    LISTA_maior_valor=[0]*len(matriz_DadosBarra[1])
                    LISTAindex_maior_valor=[0]*len(matriz_DadosBarra[1])
                    DeltaVsave=[0]*len(matriz_DadosBarra[1])
                    
                    for aux22 in range(len(matriz_DadosBarra[1])):
                        matriz_TravaPRoda[aux22]=matriz_DadosBarra[1][aux22] 

                    for aux in range(len(matriz_DadosBarra[1])):
                        # ──────────────────────────────────────────────────────────────────────────────
                        # Bloco de parada segura – coloque-o logo após abrir o while
                        # ──────────────────────────────────────────────────────────────────────────────
                        if stop_checker and stop_checker():          # função vinda de G_TERMINAL
                            print(">>> Execução interrompida pelo usuário via interface.")

                            # 1) monta o que já foi calculado até aqui
                            EvolutionMatrixMatriz2 = [
                                None,             # curva ΔV
                                None           # curva −ΣPger
                            ]

                            # 2) monta   PORTAS_s_v   com os flags e vetores parciais
                            PORTAS_s_v = [
                                None,
                                None,
                                None,
                                None,
                                None,
                                None
                            ]
                            

                            # 3) devolve exatamente o que a função promete retornar
                            return (EvolutionMatrixMatriz2, PORTAS_s_v, ZERO_PACOTE)
                        # ──────────────────────────────────────────────────────────────────────────────



                        if ATIVA_ESPEC[aux]!=0 and aux!=0:                                   
                            if status[aux]=='avante':
                                matriz_DadosBarra[1][aux]=matriz_TravaPRoda[aux]-passoE3
                                #index_da_barra_adicionada[aux]=aux

                                Fluxo_divergente='no' 
                                try:
                                    (DeltaV, Delta0, PotP, PotQ, _, _, cont, MATRIZ_Y, Barras_PQ, JACOBIANA_INICIAL, JACOBIANA_FINAL, BarraQViola_estatica,_, _, _, _, _, _, _, _, _, _, VerificaSeViola,  _ , _ , _ )=CHAMA_FLNR_03_LTT (matrizSystem,matrizSystem2,matriz_DadosBarra,infoVctrl,MODELin,Tolerancia,'no', None, None, None, None, None, None, None, None, 'no', None, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY)
                                    DeltaV=[float(x) for x in DeltaV]
                                    Delta0=[float(x) for x in Delta0]
                                    PotP=[float(x) for x in PotP]
                                    PotQ=[float(x) for x in PotQ] 
                                    #DeltaV_trajetory.append(DeltaV)
                                    
                                    if cont==200:
                                        saveAbnormalPoints(matriz_DadosBarra[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN)

                                except Exception as e:
                                    Fluxo_divergente='yes' 
                                    Observation='FLUXO DIVERGENTE.'
                                    DeltaV=[0]*len(ATIVA_ESPEC)  
                                    Delta0=[0]*len(ATIVA_ESPEC) 
                                    PotP=[0]*len(ATIVA_ESPEC)
                                    PotQ=[0]*len(ATIVA_ESPEC)
                                    Barras_PQ= ['FLUXO DIVERGENTE']*len(ATIVA_ESPEC)
                                    cont=0  
                                    JACOBIANA_FINAL=[] 
                                    JACOBIANA_INICIAL=[]
                                    MATRIZ_Y=[]
                                    stringQauntidadeQViolaInical='FLUXO DIVERGENTE!'
                                    stingBarraQViola_estatica='FLUXO DIVERGENTE!'
                                    saveDivergencies(matriz_DadosBarra[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN)
                                
                                if Fluxo_divergente=='no':
                                    try:
                                        
                                        erro=[0]*len(DeltaV)
                                        for aux2 in range(len(DeltaV)):
                                            erro[aux2]=float(DeltaV_0[aux2]-DeltaV[aux2])                          
                                        vet_erroDaRodada[aux]=erro   
                                        DeltaVsave[aux]=DeltaV                    
                                        LISTA_maior_valor[aux] = max(erro)  
                                        LISTAindex_maior_valor[aux] = erro.index(max(erro))  
                                        # if LISTAindex_maior_valor[aux]==7:                              
                                        #     print('LISTAindex_maior_valor[aux]=',LISTAindex_maior_valor)
                                        
                                        for i in range(len(LISTAindex_maior_valor)):
                                            if ATIVA_ESPEC[LISTAindex_maior_valor[i]]==0:
                                                LISTAindex_maior_valor[i]=0
                                                LISTA_maior_valor[i]=0

                                    except Exception as e:
                                        print('Não encontrou barras de maiores impacto. ' \
                                        'Desenhe a curva escolhendo as barras manualmente.')
                            
                            for aux22 in range(len(matriz_DadosBarra[1])):
                                matriz_DadosBarra[1][aux22]=matriz_TravaPRoda[aux22]          
                                

                if cont_confirma_primeiraVez==0:
                    MaxMax=max(LISTA_maior_valor)                                    
                    MaxMaxindex=LISTA_maior_valor.index(MaxMax)
                    LISTAPrioritys[MaxMaxindex]='avante'
                    LISTAindex_maior_valor_estatica.append(LISTAindex_maior_valor)
                    LISTA_maior_valor_estatica.append(LISTA_maior_valor)
                    cont_confirma_primeiraVez=1
                else:
                    # Obtém os valores únicos presentes na lista
                    valores_unicos = set(LISTAindex_maior_valor)
                    res1, res2 = processar_matrizes(LISTAindex_maior_valor_estatica, LISTA_maior_valor_estatica)
                    

                    if trava_imprimir==0 and res1!=None:
                        res2_res1_ordenado = sorted(zip(res2, res1), reverse=True)
                        res2_ordenado, res1_ordenado = zip(*res2_res1_ordenado)

                        # Converter para lista (se necessário)
                        res2_ordenado = list(res2_ordenado)
                        res1_ordenado = list(res1_ordenado)

                        print('📉  Barras de Maior Impacto sobre as tensões:')
                        print('     - São criadas duas listas de controle: Barras de maior impacto e' )
                        print('       o registro da maior queda de tensão encontrada ao adicionar a' )
                        print('       potência da barra de um degrau conhecido (passo).' )
                        print('     - A lista Barras de maior impacto corresponde a barra identificada' )
                        print('       cuja alteração pelo passo leva a maior queda de tensão de alguma' )
                        print('       barra do sistema. Esta barra não necessariamente corresponde a' )
                        print('       barra que teve a maior queda - a menos que sua potência comece' )
                        print('       a ser relevante sobre o sistema.' )
                        print('     - O algoritmo define a listagem a partir da queda de tensão registrada')
                        print('       e, portanto, apenas as barras PQ no momento incial da avaliação são')
                        print('       candidatas plausíveis. As barras PV são avaliadas caso caso nenhum')
                        print('       critério de parada seja atingido com a listagem.')                        
                        
                        vetor = [x + 1 for x in res1_ordenado]
                        imprimir_barras_e_quedas_numerado(vetor, [round(x, 5) for x in res2_ordenado], colunas=2)
                        #print('****************************************************************************') 
                        trava_imprimir=1     

                    if pegar_quemParouUltimo!=None:
                        for pegarQuemLimita in pegar_quemParouUltimo:
                            res1, res2 = remover_elemento_sincronizado(res1, res2, pegarQuemLimita)

                    if max(res2)>MaxMax:
                        if LISTAPrioritys[MaxMaxindex]=='-' or LISTAPrioritys[MaxMaxindex]=='avante':
                            # if MaxMaxindex==7:
                            #     print('help')  
                            if ATIVA_ESPEC[MaxMaxindex]!=0:
                                MaxMax=max(res2)
                                LISTAPrioritys[MaxMaxindex]='parar'
                                status[MaxMaxindex]='parar'                    
                                MaxMaxindex=res1[res2.index(max(res2))]                    
                                LISTAPrioritys[MaxMaxindex]='avante'
                                status[MaxMaxindex]='avante' 


                    if len(valores_unicos) == 1:
                        valor_unico = valores_unicos.pop()  # Recupera o único valor
                    else:
                        LISTAindex_maior_valor_estatica.append(LISTAindex_maior_valor)
                        LISTA_maior_valor_estatica.append(LISTA_maior_valor)


                for aux_checaLimites in range(len(LISTAPrioritys)):
                    if LISTAPrioritys[aux_checaLimites]=='avante':
                        if matriz_DadosBarra[1][aux_checaLimites]>matriz_TravaPSempre[aux_checaLimites]*(1+limite_variacao/100):
                            
                            Volta_textoAPATE(pegar_quemParouUltimo_PotRef, pegar_quemParouUltimo_PotVar, RegimeE3, 
                                                callback_barras, aux_checaLimites, DB_P_REF, (-1)*matriz_DadosBarra[1][aux_checaLimites], pegar_quemParouUltimo)
                            
                            status[aux_checaLimites]='avante'
                            
                            matriz_DadosBarra[1][aux_checaLimites]=matriz_DadosBarra[1][aux_checaLimites]-passoE3

                        else:    
                            matriz_DadosBarra[1][aux_checaLimites]=matriz_TravaPSempre[aux_checaLimites]*(1+limite_variacao/100) 
                            status[aux_checaLimites]='parar' 
                            LISTAPrioritys[aux_checaLimites]='parar'
                            pegar_quemParouUltimo.append(aux_checaLimites)
                            pegar_quemParouUltimo_PotVar.append((-1)*matriz_DadosBarra[1][aux_checaLimites])
                            if aux_checaLimites in DB_listBar:
                                pegar_quemParouUltimo_PotRef.append(DB_P_REF[aux_checaLimites])
                            aumenta_rank=1     
                            if aumenta_rank<len(res2):
                                aumenta_rank=aumenta_rank+1 
                                outroMaior=kth_maior(res2, aumenta_rank)
                                MaxMax=outroMaior
                                MaxMaxindex=res1[res2.index(outroMaior)]
                                LISTAPrioritys[MaxMaxindex]='avante'
                            else:
                                ORDEM_GERAL='PARAR'
                                LIMITOU_AS_GRANDES_PES='yes'
                                LIMITOU_AS_GRANDES_PES_val=matriz_DadosBarra[1]

                        Fluxo_divergenteOficial='no' 
                        try:
                            (DeltaV, _ , PotP, PotQ , _, _, cont , _ , _ , _ , _ , _ ,_, _, _, _, _, _, _, _, _, _, _ , _ , _ , _ )=CHAMA_FLNR_03_LTT (matrizSystem,matrizSystem2,matriz_DadosBarra,infoVctrl,MODELin,Tolerancia,'no', None, None, None, None, None, None, None, None, 'no', None, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY)
                            DeltaV=[float(x) for x in DeltaV]
                            PotP=[float(x) for x in PotP]
                            #PotP=[float(x) for x in PotP]
                            PotQ=[float(x) for x in PotQ]                             
                            #print('matriz_DadosBarra[1]=',matriz_DadosBarra)
                            
                            pot_p_gerada=[]
                            pot_q_gerada=[]
                            for i in range(len(PotP)):
                                # Cálculo das potências geradas
                                if infoVctrl[0][i]=='G' or infoVctrl[0][i]=='CS' or infoVctrl[0][i]=='swing':
                                    pot_p_gerada.append(PotP[i] - matriz_DadosBarra[1][i])  # Potência P gerada    
                                    pot_q_gerada.append(PotQ[i] - matriz_DadosBarra[2][i])  # Potência Q gerada                            
                            soma_p = np.sum(pot_p_gerada)
                            soma_q = np.sum(pot_q_gerada)
                            PotSger=np.sqrt(soma_p**2+soma_q**2)
                            fpGlobal=soma_p/PotSger

                            if cont==200:
                                saveAbnormalPoints(matriz_DadosBarra[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN)
                            
                        except Exception as e:
                            Fluxo_divergenteOficial='yes' 
                            saveDivergencies(matriz_DadosBarra[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN)
                        
                cont_aux=0
                
                if Fluxo_divergenteOficial=='no':
                    DeltaV_trajetory.append(DeltaV)
                    somaPger=0
                    for auxilair in range(len(matriz_DadosBarra[1])):
                        somaPger=somaPger+matriz_DadosBarra[1][auxilair]                        
                    PotGer_trajetory.append((-1)*somaPger)                         
                    PotGer_fatorDePotGlobal.append(fpGlobal)                                                         

                contador_aux=0
                for auxiliar in range(len(status)):
                    if status[auxiliar]=='parar':
                        contador_aux=contador_aux+1
                
                if contador_aux==len(status):
                    ORDEM_GERAL='PARAR'

                for auxiliar_verificaseEstoura in range(len(DeltaV)):
                    if DeltaV[auxiliar_verificaseEstoura]>10^3:
                        ORDEM_GERAL='PARAR'
                        saveDivergencies(matriz_DadosBarra[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN)
                
                if ORDEM_GERAL=='PARAR':        
                    pegar_quemParouUltimo.append(aux_checaLimites)

        SALVAR_BARRAS_ADICT=pegar_quemParouUltimo
        salva_ultimo_adict=aux_checaLimites


    elif RegimeE3=='LEVE':
        print('\n______________________________________________________________________________')
        print("🪶 Avaliação de regime LEVE: Barras de MAIORES impactos identificadas.")
        print('     - Desligamento de cargas (potência ativa). ')
        print('     - Aleteração COMPLETA nas potências das Barras avaliadas na listagem')
        print('       de maiores impactos sobre a queda de tensão.\n')
        ORDEM_GERAL='AVANTE'
        if Fluxo_divergente_0=='no':
            Fluxo_divergente='no'
            LISTAPrioritys=['-']*len(matriz_DadosBarra[1])
            cont_confirma_primeiraVez=0
            LISTAindex_maior_valor_estatica=[]
            LISTA_maior_valor_estatica=[]
            #limitou='no'
            pegar_quemParouUltimo=[]
            pegar_quemParouUltimo_PotRef=[]
            pegar_quemParouUltimo_PotVar=[]
            MaxMaxindex=0
            res1=None
            trava_imprimir=0
            while (Fluxo_divergente=='no' and ORDEM_GERAL=='AVANTE'):
                # ──────────────────────────────────────────────────────────────────────────────
                # Bloco de parada segura – coloque-o logo após abrir o while
                # ──────────────────────────────────────────────────────────────────────────────
                if stop_checker and stop_checker():          # função vinda de G_TERMINAL
                    print("\n>>> Execução interrompida pelo usuário via interface.")
                    vetor = [x + 1 for x in pegar_quemParouUltimo]
                   # print('    * Barras prenchidas completamente: ', vetor)
                    print("      - Barras:")
                    for i in range(0, len(vetor), 17):
                        linha = vetor[i:i+17]
                        texto_barras = ", ".join(str(b) for b in linha)
                        print(f"        {texto_barras}")

                    # 1) monta o que já foi calculado até aqui
                    EvolutionMatrixMatriz2 = [
                        DeltaV_trajetory.copy(),             # curva ΔV
                        PotGer_trajetory.copy()              # curva −ΣPger
                    ]

                    # 2) monta   PORTAS_s_v   com os flags e vetores parciais
                    PORTAS_s_v = [
                        LIMITOU_AS_GRANDES_LES,
                        LIMITOU_AS_GRANDES_PES,
                        LIMITOU_AS_GRANDES_LES_val,
                        LIMITOU_AS_GRANDES_PES_val,
                        maior_valor_trajetory_pot,
                        PotGer_fatorDePotGlobal
                    ]

                    # 3) devolve exatamente o que a função promete retornar
                    return (EvolutionMatrixMatriz2, PORTAS_s_v, ZERO_PACOTE)
                # ──────────────────────────────────────────────────────────────────────────────

                if var_limitarCalculo=='yes' and res1==None:
                    deveRodarProcuraMaior='yes'
                elif var_limitarCalculo=='yes' and res1!=None: 
                    deveRodarProcuraMaior='no'    
                elif var_limitarCalculo=='no':
                    deveRodarProcuraMaior='yes'
                
                if deveRodarProcuraMaior=='yes':
                    vet_erroDaRodada=[0]*len(matriz_DadosBarra[1])
                    matriz_TravaPRoda=[0]*len(matriz_DadosBarra[1])
                    LISTA_maior_valor=[0]*len(matriz_DadosBarra[1])
                    LISTAindex_maior_valor=[0]*len(matriz_DadosBarra[1])
                    DeltaVsave=[0]*len(matriz_DadosBarra[1])
                    PotPsave=[0]*len(matriz_DadosBarra[1])

                    #status[0]='parar'

                    for aux22 in range(len(matriz_DadosBarra_universal[1])):
                        matriz_TravaPRoda[aux22]=matriz_DadosBarra_universal[1][aux22] 


                    for aux in range(len(matriz_DadosBarra_universal[1])):
                        # ──────────────────────────────────────────────────────────────────────────────
                        # Bloco de parada segura – coloque-o logo após abrir o while
                        # ──────────────────────────────────────────────────────────────────────────────
                        if stop_checker and stop_checker():          # função vinda de G_TERMINAL
                            print("\n>>> Execução interrompida pelo usuário via interface.")
                            # 1) monta o que já foi calculado até aqui
                            EvolutionMatrixMatriz2 = [
                                None,             # curva ΔV
                                None           # curva −ΣPger
                            ]

                            # 2) monta   PORTAS_s_v   com os flags e vetores parciais
                            PORTAS_s_v = [
                                None,
                                None,
                                None,
                                None,
                                None,
                                None
                            ]

                            # 3) devolve exatamente o que a função promete retornar
                            return (EvolutionMatrixMatriz2, PORTAS_s_v, ZERO_PACOTE)
                        # ──────────────────────────────────────────────────────────────────────────────


                        if ATIVA_ESPEC[aux]!=0 and aux!=0:                                    
                            if status[aux]=='avante':
                                matriz_DadosBarra_universal[1][aux]=matriz_TravaPRoda[aux]+passoE3

                                Fluxo_divergente='no' 
                                try:
                                    (DeltaV, Delta0, PotP, PotQ, _, _, cont, MATRIZ_Y, Barras_PQ, JACOBIANA_INICIAL, JACOBIANA_FINAL, BarraQViola_estatica,_, _, _, _, _, _, _, _, _, _, VerificaSeViola,  _ , _ , _ )=CHAMA_FLNR_03_LTT (matrizSystem,matrizSystem2,matriz_DadosBarra_universal,infoVctrl,MODELin,Tolerancia,'no', None, None, None, None, None, None, None, None, 'no', None, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY)
                                    DeltaV=[float(x) for x in DeltaV]
                                    Delta0=[float(x) for x in Delta0]
                                    PotP=[float(x) for x in PotP]
                                    PotQ=[float(x) for x in PotQ] 

                                    if cont==200:
                                        saveAbnormalPoints(matriz_DadosBarra_universal[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN)                                     

                                except Exception as e:
                                    Fluxo_divergente='yes' 
                                    Observation='FLUXO DIVERGENTE.'
                                    DeltaV=[0]*len(ATIVA_ESPEC)  
                                    Delta0=[0]*len(ATIVA_ESPEC) 
                                    PotP=[0]*len(ATIVA_ESPEC)
                                    PotQ=[0]*len(ATIVA_ESPEC)
                                    Barras_PQ= ['FLUXO DIVERGENTE']*len(ATIVA_ESPEC)
                                    cont=0  
                                    JACOBIANA_FINAL=[] 
                                    JACOBIANA_INICIAL=[]
                                    MATRIZ_Y=[]
                                    stringQauntidadeQViolaInical='FLUXO DIVERGENTE!'
                                    stingBarraQViola_estatica='FLUXO DIVERGENTE!'
                                    saveDivergencies(matriz_DadosBarra_universal[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN)

                                if Fluxo_divergente=='no':
                                    try:
                                        
                                        erro=[0]*len(DeltaV)
                                        for aux2 in range(len(DeltaV)):
                                            erro[aux2]=float(DeltaV[aux2]-DeltaV_0[aux2]) 
                                        #print(erro.index(max(erro)),' ___ ', max(erro))                         
                                        vet_erroDaRodada[aux]=erro   
                                        DeltaVsave[aux]=DeltaV
                                        PotPsave[aux]=PotP                    
                                        LISTA_maior_valor[aux] = max(erro)  
                                        LISTAindex_maior_valor[aux] = erro.index(max(erro))  
                                        
                                        for i in range(len(LISTAindex_maior_valor)):
                                            if ATIVA_ESPEC[LISTAindex_maior_valor[i]]==0:
                                                LISTAindex_maior_valor[i]=0
                                                LISTA_maior_valor[i]=0

                                    except Exception as e:
                                        print('Fluxo inicialmente divergente.')
                            
                            for aux22 in range(len(matriz_DadosBarra_universal[1])):
                                matriz_DadosBarra_universal[1][aux22]=matriz_TravaPRoda[aux22]          
                                

                if cont_confirma_primeiraVez==0:
                    MaxMax=max(LISTA_maior_valor)                                    
                    MaxMaxindex=LISTA_maior_valor.index(MaxMax)
                    LISTAPrioritys[MaxMaxindex]='avante'
                    LISTAindex_maior_valor_estatica.append(LISTAindex_maior_valor)
                    LISTA_maior_valor_estatica.append(LISTA_maior_valor)
                    cont_confirma_primeiraVez=1
                    res2=None

                else:
                    # Obtém os valores únicos presentes na lista
                    valores_unicos = set(LISTAindex_maior_valor)
                    res1, res2 = processar_matrizes(LISTAindex_maior_valor_estatica, LISTA_maior_valor_estatica)
                    
                    if trava_imprimir==0 and res1!=None:
                        res2_res1_ordenado = sorted(zip(res2, res1), reverse=True)
                        res2_ordenado, res1_ordenado = zip(*res2_res1_ordenado)

                        # Converter para lista (se necessário)
                        res2_ordenado = list(res2_ordenado)
                        res1_ordenado = list(res1_ordenado)
                        print('📉 Barras de Maior Impacto sobre as tensões:')
                        print('     - São criadas duas listas de controle: Barras de maior impacto e' )
                        print('       o registro da maior queda de tensão encontrada ao subtrair a' )
                        print('       potência da barra de um degrau conhecido (passo).' )
                        print('     - A lista Barras de maior impacto corresponde a barra identificada' )
                        print('       cuja alteração pelo passo leva a maior queda de tensão de alguma' )
                        print('       barra do sistema. Esta barra não necessariamente corresponde a' )
                        print('       barra que teve a maior queda - a menos que sua potência comece' )
                        print('       a ser relevante sobre o sistema.' )
                        print('     - O algoritmo define a listagem a partir da queda de tensão registrada')
                        print('       e, portanto, apenas as barras PQ no momento incial da avaliação são')
                        print('       candidatas plausíveis. As barras PV são avaliadas caso caso nenhum')
                        print('       critério de parada seja atingido com a listagem.')
                        
                        vetor = [x + 1 for x in res1_ordenado]
                        imprimir_barras_e_quedas_numerado(vetor, [round(x, 5) for x in res2_ordenado], colunas=2)                        
                        #print('****************************************************************************') 
                        trava_imprimir=1   


                    if pegar_quemParouUltimo!=None:
                        for pegarQuemLimita in pegar_quemParouUltimo:
                            res1, res2 = remover_elemento_sincronizado(res1, res2, pegarQuemLimita)
                        

                    if max(res2)>MaxMax:
                        if LISTAPrioritys[MaxMaxindex]=='-' or LISTAPrioritys[MaxMaxindex]=='avante':
                            if ATIVA_ESPEC[MaxMaxindex]!=0:
                                MaxMax=max(res2)
                                LISTAPrioritys[MaxMaxindex]='parar'
                                status[MaxMaxindex]='parar'                    
                                MaxMaxindex=res1[res2.index(max(res2))]                    
                                LISTAPrioritys[MaxMaxindex]='avante'
                                status[MaxMaxindex]='avante' 


                    if len(valores_unicos) == 1:
                        valor_unico = valores_unicos.pop()  # Recupera o único valor
                    else:
                        LISTAindex_maior_valor_estatica.append(LISTAindex_maior_valor)
                        LISTA_maior_valor_estatica.append(LISTA_maior_valor)


                for aux_checaLimites in range(len(LISTAPrioritys)):
                    if LISTAPrioritys[aux_checaLimites]=='avante':
                        if matriz_DadosBarra_universal[1][aux_checaLimites]<matriz_TravaPSempre[aux_checaLimites]*(1-limite_variacao/100):
                            
                            Volta_textoAPATE(pegar_quemParouUltimo_PotRef, pegar_quemParouUltimo_PotVar, RegimeE3, 
                                                callback_barras, aux_checaLimites, DB_P_REF, (-1)*matriz_DadosBarra_universal[1][aux_checaLimites], pegar_quemParouUltimo)
                            
                            status[aux_checaLimites]='avante'
                           
                            matriz_DadosBarra_universal[1][aux_checaLimites]=matriz_DadosBarra_universal[1][aux_checaLimites]+passoE3
                      
                        else:    
                            matriz_DadosBarra_universal[1][aux_checaLimites]=matriz_TravaPSempre[aux_checaLimites]*(1-limite_variacao/100) 
                            status[aux_checaLimites]='parar' 
                            LISTAPrioritys[aux_checaLimites]='parar'
                            pegar_quemParouUltimo.append(aux_checaLimites)
                            pegar_quemParouUltimo_PotVar.append((-1)*matriz_DadosBarra_universal[1][aux_checaLimites])
                            if aux_checaLimites in DB_listBar:
                                pegar_quemParouUltimo_PotRef.append(DB_P_REF[aux_checaLimites])
                            
                            if res2!=None:
                                aumenta_rank=1    
                                if aumenta_rank<len(res2):
                                    aumenta_rank=aumenta_rank+1 
                                    outroMaior=kth_maior(res2, aumenta_rank)
                                    MaxMax=outroMaior
                                    MaxMaxindex=res1[res2.index(outroMaior)]
                                    LISTAPrioritys[MaxMaxindex]='avante'
                                    verifica_todosPreenchidos='no'
                                else:
                                    ORDEM_GERAL='PARAR'
                                    verifica_todosPreenchidos='yes'
                                    LIMITOU_AS_GRANDES_LES='yes'
                                    LIMITOU_AS_GRANDES_LES_val=matriz_DadosBarra_universal[1]

                        Fluxo_divergenteOficial='no' 
                        try:
                            (DeltaV, _ , PotP, PotQ , _, _, cont , _ , _ , _ , _ , _ ,_, _, _, _, _, _, _, _, _, _, _ , _ , _ , _ )=CHAMA_FLNR_03_LTT (matrizSystem,matrizSystem2,matriz_DadosBarra_universal,infoVctrl,MODELin,Tolerancia,'no', None, None, None, None, None, None, None, None, 'no', None, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY)
                            DeltaV=[float(x) for x in DeltaV]
                            PotP=[float(x) for x in PotP]
                            #PotP=[float(x) for x in PotP]
                            PotQ=[float(x) for x in PotQ]  

                            pot_p_gerada=[]
                            pot_q_gerada=[]
                            for i in range(len(PotP)):
                                # Cálculo das potências geradas
                                if infoVctrl[0][i]=='G' or infoVctrl[0][i]=='CS' or infoVctrl[0][i]=='swing':
                                    pot_p_gerada.append(PotP[i] - matriz_DadosBarra_universal[1][i])  # Potência P gerada    
                                    pot_q_gerada.append(PotQ[i] - matriz_DadosBarra_universal[2][i])  # Potência Q gerada                            
                            soma_p = np.sum(pot_p_gerada)
                            soma_q = np.sum(pot_q_gerada)
                            PotSger=np.sqrt(soma_p**2+soma_q**2)
                            fpGlobal=soma_p/PotSger                            

                            if cont==200:
                                saveAbnormalPoints(matriz_DadosBarra_universal[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN)      
                       
                        except Exception as e:
                            Fluxo_divergenteOficial='yes' 
                            saveDivergencies(matriz_DadosBarra_universal[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN)

                
                if Fluxo_divergenteOficial=='no':
                    
                    DeltaV_trajetory.append(DeltaV)
                    
                    somaPger=0
                    for auxilair in range(len(matriz_DadosBarra_universal[1])):
                        somaPger=somaPger+matriz_DadosBarra_universal[1][auxilair]
                        # if auxilair!=0:
                        #     if matriz_DadosBarra_universal[1][auxilair]>0:
                        #         print('segura aqui')                            
                    PotGer_trajetory.append((-1)*somaPger)   
                    PotGer_fatorDePotGlobal.append(fpGlobal) 

                contador_aux=0
                for auxiliar in range(len(status)):
                    if status[auxiliar]=='parar':
                        contador_aux=contador_aux+1
                
                if contador_aux==len(status):
                    ORDEM_GERAL='PARAR'

                for auxiliar_verificaseEstoura in range(len(DeltaV)):
                    if DeltaV[auxiliar_verificaseEstoura]>10^3:
                        ORDEM_GERAL='PARAR'
                        saveDivergencies(matriz_DadosBarra_universal[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN)
                
                if ORDEM_GERAL=='PARAR':        
                    pegar_quemParouUltimo.append(aux_checaLimites)                
                # if Fluxo_divergente=='yes':
                #     ORDEM_GERAL='PARAR' 
                #     print('PAROU POR EXPLODIR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!') 
                #print('Barras com potências alteradas: ', pegar_quemParouUltimo)   
                SALVAR_BARRAS_MIN=pegar_quemParouUltimo    
                salva_ultimo_min=aux_checaLimites


    print('\n')
    print('🛑  Barras com potências ativas efetivamente ALTERADAS')
    print('      - Percentual de Alteração:', limite_variacao, '%')

    if SALVAR_BARRAS_ADICT:
        vetor = [x + 1 for x in SALVAR_BARRAS_ADICT][:-1]
        print("      - Barras:")
        for i in range(0, len(vetor), 17):
            linha = vetor[i:i+17]
            texto_barras = ", ".join(str(b) for b in linha)
            print(f"        {texto_barras}")
        print()
        if LIMITOU_AS_GRANDES_PES == 'yes':
            print('✅ Todas barras de maiores impactos alteradas com sucesso.\n')

    if SALVAR_BARRAS_MIN:
        vetor = [x + 1 for x in SALVAR_BARRAS_MIN][:-1]
        print("      - Barras:")
        for i in range(0, len(vetor), 17):
            linha = vetor[i:i+17]
            texto_barras = ", ".join(str(b) for b in linha)
            print(f"        {texto_barras}")
        print()
        if LIMITOU_AS_GRANDES_LES == 'yes':
            print('✅ Todas barras de maiores impactos alteradas com sucesso.\n')


    EvolutionMatrixMatriz2=[]
    EvolutionMatrixMatriz2.append(DeltaV_trajetory)
    EvolutionMatrixMatriz2.append(PotGer_trajetory)
    PORTAS_s_v=[LIMITOU_AS_GRANDES_LES, LIMITOU_AS_GRANDES_PES, LIMITOU_AS_GRANDES_LES_val, LIMITOU_AS_GRANDES_PES_val, maior_valor_trajetory_pot, PotGer_fatorDePotGlobal]

    return (EvolutionMatrixMatriz2, PORTAS_s_v, ZERO_PACOTE)  



def parse_ESCOLHER(esc_bar_str):
    """
    Recebe uma string no formato em que '_' separa barras e '-' indica intervalos.
    Exemplo: '116_19-21_51' → [116, 19, 20, 21, 51]
    """
    partes = esc_bar_str.split('_')  # separa os segmentos
    resultado = []
    
    for parte in partes:
        if '-' in parte:  # indica um intervalo
            inicio, fim = parte.split('-')
            # Converte os extremos para inteiro e gera a sequência (inclusivo)
            resultado.extend(range(int(inicio), int(fim) + 1))
        else:
            resultado.append(int(parte))
    
    for i in range(len(resultado)):
        resultado[i]=resultado[i]-1

    return resultado

    
def remove_duplicates_preserve_order(intervals):
    """
    Recebe uma lista de inteiros e retorna uma nova lista com cada elemento
    aparecendo apenas uma vez, na ordem em que aparecem pela primeira vez.
    
    Parâmetros:
      intervals (list): Lista de números inteiros.
    
    Retorna:
      list: Lista com os elementos únicos em sua ordem de aparição.
    """
    seen = set()
    result = []
    for item in intervals:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result


def juntaPraGrafico_LEV(EvolutionMatrixMatriz2, DeltaV_trajetory, RegimeE3, PotGer_trajetory, ZERO_PACOTE):
    EvolutionMatrixMatriz2_lin1=[]
    EvolutionMatrixMatriz2_lin2=[]

    matriz_TravaPSempre2=[0]*len(ZERO_PACOTE[6])
    for aux in range(len(ZERO_PACOTE[6])):
        matriz_TravaPSempre2[aux]=-1*ZERO_PACOTE[6][aux] 

    if EvolutionMatrixMatriz2[0]!=None:
        for i in range(len(DeltaV_trajetory)):
            EvolutionMatrixMatriz2_lin1.append(DeltaV_trajetory[len(DeltaV_trajetory)-i-1])
            EvolutionMatrixMatriz2_lin2.append(PotGer_trajetory[len(DeltaV_trajetory)-i-1])
        
        if RegimeE3=='LEVE':
            for i in range(len(EvolutionMatrixMatriz2[0])):
                EvolutionMatrixMatriz2_lin1.append(EvolutionMatrixMatriz2[0][len(EvolutionMatrixMatriz2[0])-i-1])
                EvolutionMatrixMatriz2_lin2.append(EvolutionMatrixMatriz2[1][len(EvolutionMatrixMatriz2[0])-i-1])
        elif RegimeE3=='AMBOS':                    
            for i in range(len(EvolutionMatrixMatriz2[0])):
                EvolutionMatrixMatriz2_lin1.append(EvolutionMatrixMatriz2[0][i])
                EvolutionMatrixMatriz2_lin2.append(EvolutionMatrixMatriz2[1][i])

        EvolutionMatrixMatriz2=[]
        EvolutionMatrixMatriz2.append(EvolutionMatrixMatriz2_lin1)
        EvolutionMatrixMatriz2.append(EvolutionMatrixMatriz2_lin2)
    else:
        return(None, matriz_TravaPSempre2)
    
    return(EvolutionMatrixMatriz2, matriz_TravaPSempre2)




def complementa_LEV(ZERO_PACOTE, PORTAS_s_v_LEV, PORTAS_s_v, RegimeE3, limite_variacao, 
                    limite_variacao_lev, fpGlobal_Vector_complement01_lev, fpGlobal_Vector_complement01_pes, 
                    passoE3, Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN, stop_checker, 
                    EvolutionMatrixMatriz2, MODELin, ComutacaoMaxima, callback_barras):
    
    vetor_novos=[]

    infoVctrl=ZERO_PACOTE[3]

    EvolutionMatrixMatriz2 = list(EvolutionMatrixMatriz2)
    EvolutionMatrixMatriz2[0] = list(EvolutionMatrixMatriz2[0])
    EvolutionMatrixMatriz2[1] = list(EvolutionMatrixMatriz2[1])

    matriz_DadosBarra=ZERO_PACOTE[2]   
    Fluxo_divergente_0=ZERO_PACOTE[4]
    ATIVA_ESPEC=ZERO_PACOTE[5]
    matrizSystem=ZERO_PACOTE[0]
    matrizSystem2=ZERO_PACOTE[1]
    matriz_TravaPSempre2=ZERO_PACOTE[6]
    MatrizY=ZERO_PACOTE[7]


    status=['avante']*len(matriz_DadosBarra[1])
    DeltaV_trajetory=[]
    PotGer_trajetory=[]

    if PORTAS_s_v[0]=='yes':
        matriz_DadosBarra[1]=PORTAS_s_v[2]
    else:
        matriz_DadosBarra[1]=PORTAS_s_v_LEV[2]

    #matriz_DadosBarra[1]=PORTAS_s_v[2]
    matriz_TravaPSempre=[0]*len(matriz_DadosBarra[1])
    matriz_TravaPSempreNew=[0]*len(matriz_DadosBarra[1])
    for aux in range(len(matriz_DadosBarra[1])):
        matriz_TravaPSempre[aux]=matriz_DadosBarra[1][aux] 
        matriz_TravaPSempreNew[aux]=-1*matriz_DadosBarra[1][aux]

    PotRemovida=[]
    PotRef=[]
    bars=[]

    primeiraColeta='yes'
    coleta='no'
    bars_salvas=[]
    PotRef_salvas=[]

    PotRemovida_lin=[]
    PotRef_lin=[]
    bars_lin=[]

    ORDEM_GERAL='AVANTE'
    ORDEM_GERAL_AUX='AVANTE'

    if Fluxo_divergente_0=='no':
        
        Fluxo_divergente='no'
        LISTAPrioritys=['-']*len(matriz_DadosBarra[1])
        if RegimeE3=='AMBOS':
            limite_variacao=limite_variacao_lev

        while ORDEM_GERAL=='AVANTE':
            primeira='yes'
            if stop_checker and stop_checker():
                print("\n>>> Execução interrompida pelo usuário via interface.")
            
                (EvolutionMatrixMatriz2, ponto_inicial)=juntaPraGrafico_LEV(EvolutionMatrixMatriz2, DeltaV_trajetory, RegimeE3, PotGer_trajetory, ZERO_PACOTE)
                return(EvolutionMatrixMatriz2, vetor_novos)

            CONT_VESE0=0
            for aux in range(len(matriz_DadosBarra[1])):
                if matriz_DadosBarra[1][aux]!=matriz_TravaPSempre2[aux]*(1-limite_variacao/100):
                    CONT_VESE0=CONT_VESE0+1   
                    LISTAPrioritys[aux]='avante'  
            
            if CONT_VESE0!=0 and ORDEM_GERAL_AUX=='AVANTE':
                
                for aux in range(len(matriz_DadosBarra[1])):
                    if stop_checker and stop_checker():
                        print("\n>>> Execução interrompida pelo usuário via interface.")
                        (EvolutionMatrixMatriz2, ponto_inicial)=juntaPraGrafico_LEV(EvolutionMatrixMatriz2, DeltaV_trajetory, RegimeE3, PotGer_trajetory, ZERO_PACOTE)
                        return(EvolutionMatrixMatriz2, vetor_novos)

                    if LISTAPrioritys[aux]=='avante':
                        if aux not in vetor_novos:
                            vetor_novos.append(aux)

                        matriz_DadosBarra[1][aux]=matriz_DadosBarra[1][aux]+passoE3
                        try:
                            (DeltaV, _ , PotP , PotQ , _, _, cont , _ , _ , _ , _ , _ ,_, _, _, _, _, _, _, _, _, _, _ ,  _ , _ , _ )=CHAMA_FLNR_03_LTT (matrizSystem,matrizSystem2,matriz_DadosBarra,infoVctrl,MODELin,Tolerancia,'no', None, None, None, None, None, None, None, None, 'no', None, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY)
                            DeltaV=[float(x) for x in DeltaV]
                            PotP=[float(x) for x in PotP]
                            PotQ=[float(x) for x in PotQ] 
                            
                            DeltaV_trajetory.append(DeltaV)
                        
                            somaPger=0
                            for auxilair in range(len(matriz_DadosBarra[1])):
                                somaPger=somaPger+matriz_DadosBarra[1][auxilair]                           
                            PotGer_trajetory.append((-1)*somaPger) 
                            
                            pot_p_gerada=[]
                            pot_q_gerada=[]
                            for i in range(len(PotP)):
                                # Cálculo das potências geradas
                                if infoVctrl[0][i]=='G' or infoVctrl[0][i]=='CS' or infoVctrl[0][i]=='swing':
                                    pot_p_gerada.append(PotP[i] - matriz_DadosBarra[1][i])  # Potência P gerada    
                                    pot_q_gerada.append(PotQ[i] - matriz_DadosBarra[2][i])  # Potência Q gerada                                                           
                            soma_p = np.sum(pot_p_gerada)
                            soma_q = np.sum(pot_q_gerada)
                            PotSger=np.sqrt(soma_p**2+soma_q**2)
                            fpGlobal=soma_p/PotSger                                    
                            fpGlobal_Vector_complement01_lev.append(fpGlobal)

                            if matriz_DadosBarra[1][aux]<matriz_TravaPSempre[aux]*(1-limite_variacao/100):
                                ORDEM_GERAL='AVANTE' 
                            else:    
                                matriz_DadosBarra[1][aux]=matriz_TravaPSempre[aux]*(1-limite_variacao/100) 
                                LISTAPrioritys[aux]='parar'

                            for auxiliar_verificaseEstoura in range(len(DeltaV)):
                                if DeltaV[auxiliar_verificaseEstoura]>10^3:
                                    ORDEM_GERAL_AUX='PARAR' 
                                    saveDivergencies(matriz_DadosBarra[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN)                                   

                            if cont==200:
                                saveAbnormalPoints(matriz_DadosBarra[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN)    


                            PotRemovida_lin.append((-1)*matriz_DadosBarra[1][aux])
                            PotRef_lin.append(matriz_TravaPSempreNew[aux])
                            bars_lin.append(aux+1)
                            if len(PotRef)==len(PotRemovida):
                                if primeira=='yes':
                                    primeira='no'
                                    porcentagens=comparar_percentual_reducao(PotRef, PotRemovida, 'LEVE')
                                    if callback_barras:
                                        vetor_arredondado = np.round(porcentagens, 2)
                                        callback_barras(bars,vetor_arredondado)
                                    else:
                                        print("Barras alteradas:", aux+1)
                            
                            if coleta=='yes':
                                if primeiraColeta=='yes':
                                    primeiraColeta='no'
                                    bars_salvas=bars
                                    PotRef_salvas=PotRef                        


                        except Exception as e:
                            Fluxo_divergente='yes' 
                            ORDEM_GERAL='PARAR'
                            saveDivergencies(matriz_DadosBarra[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN) 
                        
            else:
                ORDEM_GERAL='PARAR'

            PotRef=PotRef_lin
            PotRemovida=PotRemovida_lin
            bars=bars_lin
            PotRemovida_lin=[]
            PotRef_lin=[]
            bars_lin=[]
            coleta='yes'

        (EvolutionMatrixMatriz2, _ )=juntaPraGrafico_LEV(EvolutionMatrixMatriz2, DeltaV_trajetory, RegimeE3, PotGer_trajetory, ZERO_PACOTE)
    return(EvolutionMatrixMatriz2, vetor_novos)




def complementa_PES(ZERO_PACOTE, PORTAS_s_v_PES, PORTAS_s_v, RegimeE3, limite_variacao, 
                    limite_variacao_pes, fpGlobal_Vector_complement01_lev, fpGlobal_Vector_complement01_pes, 
                    passoE3, Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN, stop_checker, 
                    EvolutionMatrixMatriz2, MODELin, ComutacaoMaxima, callback_barras):
    
    vetor_novos=[]

    infoVctrl=ZERO_PACOTE[3]

    EvolutionMatrixMatriz2 = list(EvolutionMatrixMatriz2)
    EvolutionMatrixMatriz2[0] = list(EvolutionMatrixMatriz2[0])
    EvolutionMatrixMatriz2[1] = list(EvolutionMatrixMatriz2[1])

    matriz_DadosBarra=ZERO_PACOTE[2]   
    Fluxo_divergente_0=ZERO_PACOTE[4]
    ATIVA_ESPEC=ZERO_PACOTE[5]
    #infoVctrl=ZERO_PACOTE[3]
    matrizSystem=ZERO_PACOTE[0]
    matrizSystem2=ZERO_PACOTE[1]
    MatrizY=ZERO_PACOTE[7]

    matriz_TravaPSempre2=ZERO_PACOTE[6]
    status=['avante']*len(matriz_DadosBarra[1])
    DeltaV_trajetory=[]
    PotGer_trajetory=[]

    if PORTAS_s_v[1]=='yes':
        matriz_DadosBarra[1]=PORTAS_s_v[3]
    else:
        matriz_DadosBarra[1]=PORTAS_s_v_PES[3]

    matriz_TravaPSempre=[0]*len(matriz_DadosBarra[1])
    matriz_TravaPSempreNew=[0]*len(matriz_DadosBarra[1])
    for aux in range(len(matriz_DadosBarra[1])):
        matriz_TravaPSempre[aux]=matriz_DadosBarra[1][aux] 
        matriz_TravaPSempreNew[aux]=-1*matriz_DadosBarra[1][aux]

    PotRemovida=[]
    PotRef=[]
    bars=[]

    primeiraColeta='yes'
    coleta='no'
    bars_salvas=[]
    PotRef_salvas=[]

    PotRemovida_lin=[]
    PotRef_lin=[]
    bars_lin=[]

    ORDEM_GERAL='AVANTE'
    ORDEM_GERAL_AUX='AVANTE'
    if Fluxo_divergente_0=='no':
        
        Fluxo_divergente='no'
        LISTAPrioritys=['-']*len(matriz_DadosBarra[1])
        if RegimeE3=='AMBOS':
            limite_variacao=limite_variacao_pes

        while ORDEM_GERAL=='AVANTE':
            primeira='yes'
            if stop_checker and stop_checker():
                print("\n>>> Execução interrompida pelo usuário via interface.")
                EvolutionMatrixMatriz2[0]=EvolutionMatrixMatriz2[0]+DeltaV_trajetory
                EvolutionMatrixMatriz2[1]=EvolutionMatrixMatriz2[1]+PotGer_trajetory
                return(EvolutionMatrixMatriz2, vetor_novos)

            CONT_VESE0=0
            for aux in range(len(matriz_DadosBarra[1])):
                if matriz_DadosBarra[1][aux]!=matriz_TravaPSempre2[aux]*(1+limite_variacao/100):
                    CONT_VESE0=CONT_VESE0+1   
                    LISTAPrioritys[aux]='avante'  
            
            if CONT_VESE0!=0 and ORDEM_GERAL_AUX=='AVANTE':
                for aux in range(len(matriz_DadosBarra[1])):
                    
                    if stop_checker and stop_checker():
                        print("\n>>> Execução interrompida pelo usuário via interface.")
                        EvolutionMatrixMatriz2[0]=EvolutionMatrixMatriz2[0]+DeltaV_trajetory
                        EvolutionMatrixMatriz2[1]=EvolutionMatrixMatriz2[1]+PotGer_trajetory
                        return(EvolutionMatrixMatriz2, vetor_novos)
                    

                    if LISTAPrioritys[aux]=='avante':
                        if aux not in vetor_novos:
                            vetor_novos.append(aux)

                        # if callback_barras:
                        #     callback_barras([aux+1])
                        # else:
                        #     print("Barras alteradas:", aux)
                        #Fluxo_divergente='no' 
                        matriz_DadosBarra[1][aux]=matriz_DadosBarra[1][aux]-passoE3
                        try:
                            (DeltaV, _ , PotP , PotQ , _, _, cont , _ , _ , _ , _ , _ ,_, _, _, _, _, _, _, _, _, _, _ ,  _ , _ , _ )=CHAMA_FLNR_03_LTT (matrizSystem,matrizSystem2,matriz_DadosBarra,infoVctrl,MODELin,Tolerancia,'no', None, None, None, None, None, None, None, None, 'no', None, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY)
                            DeltaV=[float(x) for x in DeltaV]
                            PotP=[float(x) for x in PotP]
                            PotQ=[float(x) for x in PotQ] 

                            DeltaV_trajetory.append(DeltaV)
                        
                            somaPger=0
                            for auxilair in range(len(matriz_DadosBarra[1])):
                                somaPger=somaPger+matriz_DadosBarra[1][auxilair]                           
                            PotGer_trajetory.append((-1)*somaPger) 
                            
                            
                            pot_p_gerada=[]
                            pot_q_gerada=[]
                            for i in range(len(PotP)):
                                # Cálculo das potências geradas
                                if infoVctrl[0][i]=='G' or infoVctrl[0][i]=='CS' or infoVctrl[0][i]=='swing':
                                    pot_p_gerada.append(PotP[i] - matriz_DadosBarra[1][i])  # Potência P gerada    
                                    pot_q_gerada.append(PotQ[i] - matriz_DadosBarra[2][i])  # Potência Q gerada                                                           
                            soma_p = np.sum(pot_p_gerada)
                            soma_q = np.sum(pot_q_gerada)
                            PotSger=np.sqrt(soma_p**2+soma_q**2)
                            fpGlobal=soma_p/PotSger                                    
                            fpGlobal_Vector_complement01_pes.append(fpGlobal)                                    


                            if matriz_DadosBarra[1][aux]>matriz_TravaPSempre[aux]*(1+limite_variacao/100):
                                ORDEM_GERAL='AVANTE' 
                            else:    
                                matriz_DadosBarra[1][aux]=matriz_TravaPSempre[aux]*(1+limite_variacao/100) 
                                LISTAPrioritys[aux]='parar'

                            for auxiliar_verificaseEstoura in range(len(DeltaV)):
                                if DeltaV[auxiliar_verificaseEstoura]>10^3:
                                    ORDEM_GERAL_AUX='PARAR' 
                                    saveDivergencies(matriz_DadosBarra[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN) 

                            if cont==200:
                                saveAbnormalPoints(matriz_DadosBarra[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN)  


                            PotRemovida_lin.append((-1)*matriz_DadosBarra[1][aux])
                            PotRef_lin.append(matriz_TravaPSempreNew[aux])
                            bars_lin.append(aux+1)
                            if len(PotRef)==len(PotRemovida):
                                if primeira=='yes':
                                    primeira='no'
                                    porcentagens=comparar_percentual_reducao(PotRef, PotRemovida, 'LEVE')
                                    if callback_barras:
                                        vetor_arredondado = np.round(porcentagens, 2)
                                        callback_barras(bars,vetor_arredondado)
                                    else:
                                        print("Barras alteradas:", aux+1)
                            
                            if coleta=='yes':
                                if primeiraColeta=='yes':
                                    primeiraColeta='no'
                                    bars_salvas=bars
                                    PotRef_salvas=PotRef    

                        except Exception as e:
                            Fluxo_divergente='yes' 
                            ORDEM_GERAL='PARAR'
                            saveDivergencies(matriz_DadosBarra[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN) 
            else:
                ORDEM_GERAL='PARAR' 
            
            PotRef=PotRef_lin
            PotRemovida=PotRemovida_lin
            bars=bars_lin
            PotRemovida_lin=[]
            PotRef_lin=[]
            bars_lin=[]
            coleta='yes'

        EvolutionMatrixMatriz2[0]=EvolutionMatrixMatriz2[0]+DeltaV_trajetory
        EvolutionMatrixMatriz2[1]=EvolutionMatrixMatriz2[1]+PotGer_trajetory
    return(EvolutionMatrixMatriz2, vetor_novos)




def CHAMA_PVCURVE_MAIORES(PORTAS_E3_IN, stop_checker=None, callback_barras=None):
    
    SYSname=PORTAS_E3_IN[0]
    MODELin=PORTAS_E3_IN[1]
    Tolerancia=PORTAS_E3_IN[2]
    HabiltAval_Lim_Reativo=PORTAS_E3_IN[3]
    S_base=PORTAS_E3_IN[4]
    Desabilitar_CS=PORTAS_E3_IN[5]
    Tipo_de_logicaSuplementar=PORTAS_E3_IN[6]
    ComutacaoMaxima=PORTAS_E3_IN[7]
    Ativar_inverter=PORTAS_E3_IN[8]
    passoE3=PORTAS_E3_IN[9]
    limite_variacao=PORTAS_E3_IN[10]
    RegimeE3=PORTAS_E3_IN[11]
    limite_variacao_lev=PORTAS_E3_IN[12]
    limite_variacao_pes=PORTAS_E3_IN[13]
    Estrategia=PORTAS_E3_IN[14]
    ESCOLHER=PORTAS_E3_IN[15]
    GirarTrafo=PORTAS_E3_IN[16]
    #limitarCalculo=PORTAS_E3_IN[16]

    fpGlobal_Vector_complement01_pes=[]
    fpGlobal_Vector_complement01_lev=[]
    PORTAS_s_v_in=[None, None]
    EvolutionMatrixMatriz2=[None, None]
    if Estrategia=='MAIORES':
        if RegimeE3=='LEVE' or RegimeE3=='PESADO':
            PORTAS_s_v=['no', 'no', None, None, None]
            ( EvolutionMatrixMatriz2, PORTAS_s_v, ZERO_PACOTE) = GoPC_generator_PVcurve_MAIORES(PORTAS_s_v, PORTAS_E3_IN, limite_variacao, RegimeE3, stop_checker, callback_barras)
            PORTAS_s_v_LEV=['no', 'no', None, None, None]
            PORTAS_s_v_PES=['no', 'no', None, None, None]
        elif RegimeE3=='AMBOS':
            PORTAS_s_v=['no', 'no', None, None, None]
            RegimeE3_lev='LEVE' 
            
            if limite_variacao_lev!=None:
                ( EvolutionMatrixMatriz2_LEV, PORTAS_s_v_LEV, ZERO_PACOTE) = GoPC_generator_PVcurve_MAIORES(PORTAS_s_v, PORTAS_E3_IN, limite_variacao_lev, RegimeE3_lev, stop_checker, callback_barras)
            else:
                if limite_variacao!=None:
                    ( EvolutionMatrixMatriz2_LEV, PORTAS_s_v_LEV, ZERO_PACOTE) = GoPC_generator_PVcurve_MAIORES(PORTAS_s_v, PORTAS_E3_IN, limite_variacao, RegimeE3_lev, stop_checker, callback_barras)            
                else:
                    print('PREENCHA ALGUM DOS CAMPOS DE LIMITE DE POTÊNCIA')

            # -------------------------------------------------

            # Aguarda o utilizador clicar em “Continuar”
            # -------------------------------------------------
            if stop_checker is not None:
                print("\n>>> Regime LEVE finalizado ou interrompido.")
                print("       - Aguardando autorização para iniciar o PESADO…")
                while stop_checker():           # bloqueia enquanto estiver em pausa
                    time.sleep(0.2)
            #-------------------------------------------------
            #Agora podemos calcular o regime PESADO

            RegimeE3_pes='PESADO' 
            if limite_variacao_pes!=None:
                ( EvolutionMatrixMatriz2_PES, PORTAS_s_v_PES , _ ) = GoPC_generator_PVcurve_MAIORES(PORTAS_s_v, PORTAS_E3_IN, limite_variacao_pes, RegimeE3_pes, stop_checker, callback_barras)
            else:
                if limite_variacao!=None:
                    ( EvolutionMatrixMatriz2_PES, PORTAS_s_v_PES , _ ) = GoPC_generator_PVcurve_MAIORES(PORTAS_s_v, PORTAS_E3_IN, limite_variacao, RegimeE3_pes, stop_checker, callback_barras)           
                else:
                    print('PREENCHA ALGUM DOS CAMPOS DE LIMITE DE POTÊNCIA')
            
            EvolutionMatrixMatriz2_lin1=[]
            EvolutionMatrixMatriz2_lin2=[]
            EvolutionMatrixMatriz2=[]
            if EvolutionMatrixMatriz2_LEV[0]!=None and EvolutionMatrixMatriz2_PES[0]!=None:
                try:
                    for i in range(len(EvolutionMatrixMatriz2_LEV[0])):
                        EvolutionMatrixMatriz2_lin1.append(EvolutionMatrixMatriz2_LEV[0][len(EvolutionMatrixMatriz2_LEV[0])-i-1])
                        EvolutionMatrixMatriz2_lin2.append(EvolutionMatrixMatriz2_LEV[1][len(EvolutionMatrixMatriz2_LEV[0])-i-1])
                    for i in range(len(EvolutionMatrixMatriz2_PES[0])):
                        EvolutionMatrixMatriz2_lin1.append(EvolutionMatrixMatriz2_PES[0][i])
                        EvolutionMatrixMatriz2_lin2.append(EvolutionMatrixMatriz2_PES[1][i])
                except:
                    EvolutionMatrixMatriz2_lin1=None
                    EvolutionMatrixMatriz2_lin2=None
                EvolutionMatrixMatriz2.append(EvolutionMatrixMatriz2_lin1)
                EvolutionMatrixMatriz2.append(EvolutionMatrixMatriz2_lin2)
            elif EvolutionMatrixMatriz2_LEV[0]==None and EvolutionMatrixMatriz2_PES[0]!=None:
                try:
                    for i in range(len(EvolutionMatrixMatriz2_PES[0])):
                        EvolutionMatrixMatriz2_lin1.append(EvolutionMatrixMatriz2_PES[0][i])
                        EvolutionMatrixMatriz2_lin2.append(EvolutionMatrixMatriz2_PES[1][i])
                except:
                    EvolutionMatrixMatriz2_lin1=None
                    EvolutionMatrixMatriz2_lin2=None
                EvolutionMatrixMatriz2.append(EvolutionMatrixMatriz2_lin1)
                EvolutionMatrixMatriz2.append(EvolutionMatrixMatriz2_lin2)
            elif EvolutionMatrixMatriz2_LEV[0]!=None and EvolutionMatrixMatriz2_PES[0]==None:
                try:
                    for i in range(len(EvolutionMatrixMatriz2_LEV[0])):
                        EvolutionMatrixMatriz2_lin1.append(EvolutionMatrixMatriz2_LEV[0][len(EvolutionMatrixMatriz2_LEV[0])-i-1])
                        EvolutionMatrixMatriz2_lin2.append(EvolutionMatrixMatriz2_LEV[1][len(EvolutionMatrixMatriz2_LEV[0])-i-1])
                except:
                    EvolutionMatrixMatriz2_lin1=None
                    EvolutionMatrixMatriz2_lin2=None
                EvolutionMatrixMatriz2.append(EvolutionMatrixMatriz2_lin1)
                EvolutionMatrixMatriz2.append(EvolutionMatrixMatriz2_lin2)                
        infoVctrl=ZERO_PACOTE[3]

        if EvolutionMatrixMatriz2!=[]:
            if EvolutionMatrixMatriz2[0]!=None:
                if RegimeE3=='LEVE' or RegimeE3=='AMBOS':
                    if PORTAS_s_v[0]=='yes' or PORTAS_s_v_LEV[0]=='yes':
                        print('\n______________________________________________________________________________')
                        print("🪶 Avaliação de regime LEVE: Complementando com barras NÃO LISTADAS.")
                        print('     - Desligamento de cargas (potência ativa). ')
                        print('     - Aleteração SEQUENCIAL nas potências das Barras NÃO avaliadas na listagem')
                        print('       de maiores impactos sobre a queda de tensão.\n')
                        EvolutionMatrixMatriz2, vetor_novos_lev=complementa_LEV(ZERO_PACOTE, PORTAS_s_v_LEV, PORTAS_s_v, RegimeE3, limite_variacao, 
                                    limite_variacao_lev, fpGlobal_Vector_complement01_lev, fpGlobal_Vector_complement01_pes, 
                                    passoE3, Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN, stop_checker, 
                                    EvolutionMatrixMatriz2, MODELin, ComutacaoMaxima, callback_barras)      
                        
                        if vetor_novos_lev:  # verifica se não está vazio
                            vetor_novos_lev = [x + 1 for x in vetor_novos_lev]
                            print('     - Barras:')
                            for i in range(0, len(vetor_novos_lev), 17):
                                linha = vetor_novos_lev[i:i+17]
                                texto_barras = ", ".join(str(b) for b in linha)
                                print(f"        {texto_barras}")                                    

                if RegimeE3=='PESADO' or RegimeE3=='AMBOS':
                    if PORTAS_s_v[1]=='yes' or PORTAS_s_v_PES[1]=='yes':
                        print('\n______________________________________________________________________________')
                        print("🗿 Avaliação de regime PESADO: Complementando com barras NÃO LISTADAS.")
                        print('     - Religamento de cargas (potência ativa). ')
                        print('     - Aleteração SEQUENCIAL nas potências das Barras NÃO avaliadas na listagem')
                        print('       de maiores impactos sobre a queda de tensão.\n')
                        EvolutionMatrixMatriz2, vetor_novos_pes=complementa_PES(ZERO_PACOTE, PORTAS_s_v_PES, PORTAS_s_v, RegimeE3, limite_variacao, 
                                    limite_variacao_pes, fpGlobal_Vector_complement01_lev, fpGlobal_Vector_complement01_pes, 
                                    passoE3, Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN, stop_checker, 
                                    EvolutionMatrixMatriz2, MODELin, ComutacaoMaxima, callback_barras)
                        if vetor_novos_pes:  # verifica se não está vazio
                            vetor_novos_pes = [x + 1 for x in vetor_novos_pes]
                            print('     - Barras:')                            
                            for i in range(0, len(vetor_novos_pes), 17):
                                linha = vetor_novos_pes[i:i+17]
                                texto_barras = ", ".join(str(b) for b in linha)
                                print(f"        {texto_barras}") 


        if RegimeE3=='LEVE' or RegimeE3=='PESADO':
            fpGlobal_Vector=PORTAS_s_v[5] 

        elif RegimeE3=='AMBOS':
            fpGlobal_Vector=[]
            try:
                for aux_invert in range(len(PORTAS_s_v_LEV[5])):
                    fpGlobal_Vector.append(PORTAS_s_v_LEV[5][len(PORTAS_s_v_LEV[5])-aux_invert-1])
                fpGlobal_Vector=fpGlobal_Vector+PORTAS_s_v_PES[5]
            except:
                fpGlobal_Vector=None

        if fpGlobal_Vector_complement01_lev!=[]:
            ajudaInverter=[]
            for aux_invert in range(len(fpGlobal_Vector_complement01_lev)):
                ajudaInverter.append(fpGlobal_Vector_complement01_lev[len(fpGlobal_Vector_complement01_lev)-aux_invert-1])

            fpGlobal_Vector=ajudaInverter+fpGlobal_Vector
        if fpGlobal_Vector_complement01_pes!=[]:
           fpGlobal_Vector=fpGlobal_Vector+fpGlobal_Vector_complement01_pes
    else:
        return (None, None, None)

    matriz_TravaPSempre2=[0]*len(ZERO_PACOTE[6])
    for aux in range(len(ZERO_PACOTE[6])):
        matriz_TravaPSempre2[aux]=-1*ZERO_PACOTE[6][aux] 

    return (EvolutionMatrixMatriz2, infoVctrl, fpGlobal_Vector, matriz_TravaPSempre2)



def juntaPraGraficoESCOLHER (RegimeE3, EvolutionMatrixMatriz2_lin1, EvolutionMatrixMatriz2_lin2,
                            EvolutionMatrixMatriz2_lin11, EvolutionMatrixMatriz2_lin22, 
                            PORTAS_E3_OUT_esc_lev, PORTAS_E3_OUT_esc_pes):
    if RegimeE3 == 'AMBOS':
        EvolutionMatrixMatriz2_lin111 = []
        EvolutionMatrixMatriz2_lin222 = []
        for i in range(len(EvolutionMatrixMatriz2_lin1)):
            EvolutionMatrixMatriz2_lin111.append(EvolutionMatrixMatriz2_lin1[len(EvolutionMatrixMatriz2_lin1)-i-1])
            EvolutionMatrixMatriz2_lin222.append(EvolutionMatrixMatriz2_lin2[len(EvolutionMatrixMatriz2_lin2)-i-1])
        for i in range(len(EvolutionMatrixMatriz2_lin11)):
            EvolutionMatrixMatriz2_lin111.append(EvolutionMatrixMatriz2_lin11[i])
            EvolutionMatrixMatriz2_lin222.append(EvolutionMatrixMatriz2_lin22[i])
        EvolutionMatrixMatriz2 = [EvolutionMatrixMatriz2_lin111, EvolutionMatrixMatriz2_lin222]
        PORTAS_E3_OUT_esc = list(reversed(PORTAS_E3_OUT_esc_lev)) + PORTAS_E3_OUT_esc_pes

    elif RegimeE3 == 'LEVE':
        EvolutionMatrixMatriz2 = [EvolutionMatrixMatriz2_lin1, EvolutionMatrixMatriz2_lin2]
        PORTAS_E3_OUT_esc = list(reversed(PORTAS_E3_OUT_esc_lev))

    elif RegimeE3 == 'PESADO':
        EvolutionMatrixMatriz2 = [EvolutionMatrixMatriz2_lin11, EvolutionMatrixMatriz2_lin22]
        PORTAS_E3_OUT_esc = PORTAS_E3_OUT_esc_pes
    
    return(EvolutionMatrixMatriz2, PORTAS_E3_OUT_esc)



def comparar_percentual_reducao(vetor_inicial, vetor_final, label=""):
    vetor_inicial = np.array(vetor_inicial, dtype=float).flatten()
    vetor_final = np.array(vetor_final, dtype=float).flatten()

    if vetor_inicial.shape != vetor_final.shape:
        raise ValueError("Vetores devem ter o mesmo tamanho.")

    # Ajusta sinal se for PESADO: potência final deve seguir o sinal da inicial
    if label.upper() == "PESADO":
        vetor_final = np.where(vetor_inicial >= 0, abs(vetor_final), -abs(vetor_final))

    with np.errstate(divide='ignore', invalid='ignore'):
        porcentagens = ((vetor_final - vetor_inicial) / np.abs(vetor_inicial)) * 100
        porcentagens = np.nan_to_num(porcentagens, nan=0.0, posinf=0.0, neginf=0.0)

    return porcentagens

def printagemFinal_ESC(bars_salvas, vetBarrsCtrl, matriz_DadosBarra, PotRef_salvas, regime):
    #print('\n')
    if bars_salvas:
        PotFinal=[]
        for aux_aux in range(len(bars_salvas)):
            if bars_salvas[aux_aux] in vetBarrsCtrl:
                PotFinal.append((-1)*matriz_DadosBarra[1][aux_aux])
        porcentagens=comparar_percentual_reducao(PotRef_salvas, PotFinal, regime)        
        
        print(f"\n📊 Dados da Alteração de Potência ({regime}):")
        for i, (barra, pref, pfim, pct) in enumerate(zip(bars_salvas, PotRef_salvas, PotFinal, porcentagens)):
            print(f"  - Barra {barra}: de {pref:.4f} → {pfim:.4f} pu  ({pct:.2f}%)")
    return()



def CHAMA_PVCURVE_ESCOLHER (PORTAS_E3_IN, PORTAS_E4_IN, stop_checker=None, callback_barras=None):
    
    SYSname=PORTAS_E3_IN[0]
    MODELin=PORTAS_E3_IN[1]
    Tolerancia=PORTAS_E3_IN[2]
    HabiltAval_Lim_Reativo=PORTAS_E3_IN[3]
    S_base=PORTAS_E3_IN[4]
    Desabilitar_CS=PORTAS_E3_IN[5]
    Tipo_de_logicaSuplementar=PORTAS_E3_IN[6]
    ComutacaoMaxima=PORTAS_E3_IN[7]
    Ativar_inverter=PORTAS_E3_IN[8]
    passoE3=PORTAS_E3_IN[9]
    limite_variacao=PORTAS_E3_IN[10]
    RegimeE3=PORTAS_E3_IN[11]
    limite_variacao_lev=PORTAS_E3_IN[12]
    limite_variacao_pes=PORTAS_E3_IN[13]
    Estrategia=PORTAS_E3_IN[14]
    ESCOLHER=PORTAS_E3_IN[15]
    GirarTrafo=PORTAS_E3_IN[16]
    #limitarCalculo=PORTAS_E3_IN[16]
    
    matrizSystem=PORTAS_E4_IN[0]
    matrizSystem2=PORTAS_E4_IN[1]

    if Estrategia=='ESCOLHER':
        ''' INICIALIZAÇÃO '''
        status_program='CDF' #---MANUAL or CDF (DADOS DE BARRA)
        alterar_tensao_decontrole_doCDF='X' #---X, A or B 
        QuantidadeDeDivergencias=1 
        # ([matrizSystem],[matrizSystem2])=Ler_Arquivo(SYSname)
        # len_sys0=len(matrizSystem)
        # for auxiliar_corrigeMS in range(len(matrizSystem)):
        #     matrizSystem[auxiliar_corrigeMS][18]=(-1)*matrizSystem[auxiliar_corrigeMS][18] ## IEEE30 or IEEE118 (linha em T)
        matrizSystem2 = corrige_duplicidadeDeLinha(matrizSystem2)
        ([matriz_DadosBarra],[infoVctrl])=DefineMatrizDadosBarra(matrizSystem, S_base, HabiltAval_Lim_Reativo, status_program, MODELin, None, alterar_tensao_decontrole_doCDF)
        (infoVctrl, matriz_DadosBarra)=liga_desliga_CS(matrizSystem, status_program, MODELin, None , alterar_tensao_decontrole_doCDF, S_base, HabiltAval_Lim_Reativo, Desabilitar_CS, matriz_DadosBarra, infoVctrl)
        
        modelagem_linha = MODELin # Tipo de modelo da linha (PI ou T)
        matrizSystem, matrizSystem2, modelagem_resultante = alterar_matrizes(matrizSystem, matrizSystem2, modelagem_linha)
        MatrizY=calcularMATRIZ_Y(matrizSystem, matrizSystem2, Ativar_inverter, GirarTrafo)
        
        intervals = parse_ESCOLHER(ESCOLHER)
        #intervals= [116, 43, 42, 51, 20, 21, 19, 56, 52, 85, 44, 57, 50, 32, 12, 49, 83, 107, 108, 100, 13, 97, 15, 105, 92, 94, 47, 38, 27, 82, 66, 101, 46, 1, 40, 96, 113, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        #intervals= [116, 43, 42, 51, 20, 21, 19, 56, 52, 85, 44, 57, 50, 32, 12, 49, 83, 107, 108, 100, 13, 97, 15, 105, 92, 94, 47, 38, 27, 82, 66, 101, 46, 1, 40, 96, 113, 117]
        #print('intervals=',intervals)
        intervals = remove_duplicates_preserve_order(intervals)
        contador_deBarr=len(intervals)


        matriz_TravaPSempre=[0]*len(matriz_DadosBarra[1])
        matriz_TravaPSempre2=[0]*len(matriz_DadosBarra[1])
        matriz_TravaPSempreNew=[0]*len(matriz_DadosBarra[1])

        
        vetBarrsCtrl=[]
        for aux in range(len(matriz_DadosBarra[1])):
            matriz_TravaPSempre[aux]=matriz_DadosBarra[1][aux] 
            matriz_TravaPSempre2[aux]=-1*matriz_DadosBarra[1][aux]
            matriz_TravaPSempreNew[aux]=-1*matriz_DadosBarra[1][aux]
            vetBarrsCtrl.append(aux+1)


        contador_deBarrANDAMENTO=0
        
        

        Fluxo_divergente='no'
        

        EvolutionMatrixMatriz2_lin1=[]
        EvolutionMatrixMatriz2_lin2=[]
        EvolutionMatrixMatriz2_lin11=[]
        EvolutionMatrixMatriz2_lin22=[]    
        EvolutionMatrixMatriz2=[]
        PORTAS_E3_OUT_esc=[]
        PORTAS_E3_OUT_esc_lev=[]
        PORTAS_E3_OUT_esc_pes=[]
        
        PotRemovida_lin=[]
        PotRef_lin=[]
        bars_lin=[]

        if RegimeE3=='AMBOS' or RegimeE3=='LEVE':
            print('\n______________________________________________________________________________')
            print("🪶 Avaliação de regime LEVE: Barras escolhidas")
            print('     - Desligamento de cargas (potência ativa). ')
            print('     - Aleteração SEQUENCIAL nas potências das barras escolhidas.')
            print('\n>>> Barras prenchidas sequêncialmente: ')
            #print('      - Barra: ',intervals, '\n')
            print("      - Barras:")
            vetor = [x + 1 for x in intervals]
            for i in range(0, len(vetor), 17):
                linha = vetor[i:i+17]
                texto_barras = ", ".join(str(b) for b in linha)
                print(f"        {texto_barras}")

            ORDEM_GERAL='AVANTE'
            LISTAPrioritys=['-']*len(matriz_DadosBarra[1])
            for aux in intervals:
                LISTAPrioritys[aux]='avante'         
            if RegimeE3=='AMBOS':
                limite_variacao=limite_variacao_lev   
                    
            for aux in range(len(matriz_DadosBarra[1])):
                matriz_DadosBarra[1][aux]=matriz_TravaPSempre[aux]

            PotRemovida=[]
            PotRef=[]
            bars=[]

            primeiraColeta='yes'
            coleta='no'
            bars_salvas=[]
            PotRef_salvas=[]
            while ORDEM_GERAL=='AVANTE':
                primeira='yes'
                for aux in range(len(matriz_DadosBarra[1])):

                    
                    if LISTAPrioritys[aux]=='avante':
                        matriz_DadosBarra[1][aux]=matriz_DadosBarra[1][aux]+passoE3
                      
                        try:
                            (DeltaV, _ , PotP, PotQ , _, _, cont , _, _ , _ , _ , _ ,_, _, _, _, _, _, _, _, _, _, _ ,  _ , Portas , _ )=CHAMA_FLNR_03_LTT (matrizSystem,matrizSystem2,matriz_DadosBarra,infoVctrl,MODELin,Tolerancia,'no', None, None, None, None, None, None, None, None, 'no', None, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY)
                            DeltaV=[float(x) for x in DeltaV]
                            #Delta0=[float(x) for x in Delta0]
                            PotP=[float(x) for x in PotP]
                            PotQ=[float(x) for x in PotQ] 
                            
                            somaPger=0
                            for auxilair in range(len(matriz_DadosBarra[1])):
                                somaPger=somaPger+matriz_DadosBarra[1][auxilair]                           
                            
                            pot_p_gerada=[]
                            pot_q_gerada=[]
                            for i in range(len(PotP)):
                                # Cálculo das potências geradas
                                if infoVctrl[0][i]=='G' or infoVctrl[0][i]=='CS' or infoVctrl[0][i]=='swing':
                                    pot_p_gerada.append(PotP[i] - matriz_DadosBarra[1][i])  # Potência P gerada    
                                    pot_q_gerada.append(PotQ[i] - matriz_DadosBarra[2][i])  # Potência Q gerada                            
                            soma_p = np.sum(pot_p_gerada)
                            soma_q = np.sum(pot_q_gerada)
                            PotSger=np.sqrt(soma_p**2+soma_q**2)
                            fpGlobal=soma_p/PotSger 


                            EvolutionMatrixMatriz2_lin1.append(DeltaV)
                            EvolutionMatrixMatriz2_lin2.append((-1)*somaPger)
                            PORTAS_E3_OUT_esc_lev.append(fpGlobal)
                            

                            if matriz_DadosBarra[1][aux]<matriz_TravaPSempre[aux]*(1-limite_variacao/100):
                                ORDEM_GERAL='AVANTE' 
                            else:    
                                matriz_DadosBarra[1][aux]=matriz_TravaPSempre[aux]*(1-limite_variacao/100) 
                                LISTAPrioritys[aux]='parar'                    
                            contador_deDivergenciasSeguidas=0

                            if stop_checker and stop_checker():
                                printagemFinal_ESC(bars_salvas, vetBarrsCtrl, matriz_DadosBarra, PotRef_salvas,'LEVE')
                                print('\n')
                                print(">>> Execução interrompida manualmente.")

                                (EvolutionMatrixMatriz2, PORTAS_E3_OUT_esc)=juntaPraGraficoESCOLHER (RegimeE3, EvolutionMatrixMatriz2_lin1, EvolutionMatrixMatriz2_lin2,
                                                        EvolutionMatrixMatriz2_lin11, EvolutionMatrixMatriz2_lin22, 
                                                        PORTAS_E3_OUT_esc_lev, PORTAS_E3_OUT_esc_pes)
                                
                                return EvolutionMatrixMatriz2, infoVctrl, PORTAS_E3_OUT_esc, matriz_TravaPSempre2

                            PotRemovida_lin.append((-1)*matriz_DadosBarra[1][aux])
                            PotRef_lin.append(matriz_TravaPSempreNew[aux])
                            bars_lin.append(aux+1)
                            if len(PotRef)==len(PotRemovida):
                                if primeira=='yes':
                                    primeira='no'
                                    porcentagens=comparar_percentual_reducao(PotRef, PotRemovida, 'LEVE')
                                    if callback_barras:
                                        vetor_arredondado = np.round(porcentagens, 2)
                                        callback_barras(bars,vetor_arredondado)
                                    else:
                                        print("Barras alteradas:", aux+1)
                            
                            if coleta=='yes':
                                if primeiraColeta=='yes':
                                    primeiraColeta='no'
                                    bars_salvas=bars
                                    PotRef_salvas=PotRef

                            if Portas[2]=='yes':
                                ORDEM_GERAL='PARAR'
                                saveDivergencies(matriz_DadosBarra[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN)
                                for aux2 in range(len(LISTAPrioritys)):
                                    LISTAPrioritys[aux2]='parar'  
                            
                            if cont==200:
                                saveAbnormalPoints(matriz_DadosBarra[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN)

                        except Exception as e:
                            print('DIVERGÊNCIAS DETECTADAS.')
                            Fluxo_divergente='yes' 
                            ORDEM_GERAL='PARAR'
                            saveDivergencies(matriz_DadosBarra[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN)

                            contador_deDivergenciasSeguidas=contador_deDivergenciasSeguidas+1
                            if QuantidadeDeDivergencias==contador_deDivergenciasSeguidas:
                                for aux2 in range(len(LISTAPrioritys)):
                                    LISTAPrioritys[aux2]='parar'      
                PotRef=PotRef_lin
                PotRemovida=PotRemovida_lin
                bars=bars_lin
                PotRemovida_lin=[]
                PotRef_lin=[]
                bars_lin=[]
                coleta='yes'
                cont_confirma=0
                for aux2 in range(len(LISTAPrioritys)):
                    if LISTAPrioritys[aux2]=='parar':
                        cont_confirma=cont_confirma+1 

                if cont_confirma==contador_deBarr:
                    ORDEM_GERAL='PARAR' 
            
            #if bars:
            #PotRefCtrl=[]
            if bars_salvas:
                PotFinal=[]
                for aux_aux in range(len(bars_salvas)):
                    if bars_salvas[aux_aux] in vetBarrsCtrl:
                        PotFinal.append(matriz_DadosBarra[1][aux_aux])
                porcentagens=comparar_percentual_reducao(PotRef_salvas, PotFinal, 'LEVE')        
                
                print("\n📊 Dados da Alteração de Potência (LEVE):")
                for i, (barra, pref, pfim, pct) in enumerate(zip(bars_salvas, PotRef_salvas, PotFinal, porcentagens)):
                    print(f"  - Barra {barra}: de {pref:.4f} → {pfim:.4f} pu  ({pct:.2f}%)")

            
        if RegimeE3=='AMBOS' or RegimeE3=='PESADO': 
            print('\n______________________________________________________________________________')
            print("🗿 Avaliação de regime PESADO: Barras escolhidas")
            print('     - Religamento de cargas (potência ativa). ')
            print('     - Aleteração SEQUENCIAL nas potências das barras escolhidas.')
            print('\n>>> Barras prenchidas sequêncialmente: ')
            #print('      - Barra: ',intervals, '\n')
            print("      - Barras:")
            vetor = [x + 1 for x in intervals]
            for i in range(0, len(vetor), 17):
                linha = vetor[i:i+17]
                texto_barras = ", ".join(str(b) for b in linha)
                print(f"        {texto_barras}")

            ORDEM_GERAL='AVANTE'   
            LISTAPrioritys=['-']*len(matriz_DadosBarra[1])
            for aux in intervals:
                LISTAPrioritys[aux]='avante'
            if RegimeE3=='AMBOS':
                limite_variacao=limite_variacao_pes

            for aux in range(len(matriz_DadosBarra[1])):
                matriz_DadosBarra[1][aux]=matriz_TravaPSempre[aux]
            PotRemovida=[]
            

            PotRemovida=[]
            PotRef=[]
            bars=[]

            primeiraColeta='yes'
            coleta='no'
            bars_salvas=[]
            PotRef_salvas=[]
            while ORDEM_GERAL=='AVANTE':
                primeira='yes'
                for aux in range(len(matriz_DadosBarra[1])):
                    if LISTAPrioritys[aux]=='avante':
                        matriz_DadosBarra[1][aux]=matriz_DadosBarra[1][aux]-passoE3

                        try:
                            (DeltaV, _ , PotP, PotQ , _, _, cont , _, _ , _ , _ , _ ,_, _, _, _, _, _, _, _, _, _, _ ,  _ , Portas, _ )=CHAMA_FLNR_03_LTT (matrizSystem,matrizSystem2,matriz_DadosBarra,infoVctrl,MODELin,Tolerancia,'no', None, None, None, None, None, None, None, None, 'no', None, Tipo_de_logicaSuplementar, ComutacaoMaxima, MatrizY)
                            DeltaV=[float(x) for x in DeltaV]
                            #Delta0=[float(x) for x in Delta0]
                            PotP=[float(x) for x in PotP]
                            PotQ=[float(x) for x in PotQ] 
                            
                            somaPger=0
                            for auxilair in range(len(matriz_DadosBarra[1])):
                                somaPger=somaPger+matriz_DadosBarra[1][auxilair]                           

                            pot_p_gerada=[]
                            pot_q_gerada=[]
                            for i in range(len(PotP)):
                                # Cálculo das potências geradas
                                if infoVctrl[0][i]=='G' or infoVctrl[0][i]=='CS' or infoVctrl[0][i]=='swing':
                                    pot_p_gerada.append(PotP[i] - matriz_DadosBarra[1][i])  # Potência P gerada    
                                    pot_q_gerada.append(PotQ[i] - matriz_DadosBarra[2][i])  # Potência Q gerada                            
                            soma_p = np.sum(pot_p_gerada)
                            soma_q = np.sum(pot_q_gerada)
                            PotSger=np.sqrt(soma_p**2+soma_q**2)
                            fpGlobal=soma_p/PotSger 

                            EvolutionMatrixMatriz2_lin11.append(DeltaV)
                            EvolutionMatrixMatriz2_lin22.append((-1)*somaPger)
                            PORTAS_E3_OUT_esc_pes.append(fpGlobal)

                            if matriz_DadosBarra[1][aux]>matriz_TravaPSempre[aux]*(1+limite_variacao/100):
                                ORDEM_GERAL='AVANTE' 
                            else:    
                                matriz_DadosBarra[1][aux]=matriz_TravaPSempre[aux]*(1+limite_variacao/100) 
                                LISTAPrioritys[aux]='parar'
                      
                            contador_deDivergenciasSeguidas=0    
                            
                            if stop_checker and stop_checker():
                                printagemFinal_ESC(bars_salvas, vetBarrsCtrl, matriz_DadosBarra, PotRef_salvas,'PESADO')
                                print('\n')
                                print(">>> Execução interrompida manualmente.")
                                (EvolutionMatrixMatriz2, PORTAS_E3_OUT_esc)=juntaPraGraficoESCOLHER (RegimeE3, EvolutionMatrixMatriz2_lin1, EvolutionMatrixMatriz2_lin2,
                                                        EvolutionMatrixMatriz2_lin11, EvolutionMatrixMatriz2_lin22, 
                                                        PORTAS_E3_OUT_esc_lev, PORTAS_E3_OUT_esc_pes)
                                
                                return EvolutionMatrixMatriz2, infoVctrl, PORTAS_E3_OUT_esc, matriz_TravaPSempre2
                            
                            PotRemovida_lin.append((-1)*matriz_DadosBarra[1][aux])
                            PotRef_lin.append(matriz_TravaPSempreNew[aux])
                            bars_lin.append(aux+1)
                            if len(PotRef)==len(PotRemovida):
                                if primeira=='yes':
                                    primeira='no'
                                    porcentagens=comparar_percentual_reducao(PotRef, PotRemovida, 'PESADO')
                                    if callback_barras:
                                        # print('\n>>> Dados de Alteração: ')
                                        # print('       - Barras escolhidas no estudo:', bars)
                                        #print('       - Potência de Referência:', PotRef)
                                        vetor_arredondado = np.round(porcentagens, 2)
                                        callback_barras(bars,vetor_arredondado)
                                    else:
                                        print("Barras alteradas:", aux+1)
                            
                            if coleta=='yes':
                                if primeiraColeta=='yes':
                                    primeiraColeta='no'
                                    # print("\n📊 Dados da Alteração de Potência:")
                                    # for i, (barra, pref) in enumerate(zip(bars, PotRef)):
                                    #     print(f"  - Barra {barra}: Potência de Referência = {pref:.4f} pu")
                                    bars_salvas=bars
                                    PotRef_salvas=PotRef

                            if Portas[2]=='yes':
                                ORDEM_GERAL='PARAR'
                                saveDivergencies(matriz_DadosBarra[1], Tolerancia, Tipo_de_logicaSuplementar)
                                for aux2 in range(len(LISTAPrioritys)):
                                    LISTAPrioritys[aux2]='parar'                       

                            if cont==200:
                                saveAbnormalPoints(matriz_DadosBarra[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN)

                        except Exception as e:
                            print('DIVERGÊNCIAS DETECTADAS.')
                            Fluxo_divergente='yes' 
                            ORDEM_GERAL='PARAR'
                            saveDivergencies(matriz_DadosBarra[1], Tolerancia, Tipo_de_logicaSuplementar, PORTAS_E3_IN)
                            # # Monta o caminho completo para o arquivo salvo
                            # save_dir = os.path.join(os.getcwd(), "plot", "GoPVcurve", "Divergencies")

                            # os.makedirs(save_dir, exist_ok=True)

                            # tag = create_unique_tag(save_dir, SYSname, limite_variacao_lev, limite_variacao_pes,
                            #     RegimeE3, passoE3, Estrategia, limite_variacao, Tolerancia, ESCOLHER) 
                                                
                            # save_vector_csv(matriz_DadosBarra[1],tag,"csv",save_dir)

                            contador_deDivergenciasSeguidas=contador_deDivergenciasSeguidas+1
                            if QuantidadeDeDivergencias==contador_deDivergenciasSeguidas:
                                for aux2 in range(len(LISTAPrioritys)):
                                    LISTAPrioritys[aux2]='parar'
                
                PotRef=PotRef_lin
                PotRemovida=PotRemovida_lin
                bars=bars_lin
                PotRemovida_lin=[]
                PotRef_lin=[]
                bars_lin=[]
                #PotRemovida.append(PotRemovida_lin)
                coleta='yes'
                cont_confirma=0
                for aux2 in range(len(LISTAPrioritys)):
                    if LISTAPrioritys[aux2]=='parar':
                        cont_confirma=cont_confirma+1 

                #print('wait')
                if cont_confirma==contador_deBarr:
                    ORDEM_GERAL='PARAR'             
            
            if bars_salvas:
                PotFinal=[]
                for aux_aux in range(len(bars_salvas)):
                    if bars_salvas[aux_aux] in vetBarrsCtrl:
                        PotFinal.append(matriz_DadosBarra[1][aux_aux])
                porcentagens=comparar_percentual_reducao(PotRef_salvas, PotFinal, 'PESADO')        
                
                print("\n📊 Dados da Alteração de Potência (PESADO):")
                for i, (barra, pref, pfim, pct) in enumerate(zip(bars_salvas, PotRef_salvas, PotFinal, porcentagens)):
                    print(f"  - Barra {barra}: de {pref:.4f} → {pfim:.4f} pu  ({pct:.2f}%)")

        if RegimeE3=='AMBOS':
            EvolutionMatrixMatriz2_lin111=[]
            EvolutionMatrixMatriz2_lin222=[]

            for i in range(len(EvolutionMatrixMatriz2_lin1)):
                EvolutionMatrixMatriz2_lin111.append(EvolutionMatrixMatriz2_lin1[len(EvolutionMatrixMatriz2_lin1)-i-1])
                EvolutionMatrixMatriz2_lin222.append(EvolutionMatrixMatriz2_lin2[len(EvolutionMatrixMatriz2_lin2)-i-1])
            for i in range(len(EvolutionMatrixMatriz2_lin11)):
                EvolutionMatrixMatriz2_lin111.append(EvolutionMatrixMatriz2_lin11[i])
                EvolutionMatrixMatriz2_lin222.append(EvolutionMatrixMatriz2_lin22[i])
            EvolutionMatrixMatriz2.append(EvolutionMatrixMatriz2_lin111)
            EvolutionMatrixMatriz2.append(EvolutionMatrixMatriz2_lin222)
            
            for aux_invert in range(len(PORTAS_E3_OUT_esc_lev)):
                PORTAS_E3_OUT_esc.append(PORTAS_E3_OUT_esc_lev[len(PORTAS_E3_OUT_esc_lev)-aux_invert-1])
            PORTAS_E3_OUT_esc=PORTAS_E3_OUT_esc+PORTAS_E3_OUT_esc_pes

        elif  RegimeE3=='LEVE':          
            EvolutionMatrixMatriz2.append(EvolutionMatrixMatriz2_lin1)
            EvolutionMatrixMatriz2.append(EvolutionMatrixMatriz2_lin2)  
            
            for aux_invert in range(len(PORTAS_E3_OUT_esc_lev)):
                PORTAS_E3_OUT_esc.append(PORTAS_E3_OUT_esc_lev[len(PORTAS_E3_OUT_esc_lev)-aux_invert-1])

        elif  RegimeE3=='PESADO':  
            EvolutionMatrixMatriz2.append(EvolutionMatrixMatriz2_lin11)
            EvolutionMatrixMatriz2.append(EvolutionMatrixMatriz2_lin22)  
            PORTAS_E3_OUT_esc=PORTAS_E3_OUT_esc_pes 
    else:
        return(None, None, None, None)
    
    return(EvolutionMatrixMatriz2, infoVctrl, PORTAS_E3_OUT_esc, matriz_TravaPSempre2)



# ======================================================
# Função para salvar as matrizes, infoVctrl e PONTOS_LIMITES
# ======================================================
def save_matrices(matrices, file_suffix, infoVctrl, PONTOS_LIMITES, PORTAS_E4_IN):
    specification=PORTAS_E4_IN[0]
    PONTOS_LIMITES=PORTAS_E4_IN[1]
    save_dir=PORTAS_E4_IN[2]
    soma_P_0=PORTAS_E4_IN[3]

    os.makedirs(save_dir, exist_ok=True)
    filename = f"{file_suffix}.csv"
    filepath = os.path.join(save_dir, filename)

    with open(filepath, mode='w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["# ============================================================================="])
        writer.writerow(["# SEÇÃO 1: ESPECIFICAÇÃO DO ESTUDO 3 - GENERATOR OF PV-CURVE"])
        writer.writerow(["# ============================================================================="])
        writer.writerow([])
        writer.writerow(["''' ESPECIFICAÇÃO '''"])
        if isinstance(specification, dict):
            for key, value in specification.items():
                writer.writerow([f"{key}={value}"])
        else:
            for line in specification:
                writer.writerow([line])
        writer.writerow([])

        writer.writerow(["EvolutionMatrixMatriz2[0]_TENSAO"])
        for row in matrices[0]:
            writer.writerow(row)

        writer.writerow(["EvolutionMatrixMatriz2[1]_POTP"])
        writer.writerow(matrices[1])

        writer.writerow(["infoVctrl"])
        for row in infoVctrl:
            writer.writerow(row)

        writer.writerow(["PONTOS_LIMITES"])
        for point in PONTOS_LIMITES:
            writer.writerow(point)

        writer.writerow([])
        writer.writerow(["soma_P_0"])
        writer.writerow([soma_P_0])
    
    return ()
    #print(f"Matrizes, especificação, infoVctrl e PONTOS_LIMITES salvos em: {filepath}")


# ======================================================
# Função para carregar as informações salvas (incluindo soma_P_0)
# ======================================================
def load_matrices(filepath):
    specification = {}
    matrix0 = []
    matrix1 = []
    infoVctrl = []
    pontos_limites = []
    soma_P_0 = None

    current_section = None

    with open(filepath, 'r', encoding='latin-1') as f:
        reader = csv.reader(f)
        for row in reader:
            if not row or all(cell.strip() == "" for cell in row):
                continue
            if row[0].lstrip().startswith("#"):
                continue

            if row[0].strip() == "''' ESPECIFICAÇÃO '''":
                current_section = "spec"
                continue
            elif row[0].strip() == "EvolutionMatrixMatriz2[0]_TENSAO":
                current_section = "matrix0"
                continue
            elif row[0].strip() == "EvolutionMatrixMatriz2[1]_POTP":
                current_section = "matrix1"
                continue
            elif row[0].strip() == "infoVctrl":
                current_section = "infoVctrl"
                continue
            elif row[0].strip() == "PONTOS_LIMITES":
                current_section = "PONTOS_LIMITES"
                continue
            elif row[0].strip() == "soma_P_0":
                current_section = "soma_P_0"
                continue

            if current_section == "spec":
                if "=" in row[0]:
                    key, val = row[0].split("=", 1)
                    try:
                        specification[key.strip()] = ast.literal_eval(val.strip())
                    except Exception:
                        specification[key.strip()] = val.strip()
            elif current_section == "matrix0":
                matrix0.append([float(x) for x in row])
            elif current_section == "matrix1":
                matrix1.extend([float(x) for x in row])
            elif current_section == "infoVctrl":
                infoVctrl.append(row)
            elif current_section == "PONTOS_LIMITES":
                if len(row) >= 3:
                    pontos_limites.append([float(row[0]), float(row[1]), int(float(row[2]))])
                else:
                    pontos_limites.append([float(x) for x in row if x.strip() != ""])
            elif current_section == "soma_P_0":
                try:
                    soma_P_0 = float(row[0])
                except:
                    soma_P_0 = None
    return specification, matrix0, matrix1, infoVctrl, pontos_limites, soma_P_0



def analisar_colapsos(DeltaV, PotGer, soma_P_0, infoBarr):
    menor_margem = None
    barra_critica = None
    Pcolapso_critico = None

    for i in range(DeltaV.shape[1]):
        tensoes = DeltaV[:, i]
        if np.any(np.isnan(tensoes)) or np.min(tensoes) < 0.4:
            idx_validos = np.where((~np.isnan(tensoes)) & (tensoes > 0.4))[0]
            if len(idx_validos) > 0:
                idx_ultimo = idx_validos[-1]
                Pcolapso = PotGer[idx_ultimo]
                margem = max(Pcolapso - soma_P_0 - 0.1, 0)

                if menor_margem is None or margem < menor_margem:
                    menor_margem = margem
                    barra_critica = infoBarr[i]
                    Pcolapso_critico = Pcolapso

    if menor_margem is not None:
        print("\n📉 Colapso de Tensão Detectado:")
        print(f"     - Barra de Tensão Crítica: {barra_critica}")
        print(f"        |Pcolapso = {Pcolapso_critico:.4f}    pu| ")
        print(f"        |Margem   = {menor_margem:.4f}    pu|")
        print(f"     - Potência Incial (carga total): {soma_P_0:.2f}pu")
    else:
        print("\n✅ Nenhum colapso de tensão detectado.")

    # Cálculo da faixa crítica de potência recomendada
    Pmin_seguro = PotGer[0] + 0.1
    Pmax_seguro = PotGer[-1] - 0.1
    print(f"\n🔎 Faixa recomendada para filtro 'CRITICAS': {Pmin_seguro:.2f} a {Pmax_seguro:.2f} pu\n")
    return()







def loadPVCurveInscrita(EvolutionMatrixMatriz2, infoBarr, PONTOS_LIMITES, soma_P_0):

    for aux in range(len(infoBarr)):
        infoBarr[aux] = infoBarr[aux] + 1

    DeltaV_trajetory = np.array(EvolutionMatrixMatriz2[0])
    PotGer_trajetory = np.array(EvolutionMatrixMatriz2[1])
    name = EvolutionMatrixMatriz2[2]

    # Chamada antes do gráfico
    analisar_colapsos(DeltaV_trajetory, PotGer_trajetory, soma_P_0, infoBarr)


    pontos_lim = np.array(PONTOS_LIMITES)
    pontos_lim_all = pontos_lim if pontos_lim.ndim == 2 and pontos_lim.shape[1] >= 3 else None

    fig, ax = plt.subplots(figsize=(12, 8))
    all_tensions = DeltaV_trajetory[:, :].flatten()
    ax.set_xlim(0, max(PotGer_trajetory) * 1.05)
    ax.set_ylim(min(all_tensions) * 0.95, max(all_tensions) * 1.05)
    plt.subplots_adjust(bottom=0.3)
    ax.set_xlabel('Potência das Cargas (p.u.)')
    ax.set_ylabel('Tensão (p.u.)')
    ax.set_title('Curvas PV para cada barra com PONTOS_LIMITES: ' + name)
    ax.grid(True)

    colors = plt.get_cmap("tab10").colors
    linestyles = ['-', '--', '-.', ':']

    all_lines = []
    all_labels = []
    pontos_limit_scatter = []
    estrelas_scatter = []

    for barra in range(DeltaV_trajetory.shape[1]):
        color = colors[barra % len(colors)]
        linestyle = linestyles[barra % len(linestyles)]
        label = f'Barra {infoBarr[barra]}'
        line, = ax.plot([], [], color=color, linestyle=linestyle, label=label)
        all_lines.append((line, barra))
        all_labels.append(label)

    pontos_lim = np.array(PONTOS_LIMITES)
    pontos_lim_all = pontos_lim if pontos_lim.ndim == 2 and pontos_lim.shape[1] >= 3 else None

    def update_plot(barras):
        nonlocal pontos_limit_scatter, estrelas_scatter

        for line, idx in all_lines:
            if idx in barras:
                line.set_data(PotGer_trajetory, DeltaV_trajetory[:, idx])
                line.set_visible(True)
            else:
                line.set_data([], [])
                line.set_visible(False)

        for p in pontos_limit_scatter:
            p.remove()
        pontos_limit_scatter.clear()
        for e in estrelas_scatter:
            e.remove()
        estrelas_scatter.clear()

        # Converte os índices reais das barras (infoBarr) para índice do traçado
        barras_reais = [infoBarr[i] for i in barras]
        barras_set = set(barras_reais)

        vis_pots = [linha for linha in PONTOS_LIMITES if int(linha[2]) in barras_set]



        nv=PONTOS_LIMITES
        PONTOS_LIMITES2=np.array(vis_pots)
        #vis_pots=pontos_lim_all
        if len(vis_pots):
            scat = ax.scatter(PONTOS_LIMITES2[:, 1], PONTOS_LIMITES2[:, 0], color='k', s=120, marker='o')
            pontos_limit_scatter.append(scat)

        if soma_P_0 is not None:
            for idx in barras:
                try:
                    interp = interp1d(PotGer_trajetory, DeltaV_trajetory[:, idx], bounds_error=False, fill_value=np.nan)
                    tensao_corresp = interp(soma_P_0)

                    if not np.isnan(tensao_corresp):
                        star = ax.scatter([soma_P_0], [tensao_corresp], marker='*', s=200, color='black')
                        estrelas_scatter.append(star)
                except Exception as e:
                    print(f"[Erro ao interpolar estrela para barra {idx}] {e}")

                # star = ax.scatter([soma_P_0], [tensao_corresp], marker='*', s=200, color='black')
                # estrelas_scatter.append(star)

        fig.canvas.draw_idle()

    cursor_pv = mplcursors.cursor([l[0] for l in all_lines], hover=True)
    @cursor_pv.connect("add")
    def on_add_pv(sel):
        sel.annotation.set_text(sel.artist.get_label())
        sel.annotation.get_bbox_patch().set(alpha=0.8, fc="white")

    axbox = plt.axes([0.25, 0.05, 0.3, 0.05])
    text_box = TextBox(axbox, 'Filtrar (ex: 1-5_7_9)', initial="1-14")

    axbutton = plt.axes([0.6, 0.05, 0.1, 0.05])
    button = Button(axbutton, 'Aplicar')

    def parse_barras(text):
        indices = set()
        for part in text.split("_"):
            if "-" in part:
                start, end = part.split("-")
                indices.update(range(int(start)-1, int(end)))
            else:
                indices.add(int(part)-1)
        return sorted(list(indices))

    def aplicar_callback(event):
        val = text_box.text
        try:
            new_barras = parse_barras(val)
            update_plot(new_barras)
        except Exception as e:
            print("Erro ao aplicar filtro:", e)

    button.on_clicked(aplicar_callback)

    # Legenda compacta com segmentos e símbolos
    fig_legenda = plt.figure(figsize=(5, 3))
    fig_legenda.canvas.manager.set_window_title('Legenda')
    num_cols = 3
    num_rows = int(np.ceil((len(all_labels) + 2) / num_cols))
    gs = gridspec.GridSpec(num_rows, num_cols, figure=fig_legenda, wspace=0.05, hspace=0.1)

    for i, (label, (line, _)) in enumerate(zip(all_labels, all_lines)):
        row = i // num_cols
        col = i % num_cols
        ax_leg = fig_legenda.add_subplot(gs[row, col])
        ax_leg.plot([0, 0.25], [0.5, 0.5], linestyle=line.get_linestyle(), color=line.get_color(), linewidth=2)
        ax_leg.text(0.4, 0.5, label, fontsize=7, va='center')
        ax_leg.set_xlim(0, 1)
        ax_leg.set_ylim(0, 1)
        ax_leg.axis('off')

    # Adiciona marcador da bolinha preta
    i += 1
    row = i // num_cols
    col = i % num_cols
    ax_lim = fig_legenda.add_subplot(gs[row, col])
    ax_lim.scatter([0.2], [0.5], color='black', s=80, marker='o')
    ax_lim.text(0.4, 0.5, 'PONTOS_LIMITES', fontsize=7, va='center')
    ax_lim.set_xlim(0, 1)
    ax_lim.set_ylim(0, 1)
    ax_lim.axis('off')

    # Adiciona marcador da estrela preta
    i += 1
    row = i // num_cols
    col = i % num_cols
    ax_star = fig_legenda.add_subplot(gs[row, col])
    ax_star.scatter([0.2], [0.5], color='black', s=100, marker='*')
    ax_star.text(0.4, 0.5, 'Estudo Inicial', fontsize=7, va='center')
    ax_star.set_xlim(0, 1)
    ax_star.set_ylim(0, 1)
    ax_star.axis('off')

    update_plot(list(range(DeltaV_trajetory.shape[1])))
    plt.show()
    #print('WAIT')



def save_log_terminal(save_dir, file_suffix, log_terminal):
    filepath = os.path.join(save_dir, f"{file_suffix}.csv")
    with open(filepath, mode='a', encoding='utf-8', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow([])
        writer.writerow(["# ============================================================================="])
        writer.writerow(["# SEÇÃO FINAL: LOG DO TERMINAL DURANTE O ESTUDO"])
        writer.writerow(["# ============================================================================="])
        writer.writerow([])

        for line in log_terminal.splitlines():
            writer.writerow([line])



def limpar_texto_para_csv(texto):
    texto_sem_acentos = unicodedata.normalize('NFKD', texto).encode('ASCII', 'ignore').decode('ASCII')
    texto_final = ''.join(char if ord(char) < 128 else '-' for char in texto_sem_acentos)
    return texto_final


def save_log_terminal_limpo(save_dir, file_suffix, log_terminal):
    filepath = os.path.join(save_dir, f"{file_suffix}.csv")
    log_limpo = limpar_texto_para_csv(log_terminal)

    with open(filepath, mode='a', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow([])
        writer.writerow(["# ============================================================================="])
        writer.writerow(["# SECAO FINAL: LOG DO TERMINAL DURANTE O ESTUDO"])
        writer.writerow(["# ============================================================================="])
        writer.writerow([])

        for line in log_limpo.splitlines():
            writer.writerow([line])



def obter_log_terminal():
    sys.stdout.flush()  # Garante que tudo foi escrito
    return sys.__stdout__.getvalue() if hasattr(sys.__stdout__, "getvalue") else ""



def CHAMA_savePVcurve(EvolutionMatrixMatriz2, infoVctrl, PORTAS_E3_IN, PORTAS_E4_IN):
    parameters = PORTAS_E4_IN[0]
    PONTOS_LIMITES = PORTAS_E4_IN[1]
    save_dir = PORTAS_E4_IN[2]
    soma_P_0 = PORTAS_E4_IN[3]
    log_terminal = PORTAS_E4_IN[4]  # Já vem pronto da captura no início

    Tolerancia = PORTAS_E3_IN[2]
    Tipo_de_logicaSuplementar = PORTAS_E3_IN[6]

    matrices = [EvolutionMatrixMatriz2[0], EvolutionMatrixMatriz2[1]]
    os.makedirs(save_dir, exist_ok=True)

    tag = create_unique_tag2(save_dir, len(EvolutionMatrixMatriz2[0][0]))
    file_suffix = tag

    # Salvar matrizes e informações
    save_matrices(matrices, file_suffix, infoVctrl, PONTOS_LIMITES, PORTAS_E4_IN)

    # Print para visual feedback no terminal (não será salvo no log)
    filename = f"{file_suffix}.csv"
    filepath = os.path.join(save_dir, filename)
    print('\n______________________________________________________________________________')
    print("✅ Salvamento concluído com êxito.")
    print(f"   - Arquivo para o gráfico salvo em:")
    print(f"{filepath}",'\n')

    print("🎯 Estudo finalizado com sucesso!")
    print('______________________________________________________________________________')
    # Salvar o log do terminal passado
    save_log_terminal_limpo(save_dir, file_suffix, log_terminal)

    return






def save_pfCurve(Evolution_fpGer, EvolutionMatrixMatriz2_1, PONTOS_LIMITES, Tolerancia, Tipo_de_logicaSuplementar, tam, save_dir, specification=None):
    """
    Salva os dados do gráfico dos fatores de potência em um arquivo CSV.
    
    Parâmetros:
      - Evolution_fpGer: vetor (lista ou array) com os valores do fator de potência.
      - EvolutionMatrixMatriz2_1: vetor (lista ou array) com os valores das potências das cargas (em p.u.).
      - PONTOS_LIMITES: lista de pontos, onde cada ponto é [tensão, potência, TAG].
      - Tolerancia: valor da tolerância (usado para gerar a TAG).
      - Tipo_de_logicaSuplementar: string usada para gerar a TAG.
      - tam: parâmetro (por exemplo, tamanho) usado para gerar a TAG.
      - specification: opcional, dicionário com parâmetros do estudo.
      - nameDir: nome do subdiretório para salvar (default "pfCurve").
    
    O arquivo será salvo em:
      <cwd>/plot/GoPC_PLOT3/pfCurve/<tag>.csv
    onde a TAG é gerada pela função create_unique_tag2.
    """
    #save_dir = os.path.join(os.getcwd(), "plot", "GoPC_PLOT3", nameDir)
    os.makedirs(save_dir, exist_ok=True)
    
    tag = create_unique_tag2(save_dir, tam)
    file_suffix = tag
    filepath = os.path.join(save_dir, f"{file_suffix}.csv")
    
    with open(filepath, mode='w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        # Cabeçalho de especificação
        writer.writerow(["''' SPECIFICATION '''"])
        if specification is not None:
            for key, value in specification.items():
                writer.writerow([f"{key}={value}"])
        writer.writerow([])  # linha em branco
        
        # Salva Evolution_fpGer
        writer.writerow(["Evolution_fpGer"])
        writer.writerow(Evolution_fpGer)
        
        # Salva EvolutionMatrixMatriz2[1] (potências das cargas)
        writer.writerow(["EvolutionMatrixMatriz2[1]"])
        writer.writerow(EvolutionMatrixMatriz2_1)
        
        # Salva PONTOS_LIMITES (cada linha é um ponto: [tensão, potência, TAG])
        writer.writerow(["PONTOS_LIMITES"])
        for point in PONTOS_LIMITES:
            writer.writerow(point)
    
    print(f"pfCurve saved at: {filepath}")


def plot_power_factor_line(Evolution_fpGer, EvolutionMatrixMatriz2_1, PONTOS_LIMITES, S_base=100):
    """
    Plota o fator de potência do sistema (Evolution_fpGer) em função das potências 
    das cargas (EvolutionMatrixMatriz2[1]) utilizando uma linha contínua.
    
    Além disso, marca na curva os pontos correspondentes aos valores de potência
    indicados na segunda coluna de PONTOS_LIMITES. Cada ponto de PONTOS_LIMITES é 
    [tensão, potência absoluta] e, para a marcação, a potência é convertida para p.u. 
    dividindo-se por S_base.
    
    Parâmetros:
      - Evolution_fpGer: lista ou array com os valores do fator de potência.
      - EvolutionMatrixMatriz2_1: lista ou array com os valores das potências das cargas (em p.u.).
      - PONTOS_LIMITES: lista de pontos, onde cada ponto é [tensão, potência absoluta].
      - S_base: base de potência para converter os valores de PONTOS_LIMITES para p.u. (default=100).
    """
    # Converte para arrays NumPy
    fp = np.array(Evolution_fpGer)
    p = np.array(EvolutionMatrixMatriz2_1)
    
    plt.figure(figsize=(8, 6))
    # Plota a linha contínua da curva
    plt.plot(p, fp, linestyle='-', color='b', label="Fator de Potência")
    
    # Para cada ponto em PONTOS_LIMITES, converte a potência para p.u. e marca o ponto
    for point in PONTOS_LIMITES:
        # point[0] é a tensão (aqui apenas informativa) e point[1] é a potência absoluta
        load_val_pu = point[1] / S_base  # converte para p.u.
        # Encontra o índice no vetor p cujo valor está mais próximo de load_val_pu
        idx = np.argmin(np.abs(p - load_val_pu))
        # Marca o ponto da curva correspondente a esse índice
        plt.plot(p[idx], fp[idx], marker='o', color='k', markersize=8)
    
    plt.xlabel("Potência das Cargas (p.u.)")
    plt.ylabel("Fator de Potência")
    plt.title("Fator de Potência vs Potência das Cargas")
    plt.grid(True)
    plt.legend()
    plt.show()


def load_pfCurve_info(filepath):
    """
    Lê o arquivo CSV salvo e retorna uma tupla contendo:
      - specification: dicionário com os parâmetros do estudo.
      - Evolution_fpGer: vetor do fator de potência.
      - EvolutionMatrixMatriz2[1]: vetor das potências das cargas (em p.u.).
      - PONTOS_LIMITES: lista de pontos, onde cada ponto é [tensão, potência, TAG].
    """
    specification = {}
    Evolution_fpGer = None
    EvolutionMatrixMatriz2_1 = None
    PONTOS_LIMITES = []
    
    current_section = None
    with open(filepath, 'r') as f:
        lines = f.readlines()
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line == "''' SPECIFICATION '''":
            current_section = "spec"
            continue
        elif line == "Evolution_fpGer":
            current_section = "fp"
            continue
        elif line == "EvolutionMatrixMatriz2[1]":
            current_section = "p"
            continue
        elif line == "PONTOS_LIMITES":
            current_section = "pl"
            continue
        
        if current_section == "spec":
            if "=" in line:
                key, val = line.split("=", 1)
                try:
                    specification[key.strip()] = ast.literal_eval(val.strip())
                except Exception:
                    specification[key.strip()] = val.strip()
        elif current_section == "fp":
            if Evolution_fpGer is None:
                try:
                    Evolution_fpGer = [float(x) for x in line.split(",") if x.strip() != ""]
                except Exception:
                    Evolution_fpGer = []
        elif current_section == "p":
            if EvolutionMatrixMatriz2_1 is None:
                try:
                    EvolutionMatrixMatriz2_1 = [float(x) for x in line.split(",") if x.strip() != ""]
                except Exception:
                    EvolutionMatrixMatriz2_1 = []
        elif current_section == "pl":
            try:
                parts = [x.strip() for x in line.split(",") if x.strip() != ""]
                if len(parts) >= 3:
                    voltage = float(parts[0])
                    load = float(parts[1])
                    tag_val = int(float(parts[2]))
                    point = [voltage, load, tag_val]
                else:
                    point = [float(x) for x in parts]
                if point:
                    PONTOS_LIMITES.append(point)
            except Exception:
                pass
    return specification, Evolution_fpGer, EvolutionMatrixMatriz2_1, PONTOS_LIMITES

# ======================================================
# Função para carregar e sobrepor as curvas pf e pontos adicionais
# ======================================================
def load_and_overlay_pfCurves(filepaths, matriz_list=None, matriz_depois_list=None):
    """
    Carrega os arquivos pfCurve e sobrepõe as curvas no mesmo gráfico.
    Para cada curva, marca os pontos limites (obtidos do CSV) como estrelas coloridas,
    usando a TAG (terceiro valor do ponto) para definir a cor. Pontos com a mesma TAG
    receberão a mesma cor e serão rotulados apenas uma vez na legenda.
    
    Além disso, se forem fornecidas duas matrizes extras:
      - matriz_list: pontos "antes" (3 linhas: [y, x, grupo])
      - matriz_depois_list: pontos "depois" (3 linhas: [y, x, grupo])
    Esses pontos serão plotados com cores distintas por grupo e cada par (antes e depois)
    será conectado por uma linha preta.
    """
    plt.figure(figsize=(8,6))
    
    # Dicionário para atribuição de cor por TAG (para os pontos limites)
    tag_color = {}
    cmap = plt.get_cmap("Set1")
    added_tags = set()  # Para evitar rótulos duplicados na legenda
    
    # Plot das curvas dos arquivos pfCurve e seus pontos limites (do CSV)
    for fp in filepaths:
        spec, fp_curve, p_curve, pontos_lim = load_pfCurve_info(fp)
        fp_curve = np.array(fp_curve)
        p_curve = np.array(p_curve)
        label = spec.get("SYSname", os.path.basename(fp))
        plt.plot(p_curve, fp_curve, linestyle='-', label=label)
        
        if pontos_lim:
            for point in pontos_lim:
                # point[0]: tensão, point[1]: potência, point[2]: TAG
                tag_val = point[2]
                if tag_val not in tag_color:
                    tag_color[tag_val] = cmap(len(tag_color) % cmap.N)
                load_val = point[1]
                idx = np.argmin(np.abs(p_curve - load_val))
                # Adiciona o rótulo somente se essa TAG ainda não foi adicionada
                if tag_val not in added_tags:
                    plt.plot(p_curve[idx], fp_curve[idx], marker='*', color=tag_color[tag_val],
                             markersize=12, label=f"PONTOS_LIMITES (TAG {tag_val})")
                    added_tags.add(tag_val)
                else:
                    plt.plot(p_curve[idx], fp_curve[idx], marker='*', color=tag_color[tag_val],
                             markersize=12)
    
    # Se forem fornecidas as matrizes extras (pontos antes e depois)
    if matriz_list is not None and matriz_depois_list is not None:
        try:
            ml_y = np.array(matriz_list[0], dtype=float)
            ml_x = np.array(matriz_list[1], dtype=float)
            ml_groups = np.array(matriz_list[2], dtype=int)
            
            mdl_y = np.array(matriz_depois_list[0], dtype=float)
            mdl_x = np.array(matriz_depois_list[1], dtype=float)
            mdl_groups = np.array(matriz_depois_list[2], dtype=int)
        except Exception as e:
            print("Erro ao converter matriz_list ou matriz_depois_list:", e)
            return
        
        if not (ml_x.shape == ml_y.shape == ml_groups.shape and mdl_x.shape == mdl_y.shape == mdl_groups.shape):
            print("As matrizes adicionais não possuem o mesmo tamanho em cada linha.")
        else:
            unique_groups = np.unique(ml_groups)
            extra_cmap = plt.get_cmap("Set2")
            for g in unique_groups:
                indices = np.where(ml_groups == g)[0]
                color_extra = extra_cmap(int(g) % extra_cmap.N)
                plt.scatter(ml_x[indices], ml_y[indices],
                            color=color_extra, s=120, marker='o',
                            label=f"Antes - Group {g}")
                plt.scatter(mdl_x[indices], mdl_y[indices],
                            color=color_extra, s=120, marker='s',
                            label=f"Depois - Group {g}")
                for idx in indices:
                    plt.plot([ml_x[idx], mdl_x[idx]], [ml_y[idx], mdl_y[idx]], color='k', linestyle='-')
    
    plt.xlabel("Potência das Cargas (p.u.)")
    plt.ylabel("Fator de Potência")
    plt.title("Fator de Potência vs Potência das Cargas (Sobreposição)")
    plt.grid(True)
    plt.legend()
    plt.show()




def CHAMA_PLOT3(DADOS_PLOT3_IN):
    selecionarPlt3=DADOS_PLOT3_IN[0]
    GrafficDesired=DADOS_PLOT3_IN[1]
    selection_curve=DADOS_PLOT3_IN[2]
    CHOOSE_BAR=DADOS_PLOT3_IN[3]
    lim_min = DADOS_PLOT3_IN[4]
    lim_max = DADOS_PLOT3_IN[5]
    #print('-----------------------------------------------------------------------------------------------\n')    
    #print('                                         GENERATOR OF CURVES - GoCurvs')
    if GrafficDesired=='PxV':

        ''' LER O DIRETÓRIO E RETORNA TABELA DE CONTEÚDO '''
        # Exemplo de caminho para o arquivo CSV salvo
        filepath = os.path.join(os.getcwd(), "plot", "GenOfCurvs", selecionarPlt3)
        spec, mat0, mat1, infoVctrl, pontos_limites, _ = load_matrices(filepath)
        
        if CHOOSE_BAR=='CRITICAS': 
            vet_int=[]
            for aux_aux in range(len(pontos_limites)):
                if pontos_limites[aux_aux][1] < lim_max and pontos_limites[aux_aux][1] > lim_min:
                    vet_int.append(pontos_limites[aux_aux][2])

            exclusivos = list(set(vet_int))
            ordenado = sorted(exclusivos)
            CHOOSE_BAR = '_'.join(map(str, ordenado))       

        ''' PLOTAGEM '''
        print('\n📋 Parâmetros do estudo selecionado:')
        # Imprime cada parâmetro individualmente
        for key, val in spec.items():
            print(f"   - {key}: {val}")
            if key=='SOMA_P_0':
                soma_p0=float(val)

        FILTER_IN00=[selection_curve, CHOOSE_BAR]
        FILTER_IN01=[mat0, infoVctrl]
        if selection_curve=='TODAS':
            vetor = list(range(len(infoVctrl[0])))
            EvolutionMatrixMatriz2=[mat0,mat1, selecionarPlt3]
            loadPVCurveInscrita(EvolutionMatrixMatriz2, vetor, pontos_limites, soma_p0)
        elif selection_curve=='PV':
            (mat0, BarrasPV)=FILTERForPresentationOfSelectedBarr(FILTER_IN00, FILTER_IN01)
            EvolutionMatrixMatriz2=[mat0,mat1, selecionarPlt3]
            loadPVCurveInscrita(EvolutionMatrixMatriz2, BarrasPV, pontos_limites, soma_p0)
        elif selection_curve=='PQ':
            (mat0, BarrasPQ)=FILTERForPresentationOfSelectedBarr(FILTER_IN00, FILTER_IN01)
            EvolutionMatrixMatriz2=[mat0,mat1, selecionarPlt3]
            loadPVCurveInscrita(EvolutionMatrixMatriz2, BarrasPQ, pontos_limites, soma_p0)  
        elif selection_curve=='CHOOSE_BAR':
            (mat0, vetCHOOSE_BAR)=FILTERForPresentationOfSelectedBarr(FILTER_IN00, FILTER_IN01)
            EvolutionMatrixMatriz2=[mat0,mat1, selecionarPlt3]
            loadPVCurveInscrita(EvolutionMatrixMatriz2, vetCHOOSE_BAR, pontos_limites, soma_p0)   

    elif GrafficDesired=='Pxfp':
        #print('------------------------------------------------ Pxfp selected ------------------------------------------\n')
        total_pastas, nameChoosed, lista_pastas=ler_diretorio_plot3_pfCrvs(selecionarPlt3)
        if nameChoosed!=None:
            #name_Dir="plot/GenOfCurvs/pfCurve/"+nameChoosed
            #load_pfCurves_forPlot2(name_Dir)
            pf_dir = os.path.join(os.getcwd(), "plot", "GenOfCurvs", "pfCurve", nameChoosed)
            files = [os.path.join(pf_dir, f) for f in os.listdir(pf_dir) if f.endswith(".csv")]

            # Se quiser sobrepor várias curvas, passe a lista de arquivos para a função:
            load_and_overlay_pfCurves(files)        
        else:
            exit()    

