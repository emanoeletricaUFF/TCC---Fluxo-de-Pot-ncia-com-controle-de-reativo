import io

terminal_buffer = io.StringIO()