import tkinter as tk
from tkinter import ttk
import math

def mostrar_splash_temporario(root):
    splash = tk.Toplevel(root)
    splash.overrideredirect(True)

    largura, altura = 460, 180
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    splash.geometry(f"{largura}x{altura}+{(sw-largura)//2}+{(sh-altura)//2}")

    LILAS_CLARO = "#cce6ff"     # fundo azul claro (GoCurvs)
    ROXO_ESCURO = "#2e005d"     # para textos futuros (não usado aqui)
    splash.configure(bg=LILAS_CLARO)

    # Canvas com “curvas PV invertidas”
    canvas = tk.Canvas(splash, width=260, height=80, bg=LILAS_CLARO, highlightthickness=0)
    canvas.place(x=15, y=20)

    # Eixos
    canvas.create_line(15, 72, 230, 72, fill="black", width=1)
    canvas.create_line(18, 25, 18, 72, fill="black", width=1)

    # Curvas PV simuladas (descendentes)
    curvas = {
        "#008548": [(18, 42), (80, 42), (130, 43), (210, 68)],
        "#c21807": [(18, 46), (80, 46), (130, 46), (210, 70)],
        "#4e95ff": [(18, 38), (80, 38), (130, 39), (210, 66)],
        "#22a165": [(18, 34), (80, 34), (130, 36), (210, 63)],
    }
    for cor, pts in curvas.items():
        for a, b in zip(pts, pts[1:]):
            canvas.create_line(*a, *b, fill=cor, width=2, dash=(4, 2))

    # Círculos pretos nos "joelhos"
    pontos_joelho = [(145, 50), (155, 52), (165, 55), (175, 58), (195, 60)]
    for x, y in pontos_joelho:
        canvas.create_oval(x-4, y-4, x+4, y+4, fill="black", outline="black")

    # Estrela preta
    cx, cy, R_out, R_in = 130, 45, 7, 3
    vertices = []
    for k in range(10):
        ang = math.radians(-90 + k * 36)
        r = R_out if k % 2 == 0 else R_in
        vertices.extend([cx + r * math.cos(ang), cy + r * math.sin(ang)])
    canvas.create_polygon(vertices, fill="black", outline="black")

    # Texto título
    ttk.Label(splash, text="Iniciando GoCurvs...",
              font=("Segoe UI", 13, "bold"), background=LILAS_CLARO
    ).place(relx=0.55, rely=0.25, anchor="w")

    # Mensagem dinâmica
    msg_label = ttk.Label(splash, text="Carregando bibliotecas…",
                          font=("Segoe UI", 10), background=LILAS_CLARO)
    msg_label.place(relx=0.55, rely=0.52, anchor="w")

    # Barra de progresso
    barra = ttk.Progressbar(splash, mode="indeterminate", length=180)
    barra.place(relx=0.55, rely=0.75, anchor="w")
    barra.start(12)

    # Sequência de mensagens
    mensagens = [
        "Carregando bibliotecas…",
        "Verificando dependências…",
        "Extraindo arquivos embutidos…",
        "Preparando interface…"
    ]
    def avançar(i=0):
        if i < len(mensagens):
            msg_label.config(text=mensagens[i])
            splash.after(800, lambda: avançar(i+1))
    splash.after(50, avançar)

    return splash


import os
import sys
import zipfile


def extrair_recursos_embutidos():
    # Diretório onde o .exe está rodando
    if getattr(sys, 'frozen', False):
        executavel_path = sys.executable
        base_dir = os.path.dirname(executavel_path)
        recurso_zip = os.path.join(sys._MEIPASS, 'recursos_embutidos.zip')
    else:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        recurso_zip = os.path.join(base_dir, 'recursos_embutidos.zip')

    # Pasta de destino para extração
    destinos = [
        os.path.join(base_dir, 'ieee9_Marcelo.cdf'),
        os.path.join(base_dir, 'ieee14.cdf'),
        os.path.join(base_dir, 'ieee30.cdf'),
        os.path.join(base_dir, 'ieee118.cdf'),
        os.path.join(base_dir, 'plot'),
    ]

    # Verifica se já existe
    if not all(os.path.exists(d) for d in destinos):
        print("Extraindo arquivos necessários...")
        with zipfile.ZipFile(recurso_zip, 'r') as zip_ref:
            zip_ref.extractall(base_dir)


from verificacoes_iniciais import verificar_bibliotecas, verificar_e_criar_pastas



import tkinter as tk
from tkinter import ttk, filedialog, simpledialog, messagebox
import threading
import os
import io
from matplotlib import _pylab_helpers
import sys
import tkinter.scrolledtext as scrolledtext
import matplotlib.pyplot as plt
import platform
import math

from G_TERMINAL import terminal_buffer
from G_FUNCAO_C import (
    CHAMA_PVCURVE_MAIORES, CHAMA_PVCURVE_ESCOLHER, CHAMA_savePVcurve,
    loadPVCurveInscrita, determina_LimitesDeControlPotQsobrePVcurv,
    save_pfCurve, pega_nome_maiusculo, CHAMA_PLOT3, Ler_Arquivo
)



def centralizar_janela(janela, largura_min=600, altura_min=600, deslocamento_y=30):
    janela.update_idletasks()
    largura = max(janela.winfo_width(), largura_min)
    altura = max(janela.winfo_height(), altura_min)
    x = (janela.winfo_screenwidth() // 2) - (largura // 2)
    y = (janela.winfo_screenheight() // 2) - (altura // 2) - deslocamento_y
    y = max(y, 0)  # Garante que não suba demais
    janela.geometry(f"{largura}x{altura}+{x}+{y}")





def abrir_tela_expandida(janela):
    sistema = platform.system()

    if sistema == "Windows":
        try:
            janela.state('zoomed')  # Melhor forma no Windows
        except:
            # Fallback caso o método falhe
            largura = janela.winfo_screenwidth()
            altura = janela.winfo_screenheight()
            janela.geometry(f"{largura}x{altura}+0+0")
    else:
        # Para Linux/macOS e outros
        largura = janela.winfo_screenwidth()
        altura = janela.winfo_screenheight()
        janela.geometry(f"{largura}x{altura}+0+0")





class TeeStream:
    def __init__(self, *streams, callback_msg=None):
        self.streams = streams
        self.callback_msg = callback_msg

    def write(self, data):
        for s in self.streams:
            s.write(data)
        if self.callback_msg and "Barras alteradas:" in data:
            self.callback_msg(data.strip())

    def flush(self):
        for s in self.streams:
            if hasattr(s, 'flush'):
                s.flush()



class TextRedirector(io.StringIO):
    def __init__(self, text_widget):
        super().__init__()
        self.text_widget = text_widget

    def write(self, string):
        self.text_widget.configure(state='normal')
        self.text_widget.insert('end', string)
        self.text_widget.see('end')
        self.text_widget.configure(state='disabled')

    def flush(self):
        pass  # compatibilidade com print() e logs



def ler_parametros_csv(caminho):
    parametros = []
    try:
        with open(caminho, "r") as f:
            for linha in f:
                linha = linha.strip()
                if "=" in linha and not linha.startswith("#"):
                    parametros.append(linha)
    except Exception as e:
        parametros = [f"Erro ao ler parâmetros: {e}"]
    return parametros

def obter_log_terminal():
    sys.stdout.flush()  # Garante que tudo foi escrito
    return sys.__stdout__.getvalue() if hasattr(sys.__stdout__, "getvalue") else ""



def extrair_log_terminal_limpo(caminho_csv):
    try:
        with open(caminho_csv, mode="r", encoding="iso-8859-1") as f:
            linhas = f.readlines()
    except Exception as e:
        return f"[Erro ao carregar log: {e}]"

    try:
        inicio_log = None
        for i, linha in enumerate(linhas):
            if "SECAO FINAL: LOG DO TERMINAL DURANTE O ESTUDO" in linha.upper():
                inicio_log = i + 2
                break

        if inicio_log is not None:
            log_bruto = "".join(linhas[inicio_log:])
            log_limpo = log_bruto.replace('"', "")  # Remove todas as aspas
            return log_limpo
        else:
            return "[LOG DO TERMINAL NÃO ENCONTRADO]"
    except Exception as e:
        return f"[Erro ao processar log: {e}]"



def verificar_intervalo_escolher(p):
    valor = p["ESCOLHER"].get().strip()

    if not valor:
        raise ValueError("❌ Campo 'ESCOLHER' está vazio. Exemplo válido: 1-5 ou 1-5_8_10")

    if valor.startswith("-") or valor.startswith("_") or valor.endswith("-") or valor.endswith("_"):
        raise ValueError("❌ Intervalo mal formatado. Exemplo válido: 1-5 ou 1-5_8_10")

    partes = valor.split("_")
    numeros_set = set()
    intervalo_str = ""

    for parte in partes:
        if "-" in parte:
            if intervalo_str:
                raise ValueError("❌ Somente um intervalo com '-' é permitido. Ex: 1-5_9_10")

            intervalo_str = parte
            try:
                inicio, fim = map(int, parte.split("-"))
                if inicio < 1 or fim < 1 or inicio > fim:
                    raise ValueError
                numeros_set.update(range(inicio, fim + 1))
            except:
                raise ValueError("❌ Intervalo inválido. Exemplo válido: 1-5")
        else:
            try:
                num = int(parte)
                if num < 1:
                    raise ValueError
                numeros_set.add(num)
            except:
                raise ValueError("❌ Valor inválido encontrado. Use números inteiros positivos.")

    # Reconstruir a string sem repetições
    resultado = sorted(numeros_set)
    if not resultado:
        raise ValueError("❌ Nenhum número válido fornecido. Exemplo válido: 1-5 ou 1-5_9")

    # Se houver um intervalo, remontar a string com ele
    if intervalo_str:
        inicio, fim = map(int, intervalo_str.split("-"))
        extras = [str(n) for n in resultado if n < inicio or n > fim]
        valor_final = f"{intervalo_str}" + ("_" + "_".join(extras) if extras else "")
    else:
        valor_final = "_".join(map(str, resultado))

    # Atualiza o valor tratado
    p["ESCOLHER"].set(valor_final)



def coloca_notas_noTerminal():
    print("📘 NOTAS GERAIS:\n")

    print("1 - Caso o estudo selecionado em 'Arquivo CDF' seja um dos arquivos testes,")
    print("    o GoCurvs autoajusta para os padrões do estudo automaticamente. Entretanto")
    print("    É NECESSÁRIO garantir que os arquivos CDF básicos estejam na mesma pasta")
    print("    de execução do simulador. O .exe visa empacotar todos os arquivos em um")
    print("    único executável, de modo que as aplicações sejam plenamente funcionais")
    print("    desde que sejam instaladas as adequadas bibliotecas.\n")

    print("2 - O simulador só permite a execução se todos os campos estiverem preenchidos.")
    print("    Entretanto, isto NÃO GARANTE que não haja erros de preenchimento.")
    print("    É necessário pleno conhecimento do sistema a ser estudado, o correto")
    print("    preenchimento do arquivo CSV, bem como a seleção adequada de parâmetros.\n")

    print("3 - Ao rodar um novo estudo, dois terminais na TELA 3 mostram a evolução do")
    print("    estudo realizado. Ao final do processo, os dados são salvos para")
    print("    a montagem do gráfico, que será mostrado na tela logo em sequência.")
    print("    Todos os dados do Terminal também são coletados e salvos para futuras")
    print("    apresentações ao gerar o gráfico pelo botão 'Gerar Gráfico'.\n")

    print("4 - Ao clicar em 'Gerar Gráfico', o gráfico salvo é recarregado e com ele")
    print("    todo o histórico do estudo aparecerá no terminal da TELA 3.\n")

    print("5 - Apesar de muito útil para delimitar barras críticas (tanto sob a ótica de")
    print("    fontes de energia limitada quanto sob a ótica das quedas de tensão),")
    print("    é importante destacar que o gráfico PV corresponde a uma representação")
    print("    ESTÁTICA do sistema, pois as escolhas de alteração nas barras são fixas.")
    print("    Na prática, um sistema real necessita de abordagens dinâmicas para sua")
    print("    operação, o que limita as aplicações diretas da curva PV.\n")

    print("6 - Os métodos seguem estratégias diferentes de alteração das potências de carga:")
    print("    * MAIORES: segue cada barra da listagem até o seu fim antes de passar à próxima.")
    print("    * ESCOLHER: percorre todas as barras listadas de uma vez, repetidamente,")
    print("      até que alguma meta de parada seja alcançada.\n")

    print("7 - Metas de paradas: os cálculos param quando...")
    print("    1 - todas as barras chegam até o seu limite solicitado na TELA 3.")
    print("    2 - o programa começa a detectar muitos colapsos de tensão.")
    print("    3 - seja apertado o botão 'Parar Estudo'.\n")
    return()




class TelaEstudosPV:
    ARQUIVOS_FIXOS = {
        'ieee9_Marcelo.cdf': {
            "S_base": "100",
            "Tolerancia": "0.0001",
            "MODELin": "PI",
            "HabiltAval_Lim_Reativo": "Y",
            "Desabilitar_CS": "N",
            "Ativar_inverter": "no",
            "GirarTrafo": "no",
            "Logica_Spl": "0",
            "Comt_Max": "14"
        },
        'ieee14.cdf': {
            "S_base": "100",
            "Tolerancia": "0.0001",
            "MODELin": "PI",
            "HabiltAval_Lim_Reativo": "Y",
            "Desabilitar_CS": "N",
            "Ativar_inverter": "yes",
            "GirarTrafo": "no",
            "Logica_Spl": "0",
            "Comt_Max": "14"
        },
        'ieee30.cdf': {
            "S_base": "100",
            "Tolerancia": "0.0001",
            "MODELin": "PI",
            "HabiltAval_Lim_Reativo": "Y",
            "Desabilitar_CS": "N",
            "Ativar_inverter": "yes",
            "GirarTrafo": "no",
            "Logica_Spl": "0",
            "Comt_Max": "14"
        },
        'ieee118.cdf': {
            "S_base": "100",
            "Tolerancia": "0.0001",
            "MODELin": "PI",
            "HabiltAval_Lim_Reativo": "Y",
            "Desabilitar_CS": "N",
            "Ativar_inverter": "no",
            "GirarTrafo": "yes",
            "Logica_Spl": "0",
            "Comt_Max": "14"
        }
    }
    
    def __init__(self, root):
        self.root = root
        self.root.title("TELA 3 - GoCurvs")
        self.root.configure(bg="#cce6ff")  # Azul claro
        self.janela_parametros_grafico = None

        # ---------- PALETA ----------
        LILAS_CLARO = "#cce6ff"   # fundo geral
        ROXO_ESCURO = "#2e005d"   # texto

        # ========== CABEÇALHO ==========
        header = tk.Frame(root, height=80, bg=LILAS_CLARO)
        header.pack(fill="x")

        # ---- Canvas com “curvas PV invertidas” ----
        canvas = tk.Canvas(header, width=260, height=80,
                        bg=LILAS_CLARO, highlightthickness=0)
        canvas.place(x=10, y=0)

        # Eixos (X horizontal, Y vertical)
        canvas.create_line(15, 72, 230, 72, fill="black", width=1)   # eixo X
        canvas.create_line(18, 25, 18, 72, fill="black", width=1)    # eixo Y

        # 1) Curvas descendentes simuladas (curvas PV)
        curvas = {
            "#008548":  [(18, 42), (80, 42), (130, 43), (210, 68)],
            "#c21807":  [(18, 46), (80, 46), (130, 46), (210, 70)],
            "#4e95ff":  [(18, 38), (80, 38), (130, 39), (210, 66)],
            "#22a165":  [(18, 34), (80, 34), (130, 36), (210, 63)],
        }
        for cor, pts in curvas.items():
            for a, b in zip(pts, pts[1:]):
                canvas.create_line(*a, *b, fill=cor, width=2, dash=(4, 2))

        # 2) Círculos pretos (joelho das curvas)
        pontos_joelho = [(145, 50), (155, 52), (165, 55), (175, 58), (195, 60)]
        for x, y in pontos_joelho:
            canvas.create_oval(x-4, y-4, x+4, y+4, fill="black", outline="black")

        # 3) Estrela preta alinhada à curva
        cx, cy = 130, 45
        R_out, R_in = 7, 3

        vertices = []
        for k in range(10):  # 10 vértices alternando externo/interno
            ang = math.radians(-90 + k * 36)
            r = R_out if k % 2 == 0 else R_in
            vertices.extend([cx + r * math.cos(ang), cy + r * math.sin(ang)])

        canvas.create_polygon(vertices, fill="black", outline="black")




        # ---- Título centralizado ----
        frame_texto = tk.Frame(header, bg=LILAS_CLARO)
        frame_texto.place(relx=0.5, rely=0.5, anchor="center")

        titulo1 = tk.Label(frame_texto,
                        text="TELA 3 - GoCurvs",
                        font=("Segoe UI", 18, "bold"),
                        fg=ROXO_ESCURO, bg=LILAS_CLARO)
        titulo1.pack()
        titulo2 = tk.Label(frame_texto,
                        text="Gerador de Curvas",
                        font=("Segoe UI", 14),
                        fg=ROXO_ESCURO, bg=LILAS_CLARO)
        titulo2.pack()



        self.params = {
            "SYSname": tk.StringVar(value="ieee118.cdf"),
            "MODELin": tk.StringVar(value="PI"),
            "Tolerancia": tk.DoubleVar(value=0.0001),
            "HabiltAval_Lim_Reativo": tk.StringVar(value="Y"),
            "S_base": tk.DoubleVar(value=100),
            "Desabilitar_CS": tk.StringVar(value="N"),
            "Ativar_inverter": tk.StringVar(value="no"),
            "GirarTrafo": tk.StringVar(value="yes"),
            "RegimeE3": tk.StringVar(value="AMBOS"),
            "limite_variacao_lev": tk.IntVar(value=100),
            "limite_variacao_pes": tk.IntVar(value=100),
            "limite_variacao": tk.IntVar(value=100),
            "Estrategia": tk.StringVar(value="MAIORES"),
            "ESCOLHER": tk.StringVar(value=""),
            "passoE3": tk.DoubleVar(value=0.02),
            "Logica_Spl": tk.IntVar(value=2),
            "Comt_Max": tk.IntVar(value=14),
        }
        self.param_widgets = {}
        self.stop_signal = False
        self.executando = False
        self.create_widgets()
        abrir_tela_expandida(self.root)


    def validar_float(self, texto):
        if texto == "":
            return True  # Permite campo vazio temporariamente
        try:
            float(texto)
            return True
        except ValueError:
            return False



    def create_widgets(self):
        self.widgets = {}
        frame = ttk.Frame(self.root, padding=10)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure((0, 1), weight=1)
        
        vcmd = (self.root.register(self.validar_float), '%P')
        
        nomes_amigaveis = {
            "SYSname": "Arquivo CDF",
            "MODELin": "Modelo de Linha",
            "Tolerancia": "Tolerância",
            "HabiltAval_Lim_Reativo": "Avaliar Lim. Reativo",
            "S_base": "S base (MVA)",
            "Desabilitar_CS": "Desabilitar CS",
            "Ativar_inverter": "Inverter TAP",
            "GirarTrafo": "Girar Trafo",
            "RegimeE3": "Regime de Carga",
            "limite_variacao_lev": "Limite LEVE (%)",
            "limite_variacao_pes": "Limite PESADO (%)",
            "limite_variacao": "Limite Geral (%)",
            "Estrategia": "Estratégia",
            "ESCOLHER": "Barras Escolhidas",
            "passoE3": "Passo de Variação (pu)",
            "Logica_Spl": "Lógica Suplementar",
            "Comt_Max": "Comutação Máxima"            
        }

        dropdowns = {
            "MODELin": ["T", "PI"],
            "HabiltAval_Lim_Reativo": ["Y", "N"],
            "Desabilitar_CS": ["Y", "N"],
            "Ativar_inverter": ["yes", "no"],
            "GirarTrafo": ["yes", "no"],
            "RegimeE3": ["AMBOS", "LEVE", "PESADO"],
            "Estrategia": ["MAIORES", "ESCOLHER"],
            "Logica_Spl": [0, 1, 2]
        }

        parametros_sistema = [
            "SYSname", "MODELin", "Tolerancia", "S_base", "Ativar_inverter",
            "GirarTrafo", "HabiltAval_Lim_Reativo", "Desabilitar_CS", "Logica_Spl", "Comt_Max"
        ]

        parametros_curva = [
            "RegimeE3", "Estrategia", "limite_variacao_lev", "limite_variacao_pes",
            "limite_variacao", "ESCOLHER", "passoE3"
        ]
        

        tooltips_parametros = {
            "SYSname": "1 - Tanto pode selecionar item da lista suspensa quanto\noutros arquivos CDF de qualquer outro diretório.\n2 - Para utilizar a lista suspensa, mantenha os arquivos-teste\nna pasta do executável.",
            "MODELin": "Modelo elétrico das linhas.\n1 - Não se observou grande diferenças entre PI e T\n2 - PI é preferível por tornar o problema menor (T cria barras fictícias). ",
            "Tolerancia": "Tolerância em pu para o erro do fluxo de potência.",
            "S_base": "Potência base do sistema. Tipicamente 100 MVA.",
            "Ativar_inverter": "\"yes\" para ieee14 e ieee30.\n\"no\"  para ieee9_Marcelo e ieee118.",
            "GirarTrafo": "\"yes\" apenas para ieee118.cdf.\n\"no\"  para os demais arquivos-teste.",
            "HabiltAval_Lim_Reativo": "Permite avaliar os limites de reativos nos geradores.",
            "Desabilitar_CS": "Transforma barras CS em barras de carga.",
            "Logica_Spl": "Controla excesso de alternância PV↔PQ.\nAplica lógica suplementar (1 ou 2).",
            "Comt_Max": "Número máximo de comutações PV↔PQ permitidas.",
            "RegimeE3": "Define o regime de carga a ser avaliado (LEVE, PESADO ou AMBOS).",
            "Estrategia": "Estratégia de escolha das barras para modificação de carga:\n1 - MAIORES busca pelas barras de maiores impactos sobre barras de carga.\n2 - ESCOLHER permite selecionar qualquer barra de carga. ",
            "limite_variacao_lev": "Variação máxima (%) permitida \n- apenas necessário para regime AMBOS.",
            "limite_variacao_pes": "Variação máxima (%) permitida \n- apenas necessário para regime AMBOS.",
            "limite_variacao": "Variação máxima (%) permitida - apenas para regime LEVE ou PESADO.",
            "ESCOLHER": "Lista de barras escolhidas para modificação (ex: 1-5,7,9).",
            "passoE3": "Passo incremental/decremental aplicado nas modificações de carga."
        }



        # Bloco ESQUERDO: Informações do Sistema
        frame_sistema = ttk.LabelFrame(frame, text="PARÂMETROS DO SISTEMA", padding=10)
        frame_sistema.grid(row=0, column=0, sticky="nsew", padx=10, pady=5)
        frame_sistema.columnconfigure((0, 1), weight=1)

        # Bloco DIREITO: Informações da Curva
        frame_curva = ttk.LabelFrame(frame, text="PARÂMETROS DO ESTUDO", padding=10)
        frame_curva.grid(row=0, column=1, sticky="nsew", padx=10, pady=5)
        frame_curva.columnconfigure((0, 1), weight=1)

        # for idx, key in enumerate(parametros_sistema):
        #     row, col = divmod(idx, 2)
        #     sub = ttk.Frame(frame_sistema)
        #     sub.grid(row=row, column=col, padx=6, pady=6, sticky="w")
        #     ttk.Label(sub, text=nomes_amigaveis.get(key, key)).pack(anchor="w")

        #     if key == "SYSname":
        #         combo_sys = ttk.Combobox(sub, textvariable=self.params[key], width=20, state="readonly")
        #         combo_sys['values'] = list(self.ARQUIVOS_FIXOS.keys()) + ["Selecionar outro arquivo..."]
        #         combo_sys.pack(side="left")
        #         self.widgets[key] = combo_sys

        #         def ao_mudar_sysname(event=None):
        #             nome = self.params["SYSname"].get()
        #             if nome == "Selecionar outro arquivo...":
        #                 self.selecionar_arquivo()
        #             elif nome in self.ARQUIVOS_FIXOS:
        #                 config = self.ARQUIVOS_FIXOS[nome]
        #                 for k, v in config.items():
        #                     if k in self.params:
        #                         self.params[k].set(v)

        #         combo_sys.bind("<<ComboboxSelected>>", ao_mudar_sysname)

        #         ttk.Button(sub, text="...", command=self.selecionar_arquivo).pack(side="left")
        #     elif key in dropdowns:
        #         ttk.Combobox(sub, textvariable=self.params[key], values=dropdowns[key], width=15, state="readonly").pack()
        #     else:
        #         #ttk.Entry(sub, textvariable=self.params[key], width=18).pack()
        #         # Substitua apenas se for um campo numérico
        #         if key in ["Tolerancia", "S_base", "limite_variacao_lev", "limite_variacao_pes", "limite_variacao", "passoE3"]:
        #             ttk.Entry(sub, textvariable=self.params[key], width=18, validate="key", validatecommand=vcmd).pack()
        #         else:
        #             ttk.Entry(sub, textvariable=self.params[key], width=18).pack()

        for idx, key in enumerate(parametros_sistema):
            row, col = divmod(idx, 2)
            sub = ttk.Frame(frame_sistema)
            sub.grid(row=row, column=col, padx=6, pady=6, sticky="w")
            ttk.Label(sub, text=nomes_amigaveis.get(key, key)).pack(anchor="w")

            if key == "SYSname":
                combo_sys = ttk.Combobox(sub, textvariable=self.params[key], width=20, state="readonly")
                combo_sys['values'] = list(self.ARQUIVOS_FIXOS.keys()) + ["Selecionar outro arquivo..."]
                combo_sys.pack(side="left")
                self.widgets[key] = combo_sys
                self.adicionar_tooltip(combo_sys, tooltips_parametros[key])

                def ao_mudar_sysname(event=None):
                    nome = self.params["SYSname"].get()
                    if nome == "Selecionar outro arquivo...":
                        self.selecionar_arquivo()
                    elif nome in self.ARQUIVOS_FIXOS:
                        config = self.ARQUIVOS_FIXOS[nome]
                        for k, v in config.items():
                            if k in self.params:
                                self.params[k].set(v)

                combo_sys.bind("<<ComboboxSelected>>", ao_mudar_sysname)
                ttk.Button(sub, text="...", command=self.selecionar_arquivo).pack(side="left")
            elif key in dropdowns:
                widget = ttk.Combobox(sub, textvariable=self.params[key], values=dropdowns[key], width=15, state="readonly")
                widget.pack()
                self.widgets[key] = widget
                self.adicionar_tooltip(widget, tooltips_parametros[key])
            else:
                if key in ["Tolerancia", "S_base"]:
                    widget = ttk.Entry(sub, textvariable=self.params[key], width=18, validate="key", validatecommand=vcmd)
                else:
                    widget = ttk.Entry(sub, textvariable=self.params[key], width=18)
                widget.pack()
                self.widgets[key] = widget
                self.adicionar_tooltip(widget, tooltips_parametros[key])


        # for idx, key in enumerate(parametros_curva):
        #     row, col = divmod(idx, 2)
        #     sub = ttk.Frame(frame_curva)
        #     sub.grid(row=row, column=col, padx=6, pady=6, sticky="w")
        #     ttk.Label(sub, text=nomes_amigaveis.get(key, key)).pack(anchor="w")

        #     if key in dropdowns:
        #         widget = ttk.Combobox(sub, textvariable=self.params[key], values=dropdowns[key], width=15, state="readonly")
        #         widget.pack()
        #         self.widgets[key] = widget 
        #     else:
        #         widget = ttk.Entry(sub, textvariable=self.params[key], width=18)
        #         widget.pack()
        #         self.widgets[key] = widget 

        #     self.param_widgets[key] = widget  # ← GARANTIA DE SALVAMENTO

        for idx, key in enumerate(parametros_curva):
            row, col = divmod(idx, 2)
            sub = ttk.Frame(frame_curva)
            sub.grid(row=row, column=col, padx=6, pady=6, sticky="w")
            ttk.Label(sub, text=nomes_amigaveis.get(key, key)).pack(anchor="w")

            if key in dropdowns:
                widget = ttk.Combobox(sub, textvariable=self.params[key], values=dropdowns[key], width=15, state="readonly")
            else:
                widget = ttk.Entry(sub, textvariable=self.params[key], width=18)

            widget.pack()
            self.widgets[key] = widget
            self.param_widgets[key] = widget
            self.adicionar_tooltip(widget, tooltips_parametros[key])



        botoes = tk.Frame(self.root, bg="#cce6ff")
        botoes.pack(pady=4)

        style = ttk.Style()
        style.configure("AzulClaro.TButton", background="#1E90FF", foreground="black", font=("TkDefaultFont", 10, "bold"))
        style.map("AzulClaro.TButton", background=[("active", "#1C86EE")])

        style.configure("Verde.TButton", background="green", foreground="black", font=("TkDefaultFont", 10, "bold"))
        style.map("Verde.TButton", background=[("active", "#228B22")])

        style.configure("Vermelho.TButton", background="red", foreground="black", font=("TkDefaultFont", 10, "bold"))
        style.map("Vermelho.TButton", background=[("active", "#8B0000")])

        self.botao_exec = ttk.Button(botoes, text="Executar Estudo", style="AzulClaro.TButton", command=self.executar_estudo_thread)
        self.botao_exec.grid(row=0, column=0, padx=10)

        self.botao_parar = ttk.Button(botoes, text="Parar Estudo", style="Vermelho.TButton", command=self.interromper_estudo)
        self.botao_parar.grid(row=0, column=1, padx=10)

        self.botao_grafico = ttk.Button(botoes, text="Gerar Gráfico", style="AzulClaro.TButton", command=self.popup_grafico)
        self.botao_grafico.grid(row=0, column=2, padx=10)

        self.botao_limpar = ttk.Button(botoes, text="Fechar", style="Vermelho.TButton", command=self.fechar_tudo)
        self.botao_limpar.grid(row=0, column=3, padx=10)


        self.adicionar_tooltip(self.botao_exec,
            "1 - Permite montar a curva PV do 'Arquivo CDF' selecionado seguindo a metodologia escolhida.\n"
            "2 - Retorna o gráfico montado além de imprimir no terminal alguns dados básicos do estudo.")

        self.adicionar_tooltip(self.botao_parar,
            "1 - Permite parar adequadamente a execução a qualquer instância e retorna o gráfico feito até o momento.\n"
            "2 - Somente ao executar com a estratégia 'MAIORES' e se o botão for acionado em certos momentos,\n"
            "    pode não trazer nada, ou apenas parar e aguardar continuar, ou retornar o gráfico parcial.")

        self.adicionar_tooltip(self.botao_grafico,
            "1 - Permite mostrar os gráficos de estudos salvos com possibilidade de filtragem por tipo de barra:\n"
            "    (TODAS, PQ, PV, CRÍTICAS, CHOOSE_BAR).\n"
            "2 - Filtros PQ, PV e TODAS são automáticos.\n"
            "3 - Para CRÍTICAS, defina os limites mínimo e máximo de tensão (pu).\n"
            "    * Sugestões de limites sempre apareceram na primeira vez que gerar o gráfico com TODAS.\n"
            "4 - Para CHOOSE_BAR, digite as barras desejadas (ex: 1-5_7).")

        self.adicionar_tooltip(self.botao_limpar,
            "1 - Fecha todas as figuras e tabelas abertas e limpa o terminal.")

        # self.botao_limpar = ttk.Button(
        #     botoes, text="Fechar", style="Vermelho.TButton",
        #     command=lambda: [self.fechar_tudo(), self.limpar_terminal()]
        # )


        self.status = tk.Label(self.root, text="Aguardando...", bg="#cce6ff", fg="black", font=("Arial", 10, "italic"))
        self.status.pack(fill="x", pady=(5, 10))

        terminal_frame = ttk.LabelFrame(self.root, text="Terminal", padding=5)
        terminal_frame.pack(fill="both", expand=True, padx=10, pady=(0,2))

        self.terminal = scrolledtext.ScrolledText(terminal_frame, height=7, bg="white", fg="black", font=("Courier", 9))
        self.terminal.pack(fill="both", expand=True)
        self.terminal.configure(state="disabled")

        label_barras = ttk.Label(self.root, text="Barras alteradas:", padding=2)
        label_barras.pack(fill="both", expand=True, padx=10, pady=(0, 0))

        frame_texto_barras = ttk.Frame(self.root)
        frame_texto_barras.pack(fill="x", padx=10, pady=(0, 5))

        self.barras_alteradas_text = tk.Text(frame_texto_barras, height=2, font=("Courier", 9), wrap="none")
        self.barras_alteradas_text.pack(side="top", fill="x", expand=True)

        scroll_x = ttk.Scrollbar(frame_texto_barras, orient="horizontal", command=self.barras_alteradas_text.xview)
        scroll_x.pack(side="bottom", fill="x")

        self.barras_alteradas_text.configure(xscrollcommand=scroll_x.set)
        self.barras_alteradas_text.insert("1.0", "")
        self.barras_alteradas_text.config(state="disabled")

        text_redirector = TextRedirector(self.terminal)

        def atualizar_barras_alteradas(msg):
            self.label_barras_alteradas.config(text=msg)

        sys.stdout = TeeStream(text_redirector, terminal_buffer, callback_msg=atualizar_barras_alteradas)
        sys.stderr = TeeStream(text_redirector, terminal_buffer, callback_msg=atualizar_barras_alteradas)

        style.configure("Vermelho.TButton", background="red", foreground="black", font=("TkDefaultFont", 10, "bold"))
        style.map("Vermelho.TButton", background=[("active", "#B22222")])

        self.params["Estrategia"].trace_add("write", self.atualizar_estado_campos)
        self.params["RegimeE3"].trace_add("write", self.atualizar_estado_campos)

        self.atualizar_estado_campos()
        
        coloca_notas_noTerminal()
        self.terminal.see("1.0")

    def get_widget(self, key):
        return self.widgets.get(key)

    # def limpar_terminal(self):
    #     self.terminal.configure(state="normal")
    #     self.terminal.delete("1.0", tk.END)
    #     self.terminal.configure(state="disabled")


    def atualizar_estado_campos(self, *args):
        estrategia = self.params["Estrategia"].get()
        regime = self.params["RegimeE3"].get()

        estado_escolher = "normal" if estrategia == "ESCOLHER" else "disabled"
        estado_levpes = "normal" if regime == "AMBOS" else "disabled"
        estado_geral = "disabled" if regime == "AMBOS" else "normal"

        if self.get_widget("ESCOLHER"):
            self.get_widget("ESCOLHER").config(state=estado_escolher)
        if self.get_widget("limite_variacao_lev"):
            self.get_widget("limite_variacao_lev").config(state=estado_levpes)
        if self.get_widget("limite_variacao_pes"):
            self.get_widget("limite_variacao_pes").config(state=estado_levpes)
        if self.get_widget("limite_variacao"):
            self.get_widget("limite_variacao").config(state=estado_geral)



    def fechar_tudo(self):
        # Fechar figuras do Matplotlib
        
        for manager in _pylab_helpers.Gcf.get_all_fig_managers():
            fig = manager.canvas.figure
            if plt.fignum_exists(fig.number):
                plt.close(fig)

        # Fechar matrizes abertas
        for janela in getattr(self, 'janelas_matrizes', []):
            if janela and janela.winfo_exists():
                janela.destroy()
        self.janelas_matrizes = []

        # Fechar tabelas/listas abertas
        for janela in getattr(self, 'janelas_listas', []):
            if janela and janela.winfo_exists():
                janela.destroy()
        self.janelas_listas = []

        self.terminal.configure(state='normal')
        self.terminal.delete('1.0', tk.END)
        self.terminal.configure(state='disabled')
        coloca_notas_noTerminal()
        self.terminal.see("1.0")
        self.status.config(text="Todas as janelas e gráficos foram fechados.")

    def limpar_terminal(self):
        self.terminal.configure(state='normal')
        self.terminal.delete('1.0', tk.END)
        self.terminal.configure(state='disabled')




    def exibir_barras_alteradas(self, vetor_barras, vetor_porcentagens=None):
        texto_barras = "Barras: " + "_".join(str(b) for b in vetor_barras)
        
        if vetor_porcentagens is not None:
            texto_porcentagem = "Porcentagens: " + "_".join(f"{p:.2f}" for p in vetor_porcentagens)
            texto_final = texto_barras + "\n" + texto_porcentagem
        else:
            texto_final = texto_barras
        
        self.barras_alteradas_text.config(state="normal")
        self.barras_alteradas_text.delete("1.0", "end")
        self.barras_alteradas_text.insert("1.0", texto_final)
        self.barras_alteradas_text.config(state="disabled")

        self.barras_alteradas_text.xview_moveto(1.0)  # move a visualização para o final horizontal



    def interromper_estudo(self):
        if not getattr(self, "executando", False):
            self.status.config(text="Nenhum estudo em execução.")
            return

        p = {k: v.get() for k, v in self.params.items()}

        if p["RegimeE3"] == "AMBOS":
            self.stop_signal = not getattr(self, "stop_signal", False)

            if self.stop_signal:
                self.botao_parar.config(text="Continuar")
                self.status.config(text="Estudo em pausa. Clique em 'Continuar' para prosseguir.")
            else:
                self.botao_parar.config(text="Parar Estudo")
                self.status.config(text="Continuando o estudo…")
        else:
            self.stop_signal = True
            self.status.config(text="Execução interrompida pelo usuário.")



    def selecionar_arquivo(self):
        caminho = filedialog.askopenfilename(filetypes=[("CDF Files", "*.cdf")])
        if caminho:
            self.params["SYSname"].set(caminho)



    def executar_estudo_thread(self):
        # Limpa o terminal (caso tenha um terminal do tipo Text)
        self.terminal.config(state="normal")
        self.terminal.delete("1.0", tk.END)
        self.terminal.config(state="disabled")

        threading.Thread(target=self.executar_estudo, daemon=True).start()

    def _exibir_erro(self, mensagem, titulo="Erro"):
        messagebox.showerror(titulo, mensagem)

    # def _habilitar_botoes(self):
    #     self.executar_button.config(state="normal")
    #     self.limpar_button.config(state="normal")
    #     self.salvar_button.config(state="normal")


    def executar_estudo(self):
        cdf_nome = self.params["SYSname"].get().strip()
        self.botao_parar.config(state=tk.NORMAL)

        if "Selecionar outro arquivo..." in cdf_nome and not os.path.isfile(cdf_nome):
            messagebox.showerror("Erro de entrada", "Você selecionou 'Selecionar outro' mas não forneceu um arquivo .CDF válido.")
            self.status.config(text="⚠️ Corrija o campo 'Arquivo CDF'.")
            print('❗❗❗❗❗❗❗❗❗❗❗❗   ERRO GRAVE DE EXECUÇÃO IDENTIFICADO   ❗❗❗❗❗❗❗❗❗❗❗❗')
            print('\n   - Preencheu adequadamente todos os campos?')
            print('   - Arquivo CDF convergindo inicialmente?')  
            self.botao_exec.config(state=tk.NORMAL)
            self.botao_parar.config(state=tk.DISABLED)
            return

        # 2. Campos obrigatórios comuns
        campos_obrigatorios = {
            "Tolerancia": "Tolerância",
            "S_base": "S base (MVA)",
            "passoE3": "Passo de Variação (pu)",
            "Comt_Max": "Comutação Máxima"
        }

        # Checagem dos limites conforme o regime
        regime = self.params["RegimeE3"].get()
        if regime == "AMBOS":
            campos_obrigatorios.update({
                "limite_variacao_lev": "Limite LEVE (%)",
                "limite_variacao_pes": "Limite PESADO (%)"
            })
        else:
            campos_obrigatorios.update({
                "limite_variacao": "Limite Geral (%)"
            })

        # tol=self.params["Tolerancia"].get()
        # potBase=self.params["S_base"].get()
        # limMAX = self.params["limite_variacao_pes"].get()
        # limMIN = self.params["limite_variacao_lev"].get()
        # limGER = self.params["limite_variacao"].get()   
        # Comut = self.params["Comt_Max"].get()      
                
        
        #liberar='no'
        try:
            def raise_erro():
                messagebox.showerror("Erro de entrada", f"O campo obrigatório '{nome}' está vazio ou inválido. Por favor, preencha corretamente.")
                self.status.config(text=f"⚠️ Preencha o campo '{nome}' para continuar.")
                self.botao_exec.config(state=tk.NORMAL)
                self.botao_parar.config(state=tk.DISABLED)
                raise Exception("Interrompido por campo obrigatório inválido.")
                    
            for chave, nome in campos_obrigatorios.items():
                valor = self.params[chave].get()
                if isinstance(valor, str):
                    if not valor.strip():
                        raise_erro()
                else:
                    if valor is None or valor == 0:
                        raise_erro()
            liberar='yes'
        except:
            liberar='no'
            messagebox.showerror("Erro de entrada", f"O campo obrigatório '{nome}' está vazio ou inválido. Por favor, preencha corretamente.")
            self.status.config(text=f"⚠️ Preencha o campo '{nome}' para continuar.")
            self.botao_exec.config(state=tk.NORMAL)
            self.botao_parar.config(state=tk.DISABLED)

        if liberar=='yes':
            self.status.config(text="Executando estudo... Aguarde.")
            self.botao_exec.state(["disabled"])
            self.executando = True
            self.stop_signal = False  # Resetar antes de iniciar novo estudo
            # stop_checker = lambda regime: (
            #     self.stop_signal_leve if regime == "LEVE" else
            #     self.stop_signal_pesado if regime == "PESADO" else False
            # )
            self.botao_parar.config(text="Parar Estudo")
            self.limpar_terminal()
            terminal_buffer.seek(0)
            terminal_buffer.truncate(0)

            #self.botao_gerar_grafico.config(state="disabled")

            p = {k: v.get() for k, v in self.params.items()}
            nameDir = pega_nome_maiusculo(p["SYSname"])
            if p["Logica_Spl"]!=0:
                portas_e3 = [
                    p["SYSname"], p["MODELin"], p["Tolerancia"], p["HabiltAval_Lim_Reativo"], p["S_base"], p["Desabilitar_CS"],
                    p["Logica_Spl"] , p["Comt_Max"] , p["Ativar_inverter"], p["passoE3"], p["limite_variacao"], p["RegimeE3"],
                    p["limite_variacao_lev"], p["limite_variacao_pes"], p["Estrategia"], p["ESCOLHER"], p["GirarTrafo"]
                ]
            else:
                portas_e3 = [
                    p["SYSname"], p["MODELin"], p["Tolerancia"], p["HabiltAval_Lim_Reativo"], p["S_base"], p["Desabilitar_CS"],
                    None , p["Comt_Max"] , p["Ativar_inverter"], p["passoE3"], p["limite_variacao"], p["RegimeE3"],
                    p["limite_variacao_lev"], p["limite_variacao_pes"], p["Estrategia"], p["ESCOLHER"], p["GirarTrafo"]
                ]


            if p["Estrategia"] == "ESCOLHER":
                # Mensagens
                msg1 = "⏳ INICIANDO MONTAGEM DAS CURVAS PV"
                msg2 = f"SISTEMA {p['SYSname']} - ESTRATÉGIA ESCOLHER"

                # Determinar a maior largura entre as mensagens
                largura_msg = max(len(msg1), len(msg2))

                # Linha dupla do tamanho exato
                linha = "═" * largura_msg

                # Centralizar todas com base no terminal
                print(msg1.center(78))
                print(msg2.center(80))
                print(linha.center(80))
                
                ([matrizSystem],[matrizSystem2])=Ler_Arquivo(p["SYSname"])
                len_sys0=len(matrizSystem)

                try:
                    verificar_intervalo_escolher(self.params)
                except ValueError as e:
                    messagebox.showerror("Erro no campo 'ESCOLHER'", str(e))
                    self.status.config(text="⚠️ Erro de entrada. Corrija e tente novamente.")
                    self.botao_exec.config(state=tk.NORMAL)
                    self.botao_parar.config(state=tk.DISABLED)
                    return

                # Depois de validar formato do campo ESCOLHER
                try:
                    valor = self.params["ESCOLHER"].get().strip()
                    barras_escolhidas = set()

                    for parte in valor.split('_'):
                        if '-' in parte:
                            inicio, fim = map(int, parte.split('-'))
                            barras_escolhidas.update(range(inicio, fim + 1))
                        else:
                            barras_escolhidas.add(int(parte))

                    contador_deBarr = len(barras_escolhidas)
                    #len_sys0 = self.total_barras_sistema  # ← Certifique-se que isso esteja correto

                    if contador_deBarr > len_sys0:
                        raise ValueError(f"O número de barras solicitadas ({contador_deBarr}) excede o total do sistema ({len_sys0}).")

                except Exception as e:
                    print('❗❗❗❗❗❗❗❗❗❗❗❗   ERRO GRAVE DE EXECUÇÃO IDENTIFICADO   ❗❗❗❗❗❗❗❗❗❗❗❗')
                    print('\n   - Preencheu adequadamente todos os campos?')
                    print('   - Arquivo CDF convergindo inicialmente?')  
                    messagebox.showerror("Erro no campo 'ESCOLHER'", f"{e}\nInsira um intervalo válido. Ex: 1-5_8_10")
                    self.status.config(text="⚠️ Erro de entrada. Corrija e tente novamente.")
                    self.botao_exec.config(state=tk.NORMAL)
                    self.botao_parar.config(state=tk.DISABLED)
                    return
                
                self.botao_parar.config(state=tk.NORMAL)
                portas_e4=[matrizSystem, matrizSystem2]           
                EvolutionMatrixMatriz2, infoVctrl, Evolution_fpGer, pontoInicial = CHAMA_PVCURVE_ESCOLHER(portas_e3, portas_e4, stop_checker=lambda: self.stop_signal, callback_barras=self.exibir_barras_alteradas)
            else:

                # Mensagens
                msg1 = "⏳ INICIANDO MONTAGEM DAS CURVAS PV"
                msg2 = f"SISTEMA {p['SYSname']} - ESTRATÉGIA MAIORES"

                # Determinar a maior largura entre as mensagens
                largura_msg = max(len(msg1), len(msg2))

                # Linha dupla do tamanho exato
                linha = "═" * largura_msg

                # Centralizar todas com base no terminal
                print(msg1.center(78))
                print(msg2.center(80))
                print(linha.center(80))

                EvolutionMatrixMatriz2, infoVctrl, Evolution_fpGer, pontoInicial = CHAMA_PVCURVE_MAIORES(portas_e3, stop_checker=lambda: self.stop_signal, callback_barras=self.exibir_barras_alteradas)


            soma_P_0 = sum(pontoInicial)
            parameters = {**p, "SOMA_P_0": soma_P_0}
            pv_dir = os.path.join(os.getcwd(), "plot", "GenOfCurvs")
            try:
                PONTOS_LIMITES = determina_LimitesDeControlPotQsobrePVcurv(EvolutionMatrixMatriz2, infoVctrl)
            except:
                PONTOS_LIMITES=None


            portas_e4 = [parameters, PONTOS_LIMITES, pv_dir, soma_P_0]

            try:
                EvolutionMatrixMatriz2.append(p["SYSname"])

                # Captura o terminal completo ANTES do salvamento
                log_terminal = terminal_buffer.getvalue()
                #portas_e4.append(log_terminal)  # adiciona como 5º item da lista portas_e4

                sys.stdout.flush()
                log_terminal = terminal_buffer.getvalue()
                portas_e4.append(log_terminal)

                CHAMA_savePVcurve(EvolutionMatrixMatriz2, infoVctrl, portas_e3, portas_e4)
                #print("✅ CHAMA_savePVcurve executada com sucesso")

                vetor = list(range(len(infoVctrl[0])))
                print('\n\n')
                msg1 = "⏳ FINALIZANDO MONTAGEM DAS CURVAS PV"
                msg2 = f"SISTEMA {p['SYSname']} - ESTRATÉGIA {p["Estrategia"]}"

                # Determinar a maior largura entre as mensagens
                largura_msg = max(len(msg1), len(msg2))

                # Linha dupla do tamanho exato
                linha = "═" * largura_msg

                # Centralizar todas com base no terminal
                print(msg1.center(78))
                print(msg2.center(80))
                print(linha.center(80))

                self.root.after(0, lambda: loadPVCurveInscrita(EvolutionMatrixMatriz2, vetor, PONTOS_LIMITES, soma_P_0))

                self.status.config(text="Estudo finalizado com sucesso!")
                self.botao_parar.config(text="Parar Estudo")
                self.executando = False
                self.stop_signal = False
            except Exception as e:
                print(f"\nErro ao salvar ou carregar curva: {e}")
                self.stop_signal = False
                self.status.config(text="Estudo finalizado sem êxito!")
                self.botao_parar.config(text="Parar Estudo")
                self.executando = False
            self.botao_exec.state(["!disabled"])
        else:
            print('❗❗❗❗❗❗❗❗❗❗❗❗   ERRO GRAVE DE EXECUÇÃO IDENTIFICADO   ❗❗❗❗❗❗❗❗❗❗❗❗')
            print('\n   - Preencheu adequadamente todos os campos?')
            print('   - Arquivo CDF convergindo inicialmente?')
           # self.botao_exec.state(["!disabled"])


    def gerar_plot3(self, popup, cb_estudo, cb_tipo, entrada_barras, entrada_min, entrada_max):
        nome = cb_estudo.get()
        sel = cb_tipo.get()
        
        min_lim = max_lim = None
        if sel == "CRITICAS":
            try:
                min_lim = float(entrada_min.get())
                max_lim = float(entrada_max.get())
                if min_lim >= max_lim:
                    raise ValueError("Limite mínimo deve ser menor que o máximo.")
            except Exception as e:
                messagebox.showerror("Erro de Entrada", f"Preencha corretamente os limites mínimo e máximo (números válidos e min < max).\n\nErro: {e}")
                return

        barras = entrada_barras.get()

        if not nome:
            messagebox.showwarning("Aviso", "Nenhum estudo selecionado.")
            return

        caminho_csv = os.path.join("plot", "GenOfCurvs", nome)

        if os.path.exists(caminho_csv):
            log = extrair_log_terminal_limpo(caminho_csv)
            #print
            # Exibe o log no terminal da GUI (apenas aqui)
            self.terminal.configure(state='normal')
            self.terminal.delete("1.0", "end")
            self.terminal.insert("end", f"🖥️ 🖥️ 🖥️ 🖥️  INICIO DO LOG SALVO PARA {nome}  🖥️ 🖥️ 🖥️ 🖥️\n")
            self.terminal.insert("end", log)
            self.terminal.see("end")
            self.terminal.configure(state='disabled')
            #print()
        else:
            print(f"Arquivo CSV do estudo '{nome}' não encontrado em: {caminho_csv}")
        
        if sel == "CRITICAS":
            barras = "CRITICAS"
            sel_ajustado = "CHOOSE_BAR"
        else:
            sel_ajustado = sel

        #DADOS = [nome, "PxV", sel, barras]
        DADOS = [nome, "PxV", sel_ajustado, barras, min_lim, max_lim]
        os.system('cls' if os.name == 'nt' else 'clear')
        print(f'🖥️ 🖥️ 🖥️ 🖥️   FIM DO LOG SALVO PARA {nome}  🖥️ 🖥️ 🖥️ 🖥️')
        print('______________________________________________________________________________')
        print('\n')
        msg1 = f"⏳ MONTAGEM DAS CURVAS PV: SISTEMA {nome}"
        

        # Determinar a maior largura entre as mensagens
        largura_msg = len(msg1)

        # Linha dupla do tamanho exato
        linha = "═" * largura_msg

        # Centralizar todas com base no terminal
        print(msg1.center(78))
        #print(msg2.center(80))
        print(linha.center(80))
        CHAMA_PLOT3(DADOS)
        #self.figuras_abertas.append(CEL)




    # def popup_grafico(self):
        
    #     popup = tk.Toplevel(self.root)
    #     popup.title("Parâmetros do Gráfico")
    #     popup.configure(bg="#f0f8ff")
    #     popup.geometry("480x420")
    #     popup.resizable(False, False)

    #     style = ttk.Style(popup)
    #     style.configure("Popup.TLabel", background="#f0f8ff")
    #     style.configure("Verde.TButton", background="green", foreground="black", font=("TkDefaultFont", 10, "bold"))
    #     style.map("Verde.TButton", background=[("active", "#228B22")])

    #     # Frame topo com combo + botão
    #     top_frame = ttk.Frame(popup)
    #     top_frame.pack(fill="x", pady=5)

    #     arquivos = [f for f in os.listdir("plot/GenOfCurvs") if f.endswith(".csv")]
    #     arquivos.sort()
    #     cb_estudo = ttk.Combobox(top_frame, values=arquivos, state="readonly", width=30)
    #     cb_estudo.pack(side="left", padx=(10, 5))
    #     cb_estudo.set(arquivos[0] if arquivos else "")


    #     self.botao_gerar_grafico = ttk.Button(top_frame, text="Gerar", style="Verde.TButton", command=lambda: self.gerar_plot3(popup, cb_estudo, cb_tipo, entrada_barras, entrada_min, entrada_max))
    #     self.botao_gerar_grafico.pack(side="right", padx=10)


    #     # Frame para limites (lado a lado) com fundo igual ao popup
    #     limites_frame = tk.Frame(popup, bg="#f0f8ff")
    #     limites_frame.pack(pady=(10, 5), padx=10, fill="x")

    #     # Labels lado a lado
    #     label_min = tk.Label(limites_frame, text="Limite Mínimo (pu):", bg="#f0f8ff")
    #     label_min.grid(row=0, column=0, sticky="w", padx=(0, 10))

    #     label_max = tk.Label(limites_frame, text="Limite Máximo (pu):", bg="#f0f8ff")
    #     label_max.grid(row=0, column=1, sticky="e", padx=(220, 0))

    #     # Entradas usando tk.Entry para permitir bg customizado
    #     entrada_min = tk.Entry(limites_frame, width=15, state="disabled", bg="#ffffff")
    #     entrada_min.grid(row=1, column=0, sticky="w", padx=(0, 10))

    #     entrada_max = tk.Entry(limites_frame, width=15, state="disabled", bg="#ffffff")
    #     entrada_max.grid(row=1, column=1, sticky="e", padx=(10, 0))


    #     # Tipo de curva
    #     ttk.Label(popup, text="Tipo de Curva:", style="Popup.TLabel").pack(pady=(10, 1))
    #     cb_tipo = ttk.Combobox(popup, values=["TODAS", "PV", "PQ", "CHOOSE_BAR", "CRITICAS"], state="readonly")
    #     cb_tipo.set("TODAS")
    #     cb_tipo.pack()

    #     # Seleção de barras
    #     ttk.Label(popup, text="Selecionar Barras:", style="Popup.TLabel").pack(pady=(10, 1))
    #     entrada_barras = ttk.Entry(popup, width=40, state="disabled")
    #     entrada_barras.pack()

    #     # Atualiza campos ao mudar o tipo
    #     def ao_mudar_tipo(event=None):
    #         tipo = cb_tipo.get()

    #         if tipo == "CRITICAS":
    #             entrada_min.config(state="normal")
    #             entrada_max.config(state="normal")
    #         else:
    #             entrada_min.delete(0, "end")
    #             entrada_max.delete(0, "end")
    #             entrada_min.config(state="disabled")
    #             entrada_max.config(state="disabled")

    #         if tipo == "CHOOSE_BAR":
    #             entrada_barras.config(state="normal")
    #             entrada_barras.delete(0, "end")
    #         else:
    #             entrada_barras.delete(0, "end")
    #             entrada_barras.config(state="disabled")

    #     cb_tipo.bind("<<ComboboxSelected>>", ao_mudar_tipo)

    #     # Área de informações do estudo
    #     info_frame = ttk.Frame(popup)
    #     info_frame.pack(fill="both", expand=True, padx=5, pady=10)

    #     info_text = tk.Text(info_frame, height=10, bg="#ffffff", state="disabled")
    #     info_text.pack(fill="both", expand=True)

    #     def carregar_info(event=None):
    #         arquivo = cb_estudo.get()
    #         if not arquivo:
    #             return
    #         caminho = os.path.join("plot/GenOfCurvs", arquivo)
    #         params = {}
    #         try:
    #             with open(caminho, newline='') as f:
    #                 for linha in f:
    #                     if "=" in linha:
    #                         k, v = linha.strip().split("=", 1)
    #                         params[k.strip()] = v.strip()
    #         except:
    #             params = {}
    #         info_text.config(state="normal")
    #         info_text.delete("1.0", "end")
    #         info_text.insert("end", "Parâmetros do estudo selecionado:\n")
    #         for k, v in params.items():
    #             info_text.insert("end", f"{k} = {v}\n")
    #         info_text.config(state="disabled")

    #     cb_estudo.bind("<<ComboboxSelected>>", carregar_info)
    #     carregar_info()

    #     # Tooltips
    #     def bind_tip(w, txt):
    #         tip = tk.Toplevel(popup)
    #         tip.withdraw()
    #         tip.overrideredirect(True)
    #         lbl = tk.Label(tip, text=txt, bg="#ffffe0", relief="solid", bd=1, font=("Arial", 9))
    #         lbl.pack()

    #         def enter(e): tip.geometry(f"+{e.x_root+10}+{e.y_root+10}"); tip.deiconify()
    #         def leave(e): tip.withdraw()
    #         w.bind("<Enter>", enter)
    #         w.bind("<Leave>", leave)

    #     bind_tip(cb_estudo, "Escolha o estudo (.csv)")
    #     bind_tip(cb_tipo, "Tipo de curva (TODAS, PV, PQ, CHOOSE_BAR, CRITICAS)")
    #     bind_tip(entrada_barras, "Informe as barras (ex: 1-9_11)")

    #     popup.lift()


    def popup_grafico(self):
        if self.janela_parametros_grafico and self.janela_parametros_grafico.winfo_exists():
            self.janela_parametros_grafico.lift()
            self.janela_parametros_grafico.focus_force()
            return

        popup = tk.Toplevel(self.root)
        popup.title("Parâmetros do Gráfico")
        popup.configure(bg="#f0f8ff")
        popup.geometry("480x420")
        popup.resizable(False, False)
        self.janela_parametros_grafico = popup
        popup.protocol("WM_DELETE_WINDOW", lambda: self.fechar_popup_grafico())

        style = ttk.Style(popup)
        style.configure("Popup.TLabel", background="#f0f8ff")
        style.configure("Verde.TButton", background="green", foreground="black", font=("TkDefaultFont", 10, "bold"))
        style.map("Verde.TButton", background=[("active", "#228B22")])

        # Frame topo com combo + botão
        top_frame = ttk.Frame(popup)
        top_frame.pack(fill="x", pady=5)

        arquivos = [f for f in os.listdir("plot/GenOfCurvs") if f.endswith(".csv")]
        arquivos.sort()
        cb_estudo = ttk.Combobox(top_frame, values=arquivos, state="readonly", width=30)
        cb_estudo.pack(side="left", padx=(10, 5))
        cb_estudo.set(arquivos[0] if arquivos else "")

        self.botao_gerar_grafico = ttk.Button(
            top_frame, text="Gerar", style="Verde.TButton",
            command=lambda: self.gerar_plot3(popup, cb_estudo, cb_tipo, entrada_barras, entrada_min, entrada_max)
        )
        self.botao_gerar_grafico.pack(side="right", padx=10)

        # Frame para limites
        limites_frame = tk.Frame(popup, bg="#f0f8ff")
        limites_frame.pack(pady=(10, 5), padx=10, fill="x")

        label_min = tk.Label(limites_frame, text="Limite Mínimo (pu):", bg="#f0f8ff")
        label_min.grid(row=0, column=0, sticky="w", padx=(0, 10))

        label_max = tk.Label(limites_frame, text="Limite Máximo (pu):", bg="#f0f8ff")
        label_max.grid(row=0, column=1, sticky="e", padx=(220, 0))

        entrada_min = tk.Entry(limites_frame, width=15, state="disabled", bg="#ffffff")
        entrada_min.grid(row=1, column=0, sticky="w", padx=(0, 10))

        entrada_max = tk.Entry(limites_frame, width=15, state="disabled", bg="#ffffff")
        entrada_max.grid(row=1, column=1, sticky="e", padx=(10, 0))

        # Tipo de curva
        ttk.Label(popup, text="Tipo de Curva:", style="Popup.TLabel").pack(pady=(10, 1))
        cb_tipo = ttk.Combobox(popup, values=["TODAS", "PV", "PQ", "CHOOSE_BAR", "CRITICAS"], state="readonly")
        cb_tipo.set("TODAS")
        cb_tipo.pack()

        # Seleção de barras
        ttk.Label(popup, text="Selecionar Barras:", style="Popup.TLabel").pack(pady=(10, 1))
        entrada_barras = ttk.Entry(popup, width=40, state="disabled")
        entrada_barras.pack()

        def ao_mudar_tipo(event=None):
            tipo = cb_tipo.get()
            if tipo == "CRITICAS":
                entrada_min.config(state="normal")
                entrada_max.config(state="normal")
            else:
                entrada_min.delete(0, "end")
                entrada_max.delete(0, "end")
                entrada_min.config(state="disabled")
                entrada_max.config(state="disabled")
            if tipo == "CHOOSE_BAR":
                entrada_barras.config(state="normal")
                entrada_barras.delete(0, "end")
            else:
                entrada_barras.delete(0, "end")
                entrada_barras.config(state="disabled")

        cb_tipo.bind("<<ComboboxSelected>>", ao_mudar_tipo)

        # Área de informações do estudo
        info_frame = ttk.Frame(popup)
        info_frame.pack(fill="both", expand=True, padx=5, pady=10)

        info_text = tk.Text(info_frame, height=10, bg="#ffffff", state="disabled")
        info_text.pack(fill="both", expand=True)

        def carregar_info(event=None):
            arquivo = cb_estudo.get()
            if not arquivo:
                return
            caminho = os.path.join("plot/GenOfCurvs", arquivo)
            params = {}
            try:
                with open(caminho, newline='') as f:
                    for linha in f:
                        if "=" in linha:
                            k, v = linha.strip().split("=", 1)
                            params[k.strip()] = v.strip()
            except:
                params = {}
            info_text.config(state="normal")
            info_text.delete("1.0", "end")
            info_text.insert("end", "Parâmetros do estudo selecionado:\n")
            for k, v in params.items():
                info_text.insert("end", f"{k} = {v}\n")
            info_text.config(state="disabled")

        cb_estudo.bind("<<ComboboxSelected>>", carregar_info)
        carregar_info()

        # Tooltips
        def bind_tip(w, txt):
            tip = tk.Toplevel(popup)
            tip.withdraw()
            tip.overrideredirect(True)
            lbl = tk.Label(tip, text=txt, bg="#ffffe0", relief="solid", bd=1, font=("Arial", 9))
            lbl.pack()
            def enter(e): tip.geometry(f"+{e.x_root+10}+{e.y_root+10}"); tip.deiconify()
            def leave(e): tip.withdraw()
            w.bind("<Enter>", enter)
            w.bind("<Leave>", leave)

        bind_tip(cb_estudo, "Escolha o estudo (.csv)")
        bind_tip(cb_tipo, "Tipo de curva (TODAS, PV, PQ, CHOOSE_BAR, CRITICAS)")
        bind_tip(entrada_barras, "Informe as barras (ex: 1-9_11)")


    def fechar_popup_grafico(self):
        if self.janela_parametros_grafico:
            self.janela_parametros_grafico.destroy()
            self.janela_parametros_grafico = None



    def adicionar_tooltip(self, widget, texto):
        tooltip = None

        def mostrar_tooltip(event):
            nonlocal tooltip
            x = widget.winfo_rootx() + 20
            y = widget.winfo_rooty() + 20
            tooltip = tk.Toplevel(widget)
            tooltip.wm_overrideredirect(True)
            tooltip.wm_geometry(f"+{x}+{y}")
            label = tk.Label(
                tooltip,
                text=texto,
                justify="left",
                background="#ffffe0",
                relief="solid",
                borderwidth=1,
                font=("Arial", 7)
            )
            label.pack(ipadx=1)

        def esconder_tooltip(event):
            nonlocal tooltip
            if tooltip:
                tooltip.destroy()
                tooltip = None

        widget.bind("<Enter>", mostrar_tooltip)
        widget.bind("<Leave>", esconder_tooltip)





# if __name__ == "__main__":
#     root = tk.Tk()
#     root.withdraw()  # Oculta a tela principal enquanto mostra o splash
#     splash = mostrar_splash_temporario(root)

#     extrair_recursos_embutidos()
#     verificar_bibliotecas()
#     #verificar_e_criar_pastas()

#     def on_closing():
#         root.quit()
#         root.destroy()
#         for manager in _pylab_helpers.Gcf.get_all_fig_managers():
#             fig = manager.canvas.figure
#             if plt.fignum_exists(fig.number):
#                 plt.close(fig)
        
#         sys.stdout = sys.__stdout__
#         sys.stderr = sys.__stderr__

#     def iniciar_interface():
#         splash.destroy()
#         #root = tk.Tk()
#         app = TelaEstudosPV(root)
#         root.protocol("WM_DELETE_WINDOW", on_closing)
#         root.mainloop()



#     def get_widget2(self, nome):
#         return self.param_widgets.get(nome, None)
        
#     def atualizar_estado_campos(self):
#         estrategia = self.params["Estrategia"].get()
#         regime = self.params["RegimeE3"].get()
        
#         estado_escolher = "normal" if estrategia == "ESCOLHER" else "disabled"
#         estado_limite_geral = "normal" if regime == "LEVE" or regime == "PESADO" else "disabled"
#         estado_limites_parciais = "normal" if regime == "AMBOS" else "disabled"
        
#         widget_escolher = self.get_widget2("ESCOLHER")
#         if widget_escolher: widget_escolher.config(state=estado_escolher)
        
#         widget_limite_geral = self.get_widget2("limite_variacao")
#         if widget_limite_geral: widget_limite_geral.config(state=estado_limite_geral)
        
#         widget_lev = self.get_widget2("limite_variacao_lev")
#         if widget_lev: widget_lev.config(state=estado_limites_parciais)
        
#         widget_pes = self.get_widget2("limite_variacao_pes")
#         if widget_pes: widget_pes.config(state=estado_limites_parciais)







if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()  # Oculta a tela principal enquanto mostra o splash

    splash = mostrar_splash_temporario(root)  # Agora sim, seguro!    
    extrair_recursos_embutidos()
    verificar_bibliotecas()
    # verificar_e_criar_pastas()

    BASE_DIR = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.dirname(__file__)
    os.chdir(BASE_DIR)



    def on_closing():
        root.quit()
        root.destroy()
        for manager in _pylab_helpers.Gcf.get_all_fig_managers():
            fig = manager.canvas.figure
            if plt.fignum_exists(fig.number):
                plt.close(fig)
        sys.stdout = sys.__stdout__
        sys.stderr = sys.__stderr__

    def iniciar_interface():
        app = TelaEstudosPV(root)
        root.protocol("WM_DELETE_WINDOW", on_closing)
        splash.destroy()
        root.mainloop()

    root.after(3500, iniciar_interface)
    root.mainloop()





