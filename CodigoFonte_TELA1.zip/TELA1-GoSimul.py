import tkinter as tk
from tkinter import ttk

def mostrar_splash_temporario(root: tk.Tk) -> tk.Toplevel:
    """Splash de abertura para a TELA 1 – GoSimul."""
    # ── Janela sem moldura ───────────────────────────────────────────────
    splash = tk.Toplevel(root)
    splash.overrideredirect(True)

    L, A = 460, 180  # largura / altura
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    splash.geometry(f"{L}x{A}+{(sw-L)//2}+{(sh-A)//2}")

    # ── Paleta da Tela 1 ────────────────────────────────────────────────
    LILAS_CLARO = "#ccffcc"   # fundo (verde bem claro)
    ROXO_ESCURO = "#2e005d"   # linhas da curva / textos
    splash.configure(bg=LILAS_CLARO)

    # ── Logo (cardiograma) ──────────────────────────────────────────────
    canvas = tk.Canvas(splash, width=260, height=70,
                       bg=LILAS_CLARO, highlightthickness=0)
    canvas.place(x=15, y=20)

    # Eixos X e Y
    x_ini, y_base = 20, 65
    canvas.create_line(x_ini-10, y_base, x_ini+230, y_base,
                       fill="black", width=1)
    canvas.create_line(x_ini, y_base+25, x_ini, y_base-35,
                       fill="black", width=1)

    # “Assinatura elétrica” (sinal)
    sinal_pts = [
        (20, 50), (30, 45), (40, 47), (50, 52), (60, 48),
        (70, 45), (80, 30), (90, 70), (100, 32), (110, 50),
        (120, 48), (130, 49), (140, 50), (150, 51), (160, 50),
        (170, 48), (180, 50), (190, 50), (200, 51), (210, 50)
    ]
    for a, b in zip(sinal_pts, sinal_pts[1:]):
        canvas.create_line(*a, *b, fill=ROXO_ESCURO, width=3)

    # ── Texto e barra de progresso ──────────────────────────────────────
    ttk.Label(splash, text="Iniciando GoSimul…",
              font=("Segoe UI", 13, "bold"),
              background=LILAS_CLARO).place(relx=0.55, rely=0.25, anchor="w")

    msg_label = ttk.Label(splash, text="Carregando bibliotecas…",
                          font=("Segoe UI", 10), background=LILAS_CLARO)
    msg_label.place(relx=0.55, rely=0.52, anchor="w")

    barra = ttk.Progressbar(splash, mode="indeterminate", length=180)
    barra.place(relx=0.55, rely=0.75, anchor="w")
    barra.start(12)

    # Mensagens animadas
    mensagens = [
        "Carregando bibliotecas…",
        "Verificando dependências…",
        "Extraindo arquivos embutidos…",
        "Preparando interface…"
    ]
    def avançar(i=0):
        if i < len(mensagens):
            msg_label.config(text=mensagens[i])
            splash.after(800, lambda: avançar(i+1))
    splash.after(50, avançar)

    return splash




import os
import sys
import zipfile
from tkinter import filedialog, messagebox
import threading
from matplotlib import pyplot as plt
from matplotlib import _pylab_helpers
from tkinter.scrolledtext import ScrolledText
import sys
import platform
import math


def extrair_recursos_embutidos():
    # Diretório onde o .exe está rodando
    if getattr(sys, 'frozen', False):
        executavel_path = sys.executable
        base_dir = os.path.dirname(executavel_path)
        recurso_zip = os.path.join(sys._MEIPASS, 'recursos_embutidos.zip')
    else:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        recurso_zip = os.path.join(base_dir, 'recursos_embutidos.zip')

    # Pasta de destino para extração
    destinos = [
        os.path.join(base_dir, 'ieee9_Marcelo.cdf'),
        os.path.join(base_dir, 'ieee14.cdf'),
        os.path.join(base_dir, 'ieee30.cdf'),
        os.path.join(base_dir, 'ieee118.cdf'),
        os.path.join(base_dir, 'plot'),
    ]

    # Verifica se já existe
    if not all(os.path.exists(d) for d in destinos):
        print("Extraindo arquivos necessários...")
        with zipfile.ZipFile(recurso_zip, 'r') as zip_ref:
            zip_ref.extractall(base_dir)


from verificacoes_iniciais import verificar_bibliotecas, verificar_e_criar_pastas

verificar_bibliotecas()
#verificar_e_criar_pastas()





from G_FUNCAO_A import (
    GoS_generator_FluxoInicial, GoS_generator_FluxoManual,
    Encabecalha_plot_PotGer, Encabecalha_plot, modificar_cdf,
    GoS_generator_EvolutionCurves, read_vector_csv,
    organiza_e_filtra_DADOS_das_Evolucoes, plot_evolution
)

from G_FUNCAO_A import junta_tabelas_fluxo

class TextRedirector:
    def __init__(self, widget, tag="stdout"):
        self.widget = widget
        self.tag = tag

    def write(self, text):
        self.widget.configure(state="normal")
        self.widget.insert("end", text)
        self.widget.see("end")
        self.widget.configure(state="disabled")

    def flush(self):
        pass


def centralizar_janela(janela, largura_min=800, altura_min=600):
    janela.update_idletasks()
    largura = max(janela.winfo_width(), largura_min)
    altura = max(janela.winfo_height(), altura_min)
    x = (janela.winfo_screenwidth() // 2) - (largura // 2)
    y = (janela.winfo_screenheight() // 2) - (altura // 2)
    janela.geometry(f"{largura}x{altura}+{x}+{y}")


def centralizar_janela1(janela, largura_min=100, altura_min=25):
    janela.update_idletasks()

    # Define um tamanho maior fixo ou mínimo
    largura = max(janela.winfo_width(), largura_min)
    #altura = max(janela.winfo_height(), altura_min)
    altura=150

    x = (janela.winfo_screenwidth() // 2) - (largura // 2)
    y = (janela.winfo_screenheight() // 2) - (altura // 2)

    janela.geometry(f"{largura}x{altura}+{x}+{y}")


def centralizar_janela2(janela, largura_min=400, altura_min=250):
    janela.update_idletasks()

    # Define um tamanho maior fixo ou mínimo
    largura = max(janela.winfo_width(), largura_min)
    altura = max(janela.winfo_height(), altura_min)

    x = (janela.winfo_screenwidth() // 2) - (largura // 2)
    y = (janela.winfo_screenheight() // 2) - (altura // 2)

    janela.geometry(f"{largura}x{altura}+{x}+{y}")


# def centralizar_janela3(janela, largura_min=800, altura_min=600, deslocamento_y=30):
#     janela.update_idletasks()
#     largura = max(janela.winfo_width(), largura_min)
#     altura = max(janela.winfo_height(), altura_min)
#     x = (janela.winfo_screenwidth() // 2) - (largura // 2)
#     y = (janela.winfo_screenheight() // 2) - (altura // 2) - deslocamento_y
#     y = max(y, 0)  # Garante que não suba demais
#     janela.geometry(f"{largura}x{altura}+{x}+{y}")




def abrir_tela_expandida(janela):
    sistema = platform.system()

    if sistema == "Windows":
        try:
            janela.state('zoomed')  # Melhor forma no Windows
        except:
            # Fallback caso o método falhe
            largura = janela.winfo_screenwidth()
            altura = janela.winfo_screenheight()
            janela.geometry(f"{largura}x{altura}+0+0")
    else:
        # Para Linux/macOS e outros
        largura = janela.winfo_screenwidth()
        altura = janela.winfo_screenheight()
        janela.geometry(f"{largura}x{altura}+0+0")



def colaca_notas_noTerminal ():
    print("📘 NOTAS GERAIS:\n")
    print("1 - Caso o estudo selecionado em \"Arquivo CDF\" seja um dos arquivos testes,")
    print("    o GoSimul autoajusta para os padrões do estudo automaticamente. Entretanto")
    print("    É NECESSÁRIO, garantir que os arquivos CDF básicos estejam na mesma pasta")
    print("    de execução do simulador. O .exe visa empacotar todos os arquivos em um")
    print("    único executável de modo que as aplicações sejam plenamente funcionais")
    print("    desde que sejam instaladas as adequadas bibliotecas.\n")

    print("2 - O simulador só permite a execução se todos os campos estiverem")
    print("    preenchidos. Entretanto, isto NÃO GARANTE que não haja erros de")
    print("    preenchimento. É necessário pleno conhecimento do sistema a ser")
    print("    estudado e o correto preenchimento do arquivo CSV bem como seleção")
    print("    adequada de parâmetros. O botão \"Executar\" mantém histórico de")
    print("    estudos, impedindo que um mesmo estudo seja rodado duas vezes")
    print("    ao menos durante a execução contínua do GoSimul ou até que se aperte")
    print("    o botão \"Limpar\". O nome da tabela resultado está de acordo com a")
    print("    simulação impressa no terminal facilitando as análises.\n")

    print("3 - O botão \"Gerar Gráfico\" imediatamente leva a uma tela de seleção onde pode-se")
    print("    escolher se deseja montar a evolução da convergência do fluxo de potência")
    print("    do \"Arquivo CDF\" selecionado na tela principal, ou se deseja avaliar os")
    print("    arquivos CSV gerados pelo estudo da TELA 3 (\"Abnormal\" e \"Divergencies\").")
    print("    \"Abnormal\" e \"Divergencies\" são pastas de arquivos criadas pela TELA 3")
    print("    dentro da \"plot\" da TELA 1, pois apesar de não serem arquivos CDF,")
    print("    estes arquivos contêm instruções que levam à construção dos gráficos")
    print("    evolutivos para fluxos mal condicionados (Abnormal) ou divergidos (Divergencies)")
    print("    encontrados somente na execução do outro estudo (vide o help da TELA 3).\n")

    print("4 - Na geração de Gráfico \"CSV\" é conveniente a adoção  de novos parâmetros ")
    print("    como a \"Lógica Suplementar\" e quantidade de \"Comutação Máxima\" para observar a")
    print("    efetividade do controle – especialmente a lógica suplementar 1, que se mostra ")
    print("    mais efetiva em restaurar o equilíbrio. É importante salientar que a adoção de")
    print("    Lógica Suplementar para retomar o controle não é efetiva para todos os casos de")
    print("    fluxos mal condicionados, especialmente para situações muito próximas ao")
    print("    colapso de tensão.\n")
    return()




class TelaWebLike:
    ARQUIVOS_FIXOS = {
        'ieee9_Marcelo.cdf': {
            "S_base": "100",
            "Tolerancia": "0.0001",
            "MODELin": "PI",
            "HabiltAval_Lim_Reativo": "Y",
            "Desabilitar_CS": "N",
            "Ativar_inverter": "no",
            "GirarTrafo": "no",
            "Logica_Spl": "0",
            "Comt_Max": "14"
        },
        'ieee14.cdf': {
            "S_base": "100",
            "Tolerancia": "0.0001",
            "MODELin": "PI",
            "HabiltAval_Lim_Reativo": "Y",
            "Desabilitar_CS": "N",
            "Ativar_inverter": "yes",
            "GirarTrafo": "no",
            "Logica_Spl": "0",
            "Comt_Max": "14"
        },
        'ieee30.cdf': {
            "S_base": "100",
            "Tolerancia": "0.0001",
            "MODELin": "PI",
            "HabiltAval_Lim_Reativo": "Y",
            "Desabilitar_CS": "N",
            "Ativar_inverter": "yes",
            "GirarTrafo": "no",
            "Logica_Spl": "0",
            "Comt_Max": "14"
        },
        'ieee118.cdf': {
            "S_base": "100",
            "Tolerancia": "0.0001",
            "MODELin": "PI",
            "HabiltAval_Lim_Reativo": "Y",
            "Desabilitar_CS": "N",
            "Ativar_inverter": "no",
            "GirarTrafo": "yes",
            "Logica_Spl": "0",
            "Comt_Max": "14"
        }
    }

    def __init__(self, root):
        self.janelas_matrizes = []
        self.janelas_listas = []
        self.root = root
        self.root.title("TELA 1 - GoSimul")
        self.root.configure(bg="#ccffcc")  # Verde claro
        abrir_tela_expandida(self.root)
        # top = tk.Toplevel(self.root)
        # top.title("Simulador de Fluxo Inicial - Interface Web")        
        # centralizar_janela(top, 1000, 600)

        # CORES PADRÃO
        LILAS_CLARO = "#ccffcc"      # fundo geral
        ROXO_ESCURO = "#2e005d"      # título e texto principal

        # ======== CABEÇALHO ========
        header = tk.Frame(self.root, height=80, bg=LILAS_CLARO)
        header.pack(fill="x")

        # Canvas para desenhar o cardiograma
        canvas = tk.Canvas(header, width=260, height=70, bg=LILAS_CLARO, highlightthickness=0)
        canvas.place(x=10, y=0)

        # ----------- Eixos X e Y -----------
        x_ini, y_base = 20, 65
        canvas.create_line(x_ini - 10, y_base, x_ini + 230, y_base, fill="black", width=1)   # eixo X
        canvas.create_line(x_ini, y_base + 25, x_ini, y_base - 35, fill="black", width=1)    # eixo Y

        # ----------- Curva de "assinatura elétrica" -----------
        sinal_pts = [
            (20, 50), (30, 45), (40, 47), (50, 52), (60, 48),
            (70, 45), (80, 30), (90, 70), (100, 32), (110, 50),
            (120, 48), (130, 49), (140, 50), (150, 51), (160, 50),
            (170, 48), (180, 50), (190, 50), (200, 51), (210, 50)
        ]
        for a, b in zip(sinal_pts, sinal_pts[1:]):
            canvas.create_line(*a, *b, fill=ROXO_ESCURO, width=3)

        # # ----------- Pontos pretos em eventos ----------
        # for px, py in [sinal_pts[6], sinal_pts[7], sinal_pts[8]]:
        #     canvas.create_oval(px-3, py-3, px+3, py+3, fill="black", outline="black")

        # ----------- Frame do texto centralizado ----------
        frame_texto = tk.Frame(header, bg=LILAS_CLARO)
        frame_texto.place(relx=0.5, rely=0.5, anchor="center")

        # Título principal
        titulo1 = tk.Label(frame_texto, text="TELA 1 - GoSimul", font=("Segoe UI", 18, "bold"), bg=LILAS_CLARO, fg=ROXO_ESCURO)
        titulo1.pack()

        # Subtítulo
        titulo2 = tk.Label(frame_texto, text="Gerador de Simulações", font=("Segoe UI", 14), bg=LILAS_CLARO, fg=ROXO_ESCURO)
        titulo2.pack()




        self.params = {
            "SYSname": tk.StringVar(value="ieee118.cdf"),
            "MODELin": tk.StringVar(value="PI"),
            "Tolerancia": tk.StringVar(value="0.0001"),
            "HabiltAval_Lim_Reativo": tk.StringVar(value="Y"),
            "S_base": tk.IntVar(value=100),
            "tipoDeSimulacao": tk.StringVar(value="Automatico"),
            "entrad_rodarManual": tk.StringVar(value="1-5*100_7*85"),
            "Regime_de_CARGA": tk.StringVar(value="pesado"),
            "Desabilitar_CS": tk.StringVar(value="N"),
            "Tipo_de_logicaSuplementar": tk.IntVar(value=0),
            "ComutacaoMaxima": tk.IntVar(value=14),
            "Ativar_inverter": tk.StringVar(value="no"),
            "GirarTrafo": tk.StringVar(value="yes")
        }
        self.historico_estudos = []  # lista de dicionários com todos os estudos executados
        self.contador_simulacoes = 1
        
        self.create_widgets()

    def exibir_matriz_y(self):
        self._exibir_matriz_complexa("Matriz de Admitâncias", index=9)

    def exibir_jacobiana_inicial(self):
        self._exibir_matriz_complexa("Jacobiana Inicial", index=10)

    def exibir_jacobiana_final(self):
        self._exibir_matriz_complexa("Jacobiana Final", index=11)

    def fechar_figuras(self):
        for manager in _pylab_helpers.Gcf.get_all_fig_managers():
            fig = manager.canvas.figure
            if plt.fignum_exists(fig.number):
                plt.close(fig)
        self.status.config(text="Todas as figuras foram fechadas.")

    def fechar_matrizes(self):
        for janela in self.janelas_matrizes:
            if janela.winfo_exists():
                janela.destroy()
        self.janelas_matrizes.clear()
        self.status.config(text="Todas as janelas de matrizes foram fechadas.")


    def fechar_tudo(self):
        # Fechar figuras do matplotlib
        for manager in _pylab_helpers.Gcf.get_all_fig_managers():
            fig = manager.canvas.figure
            if plt.fignum_exists(fig.number):
                plt.close(fig)

        # Fechar matrizes
        for janela in getattr(self, 'janelas_matrizes', []):
            if janela.winfo_exists():
                janela.destroy()
        self.janelas_matrizes.clear()

        # Fechar tabelas/listas
        for janela in getattr(self, 'janelas_listas', []):
            if janela.winfo_exists():
                janela.destroy()
        self.janelas_listas.clear()
        self.contador_simulacoes = 1
        
        self.historico_estudos.clear()
        self.terminal_output.config(state="normal")
        self.terminal_output.delete("1.0", tk.END)
        self.terminal_output.config(state="disabled")
        colaca_notas_noTerminal()
        self.terminal_output.update_idletasks()
        self.terminal_output.yview_moveto(0.0)        
        self.status.config(text="Todas as janelas auxiliares foram fechadas.")
      

    def definir_estado_botoes(self, ativo: bool):
        estado = "normal" if ativo else "disabled"
        self.botao_exec.config(state=estado)
        self.botao_grafico.config(state=estado)
        self.botao_matriz_y.config(state=estado)
        self.botao_jac_ini.config(state=estado)
        self.botao_jac_fim.config(state=estado)
        self.botao_fechar_tudo.config(state=estado)


    def create_widgets(self):
        # ---------- 1. Cabeçalho -------------------------------------------------
        self.widgets = {}

        # titulo = ttk.Label(self.root, text="TELA 1 - GoSimul")
        # titulo.pack(pady=(10, 5))
        # titulo.configure(
        #     font=("Segoe Script", 20, "bold"),
        #     background="#ccffcc",
        #     anchor="center"
        # )

        # ---------- 2. Container raiz com 2 colunas ------------------------------
        frame = ttk.Frame(self.root, padding=10)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure((0, 1), weight=1)          # ← colunas lado-a-lado

        # ---------- 3. Dicionários auxiliares -----------------------------------
        dropdowns = {
            "MODELin": ["PI", "T"],
            "HabiltAval_Lim_Reativo": ["Y", "N"],
            "tipoDeSimulacao": ["Manual", "Automatico"],
            "Regime_de_CARGA": ["leve", "pesado"],
            "Desabilitar_CS": ["Y", "N"],
            "Tipo_de_logicaSuplementar": [1, 2],
            "Ativar_inverter": ["yes", "no"],
            "GirarTrafo": ["yes", "no"]
        }

        nomes_amigaveis = {
            "SYSname": "Arquivo CDF",
            "MODELin": "Modelo de Linha",
            "Tolerancia": "Tolerância",
            "HabiltAval_Lim_Reativo": "Avaliar Lim. Reativo",
            "S_base": "S base (MVA)",
            "tipoDeSimulacao": "Tipo de Simulação",
            "entrad_rodarManual": "Modificar Manual",
            "Regime_de_CARGA": "Regime de Carga",
            "Desabilitar_CS": "Desabilitar CS",
            "Tipo_de_logicaSuplementar": "Lógica Suplementar",
            "ComutacaoMaxima": "Comutação Máx.",
            "Ativar_inverter": "Inverter TAP",
            "GirarTrafo": "Girar Trafo"
        }

        # ---------- 4. Agrupamentos (mesma ideia da GoCurvs) ---------------------
        parametros_sistema = [
            "SYSname", "MODELin", "Tolerancia", "S_base",
            "Ativar_inverter", "GirarTrafo",
            "HabiltAval_Lim_Reativo", "Desabilitar_CS",
            "Tipo_de_logicaSuplementar", "ComutacaoMaxima"
        ]

        parametros_carga = [
            "tipoDeSimulacao", "entrad_rodarManual", "Regime_de_CARGA"
        ]

        # ---------- 5. Frames laterais ------------------------------------------
        frame_sistema = ttk.LabelFrame(frame, text="PARÂMETROS DO SISTEMA", padding=10)
        frame_sistema.grid(row=0, column=0, sticky="nsew", padx=10, pady=5)
        frame_sistema.columnconfigure((0, 1), weight=1)

        frame_carga = ttk.LabelFrame(frame, text="PARÂMETROS DO ESTUDO", padding=10)
        frame_carga.grid(row=0, column=1, sticky="nsew", padx=10, pady=5)
        frame_carga.columnconfigure((0, 1), weight=1)

        # ---------- 6. Validação numérica (inteiros ou floats) -------------------
        
        vcmd_float = (self.root.register(self.validar_float), '%P')
        vcmd_int   = (self.root.register(self.validar_inteiro), '%P')

        explicacoes_parametros = {
            "SYSname": "1 - Tanto pode selecionar item da lista suspensa quanto\noutros arquivos CDF de qualquer outro diretório.\n2 - Para utilizar a lista suspensa, mantenha os arquivos teste\nna pasta do executável.",
            "MODELin": "Modelo elétrico das linhas.\nPI é o mais indicado para a maioria dos sistemas.",
            "Tolerancia": "Tolerância em pu para o erro no fluxo de potência.\nValor típico: 0.0001.",
            "S_base": "Potência base do sistema. Valor típico: 100 MVA.",
            "Ativar_inverter": '"yes" para ieee14 e ieee30.\n"no" para ieee9_Marcelo e ieee118.',
            "GirarTrafo": '"yes" apenas para ieee118.cdf.\n"no" para os demais arquivos teste.',
            "HabiltAval_Lim_Reativo": "Permite avaliar os limites de reativos nos geradores.",
            "Desabilitar_CS": "Transforma barras CS em barras de carga.",
            "Tipo_de_logicaSuplementar": "Controla excesso de alternância PV↔PQ.\nAplica lógica suplementar (1 ou 2).",
            "ComutacaoMaxima": "Número máximo de comutações PV↔PQ permitidas.",
            "tipoDeSimulacao": '"Automático" usa as potências do CDF.\n"Manual" permite editar o carregamento.',
            "entrad_rodarManual": "Ex: 1-5*100_7*85 → 100% nas barras 1-5 e 85% na barra 7.",
            "Regime_de_CARGA": '"pesado" liga carga ativa.\n"leve" desliga carga.'
        }


        # ---------- 7. Função geradora de campos ---------------------------------
        def cria_campo(parent, chave, row, col):
            """Cria label + widget para a chave dentro do parent."""
            sub = ttk.Frame(parent)
            sub.grid(row=row, column=col, padx=6, pady=6, sticky="w")
            ttk.Label(sub, text=nomes_amigaveis.get(chave, chave)).pack(anchor="w")

            # Combobox inteligente para SYSname
            if chave == "SYSname":
                cb = ttk.Combobox(sub, textvariable=self.params[chave],
                                width=20, state="readonly")
                cb["values"] = list(self.ARQUIVOS_FIXOS.keys()) + ["Selecionar outro arquivo..."]
                cb.pack(side="left")
                self.widgets[chave] = cb

                if chave in explicacoes_parametros:
                    self.adicionar_tooltip(self.widgets[chave], explicacoes_parametros[chave])

                def ao_mudar_sysname(event=None):
                    nome = self.params["SYSname"].get()
                    if nome == "Selecionar outro arquivo...":
                        self.selecionar_arquivo()
                    elif nome in self.ARQUIVOS_FIXOS:
                        for k, v in self.ARQUIVOS_FIXOS[nome].items():
                            if k in self.params:
                                self.params[k].set(v)
                cb.bind("<<ComboboxSelected>>", ao_mudar_sysname)

                ttk.Button(sub, text="...", command=self.selecionar_arquivo).pack(side="left")

            # Campos de lista fixa (drop-downs)
            elif chave in dropdowns:
                cb = ttk.Combobox(sub, textvariable=self.params[chave], width=15)
                cb["values"] = dropdowns[chave]
                cb["state"] = "readonly"
                cb.pack()
                self.widgets[chave] = cb

                if chave in explicacoes_parametros:
                    self.adicionar_tooltip(self.widgets[chave], explicacoes_parametros[chave])
            # Entradas numéricas (float ou int)
            else:
                if chave in ["Tolerancia", "S_base"]:
                    ent = ttk.Entry(sub, textvariable=self.params[chave],
                                    width=18, validate="key", validatecommand=vcmd_float)
                elif chave in ["ComutacaoMaxima"]:
                    ent = ttk.Entry(sub, textvariable=self.params[chave],
                                    width=18, validate="key", validatecommand=vcmd_int)
                else:
                    ent = ttk.Entry(sub, textvariable=self.params[chave], width=18)
                ent.pack()
                self.widgets[chave] = ent
                
                if chave in explicacoes_parametros:
                    self.adicionar_tooltip(self.widgets[chave], explicacoes_parametros[chave])


        # ---------- 8. Preenche “PARÂMETROS DO SISTEMA” --------------------------
        for idx, key in enumerate(parametros_sistema):
            r, c = divmod(idx, 2)
            cria_campo(frame_sistema, key, r, c)
            # if key == "tipoDeSimulacao":
            #     self.params["tipoDeSimulacao"].trace_add("write", lambda *a: self.atualizar_estado_entrada_manual())

        # ---------- 9. Preenche “INFORMAÇÕES SOBRE O CARREGAMENTO” --------------
        for idx, key in enumerate(parametros_carga):
            r, c = divmod(idx, 2)
            cria_campo(frame_carga, key, r, c)

        self.params["tipoDeSimulacao"].trace_add("write", lambda *a: self.atualizar_estado_entrada_manual())
        self.atualizar_estado_entrada_manual()
        # Força a read-only do Regime_de_CARGA manualmente (caso esteja se perdendo)
        # try:
        #     self.widgets["Regime_de_CARGA"].config(state="readonly")
        # except Exception as e:
        #     print(f"Erro ao tentar forçar estado readonly: {e}")

        botoes = tk.Frame(self.root, bg="#ccffcc")  # Fundo verde suave
        botoes.pack(pady=10)

        self.botao_exec = ttk.Button(botoes, text="Executar Estudo", style="BotaoVerde.TButton", command=self.executar_estudo_thread)
        self.botao_exec.grid(row=0, column=0, padx=10)

        self.botao_grafico = ttk.Button(botoes, text="Gerar Gráfico", style="BotaoVerde.TButton", command=self.popup_tipo_arquivo)
        self.botao_grafico.grid(row=0, column=1, padx=10)

        self.botao_matriz_y = ttk.Button(botoes, text="Matriz Y", style="BotaoAzul.TButton", command=self.exibir_matriz_y)
        self.botao_matriz_y.grid(row=0, column=2, padx=10)

        self.botao_jac_ini = ttk.Button(botoes, text="Jacobiana Inicial", style="BotaoAzul.TButton", command=self.exibir_jacobiana_inicial)
        self.botao_jac_ini.grid(row=0, column=3, padx=10)

        self.botao_jac_fim = ttk.Button(botoes, text="Jacobiana Final", style="BotaoAzul.TButton", command=self.exibir_jacobiana_final)
        self.botao_jac_fim.grid(row=0, column=4, padx=10)

        self.botao_fechar_tudo = ttk.Button(botoes, text="Fechar", style="BotaoVermelho.TButton", command=self.fechar_tudo)
        self.botao_fechar_tudo.grid(row=0, column=5, padx=10)

        self.adicionar_tooltip(self.botao_exec,
            "1 - Calcula o fluxo de potência do arquivo CDF selecionado.\n2 - Exibe tabela resumo e imprime dados no terminal.")

        self.adicionar_tooltip(self.botao_grafico,
            "1 - Gera gráficos da evolução das variáveis (V, θ, P, Q).\n2 - Permite filtros: PQ, PV, Perdidas, CHOOSE_BAR, etc.")

        self.adicionar_tooltip(self.botao_matriz_y,
            "Exibe a matriz de admitâncias do sistema com base na TELA 1.")

        self.adicionar_tooltip(self.botao_jac_ini,
            "Mostra a matriz Jacobiana da 1ª iteração do fluxo.")

        self.adicionar_tooltip(self.botao_jac_fim,
            "Mostra a matriz Jacobiana da última iteração do fluxo.")

        self.adicionar_tooltip(self.botao_fechar_tudo,
            "Fecha todas as janelas abertas (tabelas, matrizes, gráficos)\ne limpa o terminal.")


        self.status = tk.Label(self.root, text="Aguardando...", bg="#ccffcc", fg="black", font=("Arial", 10, "italic"))
        self.status.pack(fill="x", pady=(5, 10))


        # Terminal de saída embutido
        self.terminal_frame = ttk.LabelFrame(self.root, text="Terminal de Saída")
        self.terminal_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        self.terminal_output = ScrolledText(self.terminal_frame, height=12, wrap="word", state="disabled", font=("Courier", 10))
        self.terminal_output.pack(fill="both", expand=True)

        # Redireciona stdout e stderr
        sys.stdout = TextRedirector(self.terminal_output, "stdout")
        sys.stderr = TextRedirector(self.terminal_output, "stderr")


        style = ttk.Style()

        # Estilo Botão Verde (Executar Estudo)
        style.configure("BotaoVerde.TButton",
                        background="green", foreground="black",
                        font=("TkDefaultFont", 10, "bold"))
        style.map("BotaoVerde.TButton",
                background=[("active", "#228B22")])  # verde escuro no hover

        # Estilo Botão Azul (Gerar Gráfico)
        style.configure("BotaoAzul.TButton",
                        background="blue", foreground="black",
                        font=("TkDefaultFont", 10, "bold"))
        
        style.map("BotaoAzul.TButton",
                background=[("active", "#1E90FF")])  # azul claro no hover
        
        style.configure("BotaoVermelho.TButton",
                        background="red", foreground="black",
                        font=("TkDefaultFont", 10, "bold"))
        style.map("BotaoVermelho.TButton",
                background=[("active", "#B22222")])  # vermelho escuro no hover
        
        colaca_notas_noTerminal()
        self.terminal_output.update_idletasks()
        self.terminal_output.yview_moveto(0.0)



    def validar_float(self, texto):
        if texto == "":
            return True  # Permite campo vazio temporariamente
        try:
            float(texto)
            return True
        except ValueError:
            return False

    def validar_inteiro(self, valor):
        return valor.isdigit() or valor == ""

    def parametros_iguais_ao_ultimo_estudo(self):
        if not self.ultimo_estudo_executado:
            return False  # nunca houve execução antes

        for chave, var in self.params.items():
            valor_atual = var.get()
            valor_anterior = self.ultimo_estudo_executado.get(chave, None)
            if valor_atual != valor_anterior:
                return False  # encontrou diferença

        return True  # todos os parâmetros são iguais


    def estudo_ja_foi_executado(self):
        estudo_atual = {k: v.get() for k, v in self.params.items()}
        for estudo in self.historico_estudos:
            if estudo == estudo_atual:
                return True  # já existe estudo idêntico
        return False


    def atualizar_estado_entrada_manual(self, *args):
        tipo = self.params["tipoDeSimulacao"].get()
        widget = self.widgets.get("entrad_rodarManual")
        if widget:
            if tipo == "Automatico":
                self.params["entrad_rodarManual"].set("")
                widget.configure(state="disabled")
            else:
                widget.configure(state="normal")
                self.params["entrad_rodarManual"].set("1-5*100_7*85")
        
        widget2 = self.widgets.get("Regime_de_CARGA")
        if widget2:
            if tipo == "Automatico":
                self.params["Regime_de_CARGA"].set("")
                widget2.configure(state="readonly")
                widget2.configure(state="disabled")
            else:
                self.params["Regime_de_CARGA"].set("pesado")                
                widget2.configure(state="readonly")



    def selecionar_arquivo(self):
        caminho = filedialog.askopenfilename(filetypes=[("CDF Files", "*.cdf")])
        if caminho:
            self.params["SYSname"].set(caminho)

    def executar_estudo_thread(self):
        if self.estudo_ja_foi_executado():
            messagebox.showinfo("Aviso", "Este estudo já foi executado anteriormente. Altere algum parâmetro ou clique em 'Limpar' para reiniciar.")
            return
        threading.Thread(target=self.executar_estudo).start()

    def executar_estudo(self):
        self.definir_estado_botoes(False)
        # 2. Campos obrigatórios comuns
        campos_obrigatorios = {
            "Tolerancia": "Tolerância",
            "S_base": "S base (MVA)",
            "ComutacaoMaxima": "Comutação Máxima"
        }

        cdf_nome = self.params["SYSname"].get().strip()
        if "Selecionar outro arquivo..." in cdf_nome and not os.path.isfile(cdf_nome):
            messagebox.showerror("Erro de entrada", "Você selecionou 'Selecionar outro' mas não forneceu um arquivo .CDF válido.")
            self.status.config(text="⚠️ Corrija o campo 'Arquivo CDF'.")
            print('❗❗❗❗❗❗❗❗❗❗❗❗   ERRO GRAVE DE EXECUÇÃO IDENTIFICADO   ❗❗❗❗❗❗❗❗❗❗❗❗')
            print('\n   - Preencheu adequadamente todos os campos?')
            print('   - Arquivo CDF convergindo inicialmente?')  
            self.botao_exec.config(state=tk.NORMAL)
            # self.terminal_output.config(state="normal")
            # self.terminal_output.delete("1.0", tk.END)
            # self.terminal_output.config(state="disabled")
            liberar='no'
            return
        #print('wait')
        try:
            def raise_erro():
                #messagebox.showerror("Erro de entrada", f"O campo obrigatório '{nome}' está vazio ou inválido. Por favor, preencha corretamente.")
                #self.status.config(text=f"⚠️ Preencha o campo '{nome}' para continuar.")
                self.botao_exec.config(state=tk.NORMAL)
                liberar='no'
                #self.botao_parar.config(state=tk.DISABLED)
                raise Exception("Interrompido por campo obrigatório inválido.")
                    
            for chave, nome in campos_obrigatorios.items():
                valor = self.params[chave].get()
                if isinstance(valor, str):
                    if not valor.strip():
                        raise_erro()
                else:
                    if valor is None or valor == 0:
                        raise_erro()

            liberar='yes'
        except:
            liberar='no'
            messagebox.showerror("Erro de entrada", f"O campo obrigatório '{nome}' está vazio ou inválido. Por favor, preencha corretamente.")
            self.status.config(text=f"⚠️ Preencha o campo '{nome}' para continuar.")
            self.botao_exec.config(state=tk.NORMAL)

        if liberar=='yes':                
            self.status.config(text="Executando estudo...")
            self.botao_exec.state(["disabled"])
            p = {k: v.get() for k, v in self.params.items()}
            
            # if self.contador_simulacoes!=1:
            #     num = self.contador_simulacoes+1
            # else:
            #     num = self.contador_simulacoes
            num = self.contador_simulacoes
            T3="\n────────────────────────────────────────────────────────────────────────────────"
            print("═" * (len(T3)))
            titulo = f"📝  ESTUDO EXECULTADO:  Simulação #{num} #{num} #{num} #{num} #{num} #{num} #{num} #{num} #{num} #{num} #{num} #{num} #{num} #{num} #{num} #{num}"
            print(titulo)
            # if num!=1:
            #     print(T3)
            print("═" * (len(T3)))
            print("                                - Estudo para os parâmetros escolhidos na TELA 1.\n")
            #print("\n🧾  Parâmetros utilizados:\n" + "-"*40)
            print("\n🧾  Parâmetros utilizados:")
            for chave, valor in p.items():
                print(f"     - {chave:<25} : {valor}")
            #print("-"*40 + "\n")

            if p["tipoDeSimulacao"] == "Automatico":
                resultado = GoS_generator_FluxoInicial(
                    p["SYSname"], p["MODELin"], float(p["Tolerancia"].replace(",", ".")), p["HabiltAval_Lim_Reativo"],
                    p["S_base"], p["Desabilitar_CS"], p["Tipo_de_logicaSuplementar"], p["ComutacaoMaxima"],
                    p["Ativar_inverter"], p["GirarTrafo"]
                )
            else:
                resultado = GoS_generator_FluxoManual(
                    p["SYSname"], p["MODELin"], float(p["Tolerancia"].replace(",", ".")), p["HabiltAval_Lim_Reativo"],
                    p["entrad_rodarManual"], p["S_base"], p["Regime_de_CARGA"], p["Desabilitar_CS"],
                    p["Tipo_de_logicaSuplementar"], p["ComutacaoMaxima"], p["Ativar_inverter"], p["GirarTrafo"]
                )

            DeltaV, Delta0, PotP, PotQ, infoVctrl, matriz_DadosBarra, Barras_PQ, cont, *_ = resultado
            cabecalhoPlot, camposPlot = Encabecalha_plot(DeltaV, Delta0, PotP, PotQ, infoVctrl, cont, matriz_DadosBarra)
            cabecalhoPlotGer, camposPlotGer = Encabecalha_plot_PotGer(PotP, PotQ, infoVctrl, Barras_PQ, matriz_DadosBarra)
            
            somaP=0
            SomaQ=0
            for k in range (len(PotP)):
                somaP=PotP[k]+somaP
                SomaQ=PotQ[k]+SomaQ
            S_aparente = math.sqrt(somaP**2 + SomaQ**2)

            print("\n🔁  Convergido na iteração: ", cont)
            print("\n🔌 Potências de perdas:")
            print("    - Potência Ativa das Perdas (pu): ", round(somaP, 6))
            print("    - Potência Reativa das Perdas (pu): ", round(SomaQ, 6))
            print("    - Potência Aparente Total das Perdas (pu): ", round(S_aparente, 6))
            #print("\n")

            # for_filterSOQCAI2=[]
            # for aux in range(len(DeltaV)):
            #     if infoVctrl[0][aux]=='swing' or infoVctrl[0][aux]=='CS' or infoVctrl[0][aux]=='G':
            #         if DeltaV[aux]!=infoVctrl[1][aux]:
            #             for_filterSOQCAI2.append(aux+1)



            print(f"\n📄 Barras com controle de tensão perdido:")
            
            for_filterSOQCAI2 = []

            for aux in range(len(DeltaV)):
                if infoVctrl[0][aux] in ['swing', 'CS', 'G']:
                    tensao_controle = infoVctrl[1][aux]
                    tensao_final = DeltaV[aux]
                    if tensao_final != tensao_controle:
                        barra = aux + 1
                        for_filterSOQCAI2.append(barra)
                        print(f"    🔻 Barra {barra:>3} - Tensão de Controle: {tensao_controle:.4f} pu - Tensão Final: {tensao_final:.4f} pu")
            print(f"    >>> Total de Barras: {len(for_filterSOQCAI2)}")
            if not for_filterSOQCAI2:
                print("\n✅ Nenhuma barra com perda de controle de tensão detectada.")
            print('\n')

            #num = self.contador_simulacoes
            titulo_barras = f"Simulação #{num}"
            #titulo_potencia = f"Info. de Geração - Simulação #{num}"  

            # TabelaPopup(titulo_barras,          cabecalhoPlot,     camposPlot,     master=self)
            # TabelaPopup(titulo_potencia,  cabecalhoPlotGer,  camposPlotGer,  master=self)
            cabecalhoUni, camposUni = junta_tabelas_fluxo(
                cabecalhoPlot, camposPlot, cabecalhoPlotGer, camposPlotGer)

            TabelaPopup(titulo_barras, cabecalhoUni, camposUni, master=self)

            estudo_novo = {k: v.get() for k, v in self.params.items()}
            self.historico_estudos.append(estudo_novo)

            self.contador_simulacoes += 1
            self.status.config(text="Estudo finalizado com sucesso!")
            self.botao_exec.state(["!disabled"])
            self.definir_estado_botoes(True)
        else:
            print('\n❗❗❗❗❗❗❗❗❗❗❗❗  ERRO GRAVE DE EXECUÇÃO IDENTIFICADO   ❗❗❗❗❗❗❗❗❗❗❗❗')
            print('\n   - Preencheu adequadamente todos os campos?')
            print('   - Arquivo CDF prenchido adequadamente com o sistema?')

    def popup_tipo_arquivo(self):
        popup = tk.Toplevel(self.root)
        popup.title("Selecionar tipo de arquivo")
        centralizar_janela1(popup)

        ttk.Label(popup, text="Escolha o tipo de arquivo:").pack(padx=10, pady=10)
        tipo_var = tk.StringVar()
        tipo_menu = ttk.Combobox(popup, textvariable=tipo_var, values=["CDF", "CSV"], state="readonly")
        tipo_menu.pack(padx=10, pady=10)

        def confirmar():
            popup.destroy()
            if tipo_var.get() == "CDF":
                self.popup_cdf_parametros()
            else:
                self.popup_csv_parametros()

        ttk.Button(popup, text="Confirmar", command=confirmar).pack(pady=10)



    def popup_cdf_parametros(self):
        popup = tk.Toplevel(self.root)
        popup.title("Parâmetros do Estudo CDF")
        centralizar_janela2(popup)

        frame = ttk.Frame(popup, padding=10)
        frame.pack()

        # Usamos textvariable corretas
        self.cdf_params = {
            "selection_text": tk.StringVar(value="1 - TENSAO"),
            "selection_curve": tk.StringVar(value="TODAS"),
            "CHOOSE_BAR": tk.StringVar(value="1-12")
        }

        # Campo: SELECTION (texto)
        ttk.Label(frame, text="selection").grid(row=0, column=0, sticky="e", padx=5, pady=2)
        selection_opcoes = ["1 - TENSAO", "2 - ANGULO", "3 - MISMATCH P", "4 - MISMATCH Q"]
        selection_cb = ttk.Combobox(
            frame, textvariable=self.cdf_params["selection_text"],
            values=selection_opcoes, state="readonly"
        )
        selection_cb.grid(row=0, column=1, padx=5, pady=2)

        # Campo: SELECTION_CURVE
        ttk.Label(frame, text="selection_curve").grid(row=1, column=0, sticky="e", padx=5, pady=2)
        curva_cb = ttk.Combobox(
            frame, textvariable=self.cdf_params["selection_curve"],
            values=["TODAS", "PQ", "PV", "PERDIDAS" , "CHOOSE_BAR"], state="readonly"
        )
        curva_cb.grid(row=1, column=1, padx=5, pady=2)

        # Campo: CHOOSE_BAR
        ttk.Label(frame, text="CHOOSE_BAR").grid(row=2, column=0, sticky="e", padx=5, pady=2)
        ttk.Entry(frame, textvariable=self.cdf_params["CHOOSE_BAR"], width=30).grid(row=2, column=1, padx=5, pady=2)

        # Botão de confirmar
        def confirmar():
            popup.destroy()
            self.gerar_grafico_cdf(self.cdf_params)

        ttk.Button(frame, text="Gerar", command=confirmar).grid(row=3, column=0, columnspan=2, pady=10)

    def gerar_grafico_cdf(self, cdf_params):
        #self.definir_estado_botoes(False)
        # if self.contador_simulacoes!=1:
        #     num = self.contador_simulacoes+1
        # else:
        num = self.contador_simulacoes
        p = {k: v.get() for k, v in self.params.items()}
        
        T3="────────────────────────────────────────────────────────────────────────────────"
        # if num!=1:
        #     print(T3)
        print("═" * (len(T3)))
        titulo = f"📉  GRÁFICO GERADO - #CDF #CDF #CDF #CDF #CDF #CDF #CDF #CDF #CDF #CDF #CDF #CDF"
        #T2="                              - lido a partir dos parâmetros da tela principal."

        print(titulo)
        #print(T2)
        print("═" * (len(T3)))
        print("                              - Gráfico para os parâmetros escolhidos na TELA 1.\n")
        #print("\n🧾  Parâmetros utilizados:\n" + "-"*40)
        print("\n🧾  Parâmetros utilizados:")

        for chave, valor in p.items():
            print(f"     - {chave:<25} : {valor}")
        #print("-"*40 + "\n")

        # Converte o texto da seleção para número
        selection_map = {
            "1 - TENSAO": 1,
            "2 - ANGULO": 2,
            "3 - MISMATCH P": 3,
            "4 - MISMATCH Q": 4
        }
        selection_text = cdf_params["selection_text"].get()
        selection = selection_map.get(selection_text)
        
        if selection is None:
            self.status.config(text="Erro: seleção inválida.")
            return

        selection_curve = cdf_params["selection_curve"].get()
        CHOOSE_BAR = cdf_params["CHOOSE_BAR"].get()

        # Chama função adequada
        if p["tipoDeSimulacao"] == "Manual":
            resultado = GoS_generator_FluxoManual(
                p["SYSname"], p["MODELin"], float(p["Tolerancia"].replace(",", ".")), p["HabiltAval_Lim_Reativo"],
                p["entrad_rodarManual"], p["S_base"], p["Regime_de_CARGA"], p["Desabilitar_CS"],
                p["Tipo_de_logicaSuplementar"], p["ComutacaoMaxima"], p["Ativar_inverter"], p["GirarTrafo"]
            )
        else:
            resultado = GoS_generator_FluxoInicial(
                p["SYSname"], p["MODELin"], float(p["Tolerancia"].replace(",", ".")), p["HabiltAval_Lim_Reativo"],
                p["S_base"], p["Desabilitar_CS"], p["Tipo_de_logicaSuplementar"], p["ComutacaoMaxima"],
                p["Ativar_inverter"], p["GirarTrafo"]
            )

        # Pega resultados para plottar
        #DeltaV, _, _, _, infoVctrl, _, _, _, _, *_ , EvolutionMatrixVECTORS, _, _ = resultado

        DeltaV, _ , PotP, PotQ, infoVctrl, _ , _ , cont, *_ , EvolutionMatrixVECTORS, _, _ = resultado
        
        # somaP=0
        # SomaQ=0
        # for k in range (len(PotP)):
        #     somaP=PotP[k]+somaP
        #     SomaQ=PotQ[k]+SomaQ
        # print("Convergido na iteração: ", cont)
        # print("\n********      PERDAS DO SISTEMA:        ********")
        # print("Potência Ativa das Perdas (pu): ", somaP)
        # print("Potência Reativa das Perdas (pu): ", SomaQ)
        # print("************************************************\n")

        somaP=0
        SomaQ=0
        for k in range (len(PotP)):
            somaP=PotP[k]+somaP
            SomaQ=PotQ[k]+SomaQ
        S_aparente = math.sqrt(somaP**2 + SomaQ**2)

        print("\n🔁  Convergido na iteração: ", cont)
        print("\n🔌 Potências de perdas:")
        print("    - Potência Ativa das Perdas (pu): ", round(somaP, 6))
        print("    - Potência Reativa das Perdas (pu): ", round(SomaQ, 6))
        print("    - Potência Aparente Total das Perdas (pu): ", round(S_aparente, 6))

        print(f"\n📄 Barras com controle de tensão perdido:")
        for_filterSOQCAI2 = []
        for aux in range(len(DeltaV)):
            if infoVctrl[0][aux] in ['swing', 'CS', 'G']:
                tensao_controle = infoVctrl[1][aux]
                tensao_final = DeltaV[aux]
                if tensao_final != tensao_controle:
                    barra = aux + 1
                    for_filterSOQCAI2.append(barra)
                    print(f"    🔻 Barra {barra:>3} - Tensão de Controle: {tensao_controle:.4f} pu - Tensão Final: {tensao_final:.4f} pu")
        print(f"    >>> Total de Barras: {len(for_filterSOQCAI2)}")
        if not for_filterSOQCAI2:
            print("\n✅ Nenhuma barra com perda de controle de tensão detectada.")
        print('\n')
        entrada_00 = [selection_curve, CHOOSE_BAR]
        entrada_01 = [EvolutionMatrixVECTORS, infoVctrl, DeltaV]
        DeltaV_sets, BarrasPV = organiza_e_filtra_DADOS_das_Evolucoes(entrada_00, entrada_01)

        plot_evolution(DeltaV_sets, str(selection), BarrasPV, None)
        #self.definir_estado_botoes(True)




    def popup_csv_parametros(self):
        popup = tk.Toplevel(self.root)
        popup.title("Parâmetros do Estudo CSV")
        centralizar_janela2(popup)

        frame = ttk.Frame(popup, padding=10)
        frame.pack()

        self.csv_params = {
            "nome_arquivo": tk.StringVar(),
            "diretorio": tk.StringVar(value="AbnormalPoints"),
            "selection": tk.StringVar(value="1"),
            "selection_curve": tk.StringVar(value="TODAS"),
            "CHOOSE_BAR": tk.StringVar(value="1-12"),
            "Tipo_de_logicaSuplementar": tk.StringVar(value="1"),
            "ComutacaoMaxima": tk.StringVar(value="14")
        }

        def atualizar_arquivos(*args):
            diretorio = self.csv_params["diretorio"].get()
            caminho_dir = os.path.join(BASE_DIR, "plot", "GenOfSimul", diretorio)
            try:
                arquivos_csv = [f for f in os.listdir(caminho_dir) if f.endswith(".csv")]
                if arquivos_csv:
                    self.arquivos_menu["values"] = arquivos_csv
                    self.csv_params["nome_arquivo"].set(arquivos_csv[0])
                else:
                    self.arquivos_menu["values"] = []
                    self.csv_params["nome_arquivo"].set("")
            except FileNotFoundError:
                self.arquivos_menu["values"] = []
                self.csv_params["nome_arquivo"].set("")

        ttk.Label(frame, text="diretorio").grid(row=0, column=0, sticky="e", padx=5, pady=2)
        diretorio_menu = ttk.Combobox(
            frame, textvariable=self.csv_params["diretorio"], values=["AbnormalPoints", "Divergencies"], state="readonly"
        )
        diretorio_menu.grid(row=0, column=1, padx=5, pady=2)
        diretorio_menu.bind("<<ComboboxSelected>>", atualizar_arquivos)

        ttk.Label(frame, text="Nome do Arquivo").grid(row=1, column=0, sticky="e", padx=5, pady=2)
        self.arquivos_menu = ttk.Combobox(frame, textvariable=self.csv_params["nome_arquivo"], state="readonly")
        self.arquivos_menu.grid(row=1, column=1, padx=5, pady=2)

        ttk.Label(frame, text="Escolher Parâmetro de Fluxo").grid(row=2, column=0, sticky="e", padx=5, pady=2)
        selection_opcoes = {
            "1 - TENSAO": "1",
            "2 - ANGULO": "2",
            "3 - MISMATCH P": "3",
            "4 - MISMATCH Q": "4"
        }
        selection_combobox = ttk.Combobox(
            frame, values=list(selection_opcoes.keys()), state="readonly"
        )
        selection_combobox.set("1 - TENSAO")
        selection_combobox.grid(row=2, column=1, padx=5, pady=2)

        def atualizar_selection(*args):
            escolha = selection_combobox.get()
            self.csv_params["selection"].set(selection_opcoes.get(escolha, "1"))

        selection_combobox.bind("<<ComboboxSelected>>", atualizar_selection)

        ttk.Label(frame, text="Curvas a Exibir").grid(row=3, column=0, sticky="e", padx=5, pady=2)
        curva_combobox = ttk.Combobox(
            frame, textvariable=self.csv_params["selection_curve"], values=["TODAS", "PQ", "PV", "PERDIDAS" , "CHOOSE_BAR"], state="readonly"
        )
        curva_combobox.set("TODAS")
        curva_combobox.grid(row=3, column=1, padx=5, pady=2)

        ttk.Label(frame, text="Barras Específicas (Ex: 1-12)").grid(row=4, column=0, sticky="e", padx=5, pady=2)
        ttk.Entry(frame, textvariable=self.csv_params["CHOOSE_BAR"], width=30).grid(row=4, column=1, padx=5, pady=2)

        # Novo campo: Tipo_de_logicaSuplementar
        ttk.Label(frame, text="Tipo de Lógica Suplementar").grid(row=5, column=0, sticky="e", padx=5, pady=2)
        logica_combobox = ttk.Combobox(
            frame, textvariable=self.csv_params["Tipo_de_logicaSuplementar"], values=["1", "2", "None"], state="readonly"
        )
        logica_combobox.grid(row=5, column=1, padx=5, pady=2)

        # Novo campo: ComutacaoMaxima
        ttk.Label(frame, text="Máxima comutação permitida").grid(row=6, column=0, sticky="e", padx=5, pady=2)
        ttk.Entry(frame, textvariable=self.csv_params["ComutacaoMaxima"], width=10).grid(row=6, column=1, padx=5, pady=2)

        def confirmar():
            atualizar_selection()
            popup.destroy()
            self.gerar_grafico_csv()

        ttk.Button(frame, text="GERAR", command=confirmar).grid(row=7, column=0, columnspan=2, pady=10)

        atualizar_arquivos()




    def gerar_grafico_csv(self):
        #self.definir_estado_botoes(False)
        nome = self.csv_params["nome_arquivo"].get()
        diretorio = self.csv_params["diretorio"].get()
        caminho = os.path.join(BASE_DIR, "plot", "GenOfSimul", diretorio, nome)
        caminhonew = os.path.join("plot", "GenOfSimul", diretorio)
        parametros, _ = read_vector_csv(caminho)
        parametros["Tolerancia"] = float(parametros["Tolerancia"])
        parametros["S_base"] = float(parametros["S_base"])

        # HabiltAval_Lim_Reativo = 'Y'
        # Desabilitar_CS = 'N'

        Tipo_de_logicaSuplementar_str = self.csv_params["Tipo_de_logicaSuplementar"].get()
        Tipo_de_logicaSuplementar = None if Tipo_de_logicaSuplementar_str == "None" else int(Tipo_de_logicaSuplementar_str)
        ComutacaoMaxima = int(self.csv_params["ComutacaoMaxima"].get())

        PORTS_IN = [nome, caminho]
        num = self.contador_simulacoes
        # print("\n------------------------------------------------------------------------")
        # print("                 INFORMAÇÕES ÚTEIS DO FLUXO DE POTÊNCIA                   ")
        # print("                            Gráfico - CSV                               \n")
        # print("\n[INFO] Parâmetros utilizados:\n" + "-"*40)
        # for chave, valor in parametros.items():
        #     print(f"{chave:<25} : {valor}")
        # print("-"*40 + "\n")

        #p = {k: v.get() for k, v in self.params.items()}

        #print('\n')
        T3="────────────────────────────────────────────────────────────────────────────────"
        print("═" * (len(T3)))
        titulo = f"📉  GRÁFICO GERADO - #CSV #CSV #CSV #CSV #CSV #CSV #CSV #CSV #CSV #CSV #CSV #CSV"
        #T2="                              - lido a partir dos parâmetros da tela principal."
        # if num!=1:
        #     print(T3)
        print(titulo)
        #print(T2)
        print("═" * (len(T3)))
        #print("                              - Gráfico para os parâmetros escolhidos na TELA 1.\n")
        print("=> Gráfico LIDO e gerado a partir da TELA 3.")
        print(f"=> Arquivo: {nome}.")
        print(f"=> Diretório Salvo: {caminhonew}.\n")

        #print("\n🧾  Parâmetros utilizados:\n" + "-"*40)
        
        print("\n🧾  Parâmetros utilizados na TELA 3 para obtenção do caso CSV salvo:")
        # print("\n[INFO] Parâmetros utilizados:\n" + "-"*40)
        for chave, valor in parametros.items():
            print(f"     - {chave:<25} : {valor}")
        #print("-"*40 + "\n")

        print("\n🧾  Parâmetros atualizados para a formação final do gráfico: ")
        print(f"     - Tipo_de_logicaSuplementar: {Tipo_de_logicaSuplementar}")
        print(f"     - ComutacaoMaxima: {ComutacaoMaxima}")
              
        resultado = GoS_generator_EvolutionCurves(
            parametros["SYSname"], parametros["MODELin"], parametros["Tolerancia"], parametros["HabiltAval_Lim_Reativo"],
            parametros["S_base"], parametros["Desabilitar_CS"], Tipo_de_logicaSuplementar, ComutacaoMaxima, 
            parametros["Ativar_inverter"], PORTS_IN, 'yes'
        )
        #DeltaV, _, _, _, infoVctrl, _, _, _, _, *_ , EvolutionMatrixVECTORS, _, _, _ = resultado
        #_ , _ , PotP, PotQ, _ , _ , _ , cont, *_ = resultado
        #DeltaV, _ , PotP, PotQ, infoVctrl, _ , _ , cont, *_ , EvolutionMatrixVECTORS, _, _ = resultado
        DeltaV, _ ,PotP,PotQ, infoVctrl, _ , _ , cont, _ , _ , _ , _ , _ , _ , _ , _ , EvolutionMatrixVECTORS, _ , _ , _ = resultado
        # somaP=0
        # SomaQ=0
        # for k in range (len(PotP)):
        #     somaP=PotP[k]+somaP
        #     SomaQ=PotQ[k]+SomaQ
        # print("Convergido na iteração: ", cont)
        # print("\n********      PERDAS DO SISTEMA:        ********")
        # print("Potência Ativa das Perdas (pu): ", somaP)
        # print("Potência Reativa das Perdas (pu): ", SomaQ)
        # print("************************************************\n")

        somaP=0
        SomaQ=0
        for k in range (len(PotP)):
            somaP=PotP[k]+somaP
            SomaQ=PotQ[k]+SomaQ
        S_aparente = math.sqrt(somaP**2 + SomaQ**2)

        print("\n🔁  Convergido na iteração: ", cont)
        print("\n🔌 Potências de perdas:")
        print("    - Potência Ativa das Perdas (pu): ", round(somaP, 6))
        print("    - Potência Reativa das Perdas (pu): ", round(SomaQ, 6))
        print("    - Potência Aparente Total das Perdas (pu): ", round(S_aparente, 6))

        print(f"\n📄 Barras com controle de tensão perdido:")
        for_filterSOQCAI2 = []
        for aux in range(len(DeltaV)):
            if infoVctrl[0][aux] in ['swing', 'CS', 'G']:
                tensao_controle = infoVctrl[1][aux]
                tensao_final = DeltaV[aux]
                if tensao_final != tensao_controle:
                    barra = aux + 1
                    for_filterSOQCAI2.append(barra)
                    print(f"    🔻 Barra {barra:>3} - Tensão de Controle: {tensao_controle:.4f} pu - Tensão Final: {tensao_final:.4f} pu")
        print(f"    >>> Total de Barras: {len(for_filterSOQCAI2)}")
        if not for_filterSOQCAI2:
            print("\n✅ Nenhuma barra com perda de controle de tensão detectada.")

        print('\n')
        selection = self.csv_params["selection"].get()
        selection_curve = self.csv_params["selection_curve"].get()
        CHOOSE_BAR = self.csv_params["CHOOSE_BAR"].get()
        entrada_00 = [selection_curve, CHOOSE_BAR]
        entrada_01 = [EvolutionMatrixVECTORS, infoVctrl, DeltaV]
        DeltaV_sets, BarrasPV = organiza_e_filtra_DADOS_das_Evolucoes(entrada_00, entrada_01)
        plot_evolution(DeltaV_sets, selection, BarrasPV, None)
        #self.definir_estado_botoes(True)


    def _exibir_matriz_complexa(self, titulo, index):
        self.status.config(text=f"Carregando {titulo}...")
        p = {k: v.get() for k, v in self.params.items()}

        if p["tipoDeSimulacao"] == "Automatico":
            resultado = GoS_generator_FluxoInicial(
                p["SYSname"], p["MODELin"], float(p["Tolerancia"].replace(",", ".")), p["HabiltAval_Lim_Reativo"],
                p["S_base"], p["Desabilitar_CS"], p["Tipo_de_logicaSuplementar"], p["ComutacaoMaxima"],
                p["Ativar_inverter"], p["GirarTrafo"]
            )
        else:
            resultado = GoS_generator_FluxoManual(
                p["SYSname"], p["MODELin"], float(p["Tolerancia"].replace(",", ".")), p["HabiltAval_Lim_Reativo"],
                p["entrad_rodarManual"], p["S_base"], p["Regime_de_CARGA"], p["Desabilitar_CS"],
                p["Tipo_de_logicaSuplementar"], p["ComutacaoMaxima"], p["Ativar_inverter"], p["GirarTrafo"]
            )

        matriz = resultado[index]
        self._mostrar_matriz_em_janela(matriz, titulo)


    def _mostrar_matriz_em_janela(self, matriz, titulo):
        self.definir_estado_botoes(False)
        top = tk.Toplevel(self.root)
        top.title(titulo)
        centralizar_janela(top, 1000, 600)  # janela mais larga para facilitar

        frame = ttk.Frame(top, padding=10)
        frame.pack(fill="both", expand=True)

        cols = list(range(len(matriz[0])))
        tree = ttk.Treeview(frame, columns=cols, show="headings")

        for i in cols:
            tree.heading(i, text=f"Col {i+1}")
            tree.column(i, anchor="center", width=100, stretch=False)

        for row in matriz:
            linha = [
                f"{v.real:.4f}{'+' if v.imag >= 0 else '-'}{abs(v.imag):.4f}j" if isinstance(v, complex) else str(v)
                for v in row
            ]
            tree.insert("", "end", values=linha)

        # Scrollbars
        yscroll = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        xscroll = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)

        tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")

        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)

        self.janelas_matrizes.append(top)
        self.definir_estado_botoes(True)


    def adicionar_tooltip(self, widget, texto):
        tooltip = tk.Toplevel(widget)
        tooltip.withdraw()
        tooltip.overrideredirect(True)
        tooltip_label = tk.Label(tooltip, text=texto, justify='left',
                                background="#ffffe0", relief='solid', borderwidth=1,
                                wraplength=300, font=("Segoe UI", 7))
        tooltip_label.pack(ipadx=1)

        def mostrar_tooltip(event):
            x = event.x_root + 10
            y = event.y_root + 10
            tooltip.geometry(f"+{x}+{y}")
            tooltip.deiconify()

        def esconder_tooltip(event):
            tooltip.withdraw()

        widget.bind("<Enter>", mostrar_tooltip)
        widget.bind("<Leave>", esconder_tooltip)




# class TabelaPopup:
#     def __init__(self, titulo, cabecalhos, dados, master=None):
#         self.top = tk.Toplevel()
#         self.top.title(titulo)

#         frame = ttk.Frame(self.top, padding=10)
#         frame.pack(fill="both", expand=True)

#         tree = ttk.Treeview(frame, columns=cabecalhos, show="headings")
#         for col in cabecalhos:
#             tree.heading(col, text=col)
#             tree.column(col, anchor="center", width=80)

#         for row in dados:
#             row_formatado = [f"{x:.4f}" if isinstance(x, float) else x for x in row]
#             tree.insert("", "end", values=row_formatado)

#         tree.pack(fill="both", expand=True)
#         scrollbar = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
#         tree.configure(yscrollcommand=scrollbar.set)
#         scrollbar.pack(side="right", fill="y")

#         # ✅ Registra a janela se master for instância da classe TelaWebLike
#         if master and hasattr(master, 'janelas_listas'):
#             master.janelas_listas.append(self.top)


class TabelaPopup:
    def __init__(self, titulo, cabecalhos, dados, master=None):
        self.top = tk.Toplevel()
        self.top.title(titulo)

        frame = ttk.Frame(self.top, padding=10)
        frame.pack(fill="both", expand=True)

        # 🔁 Frame interno para Treeview + Scrollbar
        tree_frame = ttk.Frame(frame)
        tree_frame.pack(fill="both", expand=True)

        # Scrollbar associada
        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical")
        scrollbar.pack(side="right", fill="y")

        # Treeview configurado
        tree = ttk.Treeview(tree_frame, columns=cabecalhos, show="headings", yscrollcommand=scrollbar.set)
        for col in cabecalhos:
            tree.heading(col, text=col)
            tree.column(col, anchor="center", width=80)

        for row in dados:
            row_formatado = [f"{x:.4f}" if isinstance(x, float) else x for x in row]
            tree.insert("", "end", values=row_formatado)

        tree.pack(side="left", fill="both", expand=True)

        # Conectando scrollbar à Treeview
        scrollbar.config(command=tree.yview)

        # ✅ Registrar janela se necessário
        if master and hasattr(master, 'janelas_listas'):
            master.janelas_listas.append(self.top)








# if __name__ == "__main__":
#     # 🔹 Chama extração automática dos recursos embutidos
#     extrair_recursos_embutidos()

#     # 🔹 Ajusta o diretório base corretamente
#     BASE_DIR = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.dirname(__file__)
#     os.chdir(BASE_DIR)  # garante que os caminhos relativos funcionem mesmo em .exe

#     def on_closing():
#         root.quit()
#         root.destroy()
#         for manager in _pylab_helpers.Gcf.get_all_fig_managers():
#             fig = manager.canvas.figure
#             if plt.fignum_exists(fig.number):
#                 plt.close(fig)

#     root = tk.Tk()
#     app = TelaWebLike(root)
#     root.protocol("WM_DELETE_WINDOW", on_closing)
#     root.mainloop()







if __name__ == "__main__":
    # ── Passo 3 – Tk raiz e splash ──────────────────────────────────────
    root = tk.Tk()
    root.withdraw()                        # esconde janela principal
    splash = mostrar_splash_temporario(root)

    # ── Passo 1 – extrai e verifica antes do splash ─────────────────────
    extrair_recursos_embutidos()
    verificar_bibliotecas()
    # verificar_e_criar_pastas()  # se/quando precisar

    # ── Passo 2 – contexto de diretório base ────────────────────────────
    BASE_DIR = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.dirname(__file__)
    os.chdir(BASE_DIR)

    # ── Fechamento seguro ───────────────────────────────────────────────
    def on_closing():
        root.quit()
        root.destroy()
        # fecha figuras Matplotlib se houver
        for manager in _pylab_helpers.Gcf.get_all_fig_managers():
            fig = manager.canvas.figure
            if plt.fignum_exists(fig.number):
                plt.close(fig)

    # ── Passo 4 – cria a UI principal depois de alguns segundos ─────────
    def iniciar_interface():
        splash.destroy()
        app = TelaWebLike(root)            # sua classe da TELA 1
        root.protocol("WM_DELETE_WINDOW", on_closing)
        root.deiconify()                   # mostra janela principal

    # 3 – 4 s de splash antes de abrir a interface
    root.after(3500, iniciar_interface)
    root.mainloop()






