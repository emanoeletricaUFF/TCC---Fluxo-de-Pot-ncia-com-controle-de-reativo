===================================================================================================

❓❓❓❓❓❓❓❓❓❓❓ HELP - GoSimul (Gerador de Simulações) ❓❓❓❓❓❓❓❓❓❓❓

===================================================================================================



📘📘📘📘📘📘📘📘📘📘📘📘📘📘📘PARÂMETROS DE ENTRADA 📘📘📘📘📘📘📘📘📘📘📘📘📘📘



>>> PARÂMETROS DO SISTEMA (EXEMPLOS TESTES):

1  Arquivo CDF          : "ieee9\_Marcelo.cdf", "ieee14.cdf", "ieee30.cdf", "ieee118.cdf"

2  Modelo de Linha      : "PI", "T"

3  Tolerância (pu)      : 0.0001 (ou similar)

4  S base (MVA)         : 100    (ou similar)

5  Inverter TAP         : "no", "yes"

6  Girar Trafo          : "no", "yes"

7  Avaliar Lim. Reativo : "N", "Y"

8  Desabilitar CS       : "N", "Y"

9  Lógica Suplementar   : 0, 1, 2 

10 Comutação Máx.       : I onde I pertence ao conjunto dos inteiros.



>>> PARÂMETROS DO ESTUDO (EXEMPLOS TESTES):

11 Tipo de Simulação : "Automático", "Manual" 

12 Modificar Manual  : 1-5\*100\_7\*85 

13 Regime de Carga   : "pesado", "leve"









💡💡💡💡💡💡💡💡💡💡💡💡💡 SOBRE OS PARÂMETROS DE ENTRADA  💡💡💡💡💡💡💡💡💡💡💡💡



1 	"Arquivo CDF" 	     - 	 Tanto pode selecionar item da lista suspensa quanto selecionar 

&nbsp;				 outros arquivos CDF de qualquer outro diretório. Para utilizar a

&nbsp;				 a lista suspensa, certifique-se de manter os quatro arquivos testes 

&nbsp;		      	  	 na pasta do executável. 



2 	"Modelo de Linha"    - 	 Resulta em pouca mudança nas tensões e ângulos, entretanto para

&nbsp;				 a maioria dos casos, o modelo PI se demonstrou mais adequado.



3 	"Tolerância (pu) "   - 	 Tolerância deve ser preenchida de acordo com a precisão em pu

&nbsp;				 que se deseja para o "mismatch" de potência.



4 	 "S base (MVA) "     - 	 Potência base. Geralmente dotado como 100MVA.





5        "Inverter TAP"      -   "yes" para ieee14.cdf e ieee30.cdf.

&nbsp;		                 "no" para ieee9\_Marcelo e ieee118.cdf.



6        "Girar Trafo        -   "yes" apenas para ieee118.cdf.

&nbsp;				 "no" para ieee9\_Marcelo, ieee14.cdf e ieee30.cdf.



7    "Avaliar Lim. Reativo"  -   Possibilita seguir como se todas as barras tivessem controle por

&nbsp;				 há qualquer cenário de carga.



8      "Desabilitar CS"      -   Possibilita desabilitar a geração de reativa transformando-as em

&nbsp;				 barras de carga.



9    "Lógica Suplementar"    -   Detectar alternância excessiva PV ↔ PQ e interromper a fórceps. 

&nbsp;				 A aplicação de lógica suplementar é efetiva quando se há barras de 

&nbsp;				 "difíceis identificação" e é especialmente correlacionado aos 

&nbsp;				 limites operativos das unidades geradoras bem como ao perfil de

&nbsp;				 tensão do sistema como um todo.



10     "Comutação Máx."      -   Numero máximo de alternância entre PV ↔ PQ permitida.

&nbsp;				 (Apenas se a lógica suplementar for 1 ou 2.)



11    "Tipo de Simulação"    -   "Automático" roda todo o conteúdo gravado no CDF.

&nbsp;				 "Manual" permite modificar as potências ativas do carregamento:



12     "Modificar Manual"     -   No exemplo, 1-5\*100\_7\*85, significa 100% de alteração nas barras 

&nbsp;				 de 1 a 5 e 85% de alteração na barra 7.



13    "Regime de carga"      -   Seleciona o tipo de modificação que se almeja:

&nbsp;				 peado liga carga ativa, leve desliga.









💡💡💡💡💡💡💡💡💡💡💡💡💡💡💡💡 SOBRE OS BOTÕES  💡💡💡💡💡💡💡💡💡💡💡💡💡💡💡



--> Executar Estudo   : 1 - Permite calcular o fluxo de potência do "Arquivo CDF" selecionado.

&nbsp;		        2 - Retorna uma tabela com o resumo do fluxo rodado além de imprimir

&nbsp;			    no terminal alguns dados básicos do estudo.



--> Gerar Gráfico     : 1 - Permite mostrar os gráficos com os dados evolutivos de Tensão, Ângulo, 

&nbsp;			    "mismatch" de potência ativa P, "mismatch" de potência reatava Q ao 

&nbsp;			    longo das iterações ("cont") do cálculo do fluxo de potência.

&nbsp;			2 - É possível realizar filtragens das barras a ser visualizadas no gráfico

&nbsp;			    através das telas de seleção de parâmetros. Inclui-se nas filtragens 

&nbsp;			    possíveis a possibilidade de se mostrar apenas barras PQ, apenas as 

&nbsp;			    barras PV, Todas, apenas as que perdem controle, e por fim se pode 

&nbsp;			    selecionar qual barra se deseja (ex. permitido "1-5\_7"). 	     

&nbsp;			   

--> Matriz Y          : Permite visualizar a matriz de Admitâncias do sistema.

 			- coletado a partir dos parâmetros indicados na TELA 1.



--> Jacobiana Inicial : Permite visualizar a matriz Jacobiana da 1º iteração 

&nbsp;			- coletado a partir dos parâmetros indicados na TELA 1.



--> Jacobiana Final   : Permite visualizar a matriz Jacobiana da ultima iteração.

 			- coletado a partir dos parâmetros indicados na TELA 1.



--> Limpar	      : Fecha todas as figuras e tabelas abertas e limpa o terminal.

 			- coletado a partir dos parâmetros indicados na TELA 1.











💡💡💡💡💡💡💡💡💡💡💡💡💡💡💡💡💡 NOTAS GERAIS  💡💡💡💡💡💡💡💡💡💡💡💡💡💡💡



1 - Caso o estudo selecionado em "Arquivo CDF" seja um dos arquivos testes, 

&nbsp;   o GoSimul autoajusta para os padrões do estudo automaticamente. Entretanto

&nbsp;   É NECESSÁRIO, garantir que os arquivos CDF básicos estejam na mesma pasta 

&nbsp;   de execução do simulador. O .exe visa empacotar todos os arquivos em um

&nbsp;   único executável de modo que as aplicações sejam plenamente funcionais

&nbsp;   desde que sejam instaladas as adequadas bibliotecas.



2 - O simulador só permite a execução se todos os campos estiverem 

&nbsp;   preenchidos. Entretanto, isto NÃO GARANTE que não haja erros de 

&nbsp;   preenchimento. É necessário pleno conhecimento do sistema a ser 

&nbsp;   estudado e o correto preenchimento do arquivo CSV bem como seleção 

&nbsp;   adequada de parâmetros. O botão "executar" mantém histórico de 

&nbsp;   estudos, impedindo que um mesmo estudo seja rodado duas vezes 

&nbsp;   ao menos durante a execução continua do GoSimul ou até que se aperte 

&nbsp;   o botão "Limpar". O nome da tabela resultado está de acordo com a 

&nbsp;   simulação impressa no terminal facilitando as análises.



3 - O botão gerar gráfico imediatamente leva a uma tela de seleção onde pode-se

&nbsp;   escolher se deseja montar a evolução da convergência do fluxo de potência 

&nbsp;   do "Arquivo CDF" selecionado na tela principal, ou se deseja avaliar os 

&nbsp;   arquivos CSV gerados pelo estudo da TELA 3 ("Abnormal" e "Divergencies").

&nbsp;   Abnormal e "Divergencies" são pastas de arquivos criadas pela TELA 3

&nbsp;   dentro da "plot" da TELA 1, pois apesar de não serem arquivos CDF,

&nbsp;   estes arquivos contém instruções que levam a construção dos gráficos 

&nbsp;   evolutivos para fluxos mal condicionado (Abnormal) ou divergidos (Divergencies)

&nbsp;   encontrados somente na execução do outro estudo (vide o help da TELA 3).

&nbsp;   É conveniente a adoção neste momento de novos parâmetros como a Lógica 

&nbsp;   Suplementar e quantidade de comutação máxima para observar a efetividade 

&nbsp;   do controle - especialmente a lógica suplementar 1 que se mostra mais efetiva

&nbsp;   em restaurar o equilíbrio. É importante salientar que a adoção de uma 

&nbsp;   Lógica Suplementar para retomar o controle não é efetiva para todos os casos de

&nbsp;   fluxos mal condicionados especialmente para situações muito próximas ao 

&nbsp;   colapso de tensão.























